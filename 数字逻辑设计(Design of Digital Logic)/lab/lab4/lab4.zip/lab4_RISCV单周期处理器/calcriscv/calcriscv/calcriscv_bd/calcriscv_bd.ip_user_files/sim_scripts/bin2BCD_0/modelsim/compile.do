vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -incr -sv \
"../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/bin2bcd.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/sim/bin2BCD_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

