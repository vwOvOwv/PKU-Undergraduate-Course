onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib BCD2bin_0_opt

do {wave.do}

view wave
view structure
view signals

do {BCD2bin_0.udo}

run -all

quit -force
