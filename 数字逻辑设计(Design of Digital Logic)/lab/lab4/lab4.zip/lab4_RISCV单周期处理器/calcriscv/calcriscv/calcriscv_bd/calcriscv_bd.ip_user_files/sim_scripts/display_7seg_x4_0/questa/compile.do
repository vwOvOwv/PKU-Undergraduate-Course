vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xil_defaultlib

vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -sv \
"../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/sim/display_7seg_x4_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

