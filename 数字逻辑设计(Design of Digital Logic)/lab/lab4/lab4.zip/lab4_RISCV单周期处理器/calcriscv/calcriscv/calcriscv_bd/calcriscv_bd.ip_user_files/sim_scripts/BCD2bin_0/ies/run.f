-makelib ies_lib/xil_defaultlib -sv \
  "../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/bcd2bin.sv" \
  "../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/sim/BCD2bin_0.sv" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib

