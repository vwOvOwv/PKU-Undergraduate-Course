-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:23:13 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top singleriscv_bd_regfile_0_0 -prefix
--               singleriscv_bd_regfile_0_0_ singleriscv_bd_regfile_0_0_stub.vhdl
-- Design      : singleriscv_bd_regfile_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity singleriscv_bd_regfile_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    we3 : in STD_LOGIC;
    a1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    a2 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    a3 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    wd3 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rd1 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rd2 : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end singleriscv_bd_regfile_0_0;

architecture stub of singleriscv_bd_regfile_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,we3,a1[4:0],a2[4:0],a3[4:0],wd3[31:0],rd1[31:0],rd2[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "regfile,Vivado 2020.2";
begin
end;
