vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xil_defaultlib
vlib questa_lib/msim/xlslice_v1_0_2
vlib questa_lib/msim/xlconstant_v1_1_7
vlib questa_lib/msim/dist_mem_gen_v8_0_13

vmap xil_defaultlib questa_lib/msim/xil_defaultlib
vmap xlslice_v1_0_2 questa_lib/msim/xlslice_v1_0_2
vmap xlconstant_v1_1_7 questa_lib/msim/xlconstant_v1_1_7
vmap dist_mem_gen_v8_0_13 questa_lib/msim/dist_mem_gen_v8_0_13

vlog -work xil_defaultlib  -sv \
"../../../bd/singleriscv_bd/ipshared/fe38/src/regfile.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_regfile_0_0/sim/singleriscv_bd_regfile_0_0.sv" \

vlog -work xlslice_v1_0_2  \
"../../../../calcriscv_bd.gen/sources_1/bd/singleriscv_bd/ipshared/11d0/hdl/xlslice_v1_0_vl_rfs.v" \

vlog -work xil_defaultlib  \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_0/sim/singleriscv_bd_xlslice_0_0.v" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_1/sim/singleriscv_bd_xlslice_0_1.v" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_2/sim/singleriscv_bd_xlslice_0_2.v" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_3/sim/singleriscv_bd_xlslice_0_3.v" \

vlog -work xil_defaultlib  -sv \
"../../../bd/singleriscv_bd/ipshared/442f/src/extend.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_extend_0_0/sim/singleriscv_bd_extend_0_0.sv" \

vlog -work xil_defaultlib  \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_5/sim/singleriscv_bd_xlslice_0_5.v" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_6/sim/singleriscv_bd_xlslice_0_6.v" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_1_0/sim/singleriscv_bd_xlslice_1_0.v" \

vlog -work xil_defaultlib  -sv \
"../../../bd/singleriscv_bd/ipshared/dd7c/src/alu.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_alu_0_0/sim/singleriscv_bd_alu_0_0.sv" \
"../../../bd/singleriscv_bd/ipshared/c022/src/adder.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_adder_0_0/sim/singleriscv_bd_adder_0_0.sv" \

vlog -work xlconstant_v1_1_7  \
"../../../../calcriscv_bd.gen/sources_1/bd/singleriscv_bd/ipshared/fcfc/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work xil_defaultlib  \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlconstant_0_0/sim/singleriscv_bd_xlconstant_0_0.v" \

vlog -work xil_defaultlib  -sv \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_adder_0_1/sim/singleriscv_bd_adder_0_1.sv" \
"../../../bd/singleriscv_bd/ipshared/c246/src/flopr.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_flopr_0_0/sim/singleriscv_bd_flopr_0_0.sv" \
"../../../bd/singleriscv_bd/ipshared/ab1c/src/mux2.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux2_0_0/sim/singleriscv_bd_mux2_0_0.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux2_0_1/sim/singleriscv_bd_mux2_0_1.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux2_0_2/sim/singleriscv_bd_mux2_0_2.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux2_0_3/sim/singleriscv_bd_mux2_0_3.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux2_0_4/sim/singleriscv_bd_mux2_0_4.sv" \
"../../../bd/singleriscv_bd/ipshared/cce5/src/mux3.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_mux3_0_0/sim/singleriscv_bd_mux3_0_0.sv" \

vlog -work xil_defaultlib  \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_xlslice_0_7/sim/singleriscv_bd_xlslice_0_7.v" \

vlog -work xil_defaultlib  -sv \
"../../../bd/singleriscv_bd/ipshared/c0a1/src/dmem_io.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_dmem_io_0_0/sim/singleriscv_bd_dmem_io_0_0.sv" \
"../../../bd/singleriscv_bd/ipshared/49e3/src/controller.sv" \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_controller_0_0/sim/singleriscv_bd_controller_0_0.sv" \

vlog -work dist_mem_gen_v8_0_13  \
"../../../../calcriscv_bd.gen/sources_1/bd/singleriscv_bd/ipshared/0bf5/simulation/dist_mem_gen_v8_0.v" \

vlog -work xil_defaultlib  \
"../../../bd/singleriscv_bd/ip/singleriscv_bd_dist_mem_gen_0_3/sim/singleriscv_bd_dist_mem_gen_0_3.v" \
"../../../bd/singleriscv_bd/sim/singleriscv_bd.v" \

vlog -work xil_defaultlib \
"glbl.v"

