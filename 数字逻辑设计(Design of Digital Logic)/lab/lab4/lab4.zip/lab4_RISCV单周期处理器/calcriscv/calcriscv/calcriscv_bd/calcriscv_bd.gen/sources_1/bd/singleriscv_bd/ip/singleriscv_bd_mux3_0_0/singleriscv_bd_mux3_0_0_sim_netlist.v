// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:26:22 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top singleriscv_bd_mux3_0_0 -prefix
//               singleriscv_bd_mux3_0_0_ singleriscv_bd_mux3_0_0_sim_netlist.v
// Design      : singleriscv_bd_mux3_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module singleriscv_bd_mux3_0_0_mux3
   (y,
    d2,
    s,
    d1,
    d0);
  output [31:0]y;
  input [31:0]d2;
  input [1:0]s;
  input [31:0]d1;
  input [31:0]d0;

  wire [31:0]d0;
  wire [31:0]d1;
  wire [31:0]d2;
  wire [1:0]s;
  wire [31:0]y;

  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[0]_INST_0 
       (.I0(d2[0]),
        .I1(s[1]),
        .I2(d1[0]),
        .I3(s[0]),
        .I4(d0[0]),
        .O(y[0]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[10]_INST_0 
       (.I0(d2[10]),
        .I1(s[1]),
        .I2(d1[10]),
        .I3(s[0]),
        .I4(d0[10]),
        .O(y[10]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[11]_INST_0 
       (.I0(d2[11]),
        .I1(s[1]),
        .I2(d1[11]),
        .I3(s[0]),
        .I4(d0[11]),
        .O(y[11]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[12]_INST_0 
       (.I0(d2[12]),
        .I1(s[1]),
        .I2(d1[12]),
        .I3(s[0]),
        .I4(d0[12]),
        .O(y[12]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[13]_INST_0 
       (.I0(d2[13]),
        .I1(s[1]),
        .I2(d1[13]),
        .I3(s[0]),
        .I4(d0[13]),
        .O(y[13]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[14]_INST_0 
       (.I0(d2[14]),
        .I1(s[1]),
        .I2(d1[14]),
        .I3(s[0]),
        .I4(d0[14]),
        .O(y[14]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[15]_INST_0 
       (.I0(d2[15]),
        .I1(s[1]),
        .I2(d1[15]),
        .I3(s[0]),
        .I4(d0[15]),
        .O(y[15]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[16]_INST_0 
       (.I0(d2[16]),
        .I1(s[1]),
        .I2(d1[16]),
        .I3(s[0]),
        .I4(d0[16]),
        .O(y[16]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[17]_INST_0 
       (.I0(d2[17]),
        .I1(s[1]),
        .I2(d1[17]),
        .I3(s[0]),
        .I4(d0[17]),
        .O(y[17]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[18]_INST_0 
       (.I0(d2[18]),
        .I1(s[1]),
        .I2(d1[18]),
        .I3(s[0]),
        .I4(d0[18]),
        .O(y[18]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[19]_INST_0 
       (.I0(d2[19]),
        .I1(s[1]),
        .I2(d1[19]),
        .I3(s[0]),
        .I4(d0[19]),
        .O(y[19]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[1]_INST_0 
       (.I0(d2[1]),
        .I1(s[1]),
        .I2(d1[1]),
        .I3(s[0]),
        .I4(d0[1]),
        .O(y[1]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[20]_INST_0 
       (.I0(d2[20]),
        .I1(s[1]),
        .I2(d1[20]),
        .I3(s[0]),
        .I4(d0[20]),
        .O(y[20]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[21]_INST_0 
       (.I0(d2[21]),
        .I1(s[1]),
        .I2(d1[21]),
        .I3(s[0]),
        .I4(d0[21]),
        .O(y[21]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[22]_INST_0 
       (.I0(d2[22]),
        .I1(s[1]),
        .I2(d1[22]),
        .I3(s[0]),
        .I4(d0[22]),
        .O(y[22]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[23]_INST_0 
       (.I0(d2[23]),
        .I1(s[1]),
        .I2(d1[23]),
        .I3(s[0]),
        .I4(d0[23]),
        .O(y[23]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[24]_INST_0 
       (.I0(d2[24]),
        .I1(s[1]),
        .I2(d1[24]),
        .I3(s[0]),
        .I4(d0[24]),
        .O(y[24]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[25]_INST_0 
       (.I0(d2[25]),
        .I1(s[1]),
        .I2(d1[25]),
        .I3(s[0]),
        .I4(d0[25]),
        .O(y[25]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[26]_INST_0 
       (.I0(d2[26]),
        .I1(s[1]),
        .I2(d1[26]),
        .I3(s[0]),
        .I4(d0[26]),
        .O(y[26]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[27]_INST_0 
       (.I0(d2[27]),
        .I1(s[1]),
        .I2(d1[27]),
        .I3(s[0]),
        .I4(d0[27]),
        .O(y[27]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[28]_INST_0 
       (.I0(d2[28]),
        .I1(s[1]),
        .I2(d1[28]),
        .I3(s[0]),
        .I4(d0[28]),
        .O(y[28]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[29]_INST_0 
       (.I0(d2[29]),
        .I1(s[1]),
        .I2(d1[29]),
        .I3(s[0]),
        .I4(d0[29]),
        .O(y[29]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[2]_INST_0 
       (.I0(d2[2]),
        .I1(s[1]),
        .I2(d1[2]),
        .I3(s[0]),
        .I4(d0[2]),
        .O(y[2]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[30]_INST_0 
       (.I0(d2[30]),
        .I1(s[1]),
        .I2(d1[30]),
        .I3(s[0]),
        .I4(d0[30]),
        .O(y[30]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[31]_INST_0 
       (.I0(d2[31]),
        .I1(s[1]),
        .I2(d1[31]),
        .I3(s[0]),
        .I4(d0[31]),
        .O(y[31]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[3]_INST_0 
       (.I0(d2[3]),
        .I1(s[1]),
        .I2(d1[3]),
        .I3(s[0]),
        .I4(d0[3]),
        .O(y[3]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[4]_INST_0 
       (.I0(d2[4]),
        .I1(s[1]),
        .I2(d1[4]),
        .I3(s[0]),
        .I4(d0[4]),
        .O(y[4]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[5]_INST_0 
       (.I0(d2[5]),
        .I1(s[1]),
        .I2(d1[5]),
        .I3(s[0]),
        .I4(d0[5]),
        .O(y[5]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[6]_INST_0 
       (.I0(d2[6]),
        .I1(s[1]),
        .I2(d1[6]),
        .I3(s[0]),
        .I4(d0[6]),
        .O(y[6]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[7]_INST_0 
       (.I0(d2[7]),
        .I1(s[1]),
        .I2(d1[7]),
        .I3(s[0]),
        .I4(d0[7]),
        .O(y[7]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[8]_INST_0 
       (.I0(d2[8]),
        .I1(s[1]),
        .I2(d1[8]),
        .I3(s[0]),
        .I4(d0[8]),
        .O(y[8]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \y[9]_INST_0 
       (.I0(d2[9]),
        .I1(s[1]),
        .I2(d1[9]),
        .I3(s[0]),
        .I4(d0[9]),
        .O(y[9]));
endmodule

(* CHECK_LICENSE_TYPE = "singleriscv_bd_mux3_0_0,mux3,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "mux3,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module singleriscv_bd_mux3_0_0
   (d0,
    d1,
    d2,
    s,
    y);
  input [31:0]d0;
  input [31:0]d1;
  input [31:0]d2;
  input [1:0]s;
  output [31:0]y;

  wire [31:0]d0;
  wire [31:0]d1;
  wire [31:0]d2;
  wire [1:0]s;
  wire [31:0]y;

  singleriscv_bd_mux3_0_0_mux3 inst
       (.d0(d0),
        .d1(d1),
        .d2(d2),
        .s(s),
        .y(y));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
