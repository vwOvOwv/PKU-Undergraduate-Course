vopt +acc=npr -l elaborate.log -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.bin2BCD_0 xil_defaultlib.glbl -o bin2BCD_0_opt
