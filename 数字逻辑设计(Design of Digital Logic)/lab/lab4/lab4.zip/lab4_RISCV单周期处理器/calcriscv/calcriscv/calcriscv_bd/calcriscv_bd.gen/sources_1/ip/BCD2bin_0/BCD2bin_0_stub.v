// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:20:31 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/BCD2bin_0/BCD2bin_0_stub.v
// Design      : BCD2bin_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "BCD2bin,Vivado 2020.2" *)
module BCD2bin_0(bcd3, bcd2, bcd1, bcd0, bin)
/* synthesis syn_black_box black_box_pad_pin="bcd3[3:0],bcd2[3:0],bcd1[3:0],bcd0[3:0],bin[13:0]" */;
  input [3:0]bcd3;
  input [3:0]bcd2;
  input [3:0]bcd1;
  input [3:0]bcd0;
  output [13:0]bin;
endmodule
