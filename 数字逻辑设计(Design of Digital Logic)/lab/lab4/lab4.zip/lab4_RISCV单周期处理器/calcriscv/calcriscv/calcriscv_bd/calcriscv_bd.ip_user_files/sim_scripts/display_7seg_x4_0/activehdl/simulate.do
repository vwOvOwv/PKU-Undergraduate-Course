onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+display_7seg_x4_0 -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.display_7seg_x4_0 xil_defaultlib.glbl

do {wave.do}

view wave
view structure

do {display_7seg_x4_0.udo}

run -all

endsim

quit -force
