-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:27:20 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top singleriscv_bd_controller_0_0 -prefix
--               singleriscv_bd_controller_0_0_ singleriscv_bd_controller_0_0_stub.vhdl
-- Design      : singleriscv_bd_controller_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity singleriscv_bd_controller_0_0 is
  Port ( 
    op : in STD_LOGIC_VECTOR ( 6 downto 0 );
    funct3 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    funct7b5 : in STD_LOGIC;
    zero : in STD_LOGIC;
    lessthan : in STD_LOGIC;
    ResultSrc : out STD_LOGIC_VECTOR ( 1 downto 0 );
    MemWrite : out STD_LOGIC;
    PCSrc : out STD_LOGIC;
    ALUSrc : out STD_LOGIC;
    RegWrite : out STD_LOGIC;
    Jump : out STD_LOGIC;
    JumpR : out STD_LOGIC;
    UType : out STD_LOGIC;
    AUIPC : out STD_LOGIC;
    ImmSrc : out STD_LOGIC_VECTOR ( 1 downto 0 );
    ALUControl : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );

end singleriscv_bd_controller_0_0;

architecture stub of singleriscv_bd_controller_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "op[6:0],funct3[2:0],funct7b5,zero,lessthan,ResultSrc[1:0],MemWrite,PCSrc,ALUSrc,RegWrite,Jump,JumpR,UType,AUIPC,ImmSrc[1:0],ALUControl[3:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "controller,Vivado 2020.2";
begin
end;
