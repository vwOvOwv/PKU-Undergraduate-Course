-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:27:17 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top singleriscv_bd_dmem_io_0_0 -prefix
--               singleriscv_bd_dmem_io_0_0_ singleriscv_bd_dmem_io_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_dmem_io_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_dmem_io_0_0_dmem_io is
  port (
    ReadData : out STD_LOGIC_VECTOR ( 31 downto 0 );
    PortC : out STD_LOGIC_VECTOR ( 13 downto 0 );
    PortD : out STD_LOGIC_VECTOR ( 15 downto 0 );
    DataAddr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    MemWrite : in STD_LOGIC;
    reset : in STD_LOGIC;
    WriteData : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clk : in STD_LOGIC;
    PortB : in STD_LOGIC_VECTOR ( 13 downto 0 );
    PortA : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
end singleriscv_bd_dmem_io_0_0_dmem_io;

architecture STRUCTURE of singleriscv_bd_dmem_io_0_0_dmem_io is
  signal \^portc\ : STD_LOGIC_VECTOR ( 13 downto 0 );
  signal PortC0 : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[14]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[15]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[16]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[17]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[18]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[19]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[20]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[21]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[22]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[23]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[24]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[25]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[26]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[27]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[28]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[29]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[30]\ : STD_LOGIC;
  signal \PortC_reg_reg_n_0_[31]\ : STD_LOGIC;
  signal \^portd\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal PortD0 : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[16]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[17]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[18]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[19]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[20]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[21]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[22]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[23]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[24]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[25]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[26]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[27]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[28]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[29]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[30]\ : STD_LOGIC;
  signal \PortD_reg_reg_n_0_[31]\ : STD_LOGIC;
  signal ReadDataRAM : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \ReadData_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[11]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[13]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[13]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[13]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[13]_i_4_n_0\ : STD_LOGIC;
  signal \ReadData_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[17]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[18]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[1]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[1]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[21]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[22]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[24]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[25]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[26]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[27]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[28]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[29]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[2]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[30]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_10_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_11_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_12_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_13_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_14_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_15_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_16_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_4_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_5_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_6_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_7_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_8_n_0\ : STD_LOGIC;
  signal \ReadData_reg[31]_i_9_n_0\ : STD_LOGIC;
  signal \ReadData_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \ReadData_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[7]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \ReadData_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal \ReadData_reg[9]_i_2_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of RAM_reg_0_63_0_0 : label is 2048;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of RAM_reg_0_63_0_0 : label is "inst/RAM";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of RAM_reg_0_63_0_0 : label is "RAM_SP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of RAM_reg_0_63_0_0 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of RAM_reg_0_63_0_0 : label is 63;
  attribute ram_offset : integer;
  attribute ram_offset of RAM_reg_0_63_0_0 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of RAM_reg_0_63_0_0 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of RAM_reg_0_63_0_0 : label is 0;
  attribute RTL_RAM_BITS of RAM_reg_0_63_10_10 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_10_10 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_10_10 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_10_10 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_10_10 : label is 63;
  attribute ram_offset of RAM_reg_0_63_10_10 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_10_10 : label is 10;
  attribute ram_slice_end of RAM_reg_0_63_10_10 : label is 10;
  attribute RTL_RAM_BITS of RAM_reg_0_63_11_11 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_11_11 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_11_11 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_11_11 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_11_11 : label is 63;
  attribute ram_offset of RAM_reg_0_63_11_11 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_11_11 : label is 11;
  attribute ram_slice_end of RAM_reg_0_63_11_11 : label is 11;
  attribute RTL_RAM_BITS of RAM_reg_0_63_12_12 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_12_12 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_12_12 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_12_12 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_12_12 : label is 63;
  attribute ram_offset of RAM_reg_0_63_12_12 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_12_12 : label is 12;
  attribute ram_slice_end of RAM_reg_0_63_12_12 : label is 12;
  attribute RTL_RAM_BITS of RAM_reg_0_63_13_13 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_13_13 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_13_13 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_13_13 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_13_13 : label is 63;
  attribute ram_offset of RAM_reg_0_63_13_13 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_13_13 : label is 13;
  attribute ram_slice_end of RAM_reg_0_63_13_13 : label is 13;
  attribute RTL_RAM_BITS of RAM_reg_0_63_14_14 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_14_14 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_14_14 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_14_14 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_14_14 : label is 63;
  attribute ram_offset of RAM_reg_0_63_14_14 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_14_14 : label is 14;
  attribute ram_slice_end of RAM_reg_0_63_14_14 : label is 14;
  attribute RTL_RAM_BITS of RAM_reg_0_63_15_15 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_15_15 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_15_15 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_15_15 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_15_15 : label is 63;
  attribute ram_offset of RAM_reg_0_63_15_15 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_15_15 : label is 15;
  attribute ram_slice_end of RAM_reg_0_63_15_15 : label is 15;
  attribute RTL_RAM_BITS of RAM_reg_0_63_16_16 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_16_16 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_16_16 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_16_16 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_16_16 : label is 63;
  attribute ram_offset of RAM_reg_0_63_16_16 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_16_16 : label is 16;
  attribute ram_slice_end of RAM_reg_0_63_16_16 : label is 16;
  attribute RTL_RAM_BITS of RAM_reg_0_63_17_17 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_17_17 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_17_17 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_17_17 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_17_17 : label is 63;
  attribute ram_offset of RAM_reg_0_63_17_17 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_17_17 : label is 17;
  attribute ram_slice_end of RAM_reg_0_63_17_17 : label is 17;
  attribute RTL_RAM_BITS of RAM_reg_0_63_18_18 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_18_18 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_18_18 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_18_18 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_18_18 : label is 63;
  attribute ram_offset of RAM_reg_0_63_18_18 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_18_18 : label is 18;
  attribute ram_slice_end of RAM_reg_0_63_18_18 : label is 18;
  attribute RTL_RAM_BITS of RAM_reg_0_63_19_19 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_19_19 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_19_19 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_19_19 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_19_19 : label is 63;
  attribute ram_offset of RAM_reg_0_63_19_19 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_19_19 : label is 19;
  attribute ram_slice_end of RAM_reg_0_63_19_19 : label is 19;
  attribute RTL_RAM_BITS of RAM_reg_0_63_1_1 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_1_1 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_1_1 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_1_1 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_1_1 : label is 63;
  attribute ram_offset of RAM_reg_0_63_1_1 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_1_1 : label is 1;
  attribute ram_slice_end of RAM_reg_0_63_1_1 : label is 1;
  attribute RTL_RAM_BITS of RAM_reg_0_63_20_20 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_20_20 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_20_20 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_20_20 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_20_20 : label is 63;
  attribute ram_offset of RAM_reg_0_63_20_20 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_20_20 : label is 20;
  attribute ram_slice_end of RAM_reg_0_63_20_20 : label is 20;
  attribute RTL_RAM_BITS of RAM_reg_0_63_21_21 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_21_21 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_21_21 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_21_21 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_21_21 : label is 63;
  attribute ram_offset of RAM_reg_0_63_21_21 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_21_21 : label is 21;
  attribute ram_slice_end of RAM_reg_0_63_21_21 : label is 21;
  attribute RTL_RAM_BITS of RAM_reg_0_63_22_22 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_22_22 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_22_22 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_22_22 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_22_22 : label is 63;
  attribute ram_offset of RAM_reg_0_63_22_22 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_22_22 : label is 22;
  attribute ram_slice_end of RAM_reg_0_63_22_22 : label is 22;
  attribute RTL_RAM_BITS of RAM_reg_0_63_23_23 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_23_23 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_23_23 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_23_23 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_23_23 : label is 63;
  attribute ram_offset of RAM_reg_0_63_23_23 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_23_23 : label is 23;
  attribute ram_slice_end of RAM_reg_0_63_23_23 : label is 23;
  attribute RTL_RAM_BITS of RAM_reg_0_63_24_24 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_24_24 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_24_24 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_24_24 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_24_24 : label is 63;
  attribute ram_offset of RAM_reg_0_63_24_24 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_24_24 : label is 24;
  attribute ram_slice_end of RAM_reg_0_63_24_24 : label is 24;
  attribute RTL_RAM_BITS of RAM_reg_0_63_25_25 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_25_25 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_25_25 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_25_25 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_25_25 : label is 63;
  attribute ram_offset of RAM_reg_0_63_25_25 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_25_25 : label is 25;
  attribute ram_slice_end of RAM_reg_0_63_25_25 : label is 25;
  attribute RTL_RAM_BITS of RAM_reg_0_63_26_26 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_26_26 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_26_26 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_26_26 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_26_26 : label is 63;
  attribute ram_offset of RAM_reg_0_63_26_26 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_26_26 : label is 26;
  attribute ram_slice_end of RAM_reg_0_63_26_26 : label is 26;
  attribute RTL_RAM_BITS of RAM_reg_0_63_27_27 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_27_27 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_27_27 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_27_27 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_27_27 : label is 63;
  attribute ram_offset of RAM_reg_0_63_27_27 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_27_27 : label is 27;
  attribute ram_slice_end of RAM_reg_0_63_27_27 : label is 27;
  attribute RTL_RAM_BITS of RAM_reg_0_63_28_28 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_28_28 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_28_28 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_28_28 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_28_28 : label is 63;
  attribute ram_offset of RAM_reg_0_63_28_28 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_28_28 : label is 28;
  attribute ram_slice_end of RAM_reg_0_63_28_28 : label is 28;
  attribute RTL_RAM_BITS of RAM_reg_0_63_29_29 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_29_29 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_29_29 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_29_29 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_29_29 : label is 63;
  attribute ram_offset of RAM_reg_0_63_29_29 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_29_29 : label is 29;
  attribute ram_slice_end of RAM_reg_0_63_29_29 : label is 29;
  attribute RTL_RAM_BITS of RAM_reg_0_63_2_2 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_2_2 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_2_2 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_2_2 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_2_2 : label is 63;
  attribute ram_offset of RAM_reg_0_63_2_2 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_2_2 : label is 2;
  attribute ram_slice_end of RAM_reg_0_63_2_2 : label is 2;
  attribute RTL_RAM_BITS of RAM_reg_0_63_30_30 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_30_30 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_30_30 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_30_30 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_30_30 : label is 63;
  attribute ram_offset of RAM_reg_0_63_30_30 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_30_30 : label is 30;
  attribute ram_slice_end of RAM_reg_0_63_30_30 : label is 30;
  attribute RTL_RAM_BITS of RAM_reg_0_63_31_31 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_31_31 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_31_31 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_31_31 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_31_31 : label is 63;
  attribute ram_offset of RAM_reg_0_63_31_31 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_31_31 : label is 31;
  attribute ram_slice_end of RAM_reg_0_63_31_31 : label is 31;
  attribute RTL_RAM_BITS of RAM_reg_0_63_3_3 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_3_3 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_3_3 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_3_3 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_3_3 : label is 63;
  attribute ram_offset of RAM_reg_0_63_3_3 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_3_3 : label is 3;
  attribute ram_slice_end of RAM_reg_0_63_3_3 : label is 3;
  attribute RTL_RAM_BITS of RAM_reg_0_63_4_4 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_4_4 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_4_4 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_4_4 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_4_4 : label is 63;
  attribute ram_offset of RAM_reg_0_63_4_4 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_4_4 : label is 4;
  attribute ram_slice_end of RAM_reg_0_63_4_4 : label is 4;
  attribute RTL_RAM_BITS of RAM_reg_0_63_5_5 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_5_5 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_5_5 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_5_5 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_5_5 : label is 63;
  attribute ram_offset of RAM_reg_0_63_5_5 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_5_5 : label is 5;
  attribute ram_slice_end of RAM_reg_0_63_5_5 : label is 5;
  attribute RTL_RAM_BITS of RAM_reg_0_63_6_6 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_6_6 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_6_6 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_6_6 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_6_6 : label is 63;
  attribute ram_offset of RAM_reg_0_63_6_6 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_6_6 : label is 6;
  attribute ram_slice_end of RAM_reg_0_63_6_6 : label is 6;
  attribute RTL_RAM_BITS of RAM_reg_0_63_7_7 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_7_7 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_7_7 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_7_7 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_7_7 : label is 63;
  attribute ram_offset of RAM_reg_0_63_7_7 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_7_7 : label is 7;
  attribute ram_slice_end of RAM_reg_0_63_7_7 : label is 7;
  attribute RTL_RAM_BITS of RAM_reg_0_63_8_8 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_8_8 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_8_8 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_8_8 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_8_8 : label is 63;
  attribute ram_offset of RAM_reg_0_63_8_8 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_8_8 : label is 8;
  attribute ram_slice_end of RAM_reg_0_63_8_8 : label is 8;
  attribute RTL_RAM_BITS of RAM_reg_0_63_9_9 : label is 2048;
  attribute RTL_RAM_NAME of RAM_reg_0_63_9_9 : label is "inst/RAM";
  attribute RTL_RAM_TYPE of RAM_reg_0_63_9_9 : label is "RAM_SP";
  attribute ram_addr_begin of RAM_reg_0_63_9_9 : label is 0;
  attribute ram_addr_end of RAM_reg_0_63_9_9 : label is 63;
  attribute ram_offset of RAM_reg_0_63_9_9 : label is 0;
  attribute ram_slice_begin of RAM_reg_0_63_9_9 : label is 9;
  attribute ram_slice_end of RAM_reg_0_63_9_9 : label is 9;
  attribute XILINX_LEGACY_PRIM : string;
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[0]\ : label is "LD";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \ReadData_reg[0]_i_3\ : label is "soft_lutpair0";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[10]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[11]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[12]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[13]\ : label is "LD";
  attribute SOFT_HLUTNM of \ReadData_reg[13]_i_4\ : label is "soft_lutpair2";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[14]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[15]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[16]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[17]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[18]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[19]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[1]\ : label is "LD";
  attribute SOFT_HLUTNM of \ReadData_reg[1]_i_3\ : label is "soft_lutpair1";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[20]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[21]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[22]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[23]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[24]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[25]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[26]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[27]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[28]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[29]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[2]\ : label is "LD";
  attribute SOFT_HLUTNM of \ReadData_reg[2]_i_3\ : label is "soft_lutpair2";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[30]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[31]\ : label is "LD";
  attribute SOFT_HLUTNM of \ReadData_reg[31]_i_10\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ReadData_reg[31]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \ReadData_reg[31]_i_7\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ReadData_reg[31]_i_9\ : label is "soft_lutpair3";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[3]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[4]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[5]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[6]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[7]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[8]\ : label is "LD";
  attribute XILINX_LEGACY_PRIM of \ReadData_reg[9]\ : label is "LD";
begin
  PortC(13 downto 0) <= \^portc\(13 downto 0);
  PortD(15 downto 0) <= \^portd\(15 downto 0);
\PortC_reg[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => MemWrite,
      O => PortC0
    );
\PortC_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(0),
      Q => \^portc\(0),
      R => reset
    );
\PortC_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(10),
      Q => \^portc\(10),
      R => reset
    );
\PortC_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(11),
      Q => \^portc\(11),
      R => reset
    );
\PortC_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(12),
      Q => \^portc\(12),
      R => reset
    );
\PortC_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(13),
      Q => \^portc\(13),
      R => reset
    );
\PortC_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(14),
      Q => \PortC_reg_reg_n_0_[14]\,
      R => reset
    );
\PortC_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(15),
      Q => \PortC_reg_reg_n_0_[15]\,
      R => reset
    );
\PortC_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(16),
      Q => \PortC_reg_reg_n_0_[16]\,
      R => reset
    );
\PortC_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(17),
      Q => \PortC_reg_reg_n_0_[17]\,
      R => reset
    );
\PortC_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(18),
      Q => \PortC_reg_reg_n_0_[18]\,
      R => reset
    );
\PortC_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(19),
      Q => \PortC_reg_reg_n_0_[19]\,
      R => reset
    );
\PortC_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(1),
      Q => \^portc\(1),
      R => reset
    );
\PortC_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(20),
      Q => \PortC_reg_reg_n_0_[20]\,
      R => reset
    );
\PortC_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(21),
      Q => \PortC_reg_reg_n_0_[21]\,
      R => reset
    );
\PortC_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(22),
      Q => \PortC_reg_reg_n_0_[22]\,
      R => reset
    );
\PortC_reg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(23),
      Q => \PortC_reg_reg_n_0_[23]\,
      R => reset
    );
\PortC_reg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(24),
      Q => \PortC_reg_reg_n_0_[24]\,
      R => reset
    );
\PortC_reg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(25),
      Q => \PortC_reg_reg_n_0_[25]\,
      R => reset
    );
\PortC_reg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(26),
      Q => \PortC_reg_reg_n_0_[26]\,
      R => reset
    );
\PortC_reg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(27),
      Q => \PortC_reg_reg_n_0_[27]\,
      R => reset
    );
\PortC_reg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(28),
      Q => \PortC_reg_reg_n_0_[28]\,
      R => reset
    );
\PortC_reg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(29),
      Q => \PortC_reg_reg_n_0_[29]\,
      R => reset
    );
\PortC_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(2),
      Q => \^portc\(2),
      R => reset
    );
\PortC_reg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(30),
      Q => \PortC_reg_reg_n_0_[30]\,
      R => reset
    );
\PortC_reg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(31),
      Q => \PortC_reg_reg_n_0_[31]\,
      R => reset
    );
\PortC_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(3),
      Q => \^portc\(3),
      R => reset
    );
\PortC_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(4),
      Q => \^portc\(4),
      R => reset
    );
\PortC_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(5),
      Q => \^portc\(5),
      R => reset
    );
\PortC_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(6),
      Q => \^portc\(6),
      R => reset
    );
\PortC_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(7),
      Q => \^portc\(7),
      R => reset
    );
\PortC_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(8),
      Q => \^portc\(8),
      R => reset
    );
\PortC_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortC0,
      D => WriteData(9),
      Q => \^portc\(9),
      R => reset
    );
\PortD_reg[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \ReadData_reg[31]_i_4_n_0\,
      I1 => MemWrite,
      O => PortD0
    );
\PortD_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(0),
      Q => \^portd\(0),
      R => reset
    );
\PortD_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(10),
      Q => \^portd\(10),
      R => reset
    );
\PortD_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(11),
      Q => \^portd\(11),
      R => reset
    );
\PortD_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(12),
      Q => \^portd\(12),
      R => reset
    );
\PortD_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(13),
      Q => \^portd\(13),
      R => reset
    );
\PortD_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(14),
      Q => \^portd\(14),
      R => reset
    );
\PortD_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(15),
      Q => \^portd\(15),
      R => reset
    );
\PortD_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(16),
      Q => \PortD_reg_reg_n_0_[16]\,
      R => reset
    );
\PortD_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(17),
      Q => \PortD_reg_reg_n_0_[17]\,
      R => reset
    );
\PortD_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(18),
      Q => \PortD_reg_reg_n_0_[18]\,
      R => reset
    );
\PortD_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(19),
      Q => \PortD_reg_reg_n_0_[19]\,
      R => reset
    );
\PortD_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(1),
      Q => \^portd\(1),
      R => reset
    );
\PortD_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(20),
      Q => \PortD_reg_reg_n_0_[20]\,
      R => reset
    );
\PortD_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(21),
      Q => \PortD_reg_reg_n_0_[21]\,
      R => reset
    );
\PortD_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(22),
      Q => \PortD_reg_reg_n_0_[22]\,
      R => reset
    );
\PortD_reg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(23),
      Q => \PortD_reg_reg_n_0_[23]\,
      R => reset
    );
\PortD_reg_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(24),
      Q => \PortD_reg_reg_n_0_[24]\,
      R => reset
    );
\PortD_reg_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(25),
      Q => \PortD_reg_reg_n_0_[25]\,
      R => reset
    );
\PortD_reg_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(26),
      Q => \PortD_reg_reg_n_0_[26]\,
      R => reset
    );
\PortD_reg_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(27),
      Q => \PortD_reg_reg_n_0_[27]\,
      R => reset
    );
\PortD_reg_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(28),
      Q => \PortD_reg_reg_n_0_[28]\,
      R => reset
    );
\PortD_reg_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(29),
      Q => \PortD_reg_reg_n_0_[29]\,
      R => reset
    );
\PortD_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(2),
      Q => \^portd\(2),
      R => reset
    );
\PortD_reg_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(30),
      Q => \PortD_reg_reg_n_0_[30]\,
      R => reset
    );
\PortD_reg_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(31),
      Q => \PortD_reg_reg_n_0_[31]\,
      R => reset
    );
\PortD_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(3),
      Q => \^portd\(3),
      R => reset
    );
\PortD_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(4),
      Q => \^portd\(4),
      R => reset
    );
\PortD_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(5),
      Q => \^portd\(5),
      R => reset
    );
\PortD_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(6),
      Q => \^portd\(6),
      R => reset
    );
\PortD_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(7),
      Q => \^portd\(7),
      R => reset
    );
\PortD_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(8),
      Q => \^portd\(8),
      R => reset
    );
\PortD_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => PortD0,
      D => WriteData(9),
      Q => \^portd\(9),
      R => reset
    );
RAM_reg_0_63_0_0: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(0),
      O => ReadDataRAM(0),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_0_0_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => DataAddr(11),
      I1 => DataAddr(13),
      I2 => DataAddr(14),
      I3 => \ReadData_reg[31]_i_6_n_0\,
      I4 => MemWrite,
      O => p_0_in
    );
RAM_reg_0_63_10_10: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(10),
      O => ReadDataRAM(10),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_11_11: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(11),
      O => ReadDataRAM(11),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_12_12: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(12),
      O => ReadDataRAM(12),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_13_13: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(13),
      O => ReadDataRAM(13),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_14_14: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(14),
      O => ReadDataRAM(14),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_15_15: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(15),
      O => ReadDataRAM(15),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_16_16: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(16),
      O => ReadDataRAM(16),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_17_17: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(17),
      O => ReadDataRAM(17),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_18_18: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(18),
      O => ReadDataRAM(18),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_19_19: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(19),
      O => ReadDataRAM(19),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_1_1: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(1),
      O => ReadDataRAM(1),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_20_20: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(20),
      O => ReadDataRAM(20),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_21_21: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(21),
      O => ReadDataRAM(21),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_22_22: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(22),
      O => ReadDataRAM(22),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_23_23: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(23),
      O => ReadDataRAM(23),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_24_24: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(24),
      O => ReadDataRAM(24),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_25_25: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(25),
      O => ReadDataRAM(25),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_26_26: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(26),
      O => ReadDataRAM(26),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_27_27: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(27),
      O => ReadDataRAM(27),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_28_28: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(28),
      O => ReadDataRAM(28),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_29_29: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(29),
      O => ReadDataRAM(29),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_2_2: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(2),
      O => ReadDataRAM(2),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_30_30: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(30),
      O => ReadDataRAM(30),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_31_31: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(31),
      O => ReadDataRAM(31),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_3_3: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(3),
      O => ReadDataRAM(3),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_4_4: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(4),
      O => ReadDataRAM(4),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_5_5: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(5),
      O => ReadDataRAM(5),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_6_6: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(6),
      O => ReadDataRAM(6),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_7_7: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(7),
      O => ReadDataRAM(7),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_8_8: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(8),
      O => ReadDataRAM(8),
      WCLK => clk,
      WE => p_0_in
    );
RAM_reg_0_63_9_9: unisim.vcomponents.RAM64X1S
     port map (
      A0 => DataAddr(2),
      A1 => DataAddr(3),
      A2 => DataAddr(4),
      A3 => DataAddr(5),
      A4 => DataAddr(6),
      A5 => DataAddr(7),
      D => WriteData(9),
      O => ReadDataRAM(9),
      WCLK => clk,
      WE => p_0_in
    );
\ReadData_reg[0]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[0]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(0)
    );
\ReadData_reg[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \ReadData_reg[0]_i_2_n_0\,
      I1 => \ReadData_reg[0]_i_3_n_0\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(0),
      I4 => ReadDataRAM(0),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[0]_i_1_n_0\
    );
\ReadData_reg[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000AC"
    )
        port map (
      I0 => PortB(0),
      I1 => PortA(0),
      I2 => DataAddr(4),
      I3 => \ReadData_reg[31]_i_7_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => DataAddr(5),
      O => \ReadData_reg[0]_i_2_n_0\
    );
\ReadData_reg[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020000"
    )
        port map (
      I0 => DataAddr(5),
      I1 => \ReadData_reg[31]_i_8_n_0\,
      I2 => \ReadData_reg[31]_i_7_n_0\,
      I3 => DataAddr(4),
      I4 => \^portc\(0),
      O => \ReadData_reg[0]_i_3_n_0\
    );
\ReadData_reg[10]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[10]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(10)
    );
\ReadData_reg[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(10),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(10),
      I4 => \ReadData_reg[10]_i_2_n_0\,
      O => \ReadData_reg[10]_i_1_n_0\
    );
\ReadData_reg[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(10),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(10),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[10]_i_2_n_0\
    );
\ReadData_reg[11]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[11]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(11)
    );
\ReadData_reg[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(11),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(11),
      I4 => \ReadData_reg[11]_i_2_n_0\,
      O => \ReadData_reg[11]_i_1_n_0\
    );
\ReadData_reg[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(11),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(11),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[11]_i_2_n_0\
    );
\ReadData_reg[12]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[12]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(12)
    );
\ReadData_reg[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(12),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(12),
      I4 => \ReadData_reg[12]_i_2_n_0\,
      O => \ReadData_reg[12]_i_1_n_0\
    );
\ReadData_reg[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(12),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(12),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[12]_i_2_n_0\
    );
\ReadData_reg[13]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[13]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(13)
    );
\ReadData_reg[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(13),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(13),
      I4 => \ReadData_reg[13]_i_2_n_0\,
      O => \ReadData_reg[13]_i_1_n_0\
    );
\ReadData_reg[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(13),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(13),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[13]_i_2_n_0\
    );
\ReadData_reg[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => DataAddr(6),
      I1 => DataAddr(7),
      I2 => DataAddr(2),
      I3 => DataAddr(3),
      I4 => DataAddr(5),
      I5 => DataAddr(4),
      O => \ReadData_reg[13]_i_3_n_0\
    );
\ReadData_reg[13]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => DataAddr(4),
      I1 => DataAddr(5),
      O => \ReadData_reg[13]_i_4_n_0\
    );
\ReadData_reg[14]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[14]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(14)
    );
\ReadData_reg[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[14]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(14),
      I4 => ReadDataRAM(14),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[14]_i_1_n_0\
    );
\ReadData_reg[15]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[15]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(15)
    );
\ReadData_reg[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[15]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(15),
      I4 => ReadDataRAM(15),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[15]_i_1_n_0\
    );
\ReadData_reg[16]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[16]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(16)
    );
\ReadData_reg[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[16]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[16]\,
      I4 => ReadDataRAM(16),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[16]_i_1_n_0\
    );
\ReadData_reg[17]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[17]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(17)
    );
\ReadData_reg[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[17]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[17]\,
      I4 => ReadDataRAM(17),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[17]_i_1_n_0\
    );
\ReadData_reg[18]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[18]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(18)
    );
\ReadData_reg[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[18]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[18]\,
      I4 => ReadDataRAM(18),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[18]_i_1_n_0\
    );
\ReadData_reg[19]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[19]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(19)
    );
\ReadData_reg[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[19]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[19]\,
      I4 => ReadDataRAM(19),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[19]_i_1_n_0\
    );
\ReadData_reg[1]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[1]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(1)
    );
\ReadData_reg[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \ReadData_reg[1]_i_2_n_0\,
      I1 => \ReadData_reg[1]_i_3_n_0\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(1),
      I4 => ReadDataRAM(1),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[1]_i_1_n_0\
    );
\ReadData_reg[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000AC"
    )
        port map (
      I0 => PortB(1),
      I1 => PortA(1),
      I2 => DataAddr(4),
      I3 => \ReadData_reg[31]_i_7_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => DataAddr(5),
      O => \ReadData_reg[1]_i_2_n_0\
    );
\ReadData_reg[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020000"
    )
        port map (
      I0 => DataAddr(5),
      I1 => \ReadData_reg[31]_i_8_n_0\,
      I2 => \ReadData_reg[31]_i_7_n_0\,
      I3 => DataAddr(4),
      I4 => \^portc\(1),
      O => \ReadData_reg[1]_i_3_n_0\
    );
\ReadData_reg[20]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[20]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(20)
    );
\ReadData_reg[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[20]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[20]\,
      I4 => ReadDataRAM(20),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[20]_i_1_n_0\
    );
\ReadData_reg[21]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[21]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(21)
    );
\ReadData_reg[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[21]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[21]\,
      I4 => ReadDataRAM(21),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[21]_i_1_n_0\
    );
\ReadData_reg[22]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[22]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(22)
    );
\ReadData_reg[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[22]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[22]\,
      I4 => ReadDataRAM(22),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[22]_i_1_n_0\
    );
\ReadData_reg[23]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[23]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(23)
    );
\ReadData_reg[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[23]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[23]\,
      I4 => ReadDataRAM(23),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[23]_i_1_n_0\
    );
\ReadData_reg[24]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[24]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(24)
    );
\ReadData_reg[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[24]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[24]\,
      I4 => ReadDataRAM(24),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[24]_i_1_n_0\
    );
\ReadData_reg[25]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[25]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(25)
    );
\ReadData_reg[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[25]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[25]\,
      I4 => ReadDataRAM(25),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[25]_i_1_n_0\
    );
\ReadData_reg[26]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[26]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(26)
    );
\ReadData_reg[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[26]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[26]\,
      I4 => ReadDataRAM(26),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[26]_i_1_n_0\
    );
\ReadData_reg[27]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[27]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(27)
    );
\ReadData_reg[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[27]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[27]\,
      I4 => ReadDataRAM(27),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[27]_i_1_n_0\
    );
\ReadData_reg[28]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[28]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(28)
    );
\ReadData_reg[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[28]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[28]\,
      I4 => ReadDataRAM(28),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[28]_i_1_n_0\
    );
\ReadData_reg[29]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[29]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(29)
    );
\ReadData_reg[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[29]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[29]\,
      I4 => ReadDataRAM(29),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[29]_i_1_n_0\
    );
\ReadData_reg[2]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[2]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(2)
    );
\ReadData_reg[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \ReadData_reg[2]_i_2_n_0\,
      I1 => \ReadData_reg[2]_i_3_n_0\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(2),
      I4 => ReadDataRAM(2),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[2]_i_1_n_0\
    );
\ReadData_reg[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000AC"
    )
        port map (
      I0 => PortB(2),
      I1 => PortA(2),
      I2 => DataAddr(4),
      I3 => \ReadData_reg[31]_i_7_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => DataAddr(5),
      O => \ReadData_reg[2]_i_2_n_0\
    );
\ReadData_reg[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020000"
    )
        port map (
      I0 => DataAddr(5),
      I1 => \ReadData_reg[31]_i_8_n_0\,
      I2 => \ReadData_reg[31]_i_7_n_0\,
      I3 => DataAddr(4),
      I4 => \^portc\(2),
      O => \ReadData_reg[2]_i_3_n_0\
    );
\ReadData_reg[30]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[30]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(30)
    );
\ReadData_reg[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[30]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[30]\,
      I4 => ReadDataRAM(30),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[30]_i_1_n_0\
    );
\ReadData_reg[31]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[31]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(31)
    );
\ReadData_reg[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \ReadData_reg[31]_i_3_n_0\,
      I1 => \PortC_reg_reg_n_0_[31]\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \PortD_reg_reg_n_0_[31]\,
      I4 => ReadDataRAM(31),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[31]_i_1_n_0\
    );
\ReadData_reg[31]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => DataAddr(4),
      I1 => DataAddr(5),
      O => \ReadData_reg[31]_i_10_n_0\
    );
\ReadData_reg[31]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => DataAddr(17),
      I1 => DataAddr(16),
      I2 => DataAddr(19),
      I3 => DataAddr(18),
      O => \ReadData_reg[31]_i_11_n_0\
    );
\ReadData_reg[31]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFEFFFF"
    )
        port map (
      I0 => DataAddr(30),
      I1 => DataAddr(31),
      I2 => DataAddr(28),
      I3 => DataAddr(29),
      I4 => DataAddr(12),
      I5 => DataAddr(15),
      O => \ReadData_reg[31]_i_12_n_0\
    );
\ReadData_reg[31]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => DataAddr(25),
      I1 => DataAddr(24),
      I2 => DataAddr(27),
      I3 => DataAddr(26),
      O => \ReadData_reg[31]_i_13_n_0\
    );
\ReadData_reg[31]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => DataAddr(21),
      I1 => DataAddr(20),
      I2 => DataAddr(23),
      I3 => DataAddr(22),
      O => \ReadData_reg[31]_i_14_n_0\
    );
\ReadData_reg[31]_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => DataAddr(11),
      I1 => DataAddr(10),
      I2 => DataAddr(14),
      I3 => DataAddr(13),
      O => \ReadData_reg[31]_i_15_n_0\
    );
\ReadData_reg[31]_i_16\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFF"
    )
        port map (
      I0 => DataAddr(1),
      I1 => DataAddr(0),
      I2 => DataAddr(9),
      I3 => DataAddr(8),
      O => \ReadData_reg[31]_i_16_n_0\
    );
\ReadData_reg[31]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FFFF"
    )
        port map (
      I0 => DataAddr(11),
      I1 => DataAddr(13),
      I2 => DataAddr(14),
      I3 => \ReadData_reg[31]_i_6_n_0\,
      I4 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[31]_i_2_n_0\
    );
\ReadData_reg[31]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => DataAddr(4),
      I1 => \ReadData_reg[31]_i_7_n_0\,
      I2 => \ReadData_reg[31]_i_8_n_0\,
      I3 => DataAddr(5),
      O => \ReadData_reg[31]_i_3_n_0\
    );
\ReadData_reg[31]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => DataAddr(4),
      I1 => DataAddr(5),
      I2 => \ReadData_reg[31]_i_9_n_0\,
      I3 => \ReadData_reg[31]_i_8_n_0\,
      O => \ReadData_reg[31]_i_4_n_0\
    );
\ReadData_reg[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFE7FFF"
    )
        port map (
      I0 => DataAddr(6),
      I1 => DataAddr(7),
      I2 => DataAddr(2),
      I3 => DataAddr(3),
      I4 => \ReadData_reg[31]_i_10_n_0\,
      I5 => \ReadData_reg[31]_i_8_n_0\,
      O => \ReadData_reg[31]_i_5_n_0\
    );
\ReadData_reg[31]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \ReadData_reg[31]_i_11_n_0\,
      I1 => \ReadData_reg[31]_i_12_n_0\,
      I2 => \ReadData_reg[31]_i_13_n_0\,
      I3 => \ReadData_reg[31]_i_14_n_0\,
      O => \ReadData_reg[31]_i_6_n_0\
    );
\ReadData_reg[31]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => DataAddr(3),
      I1 => DataAddr(2),
      I2 => DataAddr(7),
      I3 => DataAddr(6),
      O => \ReadData_reg[31]_i_7_n_0\
    );
\ReadData_reg[31]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \ReadData_reg[31]_i_15_n_0\,
      I1 => \ReadData_reg[31]_i_16_n_0\,
      I2 => \ReadData_reg[31]_i_14_n_0\,
      I3 => \ReadData_reg[31]_i_13_n_0\,
      I4 => \ReadData_reg[31]_i_12_n_0\,
      I5 => \ReadData_reg[31]_i_11_n_0\,
      O => \ReadData_reg[31]_i_8_n_0\
    );
\ReadData_reg[31]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => DataAddr(3),
      I1 => DataAddr(2),
      I2 => DataAddr(7),
      I3 => DataAddr(6),
      O => \ReadData_reg[31]_i_9_n_0\
    );
\ReadData_reg[3]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[3]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(3)
    );
\ReadData_reg[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \ReadData_reg[3]_i_2_n_0\,
      I1 => \ReadData_reg[3]_i_3_n_0\,
      I2 => \ReadData_reg[31]_i_4_n_0\,
      I3 => \^portd\(3),
      I4 => ReadDataRAM(3),
      I5 => \ReadData_reg[31]_i_5_n_0\,
      O => \ReadData_reg[3]_i_1_n_0\
    );
\ReadData_reg[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000AC"
    )
        port map (
      I0 => PortB(3),
      I1 => PortA(3),
      I2 => DataAddr(4),
      I3 => \ReadData_reg[31]_i_7_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => DataAddr(5),
      O => \ReadData_reg[3]_i_2_n_0\
    );
\ReadData_reg[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020000"
    )
        port map (
      I0 => DataAddr(5),
      I1 => \ReadData_reg[31]_i_8_n_0\,
      I2 => \ReadData_reg[31]_i_7_n_0\,
      I3 => DataAddr(4),
      I4 => \^portc\(3),
      O => \ReadData_reg[3]_i_3_n_0\
    );
\ReadData_reg[4]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[4]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(4)
    );
\ReadData_reg[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(4),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(4),
      I4 => \ReadData_reg[4]_i_2_n_0\,
      O => \ReadData_reg[4]_i_1_n_0\
    );
\ReadData_reg[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(4),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(4),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[4]_i_2_n_0\
    );
\ReadData_reg[5]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[5]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(5)
    );
\ReadData_reg[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(5),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(5),
      I4 => \ReadData_reg[5]_i_2_n_0\,
      O => \ReadData_reg[5]_i_1_n_0\
    );
\ReadData_reg[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(5),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(5),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[5]_i_2_n_0\
    );
\ReadData_reg[6]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[6]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(6)
    );
\ReadData_reg[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(6),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(6),
      I4 => \ReadData_reg[6]_i_2_n_0\,
      O => \ReadData_reg[6]_i_1_n_0\
    );
\ReadData_reg[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(6),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(6),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[6]_i_2_n_0\
    );
\ReadData_reg[7]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[7]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(7)
    );
\ReadData_reg[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(7),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(7),
      I4 => \ReadData_reg[7]_i_2_n_0\,
      O => \ReadData_reg[7]_i_1_n_0\
    );
\ReadData_reg[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(7),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(7),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[7]_i_2_n_0\
    );
\ReadData_reg[8]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[8]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(8)
    );
\ReadData_reg[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(8),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(8),
      I4 => \ReadData_reg[8]_i_2_n_0\,
      O => \ReadData_reg[8]_i_1_n_0\
    );
\ReadData_reg[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(8),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(8),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[8]_i_2_n_0\
    );
\ReadData_reg[9]\: unisim.vcomponents.LDCE
    generic map(
      INIT => '0'
    )
        port map (
      CLR => '0',
      D => \ReadData_reg[9]_i_1_n_0\,
      G => \ReadData_reg[31]_i_2_n_0\,
      GE => '1',
      Q => ReadData(9)
    );
\ReadData_reg[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF888"
    )
        port map (
      I0 => ReadDataRAM(9),
      I1 => \ReadData_reg[31]_i_5_n_0\,
      I2 => \ReadData_reg[31]_i_3_n_0\,
      I3 => \^portc\(9),
      I4 => \ReadData_reg[9]_i_2_n_0\,
      O => \ReadData_reg[9]_i_1_n_0\
    );
\ReadData_reg[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000088880000F888"
    )
        port map (
      I0 => \^portd\(9),
      I1 => \ReadData_reg[13]_i_3_n_0\,
      I2 => PortB(9),
      I3 => \ReadData_reg[13]_i_4_n_0\,
      I4 => \ReadData_reg[31]_i_8_n_0\,
      I5 => \ReadData_reg[31]_i_7_n_0\,
      O => \ReadData_reg[9]_i_2_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_dmem_io_0_0 is
  port (
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    MemWrite : in STD_LOGIC;
    DataAddr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    WriteData : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ReadData : out STD_LOGIC_VECTOR ( 31 downto 0 );
    PortA : in STD_LOGIC_VECTOR ( 3 downto 0 );
    PortB : in STD_LOGIC_VECTOR ( 13 downto 0 );
    PortC : out STD_LOGIC_VECTOR ( 13 downto 0 );
    PortD : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of singleriscv_bd_dmem_io_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of singleriscv_bd_dmem_io_0_0 : entity is "singleriscv_bd_dmem_io_0_0,dmem_io,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of singleriscv_bd_dmem_io_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of singleriscv_bd_dmem_io_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of singleriscv_bd_dmem_io_0_0 : entity is "dmem_io,Vivado 2020.2";
end singleriscv_bd_dmem_io_0_0;

architecture STRUCTURE of singleriscv_bd_dmem_io_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN singleriscv_bd_clk_0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of reset : signal is "xilinx.com:signal:reset:1.0 reset RST";
  attribute X_INTERFACE_PARAMETER of reset : signal is "XIL_INTERFACENAME reset, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
inst: entity work.singleriscv_bd_dmem_io_0_0_dmem_io
     port map (
      DataAddr(31 downto 0) => DataAddr(31 downto 0),
      MemWrite => MemWrite,
      PortA(3 downto 0) => PortA(3 downto 0),
      PortB(13 downto 0) => PortB(13 downto 0),
      PortC(13 downto 0) => PortC(13 downto 0),
      PortD(15 downto 0) => PortD(15 downto 0),
      ReadData(31 downto 0) => ReadData(31 downto 0),
      WriteData(31 downto 0) => WriteData(31 downto 0),
      clk => clk,
      reset => reset
    );
end STRUCTURE;
