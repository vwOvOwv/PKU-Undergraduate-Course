-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:20:31 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ BCD2bin_0_stub.vhdl
-- Design      : BCD2bin_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    bcd3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bin : out STD_LOGIC_VECTOR ( 13 downto 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "bcd3[3:0],bcd2[3:0],bcd1[3:0],bcd0[3:0],bin[13:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "BCD2bin,Vivado 2020.2";
begin
end;
