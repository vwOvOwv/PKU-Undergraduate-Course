-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:20:50 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4_0_sim_netlist.vhdl
-- Design      : display_7seg_x4_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity display_7seg_x4_0_display_7seg_x4 is
  port (
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    an : out STD_LOGIC_VECTOR ( 0 to 3 );
    CLK_1KHz : in STD_LOGIC;
    in1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2 : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of display_7seg_x4_0_display_7seg_x4 : entity is "display_7seg_x4";
end display_7seg_x4_0_display_7seg_x4;

architecture STRUCTURE of display_7seg_x4_0_display_7seg_x4 is
  signal p_0_in : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal sel : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal sel0 : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \an[0]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \an[1]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an[2]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an[3]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \seg[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[3]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[5]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \seg[6]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \sel[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \sel[1]_i_1\ : label is "soft_lutpair3";
begin
\an[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => sel(1),
      I1 => sel(0),
      O => an(0)
    );
\an[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => sel(1),
      I1 => sel(0),
      O => an(1)
    );
\an[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => sel(0),
      I1 => sel(1),
      O => an(2)
    );
\an[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => sel(1),
      I1 => sel(0),
      O => an(3)
    );
\seg[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0014"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(3),
      O => seg(0)
    );
\seg[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1(1),
      I1 => in0(1),
      I2 => in3(1),
      I3 => sel(0),
      I4 => sel(1),
      I5 => in2(1),
      O => sel0(1)
    );
\seg[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1(2),
      I1 => in0(2),
      I2 => in3(2),
      I3 => sel(0),
      I4 => sel(1),
      I5 => in2(2),
      O => sel0(2)
    );
\seg[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1(0),
      I1 => in0(0),
      I2 => in3(0),
      I3 => sel(0),
      I4 => sel(1),
      I5 => in2(0),
      O => sel0(0)
    );
\seg[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1(3),
      I1 => in0(3),
      I2 => in3(3),
      I3 => sel(0),
      I4 => sel(1),
      I5 => in2(3),
      O => sel0(3)
    );
\seg[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0060"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(0),
      I2 => sel0(2),
      I3 => sel0(3),
      O => seg(1)
    );
\seg[2]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => sel0(0),
      I1 => sel0(2),
      I2 => sel0(1),
      I3 => sel0(3),
      O => seg(2)
    );
\seg[3]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0094"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(3),
      O => seg(3)
    );
\seg[4]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F1F0"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(1),
      I2 => sel0(0),
      I3 => sel0(2),
      O => seg(4)
    );
\seg[5]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00B2"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(3),
      O => seg(5)
    );
\seg[6]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0091"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(3),
      O => seg(6)
    );
\sel[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => sel(0),
      O => p_0_in(0)
    );
\sel[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel(0),
      I1 => sel(1),
      O => p_0_in(1)
    );
\sel_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_1KHz,
      CE => '1',
      D => p_0_in(0),
      Q => sel(0),
      R => '0'
    );
\sel_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_1KHz,
      CE => '1',
      D => p_0_in(1),
      Q => sel(1),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity display_7seg_x4_0 is
  port (
    CLK_1KHz : in STD_LOGIC;
    in3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an : out STD_LOGIC_VECTOR ( 0 to 3 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of display_7seg_x4_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of display_7seg_x4_0 : entity is "display_7seg_x4_0,display_7seg_x4,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of display_7seg_x4_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of display_7seg_x4_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of display_7seg_x4_0 : entity is "display_7seg_x4,Vivado 2020.2";
end display_7seg_x4_0;

architecture STRUCTURE of display_7seg_x4_0 is
begin
inst: entity work.display_7seg_x4_0_display_7seg_x4
     port map (
      CLK_1KHz => CLK_1KHz,
      an(0 to 3) => an(0 to 3),
      in0(3 downto 0) => in0(3 downto 0),
      in1(3 downto 0) => in1(3 downto 0),
      in2(3 downto 0) => in2(3 downto 0),
      in3(3 downto 0) => in3(3 downto 0),
      seg(0 to 6) => seg(0 to 6)
    );
end STRUCTURE;
