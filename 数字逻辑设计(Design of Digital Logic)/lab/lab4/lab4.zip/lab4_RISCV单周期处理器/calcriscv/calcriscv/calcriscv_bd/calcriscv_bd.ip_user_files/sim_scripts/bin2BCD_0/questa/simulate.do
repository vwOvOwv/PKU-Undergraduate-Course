onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib bin2BCD_0_opt

do {wave.do}

view wave
view structure
view signals

do {bin2BCD_0.udo}

run -all

quit -force
