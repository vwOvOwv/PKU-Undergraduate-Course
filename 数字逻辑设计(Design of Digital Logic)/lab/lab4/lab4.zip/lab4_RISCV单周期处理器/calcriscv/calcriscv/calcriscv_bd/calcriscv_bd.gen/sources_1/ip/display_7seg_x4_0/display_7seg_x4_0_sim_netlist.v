// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:20:50 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4_0_sim_netlist.v
// Design      : display_7seg_x4_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "display_7seg_x4_0,display_7seg_x4,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "display_7seg_x4,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module display_7seg_x4_0
   (CLK_1KHz,
    in3,
    in2,
    in1,
    in0,
    an,
    seg);
  input CLK_1KHz;
  input [3:0]in3;
  input [3:0]in2;
  input [3:0]in1;
  input [3:0]in0;
  output [0:3]an;
  output [0:6]seg;

  wire CLK_1KHz;
  wire [0:3]an;
  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]in2;
  wire [3:0]in3;
  wire [0:6]seg;

  display_7seg_x4_0_display_7seg_x4 inst
       (.CLK_1KHz(CLK_1KHz),
        .an(an),
        .in0(in0),
        .in1(in1),
        .in2(in2),
        .in3(in3),
        .seg(seg));
endmodule

(* ORIG_REF_NAME = "display_7seg_x4" *) 
module display_7seg_x4_0_display_7seg_x4
   (seg,
    an,
    CLK_1KHz,
    in1,
    in0,
    in3,
    in2);
  output [0:6]seg;
  output [0:3]an;
  input CLK_1KHz;
  input [3:0]in1;
  input [3:0]in0;
  input [3:0]in3;
  input [3:0]in2;

  wire CLK_1KHz;
  wire [0:3]an;
  wire [3:0]in0;
  wire [3:0]in1;
  wire [3:0]in2;
  wire [3:0]in3;
  wire [1:0]p_0_in;
  wire [0:6]seg;
  wire [1:0]sel;
  wire [3:0]sel0;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \an[0]_INST_0 
       (.I0(sel[1]),
        .I1(sel[0]),
        .O(an[0]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an[1]_INST_0 
       (.I0(sel[1]),
        .I1(sel[0]),
        .O(an[1]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an[2]_INST_0 
       (.I0(sel[0]),
        .I1(sel[1]),
        .O(an[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \an[3]_INST_0 
       (.I0(sel[1]),
        .I1(sel[0]),
        .O(an[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0014)) 
    \seg[0]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[3]),
        .O(seg[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg[0]_INST_0_i_1 
       (.I0(in1[1]),
        .I1(in0[1]),
        .I2(in3[1]),
        .I3(sel[0]),
        .I4(sel[1]),
        .I5(in2[1]),
        .O(sel0[1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg[0]_INST_0_i_2 
       (.I0(in1[2]),
        .I1(in0[2]),
        .I2(in3[2]),
        .I3(sel[0]),
        .I4(sel[1]),
        .I5(in2[2]),
        .O(sel0[2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg[0]_INST_0_i_3 
       (.I0(in1[0]),
        .I1(in0[0]),
        .I2(in3[0]),
        .I3(sel[0]),
        .I4(sel[1]),
        .I5(in2[0]),
        .O(sel0[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg[0]_INST_0_i_4 
       (.I0(in1[3]),
        .I1(in0[3]),
        .I2(in3[3]),
        .I3(sel[0]),
        .I4(sel[1]),
        .I5(in2[3]),
        .O(sel0[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0060)) 
    \seg[1]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[0]),
        .I2(sel0[2]),
        .I3(sel0[3]),
        .O(seg[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    \seg[2]_INST_0 
       (.I0(sel0[0]),
        .I1(sel0[2]),
        .I2(sel0[1]),
        .I3(sel0[3]),
        .O(seg[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0094)) 
    \seg[3]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[3]),
        .O(seg[3]));
  LUT4 #(
    .INIT(16'hF1F0)) 
    \seg[4]_INST_0 
       (.I0(sel0[3]),
        .I1(sel0[1]),
        .I2(sel0[0]),
        .I3(sel0[2]),
        .O(seg[4]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h00B2)) 
    \seg[5]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[3]),
        .O(seg[5]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0091)) 
    \seg[6]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[3]),
        .O(seg[6]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \sel[0]_i_1 
       (.I0(sel[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \sel[1]_i_1 
       (.I0(sel[0]),
        .I1(sel[1]),
        .O(p_0_in[1]));
  FDRE \sel_reg[0] 
       (.C(CLK_1KHz),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(sel[0]),
        .R(1'b0));
  FDRE \sel_reg[1] 
       (.C(CLK_1KHz),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(sel[1]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
