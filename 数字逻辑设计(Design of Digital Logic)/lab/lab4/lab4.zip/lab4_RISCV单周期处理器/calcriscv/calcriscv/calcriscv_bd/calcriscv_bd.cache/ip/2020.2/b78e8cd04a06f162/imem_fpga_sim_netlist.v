// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:12:53 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ imem_fpga_sim_netlist.v
// Design      : imem_fpga
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "imem_fpga,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (a,
    spo);
  input [5:0]a;
  output [31:0]spo;

  wire \<const0> ;
  wire [5:0]a;
  wire [31:0]\^spo ;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;
  wire [19:19]NLW_U0_spo_UNCONNECTED;

  assign spo[31:20] = \^spo [31:20];
  assign spo[19] = \<const0> ;
  assign spo[18:0] = \^spo [18:0];
  GND GND
       (.G(\<const0> ));
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "6" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "64" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "imem_fpga.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(\^spo ),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
AWk2+F/LLIwJ/3H70MT+p73z+MaZAUnylB9xu/zfH66xX8dAaOizqpslZkE4MXrWhxdHpghP7sIj
kwvWqhJ3gA==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
f3tnX2YCmmij/BT714m5fPTuG3pr/Sp1bWD1FpCFiwTkcUFmqMNcr7abCn+qa2HUp1VAs9a1kY1i
yU68W3C4ARAx1rnlow3CtMBZ+4vG1QDA+Ciu5T+MSJsiWTAoMU3jJunULwD6zEC9h/Y3bBf+ZNGj
RvbKgHQFYSq+EYUzleQ=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
C6xRmzJVnvguMc3Lt5tkoyg5+/u1VuxRooNBOmgUvD6c148xX9CV/zz4fw53vbCzqUg3WYMPAs5M
/tMrhPMrX5cqjMMHbC20NaFxsFGCfdbN+1Jiu6Ffu0obXLvBu7UGBCEaDTCY0wST3S+7NZ+HnAat
RIt5cVRmnWtLEj9MP8SxAk019LKc3+2AUY0eWFhWbTGvNoTLcRFak8vqIx8KBuqhc16O50jjNmM3
PJltfibMKzAmWpsf6xiOkaD+BvARuccAoYGgANLBAEQdJUza98//SuTN0KLZKbFSmy2WI5iAzkxJ
bhH9hPn6Ks1JkH9+j61hMSpdxSh8rM8X8Dppxw==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
pefxdCU7VwYHa7diZaenheQOVCFpIvDlVp0qUtYsCnfw3IK+d5+k4O7xc5MWvQPeJpwUWNg+c9U8
PcbHo1enWoVg9o1V4U5fg7wxYqKmubBjgGF3yJ5FYGt6FeiD7zcnIJcaP2puAYDdVnxtiJnNmFz2
OQ7UQsleDpBQo3E4NEsbtqgSaopjHREMjI4yjJ9l5XZYNPCWUzUV/mSGX/kF+vuSOZclwPm6w72e
TE0MyJZA2HPDY3HIy260pYSHuDTUpe8gTxi0s8JmpFjaMaibBcPzq2gqPSQe1d6pDE8cv0OxNYKL
gFy+uh/H5gpNjfWVBhRmUo/kFf8fs680z0B0IQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
q8meW/DFYsK3R2jTQ13P/a1BVQyF0Eb3aLhqxNSrqINAq7gQ0DvJ6JFuxd6Ce7TIpxqKUYX9026h
UujOPWt7f1brVrSWmt8cW5Um2Yy8tv+YSNv9Ig592u4GssTU6dF978RK/7L4ZuQObLOKvWLJqo3F
6gzw0VbqYS3g5aaGu+Y=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GVM7UoBz9uTOdnKd0CVM0lBuJK2N20FwcoiRGregMBQMsQuevbc7y03ZehM7mfGvEdERp1TciWoI
1b6cDAZYb0YBfSuch0bItCwhdftV3A4/R0nUF0HROsZ/rm/HV7DKDXxItqK0qcdOwqf7ju85NMa4
FJRP/Nuq/ya9IvX9BCpmUlT7tLkICG8cEL8/iJrJY3jRIBtKw85mL5OM+r22LQeYg1/3rb9Rk9BT
RZCTbDcVSUq2Awr+6f0L2NXlRwhFraBy+h9iSZKZ/U7uolyF0nB1+/BSgOl+rttZ2KxfLXe6g81N
FbxtrlpK7FNc9fx2jrKWh5bczyW6p0ATPX0ZbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
rYkJ9a3QzTBGC5CITub5Su2Qs6nnM1m+OFLf4ykZkZGIsp11NQi6h5t8dsi/rX/MeEof1XLVJGEU
N+qLOHuLrttRAipPNBsj7yqH3Amnleqy/rjy8UcckD0gxIYzuIlc+2VKoAoyrEFgofTH5bKzBaaQ
q0JSt8PES8xuld4SvsKwr+0Q23qJIUpeNL3HvzxZDmYf5OhTkwlZPi/aLwSMoPZHKwetLUg5SdBm
7K4UmxvUPD3GNxo6GW6dkG2tFW/N9+ju7i//O1A74VUrDPo1OwQfEJazwHFFpHGjCJkv2CiPU3+I
TIVvzssQcs8IphMJulwZguc7fFiYv6aZyj/GrA==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
PqIVM68d++A6qxRgSePlX8JOoCfHcFLdhzsYr1BDYvLE5JJ5WKFO0Bie6pyEiAbsH8z6oUFGm/Qy
BLXAyWfv1fmbVAwztezaMaxBF0Lw4epvQlAFVdMGJVKgvxfU7ssvLc1KfpF6R/c1o5+4Vf7zn3X+
R8k67LVYgJoxhrPoY3XYr88CjSITfNW0jLDjh0jtDWf7H7nM6QYSXVbRYczQPcepXW2MOFcCZsbi
tdla+UNJ4NeKTUK5bdE9tNZx/8BYKrJtLhyvNdwHi7EdonKLjQu63ExIHoriUmiZScMNbtr2LUBc
YYGUTIENquQ/OhU+DAVXmKbIZcQhwGaqjYeaag==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YMvD1GHkklhDlN9yur11SqhNZTItCRHxHobZtty993SsbvXTWJBbLeIJ+nQ/sv57gpjV5RswiJYh
Vu7QPlLUy2DbVjjcqxaxXlPvYaWV1eKD7BVBOV6HDzPAaAIaFvNjeRurYX0a9Dz1qkgkmttneZxB
s04mTyRdVOc7jIs5wjgXiF+iA0W50/g9JmIYyP6mMLkgEy0MbGyVfpbRfDMcrB3ACnucHTo8A0nT
V/rBUOGbTCYPmQ01tbuE2nqoEfTlmqHVKO6BZ93tQUEjrYoJdteva6yHUfH3dbV1vwwBtsdolICY
7x8cMlorxb6y2ZD7vQEYz6Q6iVnG/PmdaCkLSg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 10848)
`pragma protect data_block
BDVJrs9uxnVuHhL5YFCS2YucakvPVmEU/jajaCx/2R9QVdRUxqgYqdY8r7WhDbFkd2V4rUJz+F91
+brCsAqco7Nobn3VyIF1QJ0yxBEiqB9WWbCa+0W8sRAfOdN+3TTB8WjYSDcpiuYG4OIeC3rLNiRd
xGsmFPScs2wXoVAYApyJDoyb8+DmeKg58U5Qz1P/BHfMWLfFIEF1e0U6gPlK/MZulnDNVmLlmU7q
i9IhhHpYcwhe665CmBO50H09tTgCTHzZEs6cBeivmvfO73uvUUu2QRX4txSrONe70LohFmS2PKlu
RkhVPxK0PM/wx4Ty1+yiNOBJ+0FZfWSwiLbHNT2SOWPjxx5tSa+idcVLax7/Deq68MrjizJcjtiw
7VHxtEcZPbUKrqm1x/NSJgE0d0L5jswhXCavjrkqHTLtkDL8mr7HHRM7H6Ue6Z/Lpn1HV9XSsdP3
Ezd4RpT8c2kRIDRfbuzF+L1COennhessOv0+LWma3VRSumUtBeOXuk3MdPsYChgm4O2wvTVgqGcm
m6vTEH+0ZVIvbjGd/HYLgbB0/pVcOPfJeCFqHaBJwaFjhSlVfuuA1+h6e5FijMGvRqBTKfER+jza
xzGSUmYtieZFrfyYBfXlO5wuzyX+xeaEHdHite4dp5gjGro0UPPVhLwRsKfCwPam/1dc8v09IXdu
QKJXXJtRu4lB8JjSjMcRARsEnPzNzxEc9qCzx7GFgabYHtjT70wd+jW+3zirKf6TwPHjBtC8E73q
RaukH2EF+17Fd9Rr5n7gY2xRcOYOo4Mgi3A3n5OENvqFwHXsbIZ3vynBnRrqxhKKy8baUGJjTtbb
SvyQ7PXEiyH09P5LSDefhFNQsHYh4uKYc0mWk54mixFjFzUkKigdYhugoXakaASMLqdRxLcU9ezT
+d11Fe9fzw8/HzjuaNnn04eK/gmIUsLoRJjjPc7GZFoBdArU9+2vVX//Qa0uNvic5ZBWWmzprnIS
lP2/4V3GhuyOu47L6FaRYwp1kE+thyiucYPaA4o02Rcve4xsM98ZiVxJheBgB9SPNi1SjkefkLhU
updVDQ6TX4UtvZ2QFbDenAFxVmBwBWCNRoFYEgj7W8pOJRlU2M7VQruxX5eZK0t/UDE6DHAjNwwg
+AQbGUpS4mAncxSznY14KA/1EPnw7MkL/XUH4HItzTh1kgTNTCRvlFYJsAK0fG+NgKzwnEVJ7tkW
Crc4wX4SLULouDmEkMbtHR/Ar+w1lDgbu6NhigIdY30TuMZkXuiFs/ihEOosrqXDUkeJE3WE25YV
TW3Lct4uWirl/XQs/xPW5xPo/d/UNRX17YCRJOHDssp1TASKD12GmkAgkn0XG8BbBSIKOc4nE98z
QZoWTSIdywxS0ScATwTktrIw4aXW4/o30Ig1ODquIDGMaI/J6JeggwTv2UDaDeEVlRYDWHOr/aQX
j1hS1o5+SRSicEvyQ9u4DLV6t/DswJMQHUbjaf4a5YdYlWmaTTS1EKUdKSLr+7vvZQHrisGJp5Oj
pk3cLwu+VAo/xonOVQlF+rAyaZVMIvCkFwC+xf2LMxl/Hxqp0TmAuu+8wysoZkIxa3p/AW5+ZZ7z
Rvp7Mq4vVbXBFeGXkz/jS3QSDhTicNTDJLz0dAHHspnAEfF1R4PShnRv71t+IZA1sK49bvitJrzf
K4WzpDtSo5eU+PpRE9A0tVTiz1nIsGiKVL44WCD5BygXJlujuhlqK0QN2puF1uhVuLA8mFDPMfgK
LvIO/vidi2PsH8Ckk9TtV+FvA919xAYSwzU/ljQTa6zhKct15if9eeaWXwcykJr4ZASTjd+ZkIvc
Q+MmezfwiMFOh6VAejhiH5hbwBdHbwRr/5SxeRFVrY6qKYYLnUCONWQAlACf+RBHv1IbSmbroRT6
nND5YMhyxbh8SxK0NU+5oQzakUIi6Zmj2MfKd5PrffX9SdsK7Ab7WkqNoNOcP25I6YmPcVyqKY9A
d7lXy0cvUTnBZlkVK3yTAK0FlEPUwHnwTOPV1REniGTgDlsdocIE2DDXcSPoFYk+xx/7bFtpMndb
z3hGRE30wfOMlIbAD0voTjapXErPXqJD6SEtn5pPPlGkEZ4BSm+Z/kUGvbWMM0VNmJ1xKFO+Q4hL
NDjq8wRjSjs/BoHSUopJHuJNyqTAWcmS+gaZa9tZPXKfbYvmkzFwGjel2pnML5YB1mQUD+3GqkgG
A84hrihplgEsDdM509r/sEAHul4SdkgcADC+5ODEd6bb2fzV+ASyFE9hG4xXHrKcKfSq3zm6+Wo8
9qDBNzAvS8Wa78SLO0BjtfZFGWSUH/wZ3IKmSRvb98sqUrZTD+83QhvDg1BJoXOaEEmGy1p9Nrfv
oTWp+jrk+BFjTNXLeJoXfJmlV0QcSgMBtlJYxbY82riDRGbbguWtpk9UJW8jGpoDfLt/20NOa2gO
i4S/G7AVQdqc2wUELqhbG1OpFFN+8wlte2+jKAJRM9PVUacmWe0ciWBvmhUmKDAHeEg6dgD+Ry37
lmitmONLFW6HU4FZdqM1qzPnAMxGZpyVeYc7++XMFAlZcClUGI8fuuZvbFWbG4mXfkaBsKD7oTbE
cBQe6yRO0dqio42CADbJ+dTjhiAN5jrre7Jb6zic+1PY5EmeZ9snfFRCQFgZXp0IyKV+qdW7qM75
ESnRXNJfqJ5wKL6R/wr4l3aqOowb3i+WSugnEORHt05Q+RfTGn+YqTcsBlF2BigIwEpOE3625Weh
QNKAMusCM5zsc7KDYSxN5moYP1NtxD2IzIZaGAktrrqwhnOVL63L0RcB/YStVbZGfOinL5EkoWJf
GKN9J3v9A0w+40EF3K98A62IFRjD1u81vjlOCWZO6iIKAj5N9wbZ0xCPriTABWtZ/3r9GlSRgV0p
QOOyKQxX8pTuCgStb2JDeOwA/c/9PSNvvq9lFygTyWTH6g9NE9D7ubS5UidSF9ybs5I5eXTk5a5D
VE7QQAzX0pHn7gBkRMBg6QreP+qbfr1ABWLYaofNU3wUOWJg2Ft2uCXfG9+ffxj1bCF4S6yrF4zE
3cNjscwjpoae61Wld3VduK906z/6yqzAgC6X+qhwD6NXggbyRVJoIZMK8ebiHCb19NXAJ5QpGaLr
tm1TMGgEo8qq+qzI9gaKC8JkA9S6Mdt74+JxVp87cxaeEHuZKZ6NDO6mYMj6VU5klkgDt5brq6DE
qNMAFMhp3W6aoHS33sTeN7qzdt0aXvFb1O5q4x56aEy1BMipgwfL1CVu1lWr6GtKrcMnFPIKHKcK
fxYLOIxtaOTnGxxckmg1cw7OJYcnD++vY/Zp6rx6YHVjPPTX6wxGNZLJopLyJEkc0BWPSh/AwM/5
JYQa790sDor6zPsKfg9sPgDI5pjR3bBuXNz62hTFNOz76g4Hj45Us4aND1JtRtK2XzCuvQQ+uNBa
kq/p2iL0kH6aN6++ssyiGcIp5jkGzKQNTo7U439wXx+e0C33/4FvKRuCAkipFf1R8J1zVQfva7oS
xq71JZBJ3q55zKaSNtqkBl8q+DFnuraZTYspwTZpaZ89DafcvhIJYZDqz+aMLA2g70IdWDYuU9Dc
urVeex8kPM+rbJrVPKY1nRujpRDJ1HlweTfzHQJ8at2evlIb9x3etvVTIVkfySgWPOQTFd23WniY
2kOFZ/F9cnZPez5vf2b2GXdeeFCWZ1hCAtsCpo4wqOKwg9OYwXjVFYEaBO3ZVZJvGc4cp1UfP6EA
mPjqXmy2jaSqaPpJYSwKNOULyWOHH+3n1/dpW2cHGtGBZwhtCs7yS+3mJQPw+C35QqVgC0dd5Iad
DTE3yvbziVcZDZ3FPO8EfA/Bn5lwSsjuIB77RKvlZO3IxOFIs3AifHU9PaZb5lJxO/fozYmGpKjy
nMNCVxE4ZvYgo8CGzw5rJbJMS8EX1WAWKK3sYb71IyQqgozPLD/mpv0yMquz1W5iLSm8tSqDU5Rm
1y2YbLskyTlnrGpkdIj5eVSrCnK03Bkr4GUhXrE/xL72BCla5CXkbr8+ZJvofeYrzvhGBgibk7zt
5GjB/gb/TFC2HK+jXjnNoOE01ckM0GvlcXXp0Xmxy1MVxGY4US250ct48wgkvs4LYdWJnUOOkx+5
C7t5unskPDknV52bb6DJvVVI7vj2qh9H4yE2cKSCTkC4+qAnai81VwqY+mD1xai1pnLrWwW4i3XS
zfG8Owwd8Wc+1BqC/YdeGYw1hjdlIdOXwk7OFtOmUQVVv3DfsgHj39VF3r/QDpZsSPctKOOJtjpw
EjRVORtqnDVRY/cVsusAeGMiAT8uuAHFDdKuBH6d4zqvBcUT9gP6rUoinmsSvxK4ZPdk3vx5nd9H
qqWHG5oLlnFDc2Tox1cTYqPMap6cbt0PRS/sP6ee/1bWiTgNNaoWgGizwOV9csyXRWSLfXemeWPY
VmN31zcCQXZa2BsxkCC/dxtNWCcjB+ibOhctG179h60EV39WVof8OTFUXSbudxBOULd4ZqT1YFJS
F0R3GGCyPx5GPNJ/T7PKAY5vntBWcqlRX9aAp1VnPnhDiqXvPMjglXd2malXjBvVfk2gx1Qrcx/0
CrMCGCyWlwGUjj/9FT/cVjB1yGwB4Czdki+9VIxxWkYZs8a2vz+U26yDchXM47Og/VifL3zp1wII
YchQteNGuiWG/3jqnkX34bL0/QkgdNbbWA0bSpTfH9+A2akLTOBPDbikAl8tn9bWzMrtkUTE7r/q
pOnPIcynhaFH42yJX/m1QctdSfuqyQiWnp+iMqMN0lBlgByp7cR8ThBFqDollcEy4QTA9C4vMtra
TSSEvFslxIEhYEzyjprkSHuWXhST4WrdxTihJXG2AfmYMcEv/exdAnLFuEefzrIt8Pp4kW/pBeKB
UHI0f0TUa5U/EKnjYblZ9FmGhc9oB64nuqOflzdQ+x1gIs6HHel5y6UKrq6Lb9wACV6+d2JJPgfs
85CIJ8L6QimPHaTh1OVr4/KpV/rCAeBbFwquVyoWAbNoaOHcVdlfbDmTi6W7i94UJ+lNR18BsDHa
oBiu6o6uMTsdAYOgev1xfdyMWNyS2nXBcb9cpR8RHp8yOyb5hbR3W/5jdbXqHd5C8yQajScc+XI1
OWQ1+YB7h0bAqe7+s3kaLrmBYN8zodof0lOMcu5oxcWhG8VvlEyUwy/BzKY+QTYq+SsBvLhKjNZk
Z1JXUDSl+oayfqEpcv2Vi4TESEeQsVkn1/U+1zE670Jv7ES5iIdYjJH2yc8wzXi0FlKJy2IkQwhu
nG1/R4nOdBnW2X6twk70jM3i6woZHDRVD8qRJiQaegbEQOLZ67quzOpnqq82tlfkkxdLFRT+LeMA
XdEzERyiqSIbgdcNb2qBZ0ItRsm0G1sp6LERRc/Vcx1U3bfz/DWwrcvbmFjZLhQWYEtSFu5aGv3Z
i2bIK/G6Yq7gIN3GncXXkBwuN0KMvEfsj9KEsRMZfvCWhonLuYDEO3tF9jd7M8BGTfOhndtSqlE6
PeFVbog7o9PgOZYeku+U2Ah/wExqyIVAEmG0jKIAB73nSRlNMOMd+tFtffvkrr9UtUCdu30rtC30
tPfUgsqr/Y7EDXCDY1rHcyqOA9IW7u73cW2gBVCTbh51yJD9bf8uSfnWLiFeVHQKXho2NG3zJGfR
p0ggyz6C47/exzQycj6r/krF+p1y6AygJIwrKXlg+UDlyEMr8nYpbdwzLYYHVee2IURF37zErxTU
0aZbyexZpfKqCea+nm3f0u5Jds0tIoPxQH6QVvNciEIjnBQeWR9uqnGYERr6lWz+RMsDvzqmRiSc
eo4vZeutGRsIUhgTQqWz4ezvg/kTLMiM1ONXOFAZAunDXjv71DECqwWB5YrF6vvVURh/LEP9WZBA
ZaChQxZxhI+NeZBmck+E1SaS58n2Chd158shwkcin6KcEX1NBp32K5TDrSFzFglRVb7uALQN97sZ
4eKBerZY7noXQoCRShpXtkKhT6sj0SoK51pvHwJw26L8xXjkTCdNoV2h7HAiO+D2pe6YlMiG14SD
fbVNboGTTIW6iIu4YOhzALJrHT7xJP/fmyyXmeV854xHfKeEI6ILLMz9xfo1Mog41etStCB0Yc/R
ALKmp+ezjRg+PqnSuCMYZMtIqg0Ek8Po3768TBya6Dky9ImJURWrCB2CmOd/BEQaa1mTCM1Wii4r
Qo/L0PlVhIADVt2YGAg8SeWiPXna9C4rZ8gtp2UPitGtsvngQebO3UFlitSXgwb0BR+tKWjpaSux
8RsaoNFnbt4kwn5Z7LuiDqT+NL6R1CDhW+Jpwb2jF6zr+VuyoKcfffSiTc/7TeHmkca19h9/px4x
ZS1Sz/4cUai+1wMVqjJ/lrJpZakNpNdRE8/5CBboeiRSqlBedKxiHFVTWW/0mZ19R6JzVms3T3ey
vEe+6Uix7XVJtuv8jkGSTElLm3s19AjjmnYETXevZTLZYxVDnOYz9cypZl18+M9HjfOqxjcDAfum
2SV2nJyRdssDwMpN1gmfDaI+yUoI0WiTqQNxG0qAHvxyCNl1GbRFuB9Xu7bLIhkykVtCCpvuYSEb
05Uu1na/Aq54zgaZXN4y6m+S+eUfwPIiyCkoOmD61ft1cL7G/yF+GE24pqw1US+lVJ41MW4LGaO9
NODhbW5+nZTJx6inDYoTK06VfVaPX3XZryJWkTIp72l+U36O8+/z79V4hbowgY1DaA7o+NIBxPSU
RixqzUsC3o/7ni6Md8dt9WRf2gBHn9kEXzjJE1YBt0W8c/Oo0UBBQ4DVcoSBRo3y4H94VRxMoiLP
uwgFZZ+IuqVj7C7QkVF8A8kNmDTjuFor+VSDUClDHdljHrhJyRnCcCP5XhGD1xwPmV0gzcPHIksc
4Y9dUM5bGnZoPrghfneCkEjY5Wpk+gLyAYXGwjPLEZQ6IK5bhuhxht5lCzgX5LtbyJuwi20m9T1E
/aZEYV4sXUJpoE5ZO3VmuVlUBS4RvtPeA1dImDKQMkbSXhxg6xj8gVzJ8QxPHvIZ6ORFAGoUsqE2
dVr+KI/5HfiuJLen38T2k3WfvhjHKfTSyGuvKULgYu4/wmrVHYimTdwjB7x1h9ni0PPeUvj/JGv2
6TMiiBF4ATNPjZjjuHmZGMclHMoUO+cTejmKEgGXvjiht8eIIpDxmjRdJl2e1pIjuqP4h+DRqdow
pZlm7KZlu4/CfJ2WmepqUJgdO+3bXtWh6jvGHHJ6WN1cx88jnF4QA3hV6cutEwR+PlIDLdR9ym+p
NtNwiRQPNh4PhuAjUots6VcZ7u/XuZbeMh5q7dEy345OCWkUS6EZUSfgIKNwEPMf2jt2LPR/A7GJ
Jxgp1sakqaI5xm/XMpkBX3BdqBkQvJKqaD3HN5BM+kf8vGIVzf/YfWPPKPgIwq8TIu4e53n4Gzb7
WNhWwHTeUxc8s80DFmkbmOrYX2sXwLlm9JV9sfmo0d6ZKUJRRREQvHZQgkC45w6qOz2QtdD0gS1l
JJcVqt1XHFiMGOsJgLxfcB2KTjMB8QTcG7KjUT0mPxhNN3jBMUp4jlBEZkcrlZUVD8rtN/QXgaXt
+Imc0EBEQvxrPgHqOqLDanZDd/HxY6DFA1qeApDb62SoDheeD4hdEZsOL5/PDuh6ZZxylvm2aj/Y
zEzFhhXWRbsC0yf9Hwfa6lHNy7FOOAr4tUihknfy4m1eLPlLtCSTlyiuXn6kvvRJ28DK5l0Un55H
rtFXQWqWifeFoGKcXCw7VVgPjEobiBo/+PU36TBU+UxXIow6Syih76XW2+oW0USVrnH9OF/Bha/r
AlL6lj6Vij2fFK46HVSFOuROr4pZMj0/RRiakz9smi/c5/ZloG+4b/um4Mo2mQRtA7CHgFRYTt4U
a6CerVkQWSfi2bFHyYMWMEFYc+yF81s8tGACxquUa9QO2TkBT5A726AXnGrh1y1SM1fwR1ovkyYb
VziJjtCjQZlzYgFxlHR3kIpmFZiF9Hu5jR1BojeffzjbrRG7qGgbJRaxSCX77nyHy5GDzvDOhCEG
bF6NGvnYGmMxn13fhpdwxbR0jZrVmanGMaVajtkexA5i2/3FN92OIeyVmzrwidwUJ1/POySSjAKw
bWRdevcaqztgtMyVQQXYmgJ2QJMNxuoj9o+9agyGO7T1MMY+D1y8eTknc9H4G8Wx2iwv75aWBn2t
uqL2+6W52HyKdpAOuCdxpC/0oM3hE24yKbYwGDZz6NwbQMYIEUBO+hm+tEnGjHxPpm83KO8D3n+Y
KfgLoJLuj6Xg1TJpggXjklH4RRiSY2UH9xGy7Qul6U3be2iN5udu5I5MbhLNB6UJWjxB6wmfzhfa
UZcsc1ykhCNuBXCUvzxYyHbpcb66NksgMQvnq8g4mAQ6JjfTdWvtGg76ZcUlhtoI+jrTz4EEpuaV
T0OoWYwfSXjNVMEF02lx9/4X9kxVxHacIELgaFMAzyMuyCKZNCWGnmgXBEa2M/9Tl3I3OHrinFlm
jyDcCPQcR57tgzqHMW+ZNLeqpYcwlrE1sRXht85l362hA/vvJC6ca6eV/VseTR0lIbdtSQMh+rcU
+35w/jt1nzVZS0A4JmCOlh9AxsbIJrlA1fb2ch8whBHbYkmmkNov60OzcURWjwTf11yPTfJbSMTy
7hcgtDw5GxgGFuWZcvo1Mfeod423eT5vINaKLlaI9dDEADqwP8+i/deYtcoY3LJqwvESRNK1AXMB
oDPOnDixlI+CbrsNfWf1e35PYzT06e/J+A+vFym2TGDGuPUnLshe+DlUUo/hSIGZVijLhQ3VgkPz
bcumRXhMW/FQBzleZOHJutDBYsFJaEj4SG+5x+pVgL7GSSmcbuhOPtMCRyNXXHP3zOoirf/8nuOp
MlCVNPInspwE8884UxW8aHJxlb96wmVWXi3KnOVLtUQ4ll/ZhzgVqZ4VLOhkGVPS2FyZ+lE/xezw
lW6Az6CqA206f0sTPMzGZF5kZMb6IuHLkPKQlGyXEXexhuwtfFNd303lX2LE5QdWgWBWLHHaTBZu
BQsQ5KmxTQMJLcM1IcxX0BkVVaYSxfzgmBwgZ4aVFVGQVpoUiZF1v7m70xxIBmInN6loHpdW91Yd
NTqvC7+ZtQPaoB0PV8T9l72Qy7ulyWSEInvswLqS9jE4HDRqKOKzM41MUu7Y/pMDmBzV5GukNXu5
sxotn899dS0EAxX2fiqzc9GGYhrAVd6JIikf4yvSEiu8FdPlLP9/cKuC0i1Se5IAPPX71edbe5ld
s4mHSdgwecFxpkYXJuFbtVDlA506pFU3xdVkl5llHlROowF2q0P/U8OeC9xUb8QpMBMsfqzqcHw4
ED9oVbPv+3+dV7c9vLSEJQWS0OYCydYIQu2msc2p2fYmETyJpJ5VneIreftNEtH5+iV/SHpZ4rf3
6nwgjln0M62Ts/ka9E7dg0AaoV4uAwavoxvF5Tz56WfQfoSsISCdLSDXrhX8XwxZyod8eZ5vmB2m
3oMUzLxxKkVo0o2OKxvyfeRQgllH9A9h5rAfKswCdYmottWE8F2qZJEKVLrvsN4NGoc3Tkjlj5Bq
+Gbif++2CkavsdOhBsuCZACJWUx1euqLVKZr4X/E3BGz9UMIMZJfDwQlLJWfGa8yq1qsKllDctCY
CrpJesPVfdEflAaMxpewAXAySvJ+GWHHJEBhmVf4R2AzkdjV9dZ+j4UH6CHXOasjb0nEJaB0Gn1m
VJXXhECOpfHvB5LZ9T9xEj1YZPcKbN+tv5nWSF62hbVxVCEeoPdmp6xBKXVm7cnYWThso20AZE/J
ziecJbBeD3fKhGA5sq6D+wwsoyAHMDNZw/QpWw2mGKPkFvfdYH1T+fU1JFDWfL8ChxOnKHZMXaLA
1NtoeWcNP/XJcUn+ve52QHcrBdIvmy+t+0lUiS5xp0ev8nytRclrfvH9FozSTskMMy1a4dvBEiom
XQlHBLQZ3XOf9tPQwBBoz7iwdJcejuXErl9Q1thF3wmJHF5Nj5ca93XweGWnm0RuNuK3G9FovcqP
BQyuiO4dX/H+P5TwHPhzvh52W6h9W0VT9RWhuZsohBf/YhL7Ti8V6Hg2eyhSXV3bu8x0tiggKRUC
RolYT0FsslGbeCFdhnkgYaYGjMMsjUnueljlvba+023ufo3a0bC4uIAqDXExcVXGvhG76SamEkz0
Sk4JJ3BfzrBTX9XMYUyD1OILaTEpdaj9/LY3hVjZkQgnP1xTNsV+4S2ANbIf4o8PvbsGNTPOg34p
SIexU+zQ44dEfU6eJRIwV+06+6yYD0HOO2iXk6fN6Z8Hc/sG3hfS+fSfD0soc+wX0wjRAcfIBdso
HH8IJUqDkjDAtZ4iSKa/Y/hw0r+FvEkZ8YR2UvFD2y7y9r5+4oXDrlBEbyM7yolCfQLB61DeDRwd
QKLjn0+z0EU8QEtBSw1L1eAa6EA4W8ZjIidJNho/TenV3Tmmmq+aUG3rBFu/uLUL75xrvEYisoyJ
wkHxC+WnIQ1taJ5XyEM7MW+EIFclwsSkN03NS1kBjbxna3x5zatJ0eiEiYtc8HhuEKzK+5xUTwYQ
FpbTwl7gjDTL2OEdrWgxgu/IjSTC4mjV0E9wP5Z68nf6nEi8h24XzwUnGKQQZ506y3IS99ETT59X
9FA0BVVM0rKYGxlrcBCjdwIQ1+OjzurHyOqa6FEW1msR2EfnNYQIIQl/3ggnR0919nhR5PVRAi20
bIIalhxNgt6qRVWx8r0r5v3zd9HNt5bvm+U1GIYAaVD1yl/uM8xEsVhnz/Gooj+r95AJfTlNsqoV
Aiea9tIAkxYHDW6N7m2Wa+KJsOXahCDT6qUmJ+A+A0DMFhasxDCXBaegdUE6VhKDSVXFt1Hs5iub
4bDpXX4sdrAfJEJo8Q5crvRY0sPMjhujvmmbZK42spEtY84K7OCT65ny+BCw63ANTJM8oJV6mb3r
CDV8fRYr+QVaV2pi8ZNx1/FsAvVvsHEF88VwBEu8a4iRtPT3DuvL83lSGqCan4rxvY4Jxny4Ems/
NFC7Dt2J6UDHuwc74t/x3/Wv/Ac4saXUJeRohEeVpPDvA+4IZCctBcysW3tNa67EoJqs3ilJWBgc
PF5X2Zc550ibvJD/KHPMpExurEQA3Xwa3Egx3FP/n8HhQhtr1MLxtdEfQ93ZKcI4Z9W4DCbDdPV+
KGXmb4hLG8EGD87cxM90eraeCp3AB3x5ntH9Jk3j4JLjnMAFaXiqxq9CxfBhjwVCZGwcgtq0isxc
jKVE+c7ZzdM5U/RW9F4ECG3VndowCiEyJvElZhEFm5Lz7YKwdkeDy6wqVjd9pCL2+VWOZTNmNz5G
7KU5Z+RdYDpNwZdD3S9PL0/+6VTkeDIQSt3QXfAw+3CxzomxEF5jaxhspRzX3i96VNuQQeTelV4e
nKabOUlMg3BDzhj5fVp4CgJIywBfPwNI209K5aS7HBrH4B8L+y2Et+BVua52L+TTsWWLBRuvwIQa
zGOKdOYQGyBlOUTskPBPE+MQs4I81c29I0D5Q9Z0GEB6ISinR7a2PW6MDUFdXqQdyoMdkkIR6Mhd
GCYwGJ/ejBw+9txH/QO7DiZjTFUoEEpz0hXsiMdnAcRR8JSrFWpGNYuFvOZ55FkZD4+Inn2Bzshs
L9nFqAM7ugNOuTkQ289rT+542yxgLQ5YgqpE80ZD7MZ6/SM87boP3Z+DuTo0Vqaz4Y0pTOaKmlQ4
YFX72/UkZ/RC04+9nl1zvNK07OIBVXcTKSMoA18QajthzW0IILJxF1MP/SlGfqOxJ6d1tfgDzJis
zwH5ILmxNIcP00rhCH9X5PdPGRqx0zeYghFhDbwpZ4sFsW8sRTqoAuV/vKm5XP9mpd1fXJc1W9I1
df454m0rFJjGdF0MXjmUf3YauvwFk9BSld09dRrGIFh53KOao0tbAL80UedvqHtctAEtFCk5q5kM
LyLH4KeNgi9mpwX2qlUVbVEkWgdbbVyMUEOLJWjRS35JJBn2PQGZLLDOBANH0YrDm+poT0n9sigK
kLhQy6Vk6w2z9LZky/IVTFbELn0PySACTUgwPHqwlsJLdshkM7SlGEKo0/Tie1IMuYiEzZCgjc/P
0+/h5fEuf8MFIgJxiL8aaCsA0AS4QeyNlB3bzyVbviva17IDXjPhjUpy5IO8dmJYxcw9dgR8lxwy
BTlPo0j6VOnfeldu5zXeEiP20XbbQ5EZqPLc/TwCsXPCzWmrirQzTH/DrqIfcrJZspfLMclWZmBd
U1iKo8zZQAo+O+QjYkquYRpGF09X/xthbseaHro7k5mwCkLwviTZZPfm5Uhh1HE1M3vf4uFRIKzn
NpwCtEHCMMSuVmZDlJIqRjSKRbc5jwNnlitVKH055+DtrpgiG70KoSrnyqujsC1iKw058A1bFGMB
flo6rCf5jYLBmDt7oxgDmFWtS8iDaC5MgGcc9FrjbW+z8AxOOQOVaVgZwnd7OvwnH5sTJm3lvRnE
MMxzm8F1ofkUBFLyMiuOuv3nES5hIrvcMfKv9HZKtAOgEzhDt39SCOO+2250pi4ODvGWQq9Zi47K
bzWad84UBVcx28thOggEmgYVkQFHaYh4jJWHAP2Dx8UTrvbF3vHpt/Hp1wTD/+JRDtkNjFEXbJuD
Oed/IetJ5mWW9QkLgfgnIXnbPM8615GH1pXkgjSQU3M6GfrlnI7+4kuAATH045xcgr0HqWrkQDEV
+6S5jLhjUvZAXgmPCSSsPEEtsHCKI5ofPZCJHXcczU2GbVX4R5aVDumEpYoSADuIaYPMPyfkTexW
d7oaKaeMFRDYwC4slocrF+6e4Scp9j8pEyL1ZKpkOeZXWob0+ZB90mLctm1mwasqrLE4aSIIrQwr
LKjKqdz/9LdylGe0UlrhxZrwqETBd0I+VjZt6mKyl4KOWpm/tIjCD0TlBfaofU0YM4FhZqd3nrrJ
y2tHuSfaoSFgEwRdXf5qj2uc4Y6W1yqIaErPvL+BhCTUn2kB+g7e93i7cCB0xDsoW0XmcypztTSi
0HX/JpHXamQxrPSFpGvQMmtt6t5czU+v7eBVKlUQYEcnI+7R2gonowzPPmJz0cQ8oHep3GAURqjO
Cn2EWjTLwhyVyoASdv0UWm2uwPpKe1Jo+rLS85wRdkyjkuruXQbyg2r2pYFLgf/kClsfzcib2YFp
6LMNlRQINe9vvZFtsexTRnwqhTdkZAklMZiiwrXaDXio/otmGU65K2L9KqbxhuDCi6MNrUV0wnii
TPdsyZp6sBTsE2HAY1IJAE6uO3sAgvSq4s/E9kgtsG6kYG+p+CpmhoaStEDP4tsaztjFPdwkWZND
bZx81ew47WqFUKzHg5T2nc5Lqbe8MvBaqRD0p7GmiKhWTEf6J/XRoCSFYOQQ498FkXUSt/yXWnIs
bAdoHMLbri15I0mi4awHSb0WBcxmtS+DjEVOZfi3OKJ3Eko4Paa14Xyv6S9r/uT6m22FAv5oiJ3d
THAyuoeMaW+f5kFPphZ4XKgKrhrUa3Ig7Em7w+iX76w9YHwdTmJBnYxVCsUcimNk8PgK4RPlynKl
x4ViUx37yJPco5GQg2HeqHT1foNxzTQQLaz1RI0laiwfzUSvtw+MssOXORK4PsTKI8DcErACaldA
CYqM6OVXQprpY0j4ydpyWTw49GDnaDMkYsv6IjV+OVMcoNarCFNROMAaKpRXYlmloifEA/6Bj3K1
LaCYTpoOp5za6ldyJFjOggAkPaegabS97WUYKFkAV0OIC3p7fgTmWVubYLEKi3CbFVE/yRvBAL/n
BY6jvN+xIEdrsHcRrYAlL3LCUoSCKnvTbbnFMhOZ+zgMYGDNcH6ybiDTi8Mw6XoRJTqEqJ/lFMlS
sMjMPYPNgvCyLAd9gtF+ugTbLsUAd23atn53c8Jia4wdkFpF7cm2v4ULWYlJqLS3jlxvdKmP5OYT
je7k/kdO41NnNKUyHtmK2wiKEl5HtNd2xQ7rED7H/LFE1HbDAI0qWG3EI2dU3T2Pz82je/UQSkBF
yHBWwG/N5++2DB+src68gAaEAZ6rj4sZ4Vr5ILuL0B4HkOK53q5uLnrP/Y9uDPLYP3XD2vFB/0at
KdvvRkIeYgics5sR3jH7Jan3Vn+/hOzGEOSBdCVxPSCilNwWlwLHwMXZ3fm+77TbPJj0qLyRacvv
JtedqJG9yqJzvUYu9a5M8tNMgw9gicExjN2omIsdQre28uPRVpLCZlgO27s3jzaMr9gMBSq4cAkJ
ukPnHW52szaaUaJGMqCZ1c0KstY77Pb+mngqp7fQg8s6kiiTALvWF+ukYPN8cdBhIhV1/Rrgv78a
g0jopdOQ3uN6HPzWjj/Sotq58eGHUdLkZTj7YAvXtPaA/v8uwAHC2E8Gd3Y14Ox8rBO2cXcHEllC
HzXOsg53TqQN3wmR/xyUa5nwR4DrKH7/CRSPLWfYQ+CXIODyt71BjdHzs+FOpSKUYJa4yq4TbjaH
PCKjPr/6bIBSzsXw3Yz8cY2gmAH4xPaayA80Xlm+1+eITTbyyJ+FePGIwDlbiQ9VbSAEWRqRki8T
JgeCmSCGrmlRjy+vseBX9QWg
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
