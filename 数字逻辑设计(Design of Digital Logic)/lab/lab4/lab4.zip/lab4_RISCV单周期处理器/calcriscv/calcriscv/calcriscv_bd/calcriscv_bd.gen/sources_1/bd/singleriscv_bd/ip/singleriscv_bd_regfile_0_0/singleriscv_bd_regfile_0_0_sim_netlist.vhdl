-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:23:13 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top singleriscv_bd_regfile_0_0 -prefix
--               singleriscv_bd_regfile_0_0_ singleriscv_bd_regfile_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_regfile_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_regfile_0_0_regfile is
  port (
    rd1 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rd2 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    a1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    a2 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    clk : in STD_LOGIC;
    we3 : in STD_LOGIC;
    wd3 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    a3 : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
end singleriscv_bd_regfile_0_0_regfile;

architecture STRUCTURE of singleriscv_bd_regfile_0_0_regfile is
  signal rd10 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal rd20 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_rf_reg_r1_0_31_0_5_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_12_17_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_18_23_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_24_29_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_30_31_DOB_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_30_31_DOC_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_30_31_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r1_0_31_6_11_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_0_5_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_12_17_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_18_23_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_24_29_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_30_31_DOB_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_30_31_DOC_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_30_31_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal NLW_rf_reg_r2_0_31_6_11_DOD_UNCONNECTED : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_0_5 : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_0_5 : label is 1024;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_0_5 : label is "inst/rf";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_0_5 : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of rf_reg_r1_0_31_0_5 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of rf_reg_r1_0_31_0_5 : label is 31;
  attribute ram_offset : integer;
  attribute ram_offset of rf_reg_r1_0_31_0_5 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of rf_reg_r1_0_31_0_5 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of rf_reg_r1_0_31_0_5 : label is 5;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_12_17 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_12_17 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_12_17 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_12_17 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r1_0_31_12_17 : label is 0;
  attribute ram_addr_end of rf_reg_r1_0_31_12_17 : label is 31;
  attribute ram_offset of rf_reg_r1_0_31_12_17 : label is 0;
  attribute ram_slice_begin of rf_reg_r1_0_31_12_17 : label is 12;
  attribute ram_slice_end of rf_reg_r1_0_31_12_17 : label is 17;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_18_23 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_18_23 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_18_23 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_18_23 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r1_0_31_18_23 : label is 0;
  attribute ram_addr_end of rf_reg_r1_0_31_18_23 : label is 31;
  attribute ram_offset of rf_reg_r1_0_31_18_23 : label is 0;
  attribute ram_slice_begin of rf_reg_r1_0_31_18_23 : label is 18;
  attribute ram_slice_end of rf_reg_r1_0_31_18_23 : label is 23;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_24_29 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_24_29 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_24_29 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_24_29 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r1_0_31_24_29 : label is 0;
  attribute ram_addr_end of rf_reg_r1_0_31_24_29 : label is 31;
  attribute ram_offset of rf_reg_r1_0_31_24_29 : label is 0;
  attribute ram_slice_begin of rf_reg_r1_0_31_24_29 : label is 24;
  attribute ram_slice_end of rf_reg_r1_0_31_24_29 : label is 29;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_30_31 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_30_31 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_30_31 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_30_31 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r1_0_31_30_31 : label is 0;
  attribute ram_addr_end of rf_reg_r1_0_31_30_31 : label is 31;
  attribute ram_offset of rf_reg_r1_0_31_30_31 : label is 0;
  attribute ram_slice_begin of rf_reg_r1_0_31_30_31 : label is 30;
  attribute ram_slice_end of rf_reg_r1_0_31_30_31 : label is 31;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r1_0_31_6_11 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r1_0_31_6_11 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r1_0_31_6_11 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r1_0_31_6_11 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r1_0_31_6_11 : label is 0;
  attribute ram_addr_end of rf_reg_r1_0_31_6_11 : label is 31;
  attribute ram_offset of rf_reg_r1_0_31_6_11 : label is 0;
  attribute ram_slice_begin of rf_reg_r1_0_31_6_11 : label is 6;
  attribute ram_slice_end of rf_reg_r1_0_31_6_11 : label is 11;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_0_5 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_0_5 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_0_5 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_0_5 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_0_5 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_0_5 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_0_5 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_0_5 : label is 0;
  attribute ram_slice_end of rf_reg_r2_0_31_0_5 : label is 5;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_12_17 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_12_17 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_12_17 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_12_17 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_12_17 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_12_17 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_12_17 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_12_17 : label is 12;
  attribute ram_slice_end of rf_reg_r2_0_31_12_17 : label is 17;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_18_23 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_18_23 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_18_23 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_18_23 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_18_23 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_18_23 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_18_23 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_18_23 : label is 18;
  attribute ram_slice_end of rf_reg_r2_0_31_18_23 : label is 23;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_24_29 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_24_29 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_24_29 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_24_29 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_24_29 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_24_29 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_24_29 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_24_29 : label is 24;
  attribute ram_slice_end of rf_reg_r2_0_31_24_29 : label is 29;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_30_31 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_30_31 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_30_31 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_30_31 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_30_31 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_30_31 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_30_31 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_30_31 : label is 30;
  attribute ram_slice_end of rf_reg_r2_0_31_30_31 : label is 31;
  attribute METHODOLOGY_DRC_VIOS of rf_reg_r2_0_31_6_11 : label is "";
  attribute RTL_RAM_BITS of rf_reg_r2_0_31_6_11 : label is 1024;
  attribute RTL_RAM_NAME of rf_reg_r2_0_31_6_11 : label is "inst/rf";
  attribute RTL_RAM_TYPE of rf_reg_r2_0_31_6_11 : label is "RAM_SDP";
  attribute ram_addr_begin of rf_reg_r2_0_31_6_11 : label is 0;
  attribute ram_addr_end of rf_reg_r2_0_31_6_11 : label is 31;
  attribute ram_offset of rf_reg_r2_0_31_6_11 : label is 0;
  attribute ram_slice_begin of rf_reg_r2_0_31_6_11 : label is 6;
  attribute ram_slice_end of rf_reg_r2_0_31_6_11 : label is 11;
begin
\rd1[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(0),
      O => rd1(0)
    );
\rd1[10]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(10),
      O => rd1(10)
    );
\rd1[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(11),
      O => rd1(11)
    );
\rd1[12]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(12),
      O => rd1(12)
    );
\rd1[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(13),
      O => rd1(13)
    );
\rd1[14]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(14),
      O => rd1(14)
    );
\rd1[15]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(15),
      O => rd1(15)
    );
\rd1[16]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(16),
      O => rd1(16)
    );
\rd1[17]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(17),
      O => rd1(17)
    );
\rd1[18]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(18),
      O => rd1(18)
    );
\rd1[19]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(19),
      O => rd1(19)
    );
\rd1[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(1),
      O => rd1(1)
    );
\rd1[20]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(20),
      O => rd1(20)
    );
\rd1[21]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(21),
      O => rd1(21)
    );
\rd1[22]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(22),
      O => rd1(22)
    );
\rd1[23]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(23),
      O => rd1(23)
    );
\rd1[24]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(24),
      O => rd1(24)
    );
\rd1[25]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(25),
      O => rd1(25)
    );
\rd1[26]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(26),
      O => rd1(26)
    );
\rd1[27]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(27),
      O => rd1(27)
    );
\rd1[28]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(28),
      O => rd1(28)
    );
\rd1[29]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(29),
      O => rd1(29)
    );
\rd1[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(2),
      O => rd1(2)
    );
\rd1[30]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(30),
      O => rd1(30)
    );
\rd1[31]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(31),
      O => rd1(31)
    );
\rd1[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(3),
      O => rd1(3)
    );
\rd1[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(4),
      O => rd1(4)
    );
\rd1[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(5),
      O => rd1(5)
    );
\rd1[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(6),
      O => rd1(6)
    );
\rd1[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(7),
      O => rd1(7)
    );
\rd1[8]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(8),
      O => rd1(8)
    );
\rd1[9]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a1(4),
      I1 => a1(3),
      I2 => a1(1),
      I3 => a1(0),
      I4 => a1(2),
      I5 => rd10(9),
      O => rd1(9)
    );
\rd2[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(0),
      O => rd2(0)
    );
\rd2[10]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(10),
      O => rd2(10)
    );
\rd2[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(11),
      O => rd2(11)
    );
\rd2[12]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(12),
      O => rd2(12)
    );
\rd2[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(13),
      O => rd2(13)
    );
\rd2[14]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(14),
      O => rd2(14)
    );
\rd2[15]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(15),
      O => rd2(15)
    );
\rd2[16]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(16),
      O => rd2(16)
    );
\rd2[17]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(17),
      O => rd2(17)
    );
\rd2[18]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(18),
      O => rd2(18)
    );
\rd2[19]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(19),
      O => rd2(19)
    );
\rd2[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(1),
      O => rd2(1)
    );
\rd2[20]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(20),
      O => rd2(20)
    );
\rd2[21]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(21),
      O => rd2(21)
    );
\rd2[22]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(22),
      O => rd2(22)
    );
\rd2[23]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(23),
      O => rd2(23)
    );
\rd2[24]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(24),
      O => rd2(24)
    );
\rd2[25]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(25),
      O => rd2(25)
    );
\rd2[26]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(26),
      O => rd2(26)
    );
\rd2[27]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(27),
      O => rd2(27)
    );
\rd2[28]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(28),
      O => rd2(28)
    );
\rd2[29]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(29),
      O => rd2(29)
    );
\rd2[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(2),
      O => rd2(2)
    );
\rd2[30]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(30),
      O => rd2(30)
    );
\rd2[31]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(31),
      O => rd2(31)
    );
\rd2[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(3),
      O => rd2(3)
    );
\rd2[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(4),
      O => rd2(4)
    );
\rd2[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(5),
      O => rd2(5)
    );
\rd2[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(6),
      O => rd2(6)
    );
\rd2[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(7),
      O => rd2(7)
    );
\rd2[8]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(8),
      O => rd2(8)
    );
\rd2[9]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFE00000000"
    )
        port map (
      I0 => a2(4),
      I1 => a2(3),
      I2 => a2(1),
      I3 => a2(0),
      I4 => a2(2),
      I5 => rd20(9),
      O => rd2(9)
    );
rf_reg_r1_0_31_0_5: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(1 downto 0),
      DIB(1 downto 0) => wd3(3 downto 2),
      DIC(1 downto 0) => wd3(5 downto 4),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(1 downto 0),
      DOB(1 downto 0) => rd10(3 downto 2),
      DOC(1 downto 0) => rd10(5 downto 4),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_0_5_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r1_0_31_12_17: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(13 downto 12),
      DIB(1 downto 0) => wd3(15 downto 14),
      DIC(1 downto 0) => wd3(17 downto 16),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(13 downto 12),
      DOB(1 downto 0) => rd10(15 downto 14),
      DOC(1 downto 0) => rd10(17 downto 16),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_12_17_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r1_0_31_18_23: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(19 downto 18),
      DIB(1 downto 0) => wd3(21 downto 20),
      DIC(1 downto 0) => wd3(23 downto 22),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(19 downto 18),
      DOB(1 downto 0) => rd10(21 downto 20),
      DOC(1 downto 0) => rd10(23 downto 22),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_18_23_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r1_0_31_24_29: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(25 downto 24),
      DIB(1 downto 0) => wd3(27 downto 26),
      DIC(1 downto 0) => wd3(29 downto 28),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(25 downto 24),
      DOB(1 downto 0) => rd10(27 downto 26),
      DOC(1 downto 0) => rd10(29 downto 28),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_24_29_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r1_0_31_30_31: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(31 downto 30),
      DIB(1 downto 0) => B"00",
      DIC(1 downto 0) => B"00",
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(31 downto 30),
      DOB(1 downto 0) => NLW_rf_reg_r1_0_31_30_31_DOB_UNCONNECTED(1 downto 0),
      DOC(1 downto 0) => NLW_rf_reg_r1_0_31_30_31_DOC_UNCONNECTED(1 downto 0),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_30_31_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r1_0_31_6_11: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a1(4 downto 0),
      ADDRB(4 downto 0) => a1(4 downto 0),
      ADDRC(4 downto 0) => a1(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(7 downto 6),
      DIB(1 downto 0) => wd3(9 downto 8),
      DIC(1 downto 0) => wd3(11 downto 10),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd10(7 downto 6),
      DOB(1 downto 0) => rd10(9 downto 8),
      DOC(1 downto 0) => rd10(11 downto 10),
      DOD(1 downto 0) => NLW_rf_reg_r1_0_31_6_11_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_0_5: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(1 downto 0),
      DIB(1 downto 0) => wd3(3 downto 2),
      DIC(1 downto 0) => wd3(5 downto 4),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(1 downto 0),
      DOB(1 downto 0) => rd20(3 downto 2),
      DOC(1 downto 0) => rd20(5 downto 4),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_0_5_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_12_17: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(13 downto 12),
      DIB(1 downto 0) => wd3(15 downto 14),
      DIC(1 downto 0) => wd3(17 downto 16),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(13 downto 12),
      DOB(1 downto 0) => rd20(15 downto 14),
      DOC(1 downto 0) => rd20(17 downto 16),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_12_17_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_18_23: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(19 downto 18),
      DIB(1 downto 0) => wd3(21 downto 20),
      DIC(1 downto 0) => wd3(23 downto 22),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(19 downto 18),
      DOB(1 downto 0) => rd20(21 downto 20),
      DOC(1 downto 0) => rd20(23 downto 22),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_18_23_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_24_29: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(25 downto 24),
      DIB(1 downto 0) => wd3(27 downto 26),
      DIC(1 downto 0) => wd3(29 downto 28),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(25 downto 24),
      DOB(1 downto 0) => rd20(27 downto 26),
      DOC(1 downto 0) => rd20(29 downto 28),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_24_29_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_30_31: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(31 downto 30),
      DIB(1 downto 0) => B"00",
      DIC(1 downto 0) => B"00",
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(31 downto 30),
      DOB(1 downto 0) => NLW_rf_reg_r2_0_31_30_31_DOB_UNCONNECTED(1 downto 0),
      DOC(1 downto 0) => NLW_rf_reg_r2_0_31_30_31_DOC_UNCONNECTED(1 downto 0),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_30_31_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
rf_reg_r2_0_31_6_11: unisim.vcomponents.RAM32M
     port map (
      ADDRA(4 downto 0) => a2(4 downto 0),
      ADDRB(4 downto 0) => a2(4 downto 0),
      ADDRC(4 downto 0) => a2(4 downto 0),
      ADDRD(4 downto 0) => a3(4 downto 0),
      DIA(1 downto 0) => wd3(7 downto 6),
      DIB(1 downto 0) => wd3(9 downto 8),
      DIC(1 downto 0) => wd3(11 downto 10),
      DID(1 downto 0) => B"00",
      DOA(1 downto 0) => rd20(7 downto 6),
      DOB(1 downto 0) => rd20(9 downto 8),
      DOC(1 downto 0) => rd20(11 downto 10),
      DOD(1 downto 0) => NLW_rf_reg_r2_0_31_6_11_DOD_UNCONNECTED(1 downto 0),
      WCLK => clk,
      WE => we3
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_regfile_0_0 is
  port (
    clk : in STD_LOGIC;
    we3 : in STD_LOGIC;
    a1 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    a2 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    a3 : in STD_LOGIC_VECTOR ( 4 downto 0 );
    wd3 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    rd1 : out STD_LOGIC_VECTOR ( 31 downto 0 );
    rd2 : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of singleriscv_bd_regfile_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of singleriscv_bd_regfile_0_0 : entity is "singleriscv_bd_regfile_0_0,regfile,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of singleriscv_bd_regfile_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of singleriscv_bd_regfile_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of singleriscv_bd_regfile_0_0 : entity is "regfile,Vivado 2020.2";
end singleriscv_bd_regfile_0_0;

architecture STRUCTURE of singleriscv_bd_regfile_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN singleriscv_bd_clk_0, INSERT_VIP 0";
begin
inst: entity work.singleriscv_bd_regfile_0_0_regfile
     port map (
      a1(4 downto 0) => a1(4 downto 0),
      a2(4 downto 0) => a2(4 downto 0),
      a3(4 downto 0) => a3(4 downto 0),
      clk => clk,
      rd1(31 downto 0) => rd1(31 downto 0),
      rd2(31 downto 0) => rd2(31 downto 0),
      wd3(31 downto 0) => wd3(31 downto 0),
      we3 => we3
    );
end STRUCTURE;
