vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xil_defaultlib

vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -sv \
"../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/bin2bcd.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/sim/bin2BCD_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

