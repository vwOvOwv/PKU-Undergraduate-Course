// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:27:20 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top singleriscv_bd_controller_0_0 -prefix
//               singleriscv_bd_controller_0_0_ singleriscv_bd_controller_0_0_stub.v
// Design      : singleriscv_bd_controller_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "controller,Vivado 2020.2" *)
module singleriscv_bd_controller_0_0(op, funct3, funct7b5, zero, lessthan, ResultSrc, 
  MemWrite, PCSrc, ALUSrc, RegWrite, Jump, JumpR, UType, AUIPC, ImmSrc, ALUControl)
/* synthesis syn_black_box black_box_pad_pin="op[6:0],funct3[2:0],funct7b5,zero,lessthan,ResultSrc[1:0],MemWrite,PCSrc,ALUSrc,RegWrite,Jump,JumpR,UType,AUIPC,ImmSrc[1:0],ALUControl[3:0]" */;
  input [6:0]op;
  input [2:0]funct3;
  input funct7b5;
  input zero;
  input lessthan;
  output [1:0]ResultSrc;
  output MemWrite;
  output PCSrc;
  output ALUSrc;
  output RegWrite;
  output Jump;
  output JumpR;
  output UType;
  output AUIPC;
  output [1:0]ImmSrc;
  output [3:0]ALUControl;
endmodule
