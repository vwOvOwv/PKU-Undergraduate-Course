vlib work
vlib riviera

vlib riviera/xil_defaultlib

vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xil_defaultlib  -sv2k12 \
"../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/bcd2bin.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/sim/BCD2bin_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

