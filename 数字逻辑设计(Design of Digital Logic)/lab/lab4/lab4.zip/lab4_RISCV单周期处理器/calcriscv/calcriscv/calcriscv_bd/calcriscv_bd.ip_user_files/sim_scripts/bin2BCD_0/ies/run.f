-makelib ies_lib/xil_defaultlib -sv \
  "../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/bin2bcd.sv" \
  "../../../../calcriscv_bd.gen/sources_1/ip/bin2BCD_0/sim/bin2BCD_0.sv" \
-endlib
-makelib ies_lib/xil_defaultlib \
  glbl.v
-endlib

