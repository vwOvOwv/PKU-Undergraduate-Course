// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:27:17 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ singleriscv_bd_dmem_io_0_0_sim_netlist.v
// Design      : singleriscv_bd_dmem_io_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dmem_io
   (ReadData,
    PortC,
    PortD,
    DataAddr,
    MemWrite,
    reset,
    WriteData,
    clk,
    PortB,
    PortA);
  output [31:0]ReadData;
  output [13:0]PortC;
  output [15:0]PortD;
  input [31:0]DataAddr;
  input MemWrite;
  input reset;
  input [31:0]WriteData;
  input clk;
  input [13:0]PortB;
  input [3:0]PortA;

  wire [31:0]DataAddr;
  wire MemWrite;
  wire [3:0]PortA;
  wire [13:0]PortB;
  wire [13:0]PortC;
  wire PortC0;
  wire \PortC_reg_reg_n_0_[14] ;
  wire \PortC_reg_reg_n_0_[15] ;
  wire \PortC_reg_reg_n_0_[16] ;
  wire \PortC_reg_reg_n_0_[17] ;
  wire \PortC_reg_reg_n_0_[18] ;
  wire \PortC_reg_reg_n_0_[19] ;
  wire \PortC_reg_reg_n_0_[20] ;
  wire \PortC_reg_reg_n_0_[21] ;
  wire \PortC_reg_reg_n_0_[22] ;
  wire \PortC_reg_reg_n_0_[23] ;
  wire \PortC_reg_reg_n_0_[24] ;
  wire \PortC_reg_reg_n_0_[25] ;
  wire \PortC_reg_reg_n_0_[26] ;
  wire \PortC_reg_reg_n_0_[27] ;
  wire \PortC_reg_reg_n_0_[28] ;
  wire \PortC_reg_reg_n_0_[29] ;
  wire \PortC_reg_reg_n_0_[30] ;
  wire \PortC_reg_reg_n_0_[31] ;
  wire [15:0]PortD;
  wire PortD0;
  wire \PortD_reg_reg_n_0_[16] ;
  wire \PortD_reg_reg_n_0_[17] ;
  wire \PortD_reg_reg_n_0_[18] ;
  wire \PortD_reg_reg_n_0_[19] ;
  wire \PortD_reg_reg_n_0_[20] ;
  wire \PortD_reg_reg_n_0_[21] ;
  wire \PortD_reg_reg_n_0_[22] ;
  wire \PortD_reg_reg_n_0_[23] ;
  wire \PortD_reg_reg_n_0_[24] ;
  wire \PortD_reg_reg_n_0_[25] ;
  wire \PortD_reg_reg_n_0_[26] ;
  wire \PortD_reg_reg_n_0_[27] ;
  wire \PortD_reg_reg_n_0_[28] ;
  wire \PortD_reg_reg_n_0_[29] ;
  wire \PortD_reg_reg_n_0_[30] ;
  wire \PortD_reg_reg_n_0_[31] ;
  wire [31:0]ReadData;
  wire [31:0]ReadDataRAM;
  wire \ReadData_reg[0]_i_1_n_0 ;
  wire \ReadData_reg[0]_i_2_n_0 ;
  wire \ReadData_reg[0]_i_3_n_0 ;
  wire \ReadData_reg[10]_i_1_n_0 ;
  wire \ReadData_reg[10]_i_2_n_0 ;
  wire \ReadData_reg[11]_i_1_n_0 ;
  wire \ReadData_reg[11]_i_2_n_0 ;
  wire \ReadData_reg[12]_i_1_n_0 ;
  wire \ReadData_reg[12]_i_2_n_0 ;
  wire \ReadData_reg[13]_i_1_n_0 ;
  wire \ReadData_reg[13]_i_2_n_0 ;
  wire \ReadData_reg[13]_i_3_n_0 ;
  wire \ReadData_reg[13]_i_4_n_0 ;
  wire \ReadData_reg[14]_i_1_n_0 ;
  wire \ReadData_reg[15]_i_1_n_0 ;
  wire \ReadData_reg[16]_i_1_n_0 ;
  wire \ReadData_reg[17]_i_1_n_0 ;
  wire \ReadData_reg[18]_i_1_n_0 ;
  wire \ReadData_reg[19]_i_1_n_0 ;
  wire \ReadData_reg[1]_i_1_n_0 ;
  wire \ReadData_reg[1]_i_2_n_0 ;
  wire \ReadData_reg[1]_i_3_n_0 ;
  wire \ReadData_reg[20]_i_1_n_0 ;
  wire \ReadData_reg[21]_i_1_n_0 ;
  wire \ReadData_reg[22]_i_1_n_0 ;
  wire \ReadData_reg[23]_i_1_n_0 ;
  wire \ReadData_reg[24]_i_1_n_0 ;
  wire \ReadData_reg[25]_i_1_n_0 ;
  wire \ReadData_reg[26]_i_1_n_0 ;
  wire \ReadData_reg[27]_i_1_n_0 ;
  wire \ReadData_reg[28]_i_1_n_0 ;
  wire \ReadData_reg[29]_i_1_n_0 ;
  wire \ReadData_reg[2]_i_1_n_0 ;
  wire \ReadData_reg[2]_i_2_n_0 ;
  wire \ReadData_reg[2]_i_3_n_0 ;
  wire \ReadData_reg[30]_i_1_n_0 ;
  wire \ReadData_reg[31]_i_10_n_0 ;
  wire \ReadData_reg[31]_i_11_n_0 ;
  wire \ReadData_reg[31]_i_12_n_0 ;
  wire \ReadData_reg[31]_i_13_n_0 ;
  wire \ReadData_reg[31]_i_14_n_0 ;
  wire \ReadData_reg[31]_i_15_n_0 ;
  wire \ReadData_reg[31]_i_16_n_0 ;
  wire \ReadData_reg[31]_i_1_n_0 ;
  wire \ReadData_reg[31]_i_2_n_0 ;
  wire \ReadData_reg[31]_i_3_n_0 ;
  wire \ReadData_reg[31]_i_4_n_0 ;
  wire \ReadData_reg[31]_i_5_n_0 ;
  wire \ReadData_reg[31]_i_6_n_0 ;
  wire \ReadData_reg[31]_i_7_n_0 ;
  wire \ReadData_reg[31]_i_8_n_0 ;
  wire \ReadData_reg[31]_i_9_n_0 ;
  wire \ReadData_reg[3]_i_1_n_0 ;
  wire \ReadData_reg[3]_i_2_n_0 ;
  wire \ReadData_reg[3]_i_3_n_0 ;
  wire \ReadData_reg[4]_i_1_n_0 ;
  wire \ReadData_reg[4]_i_2_n_0 ;
  wire \ReadData_reg[5]_i_1_n_0 ;
  wire \ReadData_reg[5]_i_2_n_0 ;
  wire \ReadData_reg[6]_i_1_n_0 ;
  wire \ReadData_reg[6]_i_2_n_0 ;
  wire \ReadData_reg[7]_i_1_n_0 ;
  wire \ReadData_reg[7]_i_2_n_0 ;
  wire \ReadData_reg[8]_i_1_n_0 ;
  wire \ReadData_reg[8]_i_2_n_0 ;
  wire \ReadData_reg[9]_i_1_n_0 ;
  wire \ReadData_reg[9]_i_2_n_0 ;
  wire [31:0]WriteData;
  wire clk;
  wire p_0_in;
  wire reset;

  LUT2 #(
    .INIT(4'h8)) 
    \PortC_reg[13]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(MemWrite),
        .O(PortC0));
  FDRE \PortC_reg_reg[0] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[0]),
        .Q(PortC[0]),
        .R(reset));
  FDRE \PortC_reg_reg[10] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[10]),
        .Q(PortC[10]),
        .R(reset));
  FDRE \PortC_reg_reg[11] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[11]),
        .Q(PortC[11]),
        .R(reset));
  FDRE \PortC_reg_reg[12] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[12]),
        .Q(PortC[12]),
        .R(reset));
  FDRE \PortC_reg_reg[13] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[13]),
        .Q(PortC[13]),
        .R(reset));
  FDRE \PortC_reg_reg[14] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[14]),
        .Q(\PortC_reg_reg_n_0_[14] ),
        .R(reset));
  FDRE \PortC_reg_reg[15] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[15]),
        .Q(\PortC_reg_reg_n_0_[15] ),
        .R(reset));
  FDRE \PortC_reg_reg[16] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[16]),
        .Q(\PortC_reg_reg_n_0_[16] ),
        .R(reset));
  FDRE \PortC_reg_reg[17] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[17]),
        .Q(\PortC_reg_reg_n_0_[17] ),
        .R(reset));
  FDRE \PortC_reg_reg[18] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[18]),
        .Q(\PortC_reg_reg_n_0_[18] ),
        .R(reset));
  FDRE \PortC_reg_reg[19] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[19]),
        .Q(\PortC_reg_reg_n_0_[19] ),
        .R(reset));
  FDRE \PortC_reg_reg[1] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[1]),
        .Q(PortC[1]),
        .R(reset));
  FDRE \PortC_reg_reg[20] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[20]),
        .Q(\PortC_reg_reg_n_0_[20] ),
        .R(reset));
  FDRE \PortC_reg_reg[21] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[21]),
        .Q(\PortC_reg_reg_n_0_[21] ),
        .R(reset));
  FDRE \PortC_reg_reg[22] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[22]),
        .Q(\PortC_reg_reg_n_0_[22] ),
        .R(reset));
  FDRE \PortC_reg_reg[23] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[23]),
        .Q(\PortC_reg_reg_n_0_[23] ),
        .R(reset));
  FDRE \PortC_reg_reg[24] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[24]),
        .Q(\PortC_reg_reg_n_0_[24] ),
        .R(reset));
  FDRE \PortC_reg_reg[25] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[25]),
        .Q(\PortC_reg_reg_n_0_[25] ),
        .R(reset));
  FDRE \PortC_reg_reg[26] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[26]),
        .Q(\PortC_reg_reg_n_0_[26] ),
        .R(reset));
  FDRE \PortC_reg_reg[27] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[27]),
        .Q(\PortC_reg_reg_n_0_[27] ),
        .R(reset));
  FDRE \PortC_reg_reg[28] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[28]),
        .Q(\PortC_reg_reg_n_0_[28] ),
        .R(reset));
  FDRE \PortC_reg_reg[29] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[29]),
        .Q(\PortC_reg_reg_n_0_[29] ),
        .R(reset));
  FDRE \PortC_reg_reg[2] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[2]),
        .Q(PortC[2]),
        .R(reset));
  FDRE \PortC_reg_reg[30] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[30]),
        .Q(\PortC_reg_reg_n_0_[30] ),
        .R(reset));
  FDRE \PortC_reg_reg[31] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[31]),
        .Q(\PortC_reg_reg_n_0_[31] ),
        .R(reset));
  FDRE \PortC_reg_reg[3] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[3]),
        .Q(PortC[3]),
        .R(reset));
  FDRE \PortC_reg_reg[4] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[4]),
        .Q(PortC[4]),
        .R(reset));
  FDRE \PortC_reg_reg[5] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[5]),
        .Q(PortC[5]),
        .R(reset));
  FDRE \PortC_reg_reg[6] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[6]),
        .Q(PortC[6]),
        .R(reset));
  FDRE \PortC_reg_reg[7] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[7]),
        .Q(PortC[7]),
        .R(reset));
  FDRE \PortC_reg_reg[8] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[8]),
        .Q(PortC[8]),
        .R(reset));
  FDRE \PortC_reg_reg[9] 
       (.C(clk),
        .CE(PortC0),
        .D(WriteData[9]),
        .Q(PortC[9]),
        .R(reset));
  LUT2 #(
    .INIT(4'h8)) 
    \PortD_reg[15]_i_1 
       (.I0(\ReadData_reg[31]_i_4_n_0 ),
        .I1(MemWrite),
        .O(PortD0));
  FDRE \PortD_reg_reg[0] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[0]),
        .Q(PortD[0]),
        .R(reset));
  FDRE \PortD_reg_reg[10] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[10]),
        .Q(PortD[10]),
        .R(reset));
  FDRE \PortD_reg_reg[11] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[11]),
        .Q(PortD[11]),
        .R(reset));
  FDRE \PortD_reg_reg[12] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[12]),
        .Q(PortD[12]),
        .R(reset));
  FDRE \PortD_reg_reg[13] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[13]),
        .Q(PortD[13]),
        .R(reset));
  FDRE \PortD_reg_reg[14] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[14]),
        .Q(PortD[14]),
        .R(reset));
  FDRE \PortD_reg_reg[15] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[15]),
        .Q(PortD[15]),
        .R(reset));
  FDRE \PortD_reg_reg[16] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[16]),
        .Q(\PortD_reg_reg_n_0_[16] ),
        .R(reset));
  FDRE \PortD_reg_reg[17] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[17]),
        .Q(\PortD_reg_reg_n_0_[17] ),
        .R(reset));
  FDRE \PortD_reg_reg[18] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[18]),
        .Q(\PortD_reg_reg_n_0_[18] ),
        .R(reset));
  FDRE \PortD_reg_reg[19] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[19]),
        .Q(\PortD_reg_reg_n_0_[19] ),
        .R(reset));
  FDRE \PortD_reg_reg[1] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[1]),
        .Q(PortD[1]),
        .R(reset));
  FDRE \PortD_reg_reg[20] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[20]),
        .Q(\PortD_reg_reg_n_0_[20] ),
        .R(reset));
  FDRE \PortD_reg_reg[21] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[21]),
        .Q(\PortD_reg_reg_n_0_[21] ),
        .R(reset));
  FDRE \PortD_reg_reg[22] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[22]),
        .Q(\PortD_reg_reg_n_0_[22] ),
        .R(reset));
  FDRE \PortD_reg_reg[23] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[23]),
        .Q(\PortD_reg_reg_n_0_[23] ),
        .R(reset));
  FDRE \PortD_reg_reg[24] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[24]),
        .Q(\PortD_reg_reg_n_0_[24] ),
        .R(reset));
  FDRE \PortD_reg_reg[25] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[25]),
        .Q(\PortD_reg_reg_n_0_[25] ),
        .R(reset));
  FDRE \PortD_reg_reg[26] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[26]),
        .Q(\PortD_reg_reg_n_0_[26] ),
        .R(reset));
  FDRE \PortD_reg_reg[27] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[27]),
        .Q(\PortD_reg_reg_n_0_[27] ),
        .R(reset));
  FDRE \PortD_reg_reg[28] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[28]),
        .Q(\PortD_reg_reg_n_0_[28] ),
        .R(reset));
  FDRE \PortD_reg_reg[29] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[29]),
        .Q(\PortD_reg_reg_n_0_[29] ),
        .R(reset));
  FDRE \PortD_reg_reg[2] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[2]),
        .Q(PortD[2]),
        .R(reset));
  FDRE \PortD_reg_reg[30] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[30]),
        .Q(\PortD_reg_reg_n_0_[30] ),
        .R(reset));
  FDRE \PortD_reg_reg[31] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[31]),
        .Q(\PortD_reg_reg_n_0_[31] ),
        .R(reset));
  FDRE \PortD_reg_reg[3] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[3]),
        .Q(PortD[3]),
        .R(reset));
  FDRE \PortD_reg_reg[4] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[4]),
        .Q(PortD[4]),
        .R(reset));
  FDRE \PortD_reg_reg[5] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[5]),
        .Q(PortD[5]),
        .R(reset));
  FDRE \PortD_reg_reg[6] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[6]),
        .Q(PortD[6]),
        .R(reset));
  FDRE \PortD_reg_reg[7] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[7]),
        .Q(PortD[7]),
        .R(reset));
  FDRE \PortD_reg_reg[8] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[8]),
        .Q(PortD[8]),
        .R(reset));
  FDRE \PortD_reg_reg[9] 
       (.C(clk),
        .CE(PortD0),
        .D(WriteData[9]),
        .Q(PortD[9]),
        .R(reset));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "0" *) 
  RAM64X1S RAM_reg_0_63_0_0
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[0]),
        .O(ReadDataRAM[0]),
        .WCLK(clk),
        .WE(p_0_in));
  LUT5 #(
    .INIT(32'h00010000)) 
    RAM_reg_0_63_0_0_i_1
       (.I0(DataAddr[11]),
        .I1(DataAddr[13]),
        .I2(DataAddr[14]),
        .I3(\ReadData_reg[31]_i_6_n_0 ),
        .I4(MemWrite),
        .O(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "10" *) 
  (* ram_slice_end = "10" *) 
  RAM64X1S RAM_reg_0_63_10_10
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[10]),
        .O(ReadDataRAM[10]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "11" *) 
  (* ram_slice_end = "11" *) 
  RAM64X1S RAM_reg_0_63_11_11
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[11]),
        .O(ReadDataRAM[11]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "12" *) 
  RAM64X1S RAM_reg_0_63_12_12
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[12]),
        .O(ReadDataRAM[12]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "13" *) 
  (* ram_slice_end = "13" *) 
  RAM64X1S RAM_reg_0_63_13_13
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[13]),
        .O(ReadDataRAM[13]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "14" *) 
  (* ram_slice_end = "14" *) 
  RAM64X1S RAM_reg_0_63_14_14
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[14]),
        .O(ReadDataRAM[14]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "15" *) 
  (* ram_slice_end = "15" *) 
  RAM64X1S RAM_reg_0_63_15_15
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[15]),
        .O(ReadDataRAM[15]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "16" *) 
  (* ram_slice_end = "16" *) 
  RAM64X1S RAM_reg_0_63_16_16
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[16]),
        .O(ReadDataRAM[16]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "17" *) 
  (* ram_slice_end = "17" *) 
  RAM64X1S RAM_reg_0_63_17_17
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[17]),
        .O(ReadDataRAM[17]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "18" *) 
  RAM64X1S RAM_reg_0_63_18_18
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[18]),
        .O(ReadDataRAM[18]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "19" *) 
  (* ram_slice_end = "19" *) 
  RAM64X1S RAM_reg_0_63_19_19
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[19]),
        .O(ReadDataRAM[19]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "1" *) 
  (* ram_slice_end = "1" *) 
  RAM64X1S RAM_reg_0_63_1_1
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[1]),
        .O(ReadDataRAM[1]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "20" *) 
  (* ram_slice_end = "20" *) 
  RAM64X1S RAM_reg_0_63_20_20
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[20]),
        .O(ReadDataRAM[20]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "21" *) 
  (* ram_slice_end = "21" *) 
  RAM64X1S RAM_reg_0_63_21_21
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[21]),
        .O(ReadDataRAM[21]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "22" *) 
  (* ram_slice_end = "22" *) 
  RAM64X1S RAM_reg_0_63_22_22
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[22]),
        .O(ReadDataRAM[22]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "23" *) 
  (* ram_slice_end = "23" *) 
  RAM64X1S RAM_reg_0_63_23_23
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[23]),
        .O(ReadDataRAM[23]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "24" *) 
  (* ram_slice_end = "24" *) 
  RAM64X1S RAM_reg_0_63_24_24
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[24]),
        .O(ReadDataRAM[24]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "25" *) 
  (* ram_slice_end = "25" *) 
  RAM64X1S RAM_reg_0_63_25_25
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[25]),
        .O(ReadDataRAM[25]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "26" *) 
  (* ram_slice_end = "26" *) 
  RAM64X1S RAM_reg_0_63_26_26
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[26]),
        .O(ReadDataRAM[26]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "27" *) 
  (* ram_slice_end = "27" *) 
  RAM64X1S RAM_reg_0_63_27_27
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[27]),
        .O(ReadDataRAM[27]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "28" *) 
  (* ram_slice_end = "28" *) 
  RAM64X1S RAM_reg_0_63_28_28
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[28]),
        .O(ReadDataRAM[28]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "29" *) 
  (* ram_slice_end = "29" *) 
  RAM64X1S RAM_reg_0_63_29_29
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[29]),
        .O(ReadDataRAM[29]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "2" *) 
  RAM64X1S RAM_reg_0_63_2_2
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[2]),
        .O(ReadDataRAM[2]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "30" *) 
  (* ram_slice_end = "30" *) 
  RAM64X1S RAM_reg_0_63_30_30
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[30]),
        .O(ReadDataRAM[30]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "31" *) 
  (* ram_slice_end = "31" *) 
  RAM64X1S RAM_reg_0_63_31_31
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[31]),
        .O(ReadDataRAM[31]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "3" *) 
  RAM64X1S RAM_reg_0_63_3_3
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[3]),
        .O(ReadDataRAM[3]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "4" *) 
  RAM64X1S RAM_reg_0_63_4_4
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[4]),
        .O(ReadDataRAM[4]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "5" *) 
  (* ram_slice_end = "5" *) 
  RAM64X1S RAM_reg_0_63_5_5
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[5]),
        .O(ReadDataRAM[5]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "6" *) 
  RAM64X1S RAM_reg_0_63_6_6
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[6]),
        .O(ReadDataRAM[6]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "7" *) 
  (* ram_slice_end = "7" *) 
  RAM64X1S RAM_reg_0_63_7_7
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[7]),
        .O(ReadDataRAM[7]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "8" *) 
  (* ram_slice_end = "8" *) 
  RAM64X1S RAM_reg_0_63_8_8
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[8]),
        .O(ReadDataRAM[8]),
        .WCLK(clk),
        .WE(p_0_in));
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "inst/RAM" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "9" *) 
  (* ram_slice_end = "9" *) 
  RAM64X1S RAM_reg_0_63_9_9
       (.A0(DataAddr[2]),
        .A1(DataAddr[3]),
        .A2(DataAddr[4]),
        .A3(DataAddr[5]),
        .A4(DataAddr[6]),
        .A5(DataAddr[7]),
        .D(WriteData[9]),
        .O(ReadDataRAM[9]),
        .WCLK(clk),
        .WE(p_0_in));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[0] 
       (.CLR(1'b0),
        .D(\ReadData_reg[0]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[0]));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \ReadData_reg[0]_i_1 
       (.I0(\ReadData_reg[0]_i_2_n_0 ),
        .I1(\ReadData_reg[0]_i_3_n_0 ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[0]),
        .I4(ReadDataRAM[0]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000AC)) 
    \ReadData_reg[0]_i_2 
       (.I0(PortB[0]),
        .I1(PortA[0]),
        .I2(DataAddr[4]),
        .I3(\ReadData_reg[31]_i_7_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(DataAddr[5]),
        .O(\ReadData_reg[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00020000)) 
    \ReadData_reg[0]_i_3 
       (.I0(DataAddr[5]),
        .I1(\ReadData_reg[31]_i_8_n_0 ),
        .I2(\ReadData_reg[31]_i_7_n_0 ),
        .I3(DataAddr[4]),
        .I4(PortC[0]),
        .O(\ReadData_reg[0]_i_3_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[10] 
       (.CLR(1'b0),
        .D(\ReadData_reg[10]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[10]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[10]_i_1 
       (.I0(ReadDataRAM[10]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[10]),
        .I4(\ReadData_reg[10]_i_2_n_0 ),
        .O(\ReadData_reg[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[10]_i_2 
       (.I0(PortD[10]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[10]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[10]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[11] 
       (.CLR(1'b0),
        .D(\ReadData_reg[11]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[11]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[11]_i_1 
       (.I0(ReadDataRAM[11]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[11]),
        .I4(\ReadData_reg[11]_i_2_n_0 ),
        .O(\ReadData_reg[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[11]_i_2 
       (.I0(PortD[11]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[11]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[11]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[12] 
       (.CLR(1'b0),
        .D(\ReadData_reg[12]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[12]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[12]_i_1 
       (.I0(ReadDataRAM[12]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[12]),
        .I4(\ReadData_reg[12]_i_2_n_0 ),
        .O(\ReadData_reg[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[12]_i_2 
       (.I0(PortD[12]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[12]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[12]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[13] 
       (.CLR(1'b0),
        .D(\ReadData_reg[13]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[13]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[13]_i_1 
       (.I0(ReadDataRAM[13]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[13]),
        .I4(\ReadData_reg[13]_i_2_n_0 ),
        .O(\ReadData_reg[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[13]_i_2 
       (.I0(PortD[13]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[13]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \ReadData_reg[13]_i_3 
       (.I0(DataAddr[6]),
        .I1(DataAddr[7]),
        .I2(DataAddr[2]),
        .I3(DataAddr[3]),
        .I4(DataAddr[5]),
        .I5(DataAddr[4]),
        .O(\ReadData_reg[13]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ReadData_reg[13]_i_4 
       (.I0(DataAddr[4]),
        .I1(DataAddr[5]),
        .O(\ReadData_reg[13]_i_4_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[14] 
       (.CLR(1'b0),
        .D(\ReadData_reg[14]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[14]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[14]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[14] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[14]),
        .I4(ReadDataRAM[14]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[14]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[15] 
       (.CLR(1'b0),
        .D(\ReadData_reg[15]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[15]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[15]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[15] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[15]),
        .I4(ReadDataRAM[15]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[15]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[16] 
       (.CLR(1'b0),
        .D(\ReadData_reg[16]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[16]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[16]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[16] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[16] ),
        .I4(ReadDataRAM[16]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[16]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[17] 
       (.CLR(1'b0),
        .D(\ReadData_reg[17]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[17]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[17]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[17] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[17] ),
        .I4(ReadDataRAM[17]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[17]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[18] 
       (.CLR(1'b0),
        .D(\ReadData_reg[18]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[18]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[18]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[18] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[18] ),
        .I4(ReadDataRAM[18]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[18]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[19] 
       (.CLR(1'b0),
        .D(\ReadData_reg[19]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[19]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[19]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[19] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[19] ),
        .I4(ReadDataRAM[19]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[19]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[1] 
       (.CLR(1'b0),
        .D(\ReadData_reg[1]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[1]));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \ReadData_reg[1]_i_1 
       (.I0(\ReadData_reg[1]_i_2_n_0 ),
        .I1(\ReadData_reg[1]_i_3_n_0 ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[1]),
        .I4(ReadDataRAM[1]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000AC)) 
    \ReadData_reg[1]_i_2 
       (.I0(PortB[1]),
        .I1(PortA[1]),
        .I2(DataAddr[4]),
        .I3(\ReadData_reg[31]_i_7_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(DataAddr[5]),
        .O(\ReadData_reg[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00020000)) 
    \ReadData_reg[1]_i_3 
       (.I0(DataAddr[5]),
        .I1(\ReadData_reg[31]_i_8_n_0 ),
        .I2(\ReadData_reg[31]_i_7_n_0 ),
        .I3(DataAddr[4]),
        .I4(PortC[1]),
        .O(\ReadData_reg[1]_i_3_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[20] 
       (.CLR(1'b0),
        .D(\ReadData_reg[20]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[20]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[20]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[20] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[20] ),
        .I4(ReadDataRAM[20]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[20]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[21] 
       (.CLR(1'b0),
        .D(\ReadData_reg[21]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[21]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[21]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[21] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[21] ),
        .I4(ReadDataRAM[21]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[21]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[22] 
       (.CLR(1'b0),
        .D(\ReadData_reg[22]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[22]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[22]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[22] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[22] ),
        .I4(ReadDataRAM[22]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[22]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[23] 
       (.CLR(1'b0),
        .D(\ReadData_reg[23]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[23]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[23]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[23] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[23] ),
        .I4(ReadDataRAM[23]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[23]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[24] 
       (.CLR(1'b0),
        .D(\ReadData_reg[24]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[24]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[24]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[24] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[24] ),
        .I4(ReadDataRAM[24]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[24]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[25] 
       (.CLR(1'b0),
        .D(\ReadData_reg[25]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[25]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[25]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[25] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[25] ),
        .I4(ReadDataRAM[25]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[25]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[26] 
       (.CLR(1'b0),
        .D(\ReadData_reg[26]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[26]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[26]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[26] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[26] ),
        .I4(ReadDataRAM[26]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[26]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[27] 
       (.CLR(1'b0),
        .D(\ReadData_reg[27]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[27]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[27]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[27] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[27] ),
        .I4(ReadDataRAM[27]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[27]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[28] 
       (.CLR(1'b0),
        .D(\ReadData_reg[28]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[28]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[28]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[28] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[28] ),
        .I4(ReadDataRAM[28]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[28]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[29] 
       (.CLR(1'b0),
        .D(\ReadData_reg[29]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[29]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[29]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[29] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[29] ),
        .I4(ReadDataRAM[29]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[29]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[2] 
       (.CLR(1'b0),
        .D(\ReadData_reg[2]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[2]));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \ReadData_reg[2]_i_1 
       (.I0(\ReadData_reg[2]_i_2_n_0 ),
        .I1(\ReadData_reg[2]_i_3_n_0 ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[2]),
        .I4(ReadDataRAM[2]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000AC)) 
    \ReadData_reg[2]_i_2 
       (.I0(PortB[2]),
        .I1(PortA[2]),
        .I2(DataAddr[4]),
        .I3(\ReadData_reg[31]_i_7_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(DataAddr[5]),
        .O(\ReadData_reg[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h00020000)) 
    \ReadData_reg[2]_i_3 
       (.I0(DataAddr[5]),
        .I1(\ReadData_reg[31]_i_8_n_0 ),
        .I2(\ReadData_reg[31]_i_7_n_0 ),
        .I3(DataAddr[4]),
        .I4(PortC[2]),
        .O(\ReadData_reg[2]_i_3_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[30] 
       (.CLR(1'b0),
        .D(\ReadData_reg[30]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[30]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[30]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[30] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[30] ),
        .I4(ReadDataRAM[30]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[30]_i_1_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[31] 
       (.CLR(1'b0),
        .D(\ReadData_reg[31]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[31]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \ReadData_reg[31]_i_1 
       (.I0(\ReadData_reg[31]_i_3_n_0 ),
        .I1(\PortC_reg_reg_n_0_[31] ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(\PortD_reg_reg_n_0_[31] ),
        .I4(ReadDataRAM[31]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[31]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \ReadData_reg[31]_i_10 
       (.I0(DataAddr[4]),
        .I1(DataAddr[5]),
        .O(\ReadData_reg[31]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \ReadData_reg[31]_i_11 
       (.I0(DataAddr[17]),
        .I1(DataAddr[16]),
        .I2(DataAddr[19]),
        .I3(DataAddr[18]),
        .O(\ReadData_reg[31]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFEFFFF)) 
    \ReadData_reg[31]_i_12 
       (.I0(DataAddr[30]),
        .I1(DataAddr[31]),
        .I2(DataAddr[28]),
        .I3(DataAddr[29]),
        .I4(DataAddr[12]),
        .I5(DataAddr[15]),
        .O(\ReadData_reg[31]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \ReadData_reg[31]_i_13 
       (.I0(DataAddr[25]),
        .I1(DataAddr[24]),
        .I2(DataAddr[27]),
        .I3(DataAddr[26]),
        .O(\ReadData_reg[31]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \ReadData_reg[31]_i_14 
       (.I0(DataAddr[21]),
        .I1(DataAddr[20]),
        .I2(DataAddr[23]),
        .I3(DataAddr[22]),
        .O(\ReadData_reg[31]_i_14_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \ReadData_reg[31]_i_15 
       (.I0(DataAddr[11]),
        .I1(DataAddr[10]),
        .I2(DataAddr[14]),
        .I3(DataAddr[13]),
        .O(\ReadData_reg[31]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'hEFFF)) 
    \ReadData_reg[31]_i_16 
       (.I0(DataAddr[1]),
        .I1(DataAddr[0]),
        .I2(DataAddr[9]),
        .I3(DataAddr[8]),
        .O(\ReadData_reg[31]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h0001FFFF)) 
    \ReadData_reg[31]_i_2 
       (.I0(DataAddr[11]),
        .I1(DataAddr[13]),
        .I2(DataAddr[14]),
        .I3(\ReadData_reg[31]_i_6_n_0 ),
        .I4(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[31]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    \ReadData_reg[31]_i_3 
       (.I0(DataAddr[4]),
        .I1(\ReadData_reg[31]_i_7_n_0 ),
        .I2(\ReadData_reg[31]_i_8_n_0 ),
        .I3(DataAddr[5]),
        .O(\ReadData_reg[31]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0008)) 
    \ReadData_reg[31]_i_4 
       (.I0(DataAddr[4]),
        .I1(DataAddr[5]),
        .I2(\ReadData_reg[31]_i_9_n_0 ),
        .I3(\ReadData_reg[31]_i_8_n_0 ),
        .O(\ReadData_reg[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFE7FFF)) 
    \ReadData_reg[31]_i_5 
       (.I0(DataAddr[6]),
        .I1(DataAddr[7]),
        .I2(DataAddr[2]),
        .I3(DataAddr[3]),
        .I4(\ReadData_reg[31]_i_10_n_0 ),
        .I5(\ReadData_reg[31]_i_8_n_0 ),
        .O(\ReadData_reg[31]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \ReadData_reg[31]_i_6 
       (.I0(\ReadData_reg[31]_i_11_n_0 ),
        .I1(\ReadData_reg[31]_i_12_n_0 ),
        .I2(\ReadData_reg[31]_i_13_n_0 ),
        .I3(\ReadData_reg[31]_i_14_n_0 ),
        .O(\ReadData_reg[31]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \ReadData_reg[31]_i_7 
       (.I0(DataAddr[3]),
        .I1(DataAddr[2]),
        .I2(DataAddr[7]),
        .I3(DataAddr[6]),
        .O(\ReadData_reg[31]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \ReadData_reg[31]_i_8 
       (.I0(\ReadData_reg[31]_i_15_n_0 ),
        .I1(\ReadData_reg[31]_i_16_n_0 ),
        .I2(\ReadData_reg[31]_i_14_n_0 ),
        .I3(\ReadData_reg[31]_i_13_n_0 ),
        .I4(\ReadData_reg[31]_i_12_n_0 ),
        .I5(\ReadData_reg[31]_i_11_n_0 ),
        .O(\ReadData_reg[31]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    \ReadData_reg[31]_i_9 
       (.I0(DataAddr[3]),
        .I1(DataAddr[2]),
        .I2(DataAddr[7]),
        .I3(DataAddr[6]),
        .O(\ReadData_reg[31]_i_9_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[3] 
       (.CLR(1'b0),
        .D(\ReadData_reg[3]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[3]));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \ReadData_reg[3]_i_1 
       (.I0(\ReadData_reg[3]_i_2_n_0 ),
        .I1(\ReadData_reg[3]_i_3_n_0 ),
        .I2(\ReadData_reg[31]_i_4_n_0 ),
        .I3(PortD[3]),
        .I4(ReadDataRAM[3]),
        .I5(\ReadData_reg[31]_i_5_n_0 ),
        .O(\ReadData_reg[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000AC)) 
    \ReadData_reg[3]_i_2 
       (.I0(PortB[3]),
        .I1(PortA[3]),
        .I2(DataAddr[4]),
        .I3(\ReadData_reg[31]_i_7_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(DataAddr[5]),
        .O(\ReadData_reg[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00020000)) 
    \ReadData_reg[3]_i_3 
       (.I0(DataAddr[5]),
        .I1(\ReadData_reg[31]_i_8_n_0 ),
        .I2(\ReadData_reg[31]_i_7_n_0 ),
        .I3(DataAddr[4]),
        .I4(PortC[3]),
        .O(\ReadData_reg[3]_i_3_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[4] 
       (.CLR(1'b0),
        .D(\ReadData_reg[4]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[4]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[4]_i_1 
       (.I0(ReadDataRAM[4]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[4]),
        .I4(\ReadData_reg[4]_i_2_n_0 ),
        .O(\ReadData_reg[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[4]_i_2 
       (.I0(PortD[4]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[4]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[4]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[5] 
       (.CLR(1'b0),
        .D(\ReadData_reg[5]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[5]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[5]_i_1 
       (.I0(ReadDataRAM[5]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[5]),
        .I4(\ReadData_reg[5]_i_2_n_0 ),
        .O(\ReadData_reg[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[5]_i_2 
       (.I0(PortD[5]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[5]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[5]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[6] 
       (.CLR(1'b0),
        .D(\ReadData_reg[6]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[6]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[6]_i_1 
       (.I0(ReadDataRAM[6]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[6]),
        .I4(\ReadData_reg[6]_i_2_n_0 ),
        .O(\ReadData_reg[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[6]_i_2 
       (.I0(PortD[6]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[6]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[6]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[7] 
       (.CLR(1'b0),
        .D(\ReadData_reg[7]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[7]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[7]_i_1 
       (.I0(ReadDataRAM[7]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[7]),
        .I4(\ReadData_reg[7]_i_2_n_0 ),
        .O(\ReadData_reg[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[7]_i_2 
       (.I0(PortD[7]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[7]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[7]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[8] 
       (.CLR(1'b0),
        .D(\ReadData_reg[8]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[8]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[8]_i_1 
       (.I0(ReadDataRAM[8]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[8]),
        .I4(\ReadData_reg[8]_i_2_n_0 ),
        .O(\ReadData_reg[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[8]_i_2 
       (.I0(PortD[8]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[8]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[8]_i_2_n_0 ));
  (* XILINX_LEGACY_PRIM = "LD" *) 
  LDCE #(
    .INIT(1'b0)) 
    \ReadData_reg[9] 
       (.CLR(1'b0),
        .D(\ReadData_reg[9]_i_1_n_0 ),
        .G(\ReadData_reg[31]_i_2_n_0 ),
        .GE(1'b1),
        .Q(ReadData[9]));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \ReadData_reg[9]_i_1 
       (.I0(ReadDataRAM[9]),
        .I1(\ReadData_reg[31]_i_5_n_0 ),
        .I2(\ReadData_reg[31]_i_3_n_0 ),
        .I3(PortC[9]),
        .I4(\ReadData_reg[9]_i_2_n_0 ),
        .O(\ReadData_reg[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000088880000F888)) 
    \ReadData_reg[9]_i_2 
       (.I0(PortD[9]),
        .I1(\ReadData_reg[13]_i_3_n_0 ),
        .I2(PortB[9]),
        .I3(\ReadData_reg[13]_i_4_n_0 ),
        .I4(\ReadData_reg[31]_i_8_n_0 ),
        .I5(\ReadData_reg[31]_i_7_n_0 ),
        .O(\ReadData_reg[9]_i_2_n_0 ));
endmodule

(* CHECK_LICENSE_TYPE = "singleriscv_bd_dmem_io_0_0,dmem_io,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "dmem_io,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    reset,
    MemWrite,
    DataAddr,
    WriteData,
    ReadData,
    PortA,
    PortB,
    PortC,
    PortD);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN singleriscv_bd_clk_0, INSERT_VIP 0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 reset RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME reset, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input reset;
  input MemWrite;
  input [31:0]DataAddr;
  input [31:0]WriteData;
  output [31:0]ReadData;
  input [3:0]PortA;
  input [13:0]PortB;
  output [13:0]PortC;
  output [15:0]PortD;

  wire [31:0]DataAddr;
  wire MemWrite;
  wire [3:0]PortA;
  wire [13:0]PortB;
  wire [13:0]PortC;
  wire [15:0]PortD;
  wire [31:0]ReadData;
  wire [31:0]WriteData;
  wire clk;
  wire reset;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dmem_io inst
       (.DataAddr(DataAddr),
        .MemWrite(MemWrite),
        .PortA(PortA),
        .PortB(PortB),
        .PortC(PortC),
        .PortD(PortD),
        .ReadData(ReadData),
        .WriteData(WriteData),
        .clk(clk),
        .reset(reset));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
