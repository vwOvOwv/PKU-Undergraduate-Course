onbreak {quit -f}
onerror {quit -f}

vsim -voptargs="+acc" -L xil_defaultlib -L xlslice_v1_0_2 -L xlconstant_v1_1_7 -L dist_mem_gen_v8_0_13 -L unisims_ver -L unimacro_ver -L secureip -lib xil_defaultlib xil_defaultlib.singleriscv_bd xil_defaultlib.glbl

do {wave.do}

view wave
view structure
view signals

do {singleriscv_bd.udo}

run -all

quit -force
