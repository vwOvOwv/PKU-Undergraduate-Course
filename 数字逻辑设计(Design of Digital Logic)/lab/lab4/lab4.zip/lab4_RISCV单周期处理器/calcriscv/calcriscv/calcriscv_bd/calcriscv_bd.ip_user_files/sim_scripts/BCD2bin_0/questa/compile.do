vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xil_defaultlib

vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xil_defaultlib  -sv \
"../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/bcd2bin.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/BCD2bin_0/sim/BCD2bin_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

