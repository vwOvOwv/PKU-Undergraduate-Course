-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:20:42 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/bin2BCD_0/bin2BCD_0_sim_netlist.vhdl
-- Design      : bin2BCD_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity bin2BCD_0 is
  port (
    bin : in STD_LOGIC_VECTOR ( 13 downto 0 );
    bcd3 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1 : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0 : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of bin2BCD_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of bin2BCD_0 : entity is "bin2BCD_0,bin2BCD,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of bin2BCD_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of bin2BCD_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of bin2BCD_0 : entity is "bin2BCD,Vivado 2020.2";
end bin2BCD_0;

architecture STRUCTURE of bin2BCD_0 is
  signal \^bcd0\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \bcd1[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd1[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd1[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bcd2[0]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bcd3[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd3[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd3[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd3[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_17_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_18_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_19_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_20_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_21_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bcd3[3]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \^bin\ : STD_LOGIC_VECTOR ( 13 downto 0 );
  signal shifter1_out : STD_LOGIC_VECTOR ( 21 to 21 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \bcd2[0]_INST_0_i_10\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bcd2[0]_INST_0_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bcd2[0]_INST_0_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bcd2[0]_INST_0_i_5\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bcd3[0]_INST_0_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bcd3[0]_INST_0_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_10\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_13\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_21\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_3\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_5\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bcd3[3]_INST_0_i_7\ : label is "soft_lutpair3";
begin
  \^bin\(13 downto 0) <= bin(13 downto 0);
  bcd0(3 downto 1) <= \^bcd0\(3 downto 1);
  bcd0(0) <= \^bin\(0);
\bcd0[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"900924094BF6DBB4"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd1[0]_INST_0_i_1_n_0\,
      I2 => \bcd1[0]_INST_0_i_2_n_0\,
      I3 => \bcd1[0]_INST_0_i_3_n_0\,
      I4 => \^bin\(2),
      I5 => \^bin\(1),
      O => \^bcd0\(1)
    );
\bcd0[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FFFF004B2409B4"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd1[0]_INST_0_i_1_n_0\,
      I2 => \bcd1[0]_INST_0_i_2_n_0\,
      I3 => \^bin\(2),
      I4 => \bcd1[0]_INST_0_i_3_n_0\,
      I5 => \^bin\(1),
      O => \^bcd0\(2)
    );
\bcd0[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0942909066429066"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd1[0]_INST_0_i_1_n_0\,
      I2 => \bcd1[0]_INST_0_i_2_n_0\,
      I3 => \^bin\(2),
      I4 => \bcd1[0]_INST_0_i_3_n_0\,
      I5 => \^bin\(1),
      O => \^bcd0\(3)
    );
\bcd1[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2D4BD2D24B4BD2B4"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd1[0]_INST_0_i_1_n_0\,
      I2 => \bcd1[0]_INST_0_i_2_n_0\,
      I3 => \^bin\(2),
      I4 => \bcd1[0]_INST_0_i_3_n_0\,
      I5 => \^bin\(1),
      O => bcd1(0)
    );
\bcd1[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin\(4),
      I1 => \bcd2[0]_INST_0_i_7_n_0\,
      I2 => \^bin\(5),
      I3 => \bcd2[0]_INST_0_i_8_n_0\,
      I4 => \bcd2[0]_INST_0_i_9_n_0\,
      I5 => \^bin\(3),
      O => \bcd1[0]_INST_0_i_1_n_0\
    );
\bcd1[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_12_n_0\,
      I1 => \bcd2[0]_INST_0_i_11_n_0\,
      I2 => \^bin\(6),
      I3 => \bcd2[0]_INST_0_i_10_n_0\,
      I4 => \^bin\(5),
      I5 => \^bin\(4),
      O => \bcd1[0]_INST_0_i_2_n_0\
    );
\bcd1[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd2[0]_INST_0_i_13_n_0\,
      I2 => \^bin\(4),
      I3 => \bcd2[0]_INST_0_i_14_n_0\,
      I4 => \bcd2[0]_INST_0_i_15_n_0\,
      I5 => \^bin\(2),
      O => \bcd1[0]_INST_0_i_3_n_0\
    );
\bcd1[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_5_n_0\,
      I1 => \bcd2[0]_INST_0_i_4_n_0\,
      I2 => \bcd2[0]_INST_0_i_3_n_0\,
      I3 => \bcd2[0]_INST_0_i_2_n_0\,
      I4 => \bcd2[0]_INST_0_i_1_n_0\,
      I5 => \bcd2[0]_INST_0_i_6_n_0\,
      O => bcd1(1)
    );
\bcd1[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"195495664251A58A"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_1_n_0\,
      I1 => \bcd2[0]_INST_0_i_2_n_0\,
      I2 => \bcd2[0]_INST_0_i_3_n_0\,
      I3 => \bcd2[0]_INST_0_i_4_n_0\,
      I4 => \bcd2[0]_INST_0_i_5_n_0\,
      I5 => \bcd2[0]_INST_0_i_6_n_0\,
      O => bcd1(2)
    );
\bcd1[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4101204807A00AD0"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_1_n_0\,
      I1 => \bcd2[0]_INST_0_i_2_n_0\,
      I2 => \bcd2[0]_INST_0_i_3_n_0\,
      I3 => \bcd2[0]_INST_0_i_4_n_0\,
      I4 => \bcd2[0]_INST_0_i_5_n_0\,
      I5 => \bcd2[0]_INST_0_i_6_n_0\,
      O => bcd1(3)
    );
\bcd2[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_1_n_0\,
      I1 => \bcd2[0]_INST_0_i_2_n_0\,
      I2 => \bcd2[0]_INST_0_i_3_n_0\,
      I3 => \bcd2[0]_INST_0_i_4_n_0\,
      I4 => \bcd2[0]_INST_0_i_5_n_0\,
      I5 => \bcd2[0]_INST_0_i_6_n_0\,
      O => bcd2(0)
    );
\bcd2[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin\(4),
      I1 => \bcd2[0]_INST_0_i_7_n_0\,
      I2 => \^bin\(5),
      I3 => \bcd2[0]_INST_0_i_8_n_0\,
      I4 => \bcd2[0]_INST_0_i_9_n_0\,
      I5 => \^bin\(3),
      O => \bcd2[0]_INST_0_i_1_n_0\
    );
\bcd2[0]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3C623C46"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_19_n_0\,
      I1 => \^bin\(8),
      I2 => \bcd3[3]_INST_0_i_20_n_0\,
      I3 => \^bin\(7),
      I4 => \bcd3[3]_INST_0_i_21_n_0\,
      O => \bcd2[0]_INST_0_i_10_n_0\
    );
\bcd2[0]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin\(7),
      I1 => \bcd3[3]_INST_0_i_19_n_0\,
      I2 => \^bin\(8),
      I3 => \bcd3[3]_INST_0_i_20_n_0\,
      I4 => \bcd3[3]_INST_0_i_21_n_0\,
      I5 => \^bin\(6),
      O => \bcd2[0]_INST_0_i_11_n_0\
    );
\bcd2[0]_INST_0_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"481137EC"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_21_n_0\,
      I1 => \bcd3[3]_INST_0_i_20_n_0\,
      I2 => \^bin\(8),
      I3 => \bcd3[3]_INST_0_i_19_n_0\,
      I4 => \^bin\(7),
      O => \bcd2[0]_INST_0_i_12_n_0\
    );
\bcd2[0]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2299545A449A2592"
    )
        port map (
      I0 => \^bin\(6),
      I1 => \^bin\(7),
      I2 => \bcd3[3]_INST_0_i_16_n_0\,
      I3 => \bcd3[3]_INST_0_i_17_n_0\,
      I4 => \bcd3[3]_INST_0_i_18_n_0\,
      I5 => \^bin\(5),
      O => \bcd2[0]_INST_0_i_13_n_0\
    );
\bcd2[0]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin\(5),
      I1 => \bcd2[0]_INST_0_i_10_n_0\,
      I2 => \^bin\(6),
      I3 => \bcd2[0]_INST_0_i_11_n_0\,
      I4 => \bcd2[0]_INST_0_i_12_n_0\,
      I5 => \^bin\(4),
      O => \bcd2[0]_INST_0_i_14_n_0\
    );
\bcd2[0]_INST_0_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_8_n_0\,
      I1 => \^bin\(5),
      O => \bcd2[0]_INST_0_i_15_n_0\
    );
\bcd2[0]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B4"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_8_n_0\,
      I1 => \bcd3[3]_INST_0_i_9_n_0\,
      I2 => \bcd3[3]_INST_0_i_10_n_0\,
      O => \bcd2[0]_INST_0_i_2_n_0\
    );
\bcd2[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin\(5),
      I1 => \bcd2[0]_INST_0_i_10_n_0\,
      I2 => \^bin\(6),
      I3 => \bcd2[0]_INST_0_i_11_n_0\,
      I4 => \bcd2[0]_INST_0_i_12_n_0\,
      I5 => \^bin\(4),
      O => \bcd2[0]_INST_0_i_3_n_0\
    );
\bcd2[0]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DF5E7A7A"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_7_n_0\,
      I1 => \bcd3[3]_INST_0_i_8_n_0\,
      I2 => \bcd3[3]_INST_0_i_9_n_0\,
      I3 => \bcd2[0]_INST_0_i_3_n_0\,
      I4 => \bcd3[3]_INST_0_i_10_n_0\,
      O => \bcd2[0]_INST_0_i_4_n_0\
    );
\bcd2[0]_INST_0_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_9_n_0\,
      I1 => \bcd3[3]_INST_0_i_8_n_0\,
      O => \bcd2[0]_INST_0_i_5_n_0\
    );
\bcd2[0]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin\(3),
      I1 => \bcd2[0]_INST_0_i_13_n_0\,
      I2 => \^bin\(4),
      I3 => \bcd2[0]_INST_0_i_14_n_0\,
      I4 => \bcd2[0]_INST_0_i_15_n_0\,
      I5 => \^bin\(2),
      O => \bcd2[0]_INST_0_i_6_n_0\
    );
\bcd2[0]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"195495664251A58A"
    )
        port map (
      I0 => \^bin\(7),
      I1 => \bcd3[3]_INST_0_i_19_n_0\,
      I2 => \^bin\(8),
      I3 => \bcd3[3]_INST_0_i_20_n_0\,
      I4 => \bcd3[3]_INST_0_i_21_n_0\,
      I5 => \^bin\(6),
      O => \bcd2[0]_INST_0_i_7_n_0\
    );
\bcd2[0]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772379EC660371C8"
    )
        port map (
      I0 => \^bin\(6),
      I1 => \^bin\(7),
      I2 => \bcd3[3]_INST_0_i_16_n_0\,
      I3 => \bcd3[3]_INST_0_i_17_n_0\,
      I4 => \bcd3[3]_INST_0_i_18_n_0\,
      I5 => \^bin\(5),
      O => \bcd2[0]_INST_0_i_8_n_0\
    );
\bcd2[0]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_21_n_0\,
      I1 => \bcd3[3]_INST_0_i_20_n_0\,
      I2 => \^bin\(8),
      I3 => \bcd3[3]_INST_0_i_19_n_0\,
      I4 => \^bin\(7),
      I5 => \^bin\(6),
      O => \bcd2[0]_INST_0_i_9_n_0\
    );
\bcd2[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"23895472"
    )
        port map (
      I0 => \bcd3[0]_INST_0_i_3_n_0\,
      I1 => \bcd3[0]_INST_0_i_2_n_0\,
      I2 => \bcd3[0]_INST_0_i_1_n_0\,
      I3 => \bcd3[3]_INST_0_i_1_n_0\,
      I4 => \bcd3[0]_INST_0_i_4_n_0\,
      O => bcd2(1)
    );
\bcd2[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5466518A"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[0]_INST_0_i_1_n_0\,
      I2 => \bcd3[0]_INST_0_i_2_n_0\,
      I3 => \bcd3[0]_INST_0_i_3_n_0\,
      I4 => \bcd3[0]_INST_0_i_4_n_0\,
      O => bcd2(2)
    );
\bcd2[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0148A0D0"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[0]_INST_0_i_1_n_0\,
      I2 => \bcd3[0]_INST_0_i_2_n_0\,
      I3 => \bcd3[0]_INST_0_i_3_n_0\,
      I4 => \bcd3[0]_INST_0_i_4_n_0\,
      O => bcd2(3)
    );
\bcd3[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A17C01EC"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[0]_INST_0_i_1_n_0\,
      I2 => \bcd3[0]_INST_0_i_2_n_0\,
      I3 => \bcd3[0]_INST_0_i_3_n_0\,
      I4 => \bcd3[0]_INST_0_i_4_n_0\,
      O => bcd3(0)
    );
\bcd3[0]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"41201804"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_5_n_0\,
      I1 => \bcd3[3]_INST_0_i_4_n_0\,
      I2 => shifter1_out(21),
      I3 => \bcd3[3]_INST_0_i_2_n_0\,
      I4 => \bcd3[3]_INST_0_i_6_n_0\,
      O => \bcd3[0]_INST_0_i_1_n_0\
    );
\bcd3[0]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C3611C86"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_2_n_0\,
      I1 => shifter1_out(21),
      I2 => \bcd3[3]_INST_0_i_4_n_0\,
      I3 => \bcd3[3]_INST_0_i_5_n_0\,
      I4 => \bcd3[3]_INST_0_i_6_n_0\,
      O => \bcd3[0]_INST_0_i_2_n_0\
    );
\bcd3[0]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"249A45A2"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_5_n_0\,
      I1 => \bcd3[3]_INST_0_i_4_n_0\,
      I2 => shifter1_out(21),
      I3 => \bcd3[3]_INST_0_i_2_n_0\,
      I4 => \bcd3[3]_INST_0_i_6_n_0\,
      O => \bcd3[0]_INST_0_i_3_n_0\
    );
\bcd3[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \bcd2[0]_INST_0_i_3_n_0\,
      I1 => \bcd3[3]_INST_0_i_7_n_0\,
      I2 => \bcd3[3]_INST_0_i_8_n_0\,
      I3 => \bcd3[3]_INST_0_i_9_n_0\,
      I4 => \bcd3[3]_INST_0_i_10_n_0\,
      I5 => \bcd2[0]_INST_0_i_1_n_0\,
      O => \bcd3[0]_INST_0_i_4_n_0\
    );
\bcd3[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E83F01C1002F33C"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[3]_INST_0_i_2_n_0\,
      I2 => shifter1_out(21),
      I3 => \bcd3[3]_INST_0_i_4_n_0\,
      I4 => \bcd3[3]_INST_0_i_5_n_0\,
      I5 => \bcd3[3]_INST_0_i_6_n_0\,
      O => bcd3(1)
    );
\bcd3[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C330332CD330300C"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[3]_INST_0_i_2_n_0\,
      I2 => shifter1_out(21),
      I3 => \bcd3[3]_INST_0_i_4_n_0\,
      I4 => \bcd3[3]_INST_0_i_5_n_0\,
      I5 => \bcd3[3]_INST_0_i_6_n_0\,
      O => bcd3(2)
    );
\bcd3[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300C0000200C04C0"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_1_n_0\,
      I1 => \bcd3[3]_INST_0_i_2_n_0\,
      I2 => shifter1_out(21),
      I3 => \bcd3[3]_INST_0_i_4_n_0\,
      I4 => \bcd3[3]_INST_0_i_5_n_0\,
      I5 => \bcd3[3]_INST_0_i_6_n_0\,
      O => bcd3(3)
    );
\bcd3[3]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95565A5A"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_7_n_0\,
      I1 => \bcd3[3]_INST_0_i_8_n_0\,
      I2 => \bcd3[3]_INST_0_i_9_n_0\,
      I3 => \bcd2[0]_INST_0_i_3_n_0\,
      I4 => \bcd3[3]_INST_0_i_10_n_0\,
      O => \bcd3[3]_INST_0_i_1_n_0\
    );
\bcd3[3]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"23895472"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_14_n_0\,
      I1 => \bcd3[3]_INST_0_i_12_n_0\,
      I2 => \bcd3[3]_INST_0_i_11_n_0\,
      I3 => \bcd3[3]_INST_0_i_13_n_0\,
      I4 => \bcd3[3]_INST_0_i_15_n_0\,
      O => \bcd3[3]_INST_0_i_10_n_0\
    );
\bcd3[3]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300C0000200C04C0"
    )
        port map (
      I0 => \^bin\(8),
      I1 => \^bin\(12),
      I2 => \^bin\(13),
      I3 => \^bin\(11),
      I4 => \^bin\(10),
      I5 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_11_n_0\
    );
\bcd3[3]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E83F01C1002F33C"
    )
        port map (
      I0 => \^bin\(8),
      I1 => \^bin\(12),
      I2 => \^bin\(13),
      I3 => \^bin\(11),
      I4 => \^bin\(10),
      I5 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_12_n_0\
    );
\bcd3[3]_INST_0_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95565A5A"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_19_n_0\,
      I1 => \^bin\(8),
      I2 => \bcd3[3]_INST_0_i_20_n_0\,
      I3 => \^bin\(7),
      I4 => \bcd3[3]_INST_0_i_21_n_0\,
      O => \bcd3[3]_INST_0_i_13_n_0\
    );
\bcd3[3]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C330332CD330300C"
    )
        port map (
      I0 => \^bin\(8),
      I1 => \^bin\(12),
      I2 => \^bin\(13),
      I3 => \^bin\(11),
      I4 => \^bin\(10),
      I5 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_14_n_0\
    );
\bcd3[3]_INST_0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin\(7),
      I1 => \bcd3[3]_INST_0_i_19_n_0\,
      I2 => \^bin\(8),
      I3 => \bcd3[3]_INST_0_i_20_n_0\,
      I4 => \bcd3[3]_INST_0_i_21_n_0\,
      I5 => \^bin\(6),
      O => \bcd3[3]_INST_0_i_15_n_0\
    );
\bcd3[3]_INST_0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2142081008104284"
    )
        port map (
      I0 => \^bin\(9),
      I1 => \^bin\(10),
      I2 => \^bin\(11),
      I3 => \^bin\(13),
      I4 => \^bin\(12),
      I5 => \^bin\(8),
      O => \bcd3[3]_INST_0_i_16_n_0\
    );
\bcd3[3]_INST_0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A2599A4545A2249A"
    )
        port map (
      I0 => \^bin\(12),
      I1 => \^bin\(13),
      I2 => \^bin\(11),
      I3 => \^bin\(10),
      I4 => \^bin\(9),
      I5 => \^bin\(8),
      O => \bcd3[3]_INST_0_i_17_n_0\
    );
\bcd3[3]_INST_0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9429A54AA54A2952"
    )
        port map (
      I0 => \^bin\(9),
      I1 => \^bin\(10),
      I2 => \^bin\(11),
      I3 => \^bin\(13),
      I4 => \^bin\(12),
      I5 => \^bin\(8),
      O => \bcd3[3]_INST_0_i_18_n_0\
    );
\bcd3[3]_INST_0_i_19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"249A45A2"
    )
        port map (
      I0 => \^bin\(10),
      I1 => \^bin\(11),
      I2 => \^bin\(13),
      I3 => \^bin\(12),
      I4 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_19_n_0\
    );
\bcd3[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3C303C303C3038F0"
    )
        port map (
      I0 => \^bin\(8),
      I1 => \^bin\(12),
      I2 => \^bin\(13),
      I3 => \^bin\(11),
      I4 => \^bin\(10),
      I5 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_2_n_0\
    );
\bcd3[3]_INST_0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3973CE9C31638C18"
    )
        port map (
      I0 => \^bin\(9),
      I1 => \^bin\(10),
      I2 => \^bin\(11),
      I3 => \^bin\(13),
      I4 => \^bin\(12),
      I5 => \^bin\(8),
      O => \bcd3[3]_INST_0_i_20_n_0\
    );
\bcd3[3]_INST_0_i_21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C3611C86"
    )
        port map (
      I0 => \^bin\(12),
      I1 => \^bin\(13),
      I2 => \^bin\(11),
      I3 => \^bin\(10),
      I4 => \^bin\(9),
      O => \bcd3[3]_INST_0_i_21_n_0\
    );
\bcd3[3]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F000E000"
    )
        port map (
      I0 => \^bin\(9),
      I1 => \^bin\(10),
      I2 => \^bin\(12),
      I3 => \^bin\(13),
      I4 => \^bin\(11),
      O => shifter1_out(21)
    );
\bcd3[3]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56AA"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_11_n_0\,
      I1 => \bcd3[3]_INST_0_i_12_n_0\,
      I2 => \bcd3[3]_INST_0_i_13_n_0\,
      I3 => \bcd3[3]_INST_0_i_14_n_0\,
      O => \bcd3[3]_INST_0_i_4_n_0\
    );
\bcd3[3]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A17C01EC"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_13_n_0\,
      I1 => \bcd3[3]_INST_0_i_11_n_0\,
      I2 => \bcd3[3]_INST_0_i_12_n_0\,
      I3 => \bcd3[3]_INST_0_i_14_n_0\,
      I4 => \bcd3[3]_INST_0_i_15_n_0\,
      O => \bcd3[3]_INST_0_i_5_n_0\
    );
\bcd3[3]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772319EC660331C8"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_15_n_0\,
      I1 => \bcd3[3]_INST_0_i_13_n_0\,
      I2 => \bcd3[3]_INST_0_i_11_n_0\,
      I3 => \bcd3[3]_INST_0_i_12_n_0\,
      I4 => \bcd3[3]_INST_0_i_14_n_0\,
      I5 => \bcd3[3]_INST_0_i_8_n_0\,
      O => \bcd3[3]_INST_0_i_6_n_0\
    );
\bcd3[3]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5466518A"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_13_n_0\,
      I1 => \bcd3[3]_INST_0_i_11_n_0\,
      I2 => \bcd3[3]_INST_0_i_12_n_0\,
      I3 => \bcd3[3]_INST_0_i_14_n_0\,
      I4 => \bcd3[3]_INST_0_i_15_n_0\,
      O => \bcd3[3]_INST_0_i_7_n_0\
    );
\bcd3[3]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772319EC660331C8"
    )
        port map (
      I0 => \^bin\(6),
      I1 => \^bin\(7),
      I2 => \bcd3[3]_INST_0_i_16_n_0\,
      I3 => \bcd3[3]_INST_0_i_17_n_0\,
      I4 => \bcd3[3]_INST_0_i_18_n_0\,
      I5 => \^bin\(5),
      O => \bcd3[3]_INST_0_i_8_n_0\
    );
\bcd3[3]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772379EC660371C8"
    )
        port map (
      I0 => \bcd3[3]_INST_0_i_15_n_0\,
      I1 => \bcd3[3]_INST_0_i_13_n_0\,
      I2 => \bcd3[3]_INST_0_i_11_n_0\,
      I3 => \bcd3[3]_INST_0_i_12_n_0\,
      I4 => \bcd3[3]_INST_0_i_14_n_0\,
      I5 => \bcd3[3]_INST_0_i_8_n_0\,
      O => \bcd3[3]_INST_0_i_9_n_0\
    );
end STRUCTURE;
