
################################################################
# This is a generated script based on design: singleriscv_bd
#
# Though there are limitations about the generated script,
# the main purpose of this utility is to make learning
# IP Integrator Tcl commands easier.
################################################################

namespace eval _tcl {
proc get_script_folder {} {
   set script_path [file normalize [info script]]
   set script_folder [file dirname $script_path]
   return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

################################################################
# Check if script is running in correct Vivado version.
################################################################
set scripts_vivado_version 2020.2
set current_vivado_version [version -short]

if { [string first $scripts_vivado_version $current_vivado_version] == -1 } {
   puts ""
   catch {common::send_gid_msg -ssname BD::TCL -id 2041 -severity "ERROR" "This script was generated using Vivado <$scripts_vivado_version> and is being run in <$current_vivado_version> of Vivado. Please run the script in Vivado <$scripts_vivado_version> then open the design in Vivado <$current_vivado_version>. Upgrade the design by running \"Tools => Report => Report IP Status...\", then run write_bd_tcl to create an updated script."}

   return 1
}

################################################################
# START
################################################################

# To test this script, run the following commands from Vivado Tcl console:
# source singleriscv_bd_script.tcl

# If there is no project opened, this script will create a
# project, but make sure you do not have an existing project
# <./myproj/project_1.xpr> in the current working folder.

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
   create_project project_1 myproj -part xc7a35tcpg236-1
   set_property BOARD_PART digilentinc.com:basys3:part0:1.1 [current_project]
}


# CHANGE DESIGN NAME HERE
variable design_name
set design_name singleriscv_bd

# If you do not already have an existing IP Integrator design open,
# you can create a design using the following command:
#    create_bd_design $design_name

# Creating design if needed
set errMsg ""
set nRet 0

set cur_design [current_bd_design -quiet]
set list_cells [get_bd_cells -quiet]

if { ${design_name} eq "" } {
   # USE CASES:
   #    1) Design_name not set

   set errMsg "Please set the variable <design_name> to a non-empty value."
   set nRet 1

} elseif { ${cur_design} ne "" && ${list_cells} eq "" } {
   # USE CASES:
   #    2): Current design opened AND is empty AND names same.
   #    3): Current design opened AND is empty AND names diff; design_name NOT in project.
   #    4): Current design opened AND is empty AND names diff; design_name exists in project.

   if { $cur_design ne $design_name } {
      common::send_gid_msg -ssname BD::TCL -id 2001 -severity "INFO" "Changing value of <design_name> from <$design_name> to <$cur_design> since current design is empty."
      set design_name [get_property NAME $cur_design]
   }
   common::send_gid_msg -ssname BD::TCL -id 2002 -severity "INFO" "Constructing design in IPI design <$cur_design>..."

} elseif { ${cur_design} ne "" && $list_cells ne "" && $cur_design eq $design_name } {
   # USE CASES:
   #    5) Current design opened AND has components AND same names.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 1
} elseif { [get_files -quiet ${design_name}.bd] ne "" } {
   # USE CASES: 
   #    6) Current opened design, has components, but diff names, design_name exists in project.
   #    7) No opened design, design_name exists in project.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 2

} else {
   # USE CASES:
   #    8) No opened design, design_name not in project.
   #    9) Current opened design, has components, but diff names, design_name not in project.

   common::send_gid_msg -ssname BD::TCL -id 2003 -severity "INFO" "Currently there is no design <$design_name> in project, so creating one..."

   create_bd_design $design_name

   common::send_gid_msg -ssname BD::TCL -id 2004 -severity "INFO" "Making design <$design_name> as current_bd_design."
   current_bd_design $design_name

}

common::send_gid_msg -ssname BD::TCL -id 2005 -severity "INFO" "Currently the variable <design_name> is equal to \"$design_name\"."

if { $nRet != 0 } {
   catch {common::send_gid_msg -ssname BD::TCL -id 2006 -severity "ERROR" $errMsg}
   return $nRet
}

##################################################################
# DESIGN PROCs
##################################################################



# Procedure to create entire design; Provide argument to make
# procedure reusable. If parentCell is "", will use root.
proc create_root_design { parentCell } {

  variable script_folder
  variable design_name

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2090 -severity "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2091 -severity "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set DataAdr [ create_bd_port -dir O -from 31 -to 0 DataAdr ]
  set MemWrite [ create_bd_port -dir O MemWrite ]
  set PortA [ create_bd_port -dir I -from 3 -to 0 PortA ]
  set PortB [ create_bd_port -dir I -from 13 -to 0 PortB ]
  set PortC [ create_bd_port -dir O -from 13 -to 0 PortC ]
  set PortD [ create_bd_port -dir O -from 15 -to 0 PortD ]
  set WriteData [ create_bd_port -dir O -from 31 -to 0 WriteData ]
  set clk [ create_bd_port -dir I -type clk clk ]
  set reset [ create_bd_port -dir I -type rst reset ]

  # Create instance: alu, and set properties
  set alu [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:alu:1.0 alu ]

  # Create instance: constant4, and set properties
  set constant4 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 constant4 ]
  set_property -dict [ list \
   CONFIG.CONST_VAL {4} \
   CONFIG.CONST_WIDTH {32} \
 ] $constant4

  # Create instance: controller, and set properties
  set controller [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:controller:1.0 controller ]

  # Create instance: dmem_io_0, and set properties
  set dmem_io_0 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:dmem_io:1.0 dmem_io_0 ]

  # Create instance: extend, and set properties
  set extend [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:extend:1.0 extend ]

  # Create instance: funct3, and set properties
  set funct3 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 funct3 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {14} \
   CONFIG.DIN_TO {12} \
   CONFIG.DOUT_WIDTH {3} \
 ] $funct3

  # Create instance: funct7b5, and set properties
  set funct7b5 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 funct7b5 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {30} \
   CONFIG.DIN_TO {30} \
   CONFIG.DOUT_WIDTH {1} \
 ] $funct7b5

  # Create instance: imem_fpga, and set properties
  set imem_fpga [ create_bd_cell -type ip -vlnv xilinx.com:ip:dist_mem_gen:8.0 imem_fpga ]
  set_property -dict [ list \
   CONFIG.coefficient_file {../../../../../../../src/riscvtest.coe} \
   CONFIG.data_width {32} \
   CONFIG.depth {256} \
   CONFIG.memory_type {rom} \
 ] $imem_fpga

  # Create instance: imm25, and set properties
  set imm25 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 imm25 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {31} \
   CONFIG.DIN_TO {7} \
   CONFIG.DOUT_WIDTH {25} \
 ] $imm25

  # Create instance: op, and set properties
  set op [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 op ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {6} \
   CONFIG.DOUT_WIDTH {7} \
 ] $op

  # Create instance: pcnext_mux2, and set properties
  set pcnext_mux2 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux2:1.0 pcnext_mux2 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $pcnext_mux2

  # Create instance: pcplus4_adder, and set properties
  set pcplus4_adder [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:adder:1.0 pcplus4_adder ]

  # Create instance: pcplus4liuauipc_mux2, and set properties
  set pcplus4liuauipc_mux2 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux2:1.0 pcplus4liuauipc_mux2 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $pcplus4liuauipc_mux2

  # Create instance: pcplus4lui_mux2, and set properties
  set pcplus4lui_mux2 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux2:1.0 pcplus4lui_mux2 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $pcplus4lui_mux2

  # Create instance: pcreg, and set properties
  set pcreg [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:flopr:1.0 pcreg ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $pcreg

  # Create instance: pcresult_mux2, and set properties
  set pcresult_mux2 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux2:1.0 pcresult_mux2 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $pcresult_mux2

  # Create instance: pctarget_adder, and set properties
  set pctarget_adder [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:adder:1.0 pctarget_adder ]

  # Create instance: rd, and set properties
  set rd [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 rd ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {11} \
   CONFIG.DIN_TO {7} \
   CONFIG.DOUT_WIDTH {5} \
 ] $rd

  # Create instance: regfile, and set properties
  set regfile [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:regfile:1.0 regfile ]

  # Create instance: result_mux3, and set properties
  set result_mux3 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux3:1.0 result_mux3 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $result_mux3

  # Create instance: rs1, and set properties
  set rs1 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 rs1 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {19} \
   CONFIG.DIN_TO {15} \
   CONFIG.DOUT_WIDTH {5} \
 ] $rs1

  # Create instance: rs2, and set properties
  set rs2 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 rs2 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {24} \
   CONFIG.DIN_TO {20} \
   CONFIG.DOUT_WIDTH {5} \
 ] $rs2

  # Create instance: srcb_mux2, and set properties
  set srcb_mux2 [ create_bd_cell -type ip -vlnv cs.pku.edu.cn:DDCA:mux2:1.0 srcb_mux2 ]
  set_property -dict [ list \
   CONFIG.WIDTH {32} \
 ] $srcb_mux2

  # Create instance: xlslice_0, and set properties
  set xlslice_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 xlslice_0 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {31} \
   CONFIG.DIN_TO {2} \
   CONFIG.DOUT_WIDTH {30} \
 ] $xlslice_0

  # Create port connections
  connect_bd_net -net PortA_0_1 [get_bd_ports PortA] [get_bd_pins dmem_io_0/PortA]
  connect_bd_net -net PortB_0_1 [get_bd_ports PortB] [get_bd_pins dmem_io_0/PortB]
  connect_bd_net -net alu_lessthan [get_bd_pins alu/lessthan] [get_bd_pins controller/lessthan]
  connect_bd_net -net alu_result [get_bd_ports DataAdr] [get_bd_pins alu/result] [get_bd_pins dmem_io_0/DataAddr] [get_bd_pins pcresult_mux2/d1] [get_bd_pins result_mux3/d0]
  connect_bd_net -net alu_zero [get_bd_pins alu/zero] [get_bd_pins controller/zero]
  connect_bd_net -net clk_1 [get_bd_ports clk] [get_bd_pins dmem_io_0/clk] [get_bd_pins pcreg/clk] [get_bd_pins regfile/clk]
  connect_bd_net -net constant4_dout [get_bd_pins constant4/dout] [get_bd_pins pcplus4_adder/b]
  connect_bd_net -net controller_ALUControl [get_bd_pins alu/alucontrol] [get_bd_pins controller/ALUControl]
  connect_bd_net -net controller_ALUSrc [get_bd_pins controller/ALUSrc] [get_bd_pins srcb_mux2/s]
  connect_bd_net -net controller_AUIPC [get_bd_pins controller/AUIPC] [get_bd_pins pcplus4liuauipc_mux2/s]
  connect_bd_net -net controller_ImmSrc [get_bd_pins controller/ImmSrc] [get_bd_pins extend/immsrc]
  connect_bd_net -net controller_Jump [get_bd_pins controller/Jump] [get_bd_pins pcplus4lui_mux2/s]
  connect_bd_net -net controller_JumpR [get_bd_pins controller/JumpR] [get_bd_pins pcresult_mux2/s]
  connect_bd_net -net controller_MemWrite [get_bd_ports MemWrite] [get_bd_pins controller/MemWrite] [get_bd_pins dmem_io_0/MemWrite]
  connect_bd_net -net controller_PCSrc [get_bd_pins controller/PCSrc] [get_bd_pins pcnext_mux2/s]
  connect_bd_net -net controller_RegWrite [get_bd_pins controller/RegWrite] [get_bd_pins regfile/we3]
  connect_bd_net -net controller_ResultSrc [get_bd_pins controller/ResultSrc] [get_bd_pins result_mux3/s]
  connect_bd_net -net controller_UType [get_bd_pins controller/UType] [get_bd_pins extend/utype]
  connect_bd_net -net dmem_io_0_PortC [get_bd_ports PortC] [get_bd_pins dmem_io_0/PortC]
  connect_bd_net -net dmem_io_0_PortD [get_bd_ports PortD] [get_bd_pins dmem_io_0/PortD]
  connect_bd_net -net dmem_io_0_ReadData [get_bd_pins dmem_io_0/ReadData] [get_bd_pins result_mux3/d1]
  connect_bd_net -net extend_immext [get_bd_pins extend/immext] [get_bd_pins pcplus4lui_mux2/d0] [get_bd_pins pctarget_adder/b] [get_bd_pins srcb_mux2/d1]
  connect_bd_net -net funct3_Dout [get_bd_pins controller/funct3] [get_bd_pins funct3/Dout]
  connect_bd_net -net funct7b5_Dout [get_bd_pins controller/funct7b5] [get_bd_pins funct7b5/Dout]
  connect_bd_net -net imem_rd [get_bd_pins funct3/Din] [get_bd_pins funct7b5/Din] [get_bd_pins imem_fpga/spo] [get_bd_pins imm25/Din] [get_bd_pins op/Din] [get_bd_pins rd/Din] [get_bd_pins rs1/Din] [get_bd_pins rs2/Din]
  connect_bd_net -net imm25_Dout [get_bd_pins extend/instr] [get_bd_pins imm25/Dout]
  connect_bd_net -net op_Dout [get_bd_pins controller/op] [get_bd_pins op/Dout]
  connect_bd_net -net pcnext_mux_y [get_bd_pins pcnext_mux2/y] [get_bd_pins pcreg/d]
  connect_bd_net -net pcplus4_adder_y [get_bd_pins pcnext_mux2/d0] [get_bd_pins pcplus4_adder/y] [get_bd_pins pcplus4lui_mux2/d1]
  connect_bd_net -net pcplus4liuaupic_mux2_y [get_bd_pins pcplus4liuauipc_mux2/y] [get_bd_pins result_mux3/d2]
  connect_bd_net -net pcplus4lui_mux2_y [get_bd_pins pcplus4liuauipc_mux2/d0] [get_bd_pins pcplus4lui_mux2/y]
  connect_bd_net -net pcreg_q [get_bd_pins pcplus4_adder/a] [get_bd_pins pcreg/q] [get_bd_pins pctarget_adder/a] [get_bd_pins xlslice_0/Din]
  connect_bd_net -net pcresult_mux2_y [get_bd_pins pcnext_mux2/d1] [get_bd_pins pcresult_mux2/y]
  connect_bd_net -net pctarget_adder_y [get_bd_pins pcplus4liuauipc_mux2/d1] [get_bd_pins pcresult_mux2/d0] [get_bd_pins pctarget_adder/y]
  connect_bd_net -net rd_Dout [get_bd_pins rd/Dout] [get_bd_pins regfile/a3]
  connect_bd_net -net regfile_rd1 [get_bd_pins alu/a] [get_bd_pins regfile/rd1]
  connect_bd_net -net regfile_rd2 [get_bd_ports WriteData] [get_bd_pins dmem_io_0/WriteData] [get_bd_pins regfile/rd2] [get_bd_pins srcb_mux2/d0]
  connect_bd_net -net reset_1 [get_bd_ports reset] [get_bd_pins dmem_io_0/reset] [get_bd_pins pcreg/reset]
  connect_bd_net -net result_mux3_y [get_bd_pins regfile/wd3] [get_bd_pins result_mux3/y]
  connect_bd_net -net rs1_Dout [get_bd_pins regfile/a1] [get_bd_pins rs1/Dout]
  connect_bd_net -net rs2_Dout [get_bd_pins regfile/a2] [get_bd_pins rs2/Dout]
  connect_bd_net -net srcb_mux2_y [get_bd_pins alu/b] [get_bd_pins srcb_mux2/y]
  connect_bd_net -net xlslice_0_Dout [get_bd_pins imem_fpga/a] [get_bd_pins xlslice_0/Dout]

  # Create address segments


  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
}
# End of create_root_design()


##################################################################
# MAIN FLOW
##################################################################

create_root_design ""


