onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib display_7seg_x4_0_opt

do {wave.do}

view wave
view structure
view signals

do {display_7seg_x4_0.udo}

run -all

quit -force
