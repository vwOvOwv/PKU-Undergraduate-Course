-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:27:17 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top singleriscv_bd_dmem_io_0_0 -prefix
--               singleriscv_bd_dmem_io_0_0_ singleriscv_bd_dmem_io_0_0_stub.vhdl
-- Design      : singleriscv_bd_dmem_io_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity singleriscv_bd_dmem_io_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    MemWrite : in STD_LOGIC;
    DataAddr : in STD_LOGIC_VECTOR ( 31 downto 0 );
    WriteData : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ReadData : out STD_LOGIC_VECTOR ( 31 downto 0 );
    PortA : in STD_LOGIC_VECTOR ( 3 downto 0 );
    PortB : in STD_LOGIC_VECTOR ( 13 downto 0 );
    PortC : out STD_LOGIC_VECTOR ( 13 downto 0 );
    PortD : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );

end singleriscv_bd_dmem_io_0_0;

architecture stub of singleriscv_bd_dmem_io_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,reset,MemWrite,DataAddr[31:0],WriteData[31:0],ReadData[31:0],PortA[3:0],PortB[13:0],PortC[13:0],PortD[15:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "dmem_io,Vivado 2020.2";
begin
end;
