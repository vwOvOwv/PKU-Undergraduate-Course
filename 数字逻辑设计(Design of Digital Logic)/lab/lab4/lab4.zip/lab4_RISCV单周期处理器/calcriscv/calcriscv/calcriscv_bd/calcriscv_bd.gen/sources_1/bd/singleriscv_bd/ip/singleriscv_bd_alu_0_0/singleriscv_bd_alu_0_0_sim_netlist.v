// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:23:09 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top singleriscv_bd_alu_0_0 -prefix
//               singleriscv_bd_alu_0_0_ singleriscv_bd_alu_0_0_sim_netlist.v
// Design      : singleriscv_bd_alu_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module singleriscv_bd_alu_0_0_alu
   (result,
    lessthan,
    zero,
    a,
    b,
    alucontrol,
    result_31_sp_1,
    \result[31]_0 ,
    \result[31]_1 ,
    \result[31]_2 ,
    \result[31]_3 ,
    result_0_sp_1,
    \result[0]_0 ,
    \result[0]_1 ,
    \result[0]_2 ,
    result_1_sp_1,
    \result[1]_0 ,
    result_2_sp_1,
    \result[2]_0 ,
    result_3_sp_1,
    \result[3]_0 ,
    result_4_sp_1,
    \result[4]_0 ,
    result_5_sp_1,
    \result[5]_0 ,
    \result[5]_1 ,
    result_6_sp_1,
    \result[6]_0 ,
    result_7_sp_1,
    \result[7]_0 ,
    \result[2]_1 ,
    \result[2]_2 ,
    \result[2]_3 ,
    \result[3]_1 ,
    \result[4]_INST_0_i_3_0 ,
    result_8_sp_1,
    \result[8]_0 ,
    result_9_sp_1,
    \result[9]_0 ,
    result_10_sp_1,
    \result[10]_0 ,
    result_11_sp_1,
    \result[11]_0 ,
    result_12_sp_1,
    \result[12]_0 ,
    result_13_sp_1,
    \result[13]_0 ,
    result_14_sp_1,
    \result[14]_0 ,
    result_15_sp_1,
    \result[15]_0 ,
    result_16_sp_1,
    \result[16]_0 ,
    \result[16]_1 ,
    result_17_sp_1,
    \result[17]_0 ,
    result_18_sp_1,
    \result[18]_0 ,
    result_19_sp_1,
    \result[19]_0 ,
    result_20_sp_1,
    \result[20]_0 ,
    result_21_sp_1,
    \result[21]_0 ,
    result_22_sp_1,
    \result[22]_0 ,
    result_23_sp_1,
    \result[23]_0 ,
    result_24_sp_1,
    \result[24]_0 ,
    result_25_sp_1,
    \result[25]_0 ,
    result_26_sp_1,
    \result[26]_0 ,
    result_27_sp_1,
    \result[27]_0 ,
    result_28_sp_1,
    \result[28]_0 ,
    \result[28]_1 ,
    result_29_sp_1,
    \result[29]_0 ,
    result_30_sp_1,
    \result[1]_1 ,
    \result[1]_2 );
  output [31:0]result;
  output lessthan;
  output zero;
  input [31:0]a;
  input [31:0]b;
  input [3:0]alucontrol;
  input result_31_sp_1;
  input \result[31]_0 ;
  input \result[31]_1 ;
  input \result[31]_2 ;
  input \result[31]_3 ;
  input result_0_sp_1;
  input \result[0]_0 ;
  input \result[0]_1 ;
  input \result[0]_2 ;
  input result_1_sp_1;
  input \result[1]_0 ;
  input result_2_sp_1;
  input \result[2]_0 ;
  input result_3_sp_1;
  input \result[3]_0 ;
  input result_4_sp_1;
  input \result[4]_0 ;
  input result_5_sp_1;
  input \result[5]_0 ;
  input \result[5]_1 ;
  input result_6_sp_1;
  input \result[6]_0 ;
  input result_7_sp_1;
  input \result[7]_0 ;
  input \result[2]_1 ;
  input \result[2]_2 ;
  input \result[2]_3 ;
  input \result[3]_1 ;
  input \result[4]_INST_0_i_3_0 ;
  input result_8_sp_1;
  input \result[8]_0 ;
  input result_9_sp_1;
  input \result[9]_0 ;
  input result_10_sp_1;
  input \result[10]_0 ;
  input result_11_sp_1;
  input \result[11]_0 ;
  input result_12_sp_1;
  input \result[12]_0 ;
  input result_13_sp_1;
  input \result[13]_0 ;
  input result_14_sp_1;
  input \result[14]_0 ;
  input result_15_sp_1;
  input \result[15]_0 ;
  input result_16_sp_1;
  input \result[16]_0 ;
  input \result[16]_1 ;
  input result_17_sp_1;
  input \result[17]_0 ;
  input result_18_sp_1;
  input \result[18]_0 ;
  input result_19_sp_1;
  input \result[19]_0 ;
  input result_20_sp_1;
  input \result[20]_0 ;
  input result_21_sp_1;
  input \result[21]_0 ;
  input result_22_sp_1;
  input \result[22]_0 ;
  input result_23_sp_1;
  input \result[23]_0 ;
  input result_24_sp_1;
  input \result[24]_0 ;
  input result_25_sp_1;
  input \result[25]_0 ;
  input result_26_sp_1;
  input \result[26]_0 ;
  input result_27_sp_1;
  input \result[27]_0 ;
  input result_28_sp_1;
  input \result[28]_0 ;
  input \result[28]_1 ;
  input result_29_sp_1;
  input \result[29]_0 ;
  input result_30_sp_1;
  input \result[1]_1 ;
  input \result[1]_2 ;

  wire [31:0]a;
  wire [3:0]alucontrol;
  wire [31:0]b;
  wire lessthan;
  wire [31:0]result;
  wire \result[0]_0 ;
  wire \result[0]_1 ;
  wire \result[0]_2 ;
  wire \result[0]_INST_0_i_2_n_0 ;
  wire \result[0]_INST_0_i_3_n_0 ;
  wire \result[10]_0 ;
  wire \result[10]_INST_0_i_2_n_0 ;
  wire \result[11]_0 ;
  wire \result[11]_INST_0_i_2_n_0 ;
  wire \result[12]_0 ;
  wire \result[12]_INST_0_i_2_n_0 ;
  wire \result[13]_0 ;
  wire \result[13]_INST_0_i_2_n_0 ;
  wire \result[14]_0 ;
  wire \result[14]_INST_0_i_2_n_0 ;
  wire \result[15]_0 ;
  wire \result[15]_INST_0_i_2_n_0 ;
  wire \result[16]_0 ;
  wire \result[16]_1 ;
  wire \result[16]_INST_0_i_1_n_0 ;
  wire \result[17]_0 ;
  wire \result[17]_INST_0_i_1_n_0 ;
  wire \result[18]_0 ;
  wire \result[18]_INST_0_i_1_n_0 ;
  wire \result[19]_0 ;
  wire \result[19]_INST_0_i_1_n_0 ;
  wire \result[1]_0 ;
  wire \result[1]_1 ;
  wire \result[1]_2 ;
  wire \result[1]_INST_0_i_2_n_0 ;
  wire \result[20]_0 ;
  wire \result[20]_INST_0_i_1_n_0 ;
  wire \result[21]_0 ;
  wire \result[21]_INST_0_i_1_n_0 ;
  wire \result[22]_0 ;
  wire \result[22]_INST_0_i_1_n_0 ;
  wire \result[23]_0 ;
  wire \result[23]_INST_0_i_1_n_0 ;
  wire \result[24]_0 ;
  wire \result[24]_INST_0_i_1_n_0 ;
  wire \result[25]_0 ;
  wire \result[25]_INST_0_i_1_n_0 ;
  wire \result[26]_0 ;
  wire \result[26]_INST_0_i_1_n_0 ;
  wire \result[27]_0 ;
  wire \result[27]_INST_0_i_1_n_0 ;
  wire \result[28]_0 ;
  wire \result[28]_1 ;
  wire \result[28]_INST_0_i_1_n_0 ;
  wire \result[29]_0 ;
  wire \result[29]_INST_0_i_1_n_0 ;
  wire \result[2]_0 ;
  wire \result[2]_1 ;
  wire \result[2]_2 ;
  wire \result[2]_3 ;
  wire \result[2]_INST_0_i_2_n_0 ;
  wire \result[30]_INST_0_i_1_n_0 ;
  wire \result[31]_0 ;
  wire \result[31]_1 ;
  wire \result[31]_2 ;
  wire \result[31]_3 ;
  wire \result[31]_INST_0_i_1_n_0 ;
  wire \result[3]_0 ;
  wire \result[3]_1 ;
  wire \result[3]_INST_0_i_2_n_0 ;
  wire \result[3]_INST_0_i_6_n_0 ;
  wire \result[4]_0 ;
  wire \result[4]_INST_0_i_13_n_0 ;
  wire \result[4]_INST_0_i_3_0 ;
  wire \result[4]_INST_0_i_3_n_0 ;
  wire \result[5]_0 ;
  wire \result[5]_1 ;
  wire \result[5]_INST_0_i_2_n_0 ;
  wire \result[6]_0 ;
  wire \result[6]_INST_0_i_2_n_0 ;
  wire \result[7]_0 ;
  wire \result[7]_INST_0_i_2_n_0 ;
  wire \result[8]_0 ;
  wire \result[8]_INST_0_i_2_n_0 ;
  wire \result[9]_0 ;
  wire \result[9]_INST_0_i_2_n_0 ;
  wire result_0_sn_1;
  wire result_10_sn_1;
  wire result_11_sn_1;
  wire result_12_sn_1;
  wire result_13_sn_1;
  wire result_14_sn_1;
  wire result_15_sn_1;
  wire result_16_sn_1;
  wire result_17_sn_1;
  wire result_18_sn_1;
  wire result_19_sn_1;
  wire result_1_sn_1;
  wire result_20_sn_1;
  wire result_21_sn_1;
  wire result_22_sn_1;
  wire result_23_sn_1;
  wire result_24_sn_1;
  wire result_25_sn_1;
  wire result_26_sn_1;
  wire result_27_sn_1;
  wire result_28_sn_1;
  wire result_29_sn_1;
  wire result_2_sn_1;
  wire result_30_sn_1;
  wire result_31_sn_1;
  wire result_3_sn_1;
  wire result_4_sn_1;
  wire result_5_sn_1;
  wire result_6_sn_1;
  wire result_7_sn_1;
  wire result_8_sn_1;
  wire result_9_sn_1;
  wire [31:0]sum__93;
  wire sum_carry__0_n_0;
  wire sum_carry__0_n_1;
  wire sum_carry__0_n_2;
  wire sum_carry__0_n_3;
  wire sum_carry__1_n_0;
  wire sum_carry__1_n_1;
  wire sum_carry__1_n_2;
  wire sum_carry__1_n_3;
  wire sum_carry__2_n_0;
  wire sum_carry__2_n_1;
  wire sum_carry__2_n_2;
  wire sum_carry__2_n_3;
  wire sum_carry__3_n_0;
  wire sum_carry__3_n_1;
  wire sum_carry__3_n_2;
  wire sum_carry__3_n_3;
  wire sum_carry__4_n_0;
  wire sum_carry__4_n_1;
  wire sum_carry__4_n_2;
  wire sum_carry__4_n_3;
  wire sum_carry__5_n_0;
  wire sum_carry__5_n_1;
  wire sum_carry__5_n_2;
  wire sum_carry__5_n_3;
  wire sum_carry__6_n_1;
  wire sum_carry__6_n_2;
  wire sum_carry__6_n_3;
  wire sum_carry_i_1__0_n_0;
  wire sum_carry_i_1__1_n_0;
  wire sum_carry_i_1__2_n_0;
  wire sum_carry_i_1__3_n_0;
  wire sum_carry_i_1__4_n_0;
  wire sum_carry_i_1__5_n_0;
  wire sum_carry_i_1__6_n_0;
  wire sum_carry_i_1_n_0;
  wire sum_carry_i_2__0_n_0;
  wire sum_carry_i_2__1_n_0;
  wire sum_carry_i_2__2_n_0;
  wire sum_carry_i_2__3_n_0;
  wire sum_carry_i_2__4_n_0;
  wire sum_carry_i_2__5_n_0;
  wire sum_carry_i_2__6_n_0;
  wire sum_carry_i_2_n_0;
  wire sum_carry_i_3__0_n_0;
  wire sum_carry_i_3__1_n_0;
  wire sum_carry_i_3__2_n_0;
  wire sum_carry_i_3__3_n_0;
  wire sum_carry_i_3__4_n_0;
  wire sum_carry_i_3__5_n_0;
  wire sum_carry_i_3__6_n_0;
  wire sum_carry_i_3_n_0;
  wire sum_carry_i_4__0_n_0;
  wire sum_carry_i_4__1_n_0;
  wire sum_carry_i_4__2_n_0;
  wire sum_carry_i_4__3_n_0;
  wire sum_carry_i_4__4_n_0;
  wire sum_carry_i_4__5_n_0;
  wire sum_carry_i_4__6_n_0;
  wire sum_carry_i_4_n_0;
  wire sum_carry_i_5_n_0;
  wire sum_carry_n_0;
  wire sum_carry_n_1;
  wire sum_carry_n_2;
  wire sum_carry_n_3;
  wire zero;
  wire zero_INST_0_i_1_n_0;
  wire zero_INST_0_i_2_n_0;
  wire zero_INST_0_i_3_n_0;
  wire zero_INST_0_i_4_n_0;
  wire zero_INST_0_i_5_n_0;
  wire zero_INST_0_i_6_n_0;
  wire zero_INST_0_i_7_n_0;
  wire zero_INST_0_i_8_n_0;
  wire [3:3]NLW_sum_carry__6_CO_UNCONNECTED;

  assign result_0_sn_1 = result_0_sp_1;
  assign result_10_sn_1 = result_10_sp_1;
  assign result_11_sn_1 = result_11_sp_1;
  assign result_12_sn_1 = result_12_sp_1;
  assign result_13_sn_1 = result_13_sp_1;
  assign result_14_sn_1 = result_14_sp_1;
  assign result_15_sn_1 = result_15_sp_1;
  assign result_16_sn_1 = result_16_sp_1;
  assign result_17_sn_1 = result_17_sp_1;
  assign result_18_sn_1 = result_18_sp_1;
  assign result_19_sn_1 = result_19_sp_1;
  assign result_1_sn_1 = result_1_sp_1;
  assign result_20_sn_1 = result_20_sp_1;
  assign result_21_sn_1 = result_21_sp_1;
  assign result_22_sn_1 = result_22_sp_1;
  assign result_23_sn_1 = result_23_sp_1;
  assign result_24_sn_1 = result_24_sp_1;
  assign result_25_sn_1 = result_25_sp_1;
  assign result_26_sn_1 = result_26_sp_1;
  assign result_27_sn_1 = result_27_sp_1;
  assign result_28_sn_1 = result_28_sp_1;
  assign result_29_sn_1 = result_29_sp_1;
  assign result_2_sn_1 = result_2_sp_1;
  assign result_30_sn_1 = result_30_sp_1;
  assign result_31_sn_1 = result_31_sp_1;
  assign result_3_sn_1 = result_3_sp_1;
  assign result_4_sn_1 = result_4_sp_1;
  assign result_5_sn_1 = result_5_sp_1;
  assign result_6_sn_1 = result_6_sp_1;
  assign result_7_sn_1 = result_7_sp_1;
  assign result_8_sn_1 = result_8_sp_1;
  assign result_9_sn_1 = result_9_sp_1;
  LUT6 #(
    .INIT(64'h8EB28E8E8E8E8E8E)) 
    lessthan_INST_0
       (.I0(sum__93[31]),
        .I1(a[31]),
        .I2(b[31]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(alucontrol[1]),
        .O(lessthan));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \result[0]_INST_0 
       (.I0(result_0_sn_1),
        .I1(\result[0]_0 ),
        .I2(\result[0]_1 ),
        .I3(\result[0]_2 ),
        .I4(\result[0]_INST_0_i_2_n_0 ),
        .I5(\result[0]_INST_0_i_3_n_0 ),
        .O(result[0]));
  LUT6 #(
    .INIT(64'hFFFF88888F888888)) 
    \result[0]_INST_0_i_2 
       (.I0(\result[2]_2 ),
        .I1(sum__93[0]),
        .I2(b[0]),
        .I3(\result[3]_1 ),
        .I4(a[0]),
        .I5(\result[1]_2 ),
        .O(\result[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAA03A300A000A00)) 
    \result[0]_INST_0_i_3 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(lessthan),
        .I4(a[0]),
        .I5(b[0]),
        .O(\result[0]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[10]_INST_0 
       (.I0(result_10_sn_1),
        .I1(\result[10]_INST_0_i_2_n_0 ),
        .I2(\result[10]_0 ),
        .I3(b[10]),
        .I4(a[10]),
        .I5(\result[5]_1 ),
        .O(result[10]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[10]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[10]),
        .I4(a[10]),
        .I5(b[10]),
        .O(\result[10]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[11]_INST_0 
       (.I0(result_11_sn_1),
        .I1(\result[11]_INST_0_i_2_n_0 ),
        .I2(\result[11]_0 ),
        .I3(b[11]),
        .I4(a[11]),
        .I5(\result[5]_1 ),
        .O(result[11]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[11]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[11]),
        .I4(a[11]),
        .I5(b[11]),
        .O(\result[11]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[12]_INST_0 
       (.I0(result_12_sn_1),
        .I1(\result[12]_INST_0_i_2_n_0 ),
        .I2(\result[12]_0 ),
        .I3(b[12]),
        .I4(a[12]),
        .I5(\result[5]_1 ),
        .O(result[12]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[12]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[12]),
        .I4(a[12]),
        .I5(b[12]),
        .O(\result[12]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[13]_INST_0 
       (.I0(result_13_sn_1),
        .I1(\result[13]_INST_0_i_2_n_0 ),
        .I2(\result[13]_0 ),
        .I3(b[13]),
        .I4(a[13]),
        .I5(\result[5]_1 ),
        .O(result[13]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[13]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[13]),
        .I4(a[13]),
        .I5(b[13]),
        .O(\result[13]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[14]_INST_0 
       (.I0(result_14_sn_1),
        .I1(\result[14]_INST_0_i_2_n_0 ),
        .I2(\result[14]_0 ),
        .I3(b[14]),
        .I4(a[14]),
        .I5(\result[5]_1 ),
        .O(result[14]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[14]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[14]),
        .I4(a[14]),
        .I5(b[14]),
        .O(\result[14]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[15]_INST_0 
       (.I0(result_15_sn_1),
        .I1(\result[15]_INST_0_i_2_n_0 ),
        .I2(\result[15]_0 ),
        .I3(b[15]),
        .I4(a[15]),
        .I5(\result[5]_1 ),
        .O(result[15]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[15]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[15]),
        .I4(a[15]),
        .I5(b[15]),
        .O(\result[15]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[16]_INST_0 
       (.I0(\result[16]_INST_0_i_1_n_0 ),
        .I1(result_16_sn_1),
        .I2(\result[16]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[16]_1 ),
        .I5(\result[0]_2 ),
        .O(result[16]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[16]_INST_0_i_1 
       (.I0(sum__93[16]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[16]),
        .I5(b[16]),
        .O(\result[16]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[17]_INST_0 
       (.I0(\result[17]_INST_0_i_1_n_0 ),
        .I1(result_17_sn_1),
        .I2(\result[17]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[16]_0 ),
        .I5(\result[0]_2 ),
        .O(result[17]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[17]_INST_0_i_1 
       (.I0(sum__93[17]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[17]),
        .I5(b[17]),
        .O(\result[17]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[18]_INST_0 
       (.I0(\result[18]_INST_0_i_1_n_0 ),
        .I1(result_18_sn_1),
        .I2(\result[18]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[17]_0 ),
        .I5(\result[0]_2 ),
        .O(result[18]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[18]_INST_0_i_1 
       (.I0(sum__93[18]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[18]),
        .I5(b[18]),
        .O(\result[18]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[19]_INST_0 
       (.I0(\result[19]_INST_0_i_1_n_0 ),
        .I1(result_19_sn_1),
        .I2(\result[19]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[18]_0 ),
        .I5(\result[0]_2 ),
        .O(result[19]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[19]_INST_0_i_1 
       (.I0(sum__93[19]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[19]),
        .I5(b[19]),
        .O(\result[19]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \result[1]_INST_0 
       (.I0(result_1_sn_1),
        .I1(\result[0]_0 ),
        .I2(result_0_sn_1),
        .I3(\result[0]_2 ),
        .I4(\result[1]_INST_0_i_2_n_0 ),
        .I5(\result[1]_0 ),
        .O(result[1]));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \result[1]_INST_0_i_2 
       (.I0(\result[2]_2 ),
        .I1(sum__93[1]),
        .I2(\result[1]_1 ),
        .I3(\result[31]_0 ),
        .I4(a[1]),
        .I5(\result[1]_2 ),
        .O(\result[1]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[20]_INST_0 
       (.I0(\result[20]_INST_0_i_1_n_0 ),
        .I1(result_20_sn_1),
        .I2(\result[20]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[19]_0 ),
        .I5(\result[0]_2 ),
        .O(result[20]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[20]_INST_0_i_1 
       (.I0(sum__93[20]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[20]),
        .I5(b[20]),
        .O(\result[20]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[21]_INST_0 
       (.I0(\result[21]_INST_0_i_1_n_0 ),
        .I1(result_21_sn_1),
        .I2(\result[21]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[20]_0 ),
        .I5(\result[0]_2 ),
        .O(result[21]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[21]_INST_0_i_1 
       (.I0(sum__93[21]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[21]),
        .I5(b[21]),
        .O(\result[21]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[22]_INST_0 
       (.I0(\result[22]_INST_0_i_1_n_0 ),
        .I1(result_22_sn_1),
        .I2(\result[22]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[21]_0 ),
        .I5(\result[0]_2 ),
        .O(result[22]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[22]_INST_0_i_1 
       (.I0(sum__93[22]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[22]),
        .I5(b[22]),
        .O(\result[22]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[23]_INST_0 
       (.I0(\result[23]_INST_0_i_1_n_0 ),
        .I1(result_23_sn_1),
        .I2(\result[23]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[22]_0 ),
        .I5(\result[0]_2 ),
        .O(result[23]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[23]_INST_0_i_1 
       (.I0(sum__93[23]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[23]),
        .I5(b[23]),
        .O(\result[23]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[24]_INST_0 
       (.I0(\result[24]_INST_0_i_1_n_0 ),
        .I1(result_24_sn_1),
        .I2(\result[24]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[23]_0 ),
        .I5(\result[0]_2 ),
        .O(result[24]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[24]_INST_0_i_1 
       (.I0(sum__93[24]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[24]),
        .I5(b[24]),
        .O(\result[24]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[25]_INST_0 
       (.I0(\result[25]_INST_0_i_1_n_0 ),
        .I1(result_25_sn_1),
        .I2(\result[25]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[24]_0 ),
        .I5(\result[0]_2 ),
        .O(result[25]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[25]_INST_0_i_1 
       (.I0(sum__93[25]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[25]),
        .I5(b[25]),
        .O(\result[25]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[26]_INST_0 
       (.I0(\result[26]_INST_0_i_1_n_0 ),
        .I1(result_26_sn_1),
        .I2(\result[26]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[25]_0 ),
        .I5(\result[0]_2 ),
        .O(result[26]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[26]_INST_0_i_1 
       (.I0(sum__93[26]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[26]),
        .I5(b[26]),
        .O(\result[26]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \result[27]_INST_0 
       (.I0(\result[27]_INST_0_i_1_n_0 ),
        .I1(result_27_sn_1),
        .I2(\result[27]_0 ),
        .I3(\result[0]_0 ),
        .I4(\result[26]_0 ),
        .I5(\result[0]_2 ),
        .O(result[27]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[27]_INST_0_i_1 
       (.I0(sum__93[27]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[27]),
        .I5(b[27]),
        .O(\result[27]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEAEAEA)) 
    \result[28]_INST_0 
       (.I0(\result[28]_INST_0_i_1_n_0 ),
        .I1(result_28_sn_1),
        .I2(\result[31]_0 ),
        .I3(\result[28]_0 ),
        .I4(\result[31]_2 ),
        .I5(\result[28]_1 ),
        .O(result[28]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[28]_INST_0_i_1 
       (.I0(sum__93[28]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[28]),
        .I5(b[28]),
        .O(\result[28]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEAEAEA)) 
    \result[29]_INST_0 
       (.I0(\result[29]_INST_0_i_1_n_0 ),
        .I1(\result[28]_0 ),
        .I2(\result[31]_0 ),
        .I3(result_29_sn_1),
        .I4(\result[31]_2 ),
        .I5(\result[29]_0 ),
        .O(result[29]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[29]_INST_0_i_1 
       (.I0(sum__93[29]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[29]),
        .I5(b[29]),
        .O(\result[29]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \result[2]_INST_0 
       (.I0(result_2_sn_1),
        .I1(\result[0]_0 ),
        .I2(result_1_sn_1),
        .I3(\result[0]_2 ),
        .I4(\result[2]_INST_0_i_2_n_0 ),
        .I5(\result[2]_0 ),
        .O(result[2]));
  LUT5 #(
    .INIT(32'hFFEAEAEA)) 
    \result[2]_INST_0_i_2 
       (.I0(\result[2]_1 ),
        .I1(\result[2]_2 ),
        .I2(sum__93[2]),
        .I3(\result[31]_2 ),
        .I4(\result[2]_3 ),
        .O(\result[2]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEAEAEA)) 
    \result[30]_INST_0 
       (.I0(\result[30]_INST_0_i_1_n_0 ),
        .I1(result_29_sn_1),
        .I2(\result[31]_0 ),
        .I3(result_31_sn_1),
        .I4(\result[31]_2 ),
        .I5(result_30_sn_1),
        .O(result[30]));
  LUT6 #(
    .INIT(64'hC0C200F200F20002)) 
    \result[30]_INST_0_i_1 
       (.I0(sum__93[30]),
        .I1(alucontrol[1]),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(a[30]),
        .I5(b[30]),
        .O(\result[30]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFEAEAEA)) 
    \result[31]_INST_0 
       (.I0(\result[31]_INST_0_i_1_n_0 ),
        .I1(result_31_sn_1),
        .I2(\result[31]_0 ),
        .I3(\result[31]_1 ),
        .I4(\result[31]_2 ),
        .I5(\result[31]_3 ),
        .O(result[31]));
  LUT6 #(
    .INIT(64'hC0000000FC3C00AA)) 
    \result[31]_INST_0_i_1 
       (.I0(sum__93[31]),
        .I1(a[31]),
        .I2(b[31]),
        .I3(alucontrol[1]),
        .I4(alucontrol[2]),
        .I5(alucontrol[0]),
        .O(\result[31]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \result[3]_INST_0 
       (.I0(result_3_sn_1),
        .I1(\result[0]_0 ),
        .I2(result_2_sn_1),
        .I3(\result[0]_2 ),
        .I4(\result[3]_INST_0_i_2_n_0 ),
        .I5(\result[3]_0 ),
        .O(result[3]));
  LUT6 #(
    .INIT(64'hFFFFFFFF8F888888)) 
    \result[3]_INST_0_i_2 
       (.I0(\result[31]_0 ),
        .I1(\result[2]_3 ),
        .I2(a[3]),
        .I3(b[3]),
        .I4(\result[3]_1 ),
        .I5(\result[3]_INST_0_i_6_n_0 ),
        .O(\result[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000002200F0)) 
    \result[3]_INST_0_i_6 
       (.I0(\result[4]_INST_0_i_3_0 ),
        .I1(b[0]),
        .I2(sum__93[3]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(alucontrol[1]),
        .O(\result[3]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \result[4]_INST_0 
       (.I0(result_4_sn_1),
        .I1(\result[0]_0 ),
        .I2(result_3_sn_1),
        .I3(\result[0]_2 ),
        .I4(\result[4]_INST_0_i_3_n_0 ),
        .I5(\result[4]_0 ),
        .O(result[4]));
  LUT6 #(
    .INIT(64'h00000000008800F0)) 
    \result[4]_INST_0_i_13 
       (.I0(\result[4]_INST_0_i_3_0 ),
        .I1(b[0]),
        .I2(sum__93[4]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(alucontrol[1]),
        .O(\result[4]_INST_0_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF8C000400)) 
    \result[4]_INST_0_i_3 
       (.I0(b[4]),
        .I1(a[4]),
        .I2(alucontrol[0]),
        .I3(alucontrol[2]),
        .I4(alucontrol[1]),
        .I5(\result[4]_INST_0_i_13_n_0 ),
        .O(\result[4]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[5]_INST_0 
       (.I0(result_5_sn_1),
        .I1(\result[5]_INST_0_i_2_n_0 ),
        .I2(\result[5]_0 ),
        .I3(b[5]),
        .I4(a[5]),
        .I5(\result[5]_1 ),
        .O(result[5]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[5]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[5]),
        .I4(a[5]),
        .I5(b[5]),
        .O(\result[5]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[6]_INST_0 
       (.I0(result_6_sn_1),
        .I1(\result[6]_INST_0_i_2_n_0 ),
        .I2(\result[6]_0 ),
        .I3(b[6]),
        .I4(a[6]),
        .I5(\result[5]_1 ),
        .O(result[6]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[6]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[6]),
        .I4(a[6]),
        .I5(b[6]),
        .O(\result[6]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[7]_INST_0 
       (.I0(result_7_sn_1),
        .I1(\result[7]_INST_0_i_2_n_0 ),
        .I2(\result[7]_0 ),
        .I3(b[7]),
        .I4(a[7]),
        .I5(\result[5]_1 ),
        .O(result[7]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[7]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[7]),
        .I4(a[7]),
        .I5(b[7]),
        .O(\result[7]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[8]_INST_0 
       (.I0(result_8_sn_1),
        .I1(\result[8]_INST_0_i_2_n_0 ),
        .I2(\result[8]_0 ),
        .I3(b[8]),
        .I4(a[8]),
        .I5(\result[5]_1 ),
        .O(result[8]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[8]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[8]),
        .I4(a[8]),
        .I5(b[8]),
        .O(\result[8]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFEFEFEFE)) 
    \result[9]_INST_0 
       (.I0(result_9_sn_1),
        .I1(\result[9]_INST_0_i_2_n_0 ),
        .I2(\result[9]_0 ),
        .I3(b[9]),
        .I4(a[9]),
        .I5(\result[5]_1 ),
        .O(result[9]));
  LUT6 #(
    .INIT(64'hA1A0313031300100)) 
    \result[9]_INST_0_i_2 
       (.I0(alucontrol[1]),
        .I1(alucontrol[0]),
        .I2(alucontrol[2]),
        .I3(sum__93[9]),
        .I4(a[9]),
        .I5(b[9]),
        .O(\result[9]_INST_0_i_2_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry
       (.CI(1'b0),
        .CO({sum_carry_n_0,sum_carry_n_1,sum_carry_n_2,sum_carry_n_3}),
        .CYINIT(sum_carry_i_1__6_n_0),
        .DI(a[3:0]),
        .O(sum__93[3:0]),
        .S({sum_carry_i_2_n_0,sum_carry_i_3_n_0,sum_carry_i_4_n_0,sum_carry_i_5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__0
       (.CI(sum_carry_n_0),
        .CO({sum_carry__0_n_0,sum_carry__0_n_1,sum_carry__0_n_2,sum_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(a[7:4]),
        .O(sum__93[7:4]),
        .S({sum_carry_i_1__0_n_0,sum_carry_i_2__0_n_0,sum_carry_i_3__0_n_0,sum_carry_i_4__0_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__1
       (.CI(sum_carry__0_n_0),
        .CO({sum_carry__1_n_0,sum_carry__1_n_1,sum_carry__1_n_2,sum_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(a[11:8]),
        .O(sum__93[11:8]),
        .S({sum_carry_i_1__1_n_0,sum_carry_i_2__1_n_0,sum_carry_i_3__1_n_0,sum_carry_i_4__1_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__2
       (.CI(sum_carry__1_n_0),
        .CO({sum_carry__2_n_0,sum_carry__2_n_1,sum_carry__2_n_2,sum_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(a[15:12]),
        .O(sum__93[15:12]),
        .S({sum_carry_i_1__2_n_0,sum_carry_i_2__2_n_0,sum_carry_i_3__2_n_0,sum_carry_i_4__2_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__3
       (.CI(sum_carry__2_n_0),
        .CO({sum_carry__3_n_0,sum_carry__3_n_1,sum_carry__3_n_2,sum_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(a[19:16]),
        .O(sum__93[19:16]),
        .S({sum_carry_i_1__3_n_0,sum_carry_i_2__3_n_0,sum_carry_i_3__3_n_0,sum_carry_i_4__3_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__4
       (.CI(sum_carry__3_n_0),
        .CO({sum_carry__4_n_0,sum_carry__4_n_1,sum_carry__4_n_2,sum_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI(a[23:20]),
        .O(sum__93[23:20]),
        .S({sum_carry_i_1__4_n_0,sum_carry_i_2__4_n_0,sum_carry_i_3__4_n_0,sum_carry_i_4__4_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__5
       (.CI(sum_carry__4_n_0),
        .CO({sum_carry__5_n_0,sum_carry__5_n_1,sum_carry__5_n_2,sum_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI(a[27:24]),
        .O(sum__93[27:24]),
        .S({sum_carry_i_1__5_n_0,sum_carry_i_2__5_n_0,sum_carry_i_3__5_n_0,sum_carry_i_4__5_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_carry__6
       (.CI(sum_carry__5_n_0),
        .CO({NLW_sum_carry__6_CO_UNCONNECTED[3],sum_carry__6_n_1,sum_carry__6_n_2,sum_carry__6_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,a[30:28]}),
        .O(sum__93[31:28]),
        .S({sum_carry_i_1_n_0,sum_carry_i_2__6_n_0,sum_carry_i_3__6_n_0,sum_carry_i_4__6_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1
       (.I0(b[31]),
        .I1(a[31]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__0
       (.I0(a[7]),
        .I1(b[7]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__1
       (.I0(a[11]),
        .I1(b[11]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__2
       (.I0(a[15]),
        .I1(b[15]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__3
       (.I0(a[19]),
        .I1(b[19]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__4
       (.I0(a[23]),
        .I1(b[23]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_1__5
       (.I0(a[27]),
        .I1(b[27]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_1__5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_carry_i_1__6
       (.I0(alucontrol[3]),
        .I1(b[0]),
        .O(sum_carry_i_1__6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2
       (.I0(a[3]),
        .I1(b[3]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__0
       (.I0(a[6]),
        .I1(b[6]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__1
       (.I0(a[10]),
        .I1(b[10]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__2
       (.I0(a[14]),
        .I1(b[14]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__3
       (.I0(a[18]),
        .I1(b[18]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__4
       (.I0(a[22]),
        .I1(b[22]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__5
       (.I0(a[26]),
        .I1(b[26]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__5_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_2__6
       (.I0(a[30]),
        .I1(b[30]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_2__6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3
       (.I0(a[2]),
        .I1(b[2]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__0
       (.I0(a[5]),
        .I1(b[5]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__1
       (.I0(a[9]),
        .I1(b[9]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__2
       (.I0(a[13]),
        .I1(b[13]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__3
       (.I0(a[17]),
        .I1(b[17]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__4
       (.I0(a[21]),
        .I1(b[21]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__5
       (.I0(a[25]),
        .I1(b[25]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__5_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_3__6
       (.I0(a[29]),
        .I1(b[29]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_3__6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4
       (.I0(a[1]),
        .I1(b[1]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__0
       (.I0(a[4]),
        .I1(b[4]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__0_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__1
       (.I0(a[8]),
        .I1(b[8]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__2
       (.I0(a[12]),
        .I1(b[12]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__3
       (.I0(a[16]),
        .I1(b[16]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__4
       (.I0(a[20]),
        .I1(b[20]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__5
       (.I0(a[24]),
        .I1(b[24]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__5_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum_carry_i_4__6
       (.I0(a[28]),
        .I1(b[28]),
        .I2(alucontrol[3]),
        .O(sum_carry_i_4__6_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_carry_i_5
       (.I0(a[0]),
        .I1(alucontrol[3]),
        .O(sum_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    zero_INST_0
       (.I0(zero_INST_0_i_1_n_0),
        .I1(zero_INST_0_i_2_n_0),
        .I2(zero_INST_0_i_3_n_0),
        .I3(zero_INST_0_i_4_n_0),
        .O(zero));
  LUT5 #(
    .INIT(32'h00010000)) 
    zero_INST_0_i_1
       (.I0(sum__93[12]),
        .I1(sum__93[13]),
        .I2(sum__93[14]),
        .I3(sum__93[15]),
        .I4(zero_INST_0_i_5_n_0),
        .O(zero_INST_0_i_1_n_0));
  LUT5 #(
    .INIT(32'h00010000)) 
    zero_INST_0_i_2
       (.I0(sum__93[2]),
        .I1(sum__93[3]),
        .I2(sum__93[0]),
        .I3(sum__93[1]),
        .I4(zero_INST_0_i_6_n_0),
        .O(zero_INST_0_i_2_n_0));
  LUT5 #(
    .INIT(32'h00010000)) 
    zero_INST_0_i_3
       (.I0(sum__93[28]),
        .I1(sum__93[29]),
        .I2(sum__93[30]),
        .I3(sum__93[31]),
        .I4(zero_INST_0_i_7_n_0),
        .O(zero_INST_0_i_3_n_0));
  LUT5 #(
    .INIT(32'h00010000)) 
    zero_INST_0_i_4
       (.I0(sum__93[18]),
        .I1(sum__93[19]),
        .I2(sum__93[16]),
        .I3(sum__93[17]),
        .I4(zero_INST_0_i_8_n_0),
        .O(zero_INST_0_i_4_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    zero_INST_0_i_5
       (.I0(sum__93[11]),
        .I1(sum__93[10]),
        .I2(sum__93[9]),
        .I3(sum__93[8]),
        .O(zero_INST_0_i_5_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    zero_INST_0_i_6
       (.I0(sum__93[7]),
        .I1(sum__93[6]),
        .I2(sum__93[5]),
        .I3(sum__93[4]),
        .O(zero_INST_0_i_6_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    zero_INST_0_i_7
       (.I0(sum__93[27]),
        .I1(sum__93[26]),
        .I2(sum__93[25]),
        .I3(sum__93[24]),
        .O(zero_INST_0_i_7_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    zero_INST_0_i_8
       (.I0(sum__93[23]),
        .I1(sum__93[22]),
        .I2(sum__93[21]),
        .I3(sum__93[20]),
        .O(zero_INST_0_i_8_n_0));
endmodule

(* CHECK_LICENSE_TYPE = "singleriscv_bd_alu_0_0,alu,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "alu,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module singleriscv_bd_alu_0_0
   (a,
    b,
    alucontrol,
    result,
    zero,
    lessthan);
  input [31:0]a;
  input [31:0]b;
  input [3:0]alucontrol;
  output [31:0]result;
  output zero;
  output lessthan;

  wire [31:0]a;
  wire [3:0]alucontrol;
  wire [31:0]b;
  wire lessthan;
  wire [31:0]result;
  wire \result[0]_INST_0_i_1_n_0 ;
  wire \result[0]_INST_0_i_4_n_0 ;
  wire \result[0]_INST_0_i_5_n_0 ;
  wire \result[10]_INST_0_i_1_n_0 ;
  wire \result[10]_INST_0_i_3_n_0 ;
  wire \result[10]_INST_0_i_4_n_0 ;
  wire \result[10]_INST_0_i_5_n_0 ;
  wire \result[10]_INST_0_i_6_n_0 ;
  wire \result[11]_INST_0_i_1_n_0 ;
  wire \result[11]_INST_0_i_3_n_0 ;
  wire \result[11]_INST_0_i_4_n_0 ;
  wire \result[11]_INST_0_i_5_n_0 ;
  wire \result[11]_INST_0_i_6_n_0 ;
  wire \result[12]_INST_0_i_1_n_0 ;
  wire \result[12]_INST_0_i_3_n_0 ;
  wire \result[12]_INST_0_i_4_n_0 ;
  wire \result[12]_INST_0_i_5_n_0 ;
  wire \result[12]_INST_0_i_6_n_0 ;
  wire \result[12]_INST_0_i_7_n_0 ;
  wire \result[13]_INST_0_i_1_n_0 ;
  wire \result[13]_INST_0_i_3_n_0 ;
  wire \result[13]_INST_0_i_4_n_0 ;
  wire \result[13]_INST_0_i_5_n_0 ;
  wire \result[13]_INST_0_i_6_n_0 ;
  wire \result[13]_INST_0_i_7_n_0 ;
  wire \result[14]_INST_0_i_1_n_0 ;
  wire \result[14]_INST_0_i_3_n_0 ;
  wire \result[14]_INST_0_i_4_n_0 ;
  wire \result[14]_INST_0_i_5_n_0 ;
  wire \result[14]_INST_0_i_6_n_0 ;
  wire \result[14]_INST_0_i_7_n_0 ;
  wire \result[15]_INST_0_i_1_n_0 ;
  wire \result[15]_INST_0_i_3_n_0 ;
  wire \result[15]_INST_0_i_4_n_0 ;
  wire \result[15]_INST_0_i_5_n_0 ;
  wire \result[15]_INST_0_i_6_n_0 ;
  wire \result[15]_INST_0_i_7_n_0 ;
  wire \result[15]_INST_0_i_8_n_0 ;
  wire \result[16]_INST_0_i_2_n_0 ;
  wire \result[16]_INST_0_i_3_n_0 ;
  wire \result[16]_INST_0_i_4_n_0 ;
  wire \result[16]_INST_0_i_5_n_0 ;
  wire \result[16]_INST_0_i_6_n_0 ;
  wire \result[17]_INST_0_i_2_n_0 ;
  wire \result[17]_INST_0_i_3_n_0 ;
  wire \result[17]_INST_0_i_4_n_0 ;
  wire \result[17]_INST_0_i_5_n_0 ;
  wire \result[17]_INST_0_i_6_n_0 ;
  wire \result[18]_INST_0_i_2_n_0 ;
  wire \result[18]_INST_0_i_3_n_0 ;
  wire \result[18]_INST_0_i_4_n_0 ;
  wire \result[18]_INST_0_i_5_n_0 ;
  wire \result[18]_INST_0_i_6_n_0 ;
  wire \result[19]_INST_0_i_2_n_0 ;
  wire \result[19]_INST_0_i_3_n_0 ;
  wire \result[19]_INST_0_i_4_n_0 ;
  wire \result[19]_INST_0_i_5_n_0 ;
  wire \result[19]_INST_0_i_6_n_0 ;
  wire \result[1]_INST_0_i_1_n_0 ;
  wire \result[1]_INST_0_i_3_n_0 ;
  wire \result[1]_INST_0_i_4_n_0 ;
  wire \result[1]_INST_0_i_5_n_0 ;
  wire \result[1]_INST_0_i_6_n_0 ;
  wire \result[1]_INST_0_i_7_n_0 ;
  wire \result[20]_INST_0_i_2_n_0 ;
  wire \result[20]_INST_0_i_3_n_0 ;
  wire \result[20]_INST_0_i_4_n_0 ;
  wire \result[20]_INST_0_i_5_n_0 ;
  wire \result[20]_INST_0_i_6_n_0 ;
  wire \result[21]_INST_0_i_2_n_0 ;
  wire \result[21]_INST_0_i_3_n_0 ;
  wire \result[21]_INST_0_i_4_n_0 ;
  wire \result[21]_INST_0_i_5_n_0 ;
  wire \result[21]_INST_0_i_6_n_0 ;
  wire \result[22]_INST_0_i_2_n_0 ;
  wire \result[22]_INST_0_i_3_n_0 ;
  wire \result[22]_INST_0_i_4_n_0 ;
  wire \result[22]_INST_0_i_5_n_0 ;
  wire \result[22]_INST_0_i_6_n_0 ;
  wire \result[23]_INST_0_i_2_n_0 ;
  wire \result[23]_INST_0_i_3_n_0 ;
  wire \result[23]_INST_0_i_4_n_0 ;
  wire \result[23]_INST_0_i_5_n_0 ;
  wire \result[23]_INST_0_i_6_n_0 ;
  wire \result[24]_INST_0_i_2_n_0 ;
  wire \result[24]_INST_0_i_3_n_0 ;
  wire \result[24]_INST_0_i_4_n_0 ;
  wire \result[24]_INST_0_i_5_n_0 ;
  wire \result[24]_INST_0_i_6_n_0 ;
  wire \result[25]_INST_0_i_2_n_0 ;
  wire \result[25]_INST_0_i_3_n_0 ;
  wire \result[25]_INST_0_i_4_n_0 ;
  wire \result[25]_INST_0_i_5_n_0 ;
  wire \result[25]_INST_0_i_6_n_0 ;
  wire \result[26]_INST_0_i_2_n_0 ;
  wire \result[26]_INST_0_i_3_n_0 ;
  wire \result[26]_INST_0_i_4_n_0 ;
  wire \result[26]_INST_0_i_5_n_0 ;
  wire \result[26]_INST_0_i_6_n_0 ;
  wire \result[26]_INST_0_i_7_n_0 ;
  wire \result[27]_INST_0_i_10_n_0 ;
  wire \result[27]_INST_0_i_11_n_0 ;
  wire \result[27]_INST_0_i_2_n_0 ;
  wire \result[27]_INST_0_i_3_n_0 ;
  wire \result[27]_INST_0_i_4_n_0 ;
  wire \result[27]_INST_0_i_5_n_0 ;
  wire \result[27]_INST_0_i_6_n_0 ;
  wire \result[27]_INST_0_i_7_n_0 ;
  wire \result[27]_INST_0_i_8_n_0 ;
  wire \result[27]_INST_0_i_9_n_0 ;
  wire \result[28]_INST_0_i_2_n_0 ;
  wire \result[28]_INST_0_i_3_n_0 ;
  wire \result[28]_INST_0_i_4_n_0 ;
  wire \result[28]_INST_0_i_5_n_0 ;
  wire \result[29]_INST_0_i_2_n_0 ;
  wire \result[29]_INST_0_i_3_n_0 ;
  wire \result[29]_INST_0_i_4_n_0 ;
  wire \result[29]_INST_0_i_5_n_0 ;
  wire \result[2]_INST_0_i_1_n_0 ;
  wire \result[2]_INST_0_i_3_n_0 ;
  wire \result[2]_INST_0_i_4_n_0 ;
  wire \result[2]_INST_0_i_5_n_0 ;
  wire \result[2]_INST_0_i_6_n_0 ;
  wire \result[2]_INST_0_i_7_n_0 ;
  wire \result[2]_INST_0_i_8_n_0 ;
  wire \result[30]_INST_0_i_2_n_0 ;
  wire \result[30]_INST_0_i_3_n_0 ;
  wire \result[30]_INST_0_i_4_n_0 ;
  wire \result[30]_INST_0_i_5_n_0 ;
  wire \result[30]_INST_0_i_6_n_0 ;
  wire \result[30]_INST_0_i_7_n_0 ;
  wire \result[31]_INST_0_i_10_n_0 ;
  wire \result[31]_INST_0_i_11_n_0 ;
  wire \result[31]_INST_0_i_12_n_0 ;
  wire \result[31]_INST_0_i_13_n_0 ;
  wire \result[31]_INST_0_i_14_n_0 ;
  wire \result[31]_INST_0_i_15_n_0 ;
  wire \result[31]_INST_0_i_16_n_0 ;
  wire \result[31]_INST_0_i_17_n_0 ;
  wire \result[31]_INST_0_i_18_n_0 ;
  wire \result[31]_INST_0_i_2_n_0 ;
  wire \result[31]_INST_0_i_3_n_0 ;
  wire \result[31]_INST_0_i_4_n_0 ;
  wire \result[31]_INST_0_i_5_n_0 ;
  wire \result[31]_INST_0_i_6_n_0 ;
  wire \result[31]_INST_0_i_7_n_0 ;
  wire \result[31]_INST_0_i_8_n_0 ;
  wire \result[31]_INST_0_i_9_n_0 ;
  wire \result[3]_INST_0_i_1_n_0 ;
  wire \result[3]_INST_0_i_3_n_0 ;
  wire \result[3]_INST_0_i_4_n_0 ;
  wire \result[3]_INST_0_i_5_n_0 ;
  wire \result[3]_INST_0_i_7_n_0 ;
  wire \result[4]_INST_0_i_10_n_0 ;
  wire \result[4]_INST_0_i_11_n_0 ;
  wire \result[4]_INST_0_i_12_n_0 ;
  wire \result[4]_INST_0_i_14_n_0 ;
  wire \result[4]_INST_0_i_15_n_0 ;
  wire \result[4]_INST_0_i_16_n_0 ;
  wire \result[4]_INST_0_i_1_n_0 ;
  wire \result[4]_INST_0_i_2_n_0 ;
  wire \result[4]_INST_0_i_4_n_0 ;
  wire \result[4]_INST_0_i_5_n_0 ;
  wire \result[4]_INST_0_i_6_n_0 ;
  wire \result[4]_INST_0_i_7_n_0 ;
  wire \result[4]_INST_0_i_8_n_0 ;
  wire \result[4]_INST_0_i_9_n_0 ;
  wire \result[5]_INST_0_i_1_n_0 ;
  wire \result[5]_INST_0_i_3_n_0 ;
  wire \result[5]_INST_0_i_4_n_0 ;
  wire \result[6]_INST_0_i_1_n_0 ;
  wire \result[6]_INST_0_i_3_n_0 ;
  wire \result[6]_INST_0_i_4_n_0 ;
  wire \result[6]_INST_0_i_5_n_0 ;
  wire \result[7]_INST_0_i_1_n_0 ;
  wire \result[7]_INST_0_i_3_n_0 ;
  wire \result[7]_INST_0_i_4_n_0 ;
  wire \result[7]_INST_0_i_5_n_0 ;
  wire \result[7]_INST_0_i_6_n_0 ;
  wire \result[8]_INST_0_i_1_n_0 ;
  wire \result[8]_INST_0_i_3_n_0 ;
  wire \result[8]_INST_0_i_4_n_0 ;
  wire \result[8]_INST_0_i_5_n_0 ;
  wire \result[8]_INST_0_i_6_n_0 ;
  wire \result[9]_INST_0_i_1_n_0 ;
  wire \result[9]_INST_0_i_3_n_0 ;
  wire \result[9]_INST_0_i_4_n_0 ;
  wire \result[9]_INST_0_i_5_n_0 ;
  wire \result[9]_INST_0_i_6_n_0 ;
  wire zero;

  singleriscv_bd_alu_0_0_alu inst
       (.a(a),
        .alucontrol(alucontrol),
        .b(b),
        .lessthan(lessthan),
        .result(result),
        .\result[0]_0 (\result[27]_INST_0_i_4_n_0 ),
        .\result[0]_1 (\result[0]_INST_0_i_1_n_0 ),
        .\result[0]_2 (\result[27]_INST_0_i_6_n_0 ),
        .\result[10]_0 (\result[10]_INST_0_i_3_n_0 ),
        .\result[11]_0 (\result[11]_INST_0_i_3_n_0 ),
        .\result[12]_0 (\result[12]_INST_0_i_3_n_0 ),
        .\result[13]_0 (\result[13]_INST_0_i_3_n_0 ),
        .\result[14]_0 (\result[14]_INST_0_i_3_n_0 ),
        .\result[15]_0 (\result[15]_INST_0_i_3_n_0 ),
        .\result[16]_0 (\result[17]_INST_0_i_3_n_0 ),
        .\result[16]_1 (\result[16]_INST_0_i_3_n_0 ),
        .\result[17]_0 (\result[18]_INST_0_i_3_n_0 ),
        .\result[18]_0 (\result[19]_INST_0_i_3_n_0 ),
        .\result[19]_0 (\result[20]_INST_0_i_3_n_0 ),
        .\result[1]_0 (\result[1]_INST_0_i_3_n_0 ),
        .\result[1]_1 (\result[1]_INST_0_i_6_n_0 ),
        .\result[1]_2 (\result[1]_INST_0_i_7_n_0 ),
        .\result[20]_0 (\result[21]_INST_0_i_3_n_0 ),
        .\result[21]_0 (\result[22]_INST_0_i_3_n_0 ),
        .\result[22]_0 (\result[23]_INST_0_i_3_n_0 ),
        .\result[23]_0 (\result[24]_INST_0_i_3_n_0 ),
        .\result[24]_0 (\result[25]_INST_0_i_3_n_0 ),
        .\result[25]_0 (\result[26]_INST_0_i_3_n_0 ),
        .\result[26]_0 (\result[27]_INST_0_i_5_n_0 ),
        .\result[27]_0 (\result[27]_INST_0_i_3_n_0 ),
        .\result[28]_0 (\result[29]_INST_0_i_2_n_0 ),
        .\result[28]_1 (\result[28]_INST_0_i_3_n_0 ),
        .\result[29]_0 (\result[29]_INST_0_i_3_n_0 ),
        .\result[2]_0 (\result[2]_INST_0_i_3_n_0 ),
        .\result[2]_1 (\result[2]_INST_0_i_5_n_0 ),
        .\result[2]_2 (\result[2]_INST_0_i_6_n_0 ),
        .\result[2]_3 (\result[3]_INST_0_i_5_n_0 ),
        .\result[31]_0 (\result[31]_INST_0_i_3_n_0 ),
        .\result[31]_1 (\result[31]_INST_0_i_4_n_0 ),
        .\result[31]_2 (\result[31]_INST_0_i_5_n_0 ),
        .\result[31]_3 (\result[31]_INST_0_i_6_n_0 ),
        .\result[3]_0 (\result[3]_INST_0_i_3_n_0 ),
        .\result[3]_1 (\result[4]_INST_0_i_14_n_0 ),
        .\result[4]_0 (\result[4]_INST_0_i_4_n_0 ),
        .\result[4]_INST_0_i_3_0 (\result[4]_INST_0_i_16_n_0 ),
        .\result[5]_0 (\result[5]_INST_0_i_3_n_0 ),
        .\result[5]_1 (\result[15]_INST_0_i_4_n_0 ),
        .\result[6]_0 (\result[6]_INST_0_i_3_n_0 ),
        .\result[7]_0 (\result[7]_INST_0_i_3_n_0 ),
        .\result[8]_0 (\result[8]_INST_0_i_3_n_0 ),
        .\result[9]_0 (\result[9]_INST_0_i_3_n_0 ),
        .result_0_sp_1(\result[1]_INST_0_i_1_n_0 ),
        .result_10_sp_1(\result[10]_INST_0_i_1_n_0 ),
        .result_11_sp_1(\result[11]_INST_0_i_1_n_0 ),
        .result_12_sp_1(\result[12]_INST_0_i_1_n_0 ),
        .result_13_sp_1(\result[13]_INST_0_i_1_n_0 ),
        .result_14_sp_1(\result[14]_INST_0_i_1_n_0 ),
        .result_15_sp_1(\result[15]_INST_0_i_1_n_0 ),
        .result_16_sp_1(\result[16]_INST_0_i_2_n_0 ),
        .result_17_sp_1(\result[17]_INST_0_i_2_n_0 ),
        .result_18_sp_1(\result[18]_INST_0_i_2_n_0 ),
        .result_19_sp_1(\result[19]_INST_0_i_2_n_0 ),
        .result_1_sp_1(\result[2]_INST_0_i_1_n_0 ),
        .result_20_sp_1(\result[20]_INST_0_i_2_n_0 ),
        .result_21_sp_1(\result[21]_INST_0_i_2_n_0 ),
        .result_22_sp_1(\result[22]_INST_0_i_2_n_0 ),
        .result_23_sp_1(\result[23]_INST_0_i_2_n_0 ),
        .result_24_sp_1(\result[24]_INST_0_i_2_n_0 ),
        .result_25_sp_1(\result[25]_INST_0_i_2_n_0 ),
        .result_26_sp_1(\result[26]_INST_0_i_2_n_0 ),
        .result_27_sp_1(\result[27]_INST_0_i_2_n_0 ),
        .result_28_sp_1(\result[28]_INST_0_i_2_n_0 ),
        .result_29_sp_1(\result[30]_INST_0_i_2_n_0 ),
        .result_2_sp_1(\result[3]_INST_0_i_1_n_0 ),
        .result_30_sp_1(\result[30]_INST_0_i_3_n_0 ),
        .result_31_sp_1(\result[31]_INST_0_i_2_n_0 ),
        .result_3_sp_1(\result[4]_INST_0_i_2_n_0 ),
        .result_4_sp_1(\result[4]_INST_0_i_1_n_0 ),
        .result_5_sp_1(\result[5]_INST_0_i_1_n_0 ),
        .result_6_sp_1(\result[6]_INST_0_i_1_n_0 ),
        .result_7_sp_1(\result[7]_INST_0_i_1_n_0 ),
        .result_8_sp_1(\result[8]_INST_0_i_1_n_0 ),
        .result_9_sp_1(\result[9]_INST_0_i_1_n_0 ),
        .zero(zero));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFECECEC)) 
    \result[0]_INST_0_i_1 
       (.I0(\result[2]_INST_0_i_4_n_0 ),
        .I1(\result[0]_INST_0_i_4_n_0 ),
        .I2(b[1]),
        .I3(b[2]),
        .I4(\result[4]_INST_0_i_11_n_0 ),
        .I5(\result[0]_INST_0_i_5_n_0 ),
        .O(\result[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[0]_INST_0_i_4 
       (.I0(a[24]),
        .I1(a[16]),
        .I2(b[3]),
        .I3(b[4]),
        .I4(b[2]),
        .I5(b[1]),
        .O(\result[0]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000A0000000C)) 
    \result[0]_INST_0_i_5 
       (.I0(a[8]),
        .I1(a[0]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[0]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[10]_INST_0_i_1 
       (.I0(\result[11]_INST_0_i_4_n_0 ),
        .I1(\result[10]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[10]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[10]_INST_0_i_3 
       (.I0(\result[10]_INST_0_i_5_n_0 ),
        .I1(\result[11]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[10]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[10]_INST_0_i_4 
       (.I0(\result[14]_INST_0_i_6_n_0 ),
        .I1(\result[16]_INST_0_i_5_n_0 ),
        .I2(\result[4]_INST_0_i_10_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[12]_INST_0_i_6_n_0 ),
        .O(\result[10]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAEAFAEAAAEAAAE)) 
    \result[10]_INST_0_i_5 
       (.I0(\result[10]_INST_0_i_6_n_0 ),
        .I1(\result[16]_INST_0_i_6_n_0 ),
        .I2(b[2]),
        .I3(b[1]),
        .I4(\result[31]_INST_0_i_16_n_0 ),
        .I5(a[7]),
        .O(\result[10]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[10]_INST_0_i_6 
       (.I0(a[3]),
        .I1(a[5]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[10]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[11]_INST_0_i_1 
       (.I0(\result[12]_INST_0_i_4_n_0 ),
        .I1(\result[11]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[11]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[11]_INST_0_i_3 
       (.I0(\result[11]_INST_0_i_5_n_0 ),
        .I1(\result[12]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[11]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[11]_INST_0_i_4 
       (.I0(\result[15]_INST_0_i_7_n_0 ),
        .I1(\result[17]_INST_0_i_5_n_0 ),
        .I2(\result[4]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[13]_INST_0_i_6_n_0 ),
        .O(\result[11]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAFAEAAAE)) 
    \result[11]_INST_0_i_5 
       (.I0(\result[11]_INST_0_i_6_n_0 ),
        .I1(\result[17]_INST_0_i_6_n_0 ),
        .I2(b[2]),
        .I3(b[1]),
        .I4(\result[15]_INST_0_i_8_n_0 ),
        .O(\result[11]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[11]_INST_0_i_6 
       (.I0(a[4]),
        .I1(a[6]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[11]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[12]_INST_0_i_1 
       (.I0(\result[13]_INST_0_i_4_n_0 ),
        .I1(\result[12]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[12]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[12]_INST_0_i_3 
       (.I0(\result[12]_INST_0_i_5_n_0 ),
        .I1(\result[13]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[12]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[12]_INST_0_i_4 
       (.I0(\result[16]_INST_0_i_5_n_0 ),
        .I1(\result[18]_INST_0_i_5_n_0 ),
        .I2(\result[12]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[14]_INST_0_i_6_n_0 ),
        .O(\result[12]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAFAEAAAE)) 
    \result[12]_INST_0_i_5 
       (.I0(\result[12]_INST_0_i_7_n_0 ),
        .I1(\result[18]_INST_0_i_6_n_0 ),
        .I2(b[2]),
        .I3(b[1]),
        .I4(\result[16]_INST_0_i_6_n_0 ),
        .O(\result[12]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[12]_INST_0_i_6 
       (.I0(a[20]),
        .I1(a[28]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[12]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[12]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[12]_INST_0_i_7 
       (.I0(a[5]),
        .I1(a[7]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[12]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[13]_INST_0_i_1 
       (.I0(\result[14]_INST_0_i_4_n_0 ),
        .I1(\result[13]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[13]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[13]_INST_0_i_3 
       (.I0(\result[13]_INST_0_i_5_n_0 ),
        .I1(\result[14]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[13]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[13]_INST_0_i_4 
       (.I0(\result[17]_INST_0_i_5_n_0 ),
        .I1(\result[19]_INST_0_i_5_n_0 ),
        .I2(\result[13]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[15]_INST_0_i_7_n_0 ),
        .O(\result[13]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFEEFCCCCCEEFC)) 
    \result[13]_INST_0_i_5 
       (.I0(\result[15]_INST_0_i_8_n_0 ),
        .I1(\result[13]_INST_0_i_7_n_0 ),
        .I2(\result[19]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[17]_INST_0_i_6_n_0 ),
        .O(\result[13]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[13]_INST_0_i_6 
       (.I0(a[21]),
        .I1(a[29]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[13]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[13]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h10000000)) 
    \result[13]_INST_0_i_7 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(a[6]),
        .O(\result[13]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[14]_INST_0_i_1 
       (.I0(\result[15]_INST_0_i_5_n_0 ),
        .I1(\result[14]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[14]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[14]_INST_0_i_3 
       (.I0(\result[14]_INST_0_i_5_n_0 ),
        .I1(\result[15]_INST_0_i_6_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[14]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[14]_INST_0_i_4 
       (.I0(\result[18]_INST_0_i_5_n_0 ),
        .I1(\result[20]_INST_0_i_5_n_0 ),
        .I2(\result[14]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[16]_INST_0_i_5_n_0 ),
        .O(\result[14]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFEEFCCCCCEEFC)) 
    \result[14]_INST_0_i_5 
       (.I0(\result[16]_INST_0_i_6_n_0 ),
        .I1(\result[14]_INST_0_i_7_n_0 ),
        .I2(\result[20]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[18]_INST_0_i_6_n_0 ),
        .O(\result[14]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[14]_INST_0_i_6 
       (.I0(a[22]),
        .I1(a[30]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[14]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[14]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h10000000)) 
    \result[14]_INST_0_i_7 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(a[7]),
        .O(\result[14]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[15]_INST_0_i_1 
       (.I0(\result[16]_INST_0_i_3_n_0 ),
        .I1(\result[15]_INST_0_i_5_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[15]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[15]_INST_0_i_3 
       (.I0(\result[15]_INST_0_i_6_n_0 ),
        .I1(\result[16]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[15]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \result[15]_INST_0_i_4 
       (.I0(alucontrol[0]),
        .I1(alucontrol[2]),
        .I2(alucontrol[1]),
        .O(\result[15]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[15]_INST_0_i_5 
       (.I0(\result[19]_INST_0_i_5_n_0 ),
        .I1(\result[21]_INST_0_i_5_n_0 ),
        .I2(\result[15]_INST_0_i_7_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[17]_INST_0_i_5_n_0 ),
        .O(\result[15]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[15]_INST_0_i_6 
       (.I0(\result[17]_INST_0_i_6_n_0 ),
        .I1(\result[15]_INST_0_i_8_n_0 ),
        .I2(\result[21]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[19]_INST_0_i_6_n_0 ),
        .O(\result[15]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hEF232F23EC202C20)) 
    \result[15]_INST_0_i_7 
       (.I0(a[23]),
        .I1(b[4]),
        .I2(b[3]),
        .I3(a[31]),
        .I4(b[30]),
        .I5(a[15]),
        .O(\result[15]_INST_0_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[15]_INST_0_i_8 
       (.I0(a[0]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[8]),
        .O(\result[15]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[16]_INST_0_i_2 
       (.I0(\result[16]_INST_0_i_4_n_0 ),
        .I1(\result[17]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[16]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[16]_INST_0_i_3 
       (.I0(\result[20]_INST_0_i_5_n_0 ),
        .I1(\result[22]_INST_0_i_5_n_0 ),
        .I2(\result[16]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[18]_INST_0_i_5_n_0 ),
        .O(\result[16]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[16]_INST_0_i_4 
       (.I0(\result[18]_INST_0_i_6_n_0 ),
        .I1(\result[16]_INST_0_i_6_n_0 ),
        .I2(\result[22]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[20]_INST_0_i_6_n_0 ),
        .O(\result[16]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[16]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[16]),
        .I3(a[24]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[16]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[16]_INST_0_i_6 
       (.I0(a[1]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[9]),
        .O(\result[16]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[17]_INST_0_i_2 
       (.I0(\result[17]_INST_0_i_4_n_0 ),
        .I1(\result[18]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[17]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[17]_INST_0_i_3 
       (.I0(\result[21]_INST_0_i_5_n_0 ),
        .I1(\result[23]_INST_0_i_5_n_0 ),
        .I2(\result[17]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[19]_INST_0_i_5_n_0 ),
        .O(\result[17]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[17]_INST_0_i_4 
       (.I0(\result[19]_INST_0_i_6_n_0 ),
        .I1(\result[17]_INST_0_i_6_n_0 ),
        .I2(\result[23]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[21]_INST_0_i_6_n_0 ),
        .O(\result[17]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[17]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[17]),
        .I3(a[25]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[17]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[17]_INST_0_i_6 
       (.I0(a[2]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[10]),
        .O(\result[17]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[18]_INST_0_i_2 
       (.I0(\result[18]_INST_0_i_4_n_0 ),
        .I1(\result[19]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[18]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[18]_INST_0_i_3 
       (.I0(\result[22]_INST_0_i_5_n_0 ),
        .I1(\result[24]_INST_0_i_5_n_0 ),
        .I2(\result[18]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[20]_INST_0_i_5_n_0 ),
        .O(\result[18]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[18]_INST_0_i_4 
       (.I0(\result[20]_INST_0_i_6_n_0 ),
        .I1(\result[18]_INST_0_i_6_n_0 ),
        .I2(\result[24]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[22]_INST_0_i_6_n_0 ),
        .O(\result[18]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[18]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[18]),
        .I3(a[26]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[18]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[18]_INST_0_i_6 
       (.I0(a[3]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[11]),
        .O(\result[18]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[19]_INST_0_i_2 
       (.I0(\result[19]_INST_0_i_4_n_0 ),
        .I1(\result[20]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[19]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[19]_INST_0_i_3 
       (.I0(\result[23]_INST_0_i_5_n_0 ),
        .I1(\result[25]_INST_0_i_5_n_0 ),
        .I2(\result[19]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[21]_INST_0_i_5_n_0 ),
        .O(\result[19]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[19]_INST_0_i_4 
       (.I0(\result[21]_INST_0_i_6_n_0 ),
        .I1(\result[19]_INST_0_i_6_n_0 ),
        .I2(\result[25]_INST_0_i_6_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[23]_INST_0_i_6_n_0 ),
        .O(\result[19]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[19]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[19]),
        .I3(a[27]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[19]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[19]_INST_0_i_6 
       (.I0(a[4]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[12]),
        .O(\result[19]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFECECEC)) 
    \result[1]_INST_0_i_1 
       (.I0(\result[3]_INST_0_i_4_n_0 ),
        .I1(\result[1]_INST_0_i_4_n_0 ),
        .I2(b[1]),
        .I3(b[2]),
        .I4(\result[4]_INST_0_i_7_n_0 ),
        .I5(\result[1]_INST_0_i_5_n_0 ),
        .O(\result[1]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'h8E000600)) 
    \result[1]_INST_0_i_3 
       (.I0(a[1]),
        .I1(b[1]),
        .I2(alucontrol[0]),
        .I3(alucontrol[2]),
        .I4(alucontrol[1]),
        .O(\result[1]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[1]_INST_0_i_4 
       (.I0(a[25]),
        .I1(a[17]),
        .I2(b[3]),
        .I3(b[4]),
        .I4(b[2]),
        .I5(b[1]),
        .O(\result[1]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000A0000000C)) 
    \result[1]_INST_0_i_5 
       (.I0(a[9]),
        .I1(a[1]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[1]_INST_0_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h00010000)) 
    \result[1]_INST_0_i_6 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(a[0]),
        .O(\result[1]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00000002)) 
    \result[1]_INST_0_i_7 
       (.I0(\result[31]_INST_0_i_5_n_0 ),
        .I1(b[2]),
        .I2(b[1]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(\result[15]_INST_0_i_4_n_0 ),
        .O(\result[1]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[20]_INST_0_i_2 
       (.I0(\result[20]_INST_0_i_4_n_0 ),
        .I1(\result[21]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[20]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[20]_INST_0_i_3 
       (.I0(\result[24]_INST_0_i_5_n_0 ),
        .I1(\result[26]_INST_0_i_5_n_0 ),
        .I2(\result[20]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[22]_INST_0_i_5_n_0 ),
        .O(\result[20]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[20]_INST_0_i_4 
       (.I0(\result[22]_INST_0_i_6_n_0 ),
        .I1(\result[20]_INST_0_i_6_n_0 ),
        .I2(\result[26]_INST_0_i_7_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[24]_INST_0_i_6_n_0 ),
        .O(\result[20]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[20]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[20]),
        .I3(a[28]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[20]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[20]_INST_0_i_6 
       (.I0(a[5]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[13]),
        .O(\result[20]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[21]_INST_0_i_2 
       (.I0(\result[21]_INST_0_i_4_n_0 ),
        .I1(\result[22]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[21]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[21]_INST_0_i_3 
       (.I0(\result[25]_INST_0_i_5_n_0 ),
        .I1(\result[27]_INST_0_i_8_n_0 ),
        .I2(\result[21]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[23]_INST_0_i_5_n_0 ),
        .O(\result[21]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[21]_INST_0_i_4 
       (.I0(\result[23]_INST_0_i_6_n_0 ),
        .I1(\result[21]_INST_0_i_6_n_0 ),
        .I2(\result[27]_INST_0_i_10_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[25]_INST_0_i_6_n_0 ),
        .O(\result[21]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[21]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[21]),
        .I3(a[29]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[21]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[21]_INST_0_i_6 
       (.I0(a[6]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[14]),
        .O(\result[21]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[22]_INST_0_i_2 
       (.I0(\result[22]_INST_0_i_4_n_0 ),
        .I1(\result[23]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[22]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[22]_INST_0_i_3 
       (.I0(\result[26]_INST_0_i_5_n_0 ),
        .I1(\result[26]_INST_0_i_6_n_0 ),
        .I2(\result[22]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[24]_INST_0_i_5_n_0 ),
        .O(\result[22]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[22]_INST_0_i_4 
       (.I0(\result[24]_INST_0_i_6_n_0 ),
        .I1(\result[22]_INST_0_i_6_n_0 ),
        .I2(\result[28]_INST_0_i_4_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[26]_INST_0_i_7_n_0 ),
        .O(\result[22]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h88888888FF00F0F0)) 
    \result[22]_INST_0_i_5 
       (.I0(a[31]),
        .I1(b[30]),
        .I2(a[22]),
        .I3(a[30]),
        .I4(b[3]),
        .I5(b[4]),
        .O(\result[22]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h0B08)) 
    \result[22]_INST_0_i_6 
       (.I0(a[7]),
        .I1(b[3]),
        .I2(b[4]),
        .I3(a[15]),
        .O(\result[22]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[23]_INST_0_i_2 
       (.I0(\result[23]_INST_0_i_4_n_0 ),
        .I1(\result[24]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[23]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[23]_INST_0_i_3 
       (.I0(\result[27]_INST_0_i_8_n_0 ),
        .I1(\result[27]_INST_0_i_9_n_0 ),
        .I2(\result[23]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[25]_INST_0_i_5_n_0 ),
        .O(\result[23]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[23]_INST_0_i_4 
       (.I0(\result[25]_INST_0_i_6_n_0 ),
        .I1(\result[23]_INST_0_i_6_n_0 ),
        .I2(\result[29]_INST_0_i_4_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[27]_INST_0_i_10_n_0 ),
        .O(\result[23]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0F0CC)) 
    \result[23]_INST_0_i_5 
       (.I0(b[30]),
        .I1(a[23]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[23]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[23]_INST_0_i_6 
       (.I0(a[16]),
        .I1(a[8]),
        .I2(a[0]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[23]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[24]_INST_0_i_2 
       (.I0(\result[24]_INST_0_i_4_n_0 ),
        .I1(\result[25]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[24]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[24]_INST_0_i_3 
       (.I0(\result[26]_INST_0_i_6_n_0 ),
        .I1(\result[30]_INST_0_i_7_n_0 ),
        .I2(\result[24]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[26]_INST_0_i_5_n_0 ),
        .O(\result[24]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[24]_INST_0_i_4 
       (.I0(\result[26]_INST_0_i_7_n_0 ),
        .I1(\result[24]_INST_0_i_6_n_0 ),
        .I2(\result[30]_INST_0_i_4_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[28]_INST_0_i_4_n_0 ),
        .O(\result[24]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[24]_INST_0_i_5 
       (.I0(a[24]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[24]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[24]_INST_0_i_6 
       (.I0(a[17]),
        .I1(a[9]),
        .I2(a[1]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[24]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[25]_INST_0_i_2 
       (.I0(\result[25]_INST_0_i_4_n_0 ),
        .I1(\result[26]_INST_0_i_4_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[25]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[25]_INST_0_i_3 
       (.I0(\result[27]_INST_0_i_9_n_0 ),
        .I1(\result[30]_INST_0_i_5_n_0 ),
        .I2(\result[25]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[27]_INST_0_i_8_n_0 ),
        .O(\result[25]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[25]_INST_0_i_4 
       (.I0(\result[27]_INST_0_i_10_n_0 ),
        .I1(\result[25]_INST_0_i_6_n_0 ),
        .I2(\result[27]_INST_0_i_11_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[29]_INST_0_i_4_n_0 ),
        .O(\result[25]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[25]_INST_0_i_5 
       (.I0(a[25]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[25]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[25]_INST_0_i_6 
       (.I0(a[18]),
        .I1(a[10]),
        .I2(a[2]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[25]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[26]_INST_0_i_2 
       (.I0(\result[26]_INST_0_i_4_n_0 ),
        .I1(\result[27]_INST_0_i_7_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[26]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[26]_INST_0_i_3 
       (.I0(\result[30]_INST_0_i_7_n_0 ),
        .I1(\result[30]_INST_0_i_6_n_0 ),
        .I2(\result[26]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[26]_INST_0_i_6_n_0 ),
        .O(\result[26]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[26]_INST_0_i_4 
       (.I0(\result[28]_INST_0_i_4_n_0 ),
        .I1(\result[26]_INST_0_i_7_n_0 ),
        .I2(\result[28]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[30]_INST_0_i_4_n_0 ),
        .O(\result[26]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[26]_INST_0_i_5 
       (.I0(a[26]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[26]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[26]_INST_0_i_6 
       (.I0(a[28]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[26]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[26]_INST_0_i_7 
       (.I0(a[19]),
        .I1(a[11]),
        .I2(a[3]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[26]_INST_0_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[27]_INST_0_i_10 
       (.I0(a[20]),
        .I1(a[12]),
        .I2(a[4]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[27]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[27]_INST_0_i_11 
       (.I0(a[8]),
        .I1(a[0]),
        .I2(a[24]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[16]),
        .O(\result[27]_INST_0_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[27]_INST_0_i_2 
       (.I0(\result[27]_INST_0_i_7_n_0 ),
        .I1(\result[28]_INST_0_i_2_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[27]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEAE00005404)) 
    \result[27]_INST_0_i_3 
       (.I0(\result[31]_INST_0_i_16_n_0 ),
        .I1(a[28]),
        .I2(b[1]),
        .I3(a[30]),
        .I4(b[2]),
        .I5(\result[30]_INST_0_i_6_n_0 ),
        .O(\result[27]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    \result[27]_INST_0_i_4 
       (.I0(alucontrol[2]),
        .I1(alucontrol[0]),
        .I2(alucontrol[1]),
        .I3(b[0]),
        .O(\result[27]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[27]_INST_0_i_5 
       (.I0(\result[30]_INST_0_i_5_n_0 ),
        .I1(\result[30]_INST_0_i_6_n_0 ),
        .I2(\result[27]_INST_0_i_8_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[27]_INST_0_i_9_n_0 ),
        .O(\result[27]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h0008)) 
    \result[27]_INST_0_i_6 
       (.I0(alucontrol[2]),
        .I1(alucontrol[0]),
        .I2(alucontrol[1]),
        .I3(b[0]),
        .O(\result[27]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[27]_INST_0_i_7 
       (.I0(\result[29]_INST_0_i_4_n_0 ),
        .I1(\result[27]_INST_0_i_10_n_0 ),
        .I2(\result[31]_INST_0_i_9_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[27]_INST_0_i_11_n_0 ),
        .O(\result[27]_INST_0_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[27]_INST_0_i_8 
       (.I0(a[27]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[27]_INST_0_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[27]_INST_0_i_9 
       (.I0(a[29]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[27]_INST_0_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[28]_INST_0_i_2 
       (.I0(\result[30]_INST_0_i_4_n_0 ),
        .I1(\result[28]_INST_0_i_4_n_0 ),
        .I2(\result[31]_INST_0_i_13_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[28]_INST_0_i_5_n_0 ),
        .O(\result[28]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[28]_INST_0_i_3 
       (.I0(\result[29]_INST_0_i_5_n_0 ),
        .I1(\result[27]_INST_0_i_3_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[28]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[28]_INST_0_i_4 
       (.I0(a[21]),
        .I1(a[13]),
        .I2(a[5]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[28]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[28]_INST_0_i_5 
       (.I0(a[9]),
        .I1(a[1]),
        .I2(a[25]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[17]),
        .O(\result[28]_INST_0_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hF0AACCAA)) 
    \result[29]_INST_0_i_2 
       (.I0(\result[31]_INST_0_i_7_n_0 ),
        .I1(\result[31]_INST_0_i_9_n_0 ),
        .I2(\result[29]_INST_0_i_4_n_0 ),
        .I3(b[1]),
        .I4(b[2]),
        .O(\result[29]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFB800B800B800)) 
    \result[29]_INST_0_i_3 
       (.I0(\result[30]_INST_0_i_6_n_0 ),
        .I1(\result[31]_INST_0_i_15_n_0 ),
        .I2(\result[30]_INST_0_i_7_n_0 ),
        .I3(\result[27]_INST_0_i_4_n_0 ),
        .I4(\result[29]_INST_0_i_5_n_0 ),
        .I5(\result[27]_INST_0_i_6_n_0 ),
        .O(\result[29]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[29]_INST_0_i_4 
       (.I0(a[22]),
        .I1(a[14]),
        .I2(a[6]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[29]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFE005400040004)) 
    \result[29]_INST_0_i_5 
       (.I0(\result[31]_INST_0_i_16_n_0 ),
        .I1(a[29]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(b[30]),
        .I5(a[31]),
        .O(\result[29]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hF0AACCAA)) 
    \result[2]_INST_0_i_1 
       (.I0(\result[2]_INST_0_i_4_n_0 ),
        .I1(\result[4]_INST_0_i_11_n_0 ),
        .I2(\result[4]_INST_0_i_9_n_0 ),
        .I3(b[1]),
        .I4(b[2]),
        .O(\result[2]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h8E000400)) 
    \result[2]_INST_0_i_3 
       (.I0(b[2]),
        .I1(a[2]),
        .I2(alucontrol[0]),
        .I3(alucontrol[2]),
        .I4(alucontrol[1]),
        .O(\result[2]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBABABAAAAABAAAAA)) 
    \result[2]_INST_0_i_4 
       (.I0(\result[2]_INST_0_i_7_n_0 ),
        .I1(b[2]),
        .I2(b[4]),
        .I3(b[3]),
        .I4(a[18]),
        .I5(a[26]),
        .O(\result[2]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFF08080808080808)) 
    \result[2]_INST_0_i_5 
       (.I0(\result[4]_INST_0_i_14_n_0 ),
        .I1(b[2]),
        .I2(a[2]),
        .I3(\result[31]_INST_0_i_3_n_0 ),
        .I4(\result[2]_INST_0_i_8_n_0 ),
        .I5(a[1]),
        .O(\result[2]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \result[2]_INST_0_i_6 
       (.I0(alucontrol[2]),
        .I1(alucontrol[0]),
        .I2(alucontrol[1]),
        .O(\result[2]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF321000003210)) 
    \result[2]_INST_0_i_7 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(a[2]),
        .I3(a[10]),
        .I4(b[2]),
        .I5(\result[4]_INST_0_i_12_n_0 ),
        .O(\result[2]_INST_0_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \result[2]_INST_0_i_8 
       (.I0(b[2]),
        .I1(b[1]),
        .I2(b[4]),
        .I3(b[3]),
        .O(\result[2]_INST_0_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hF0AACCAA)) 
    \result[30]_INST_0_i_2 
       (.I0(\result[31]_INST_0_i_11_n_0 ),
        .I1(\result[31]_INST_0_i_13_n_0 ),
        .I2(\result[30]_INST_0_i_4_n_0 ),
        .I3(b[1]),
        .I4(b[2]),
        .O(\result[30]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFF088C088C088)) 
    \result[30]_INST_0_i_3 
       (.I0(\result[30]_INST_0_i_5_n_0 ),
        .I1(\result[27]_INST_0_i_4_n_0 ),
        .I2(\result[30]_INST_0_i_6_n_0 ),
        .I3(\result[31]_INST_0_i_15_n_0 ),
        .I4(\result[30]_INST_0_i_7_n_0 ),
        .I5(\result[27]_INST_0_i_6_n_0 ),
        .O(\result[30]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h00CCF0AA)) 
    \result[30]_INST_0_i_4 
       (.I0(a[23]),
        .I1(a[15]),
        .I2(a[7]),
        .I3(b[4]),
        .I4(b[3]),
        .O(\result[30]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h888C)) 
    \result[30]_INST_0_i_5 
       (.I0(b[30]),
        .I1(a[31]),
        .I2(b[3]),
        .I3(b[4]),
        .O(\result[30]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result[30]_INST_0_i_6 
       (.I0(b[30]),
        .I1(a[31]),
        .O(\result[30]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hC0C0C0AA)) 
    \result[30]_INST_0_i_7 
       (.I0(a[30]),
        .I1(b[30]),
        .I2(a[31]),
        .I3(b[3]),
        .I4(b[4]),
        .O(\result[30]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000000A0000000C)) 
    \result[31]_INST_0_i_10 
       (.I0(a[22]),
        .I1(a[30]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[31]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hBABABAAAAABAAAAA)) 
    \result[31]_INST_0_i_11 
       (.I0(\result[31]_INST_0_i_18_n_0 ),
        .I1(b[2]),
        .I2(b[4]),
        .I3(b[3]),
        .I4(a[13]),
        .I5(a[5]),
        .O(\result[31]_INST_0_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[31]_INST_0_i_12 
       (.I0(a[7]),
        .I1(a[15]),
        .I2(b[3]),
        .I3(b[4]),
        .I4(b[2]),
        .I5(b[1]),
        .O(\result[31]_INST_0_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[31]_INST_0_i_13 
       (.I0(a[11]),
        .I1(a[3]),
        .I2(a[27]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[19]),
        .O(\result[31]_INST_0_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0000000A0000000C)) 
    \result[31]_INST_0_i_14 
       (.I0(a[23]),
        .I1(a[31]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[31]_INST_0_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \result[31]_INST_0_i_15 
       (.I0(b[1]),
        .I1(b[2]),
        .O(\result[31]_INST_0_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \result[31]_INST_0_i_16 
       (.I0(b[3]),
        .I1(b[4]),
        .O(\result[31]_INST_0_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF321000003210)) 
    \result[31]_INST_0_i_17 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(a[28]),
        .I3(a[20]),
        .I4(b[2]),
        .I5(\result[27]_INST_0_i_11_n_0 ),
        .O(\result[31]_INST_0_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF321000003210)) 
    \result[31]_INST_0_i_18 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(a[29]),
        .I3(a[21]),
        .I4(b[2]),
        .I5(\result[28]_INST_0_i_5_n_0 ),
        .O(\result[31]_INST_0_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFECECEC)) 
    \result[31]_INST_0_i_2 
       (.I0(\result[31]_INST_0_i_7_n_0 ),
        .I1(\result[31]_INST_0_i_8_n_0 ),
        .I2(b[1]),
        .I3(b[2]),
        .I4(\result[31]_INST_0_i_9_n_0 ),
        .I5(\result[31]_INST_0_i_10_n_0 ),
        .O(\result[31]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'h1000)) 
    \result[31]_INST_0_i_3 
       (.I0(alucontrol[1]),
        .I1(alucontrol[2]),
        .I2(alucontrol[0]),
        .I3(b[0]),
        .O(\result[31]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFEFECECEC)) 
    \result[31]_INST_0_i_4 
       (.I0(\result[31]_INST_0_i_11_n_0 ),
        .I1(\result[31]_INST_0_i_12_n_0 ),
        .I2(b[1]),
        .I3(b[2]),
        .I4(\result[31]_INST_0_i_13_n_0 ),
        .I5(\result[31]_INST_0_i_14_n_0 ),
        .O(\result[31]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    \result[31]_INST_0_i_5 
       (.I0(alucontrol[1]),
        .I1(alucontrol[2]),
        .I2(alucontrol[0]),
        .I3(b[0]),
        .O(\result[31]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hF000F300A000A000)) 
    \result[31]_INST_0_i_6 
       (.I0(\result[27]_INST_0_i_4_n_0 ),
        .I1(\result[31]_INST_0_i_15_n_0 ),
        .I2(b[30]),
        .I3(a[31]),
        .I4(\result[31]_INST_0_i_16_n_0 ),
        .I5(\result[27]_INST_0_i_6_n_0 ),
        .O(\result[31]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hBABABAAAAABAAAAA)) 
    \result[31]_INST_0_i_7 
       (.I0(\result[31]_INST_0_i_17_n_0 ),
        .I1(b[2]),
        .I2(b[4]),
        .I3(b[3]),
        .I4(a[12]),
        .I5(a[4]),
        .O(\result[31]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[31]_INST_0_i_8 
       (.I0(a[6]),
        .I1(a[14]),
        .I2(b[3]),
        .I3(b[4]),
        .I4(b[2]),
        .I5(b[1]),
        .O(\result[31]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[31]_INST_0_i_9 
       (.I0(a[10]),
        .I1(a[2]),
        .I2(a[26]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[18]),
        .O(\result[31]_INST_0_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hF0AACCAA)) 
    \result[3]_INST_0_i_1 
       (.I0(\result[3]_INST_0_i_4_n_0 ),
        .I1(\result[4]_INST_0_i_7_n_0 ),
        .I2(\result[4]_INST_0_i_5_n_0 ),
        .I3(b[1]),
        .I4(b[2]),
        .O(\result[3]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h8E000400)) 
    \result[3]_INST_0_i_3 
       (.I0(b[3]),
        .I1(a[3]),
        .I2(alucontrol[0]),
        .I3(alucontrol[2]),
        .I4(alucontrol[1]),
        .O(\result[3]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBABABAAAAABAAAAA)) 
    \result[3]_INST_0_i_4 
       (.I0(\result[3]_INST_0_i_7_n_0 ),
        .I1(b[2]),
        .I2(b[4]),
        .I3(b[3]),
        .I4(a[19]),
        .I5(a[27]),
        .O(\result[3]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000A0C)) 
    \result[3]_INST_0_i_5 
       (.I0(a[0]),
        .I1(a[2]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[3]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF321000003210)) 
    \result[3]_INST_0_i_7 
       (.I0(b[3]),
        .I1(b[4]),
        .I2(a[3]),
        .I3(a[11]),
        .I4(b[2]),
        .I5(\result[4]_INST_0_i_8_n_0 ),
        .O(\result[3]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_1 
       (.I0(\result[4]_INST_0_i_5_n_0 ),
        .I1(\result[4]_INST_0_i_6_n_0 ),
        .I2(\result[4]_INST_0_i_7_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_8_n_0 ),
        .O(\result[4]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[4]_INST_0_i_10 
       (.I0(a[18]),
        .I1(a[26]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[10]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[4]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_11 
       (.I0(a[20]),
        .I1(a[28]),
        .I2(a[4]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[12]),
        .O(\result[4]_INST_0_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_12 
       (.I0(a[22]),
        .I1(a[30]),
        .I2(a[6]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[14]),
        .O(\result[4]_INST_0_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \result[4]_INST_0_i_14 
       (.I0(alucontrol[2]),
        .I1(alucontrol[0]),
        .O(\result[4]_INST_0_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \result[4]_INST_0_i_15 
       (.I0(b[4]),
        .I1(b[3]),
        .I2(a[31]),
        .I3(b[30]),
        .O(\result[4]_INST_0_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000A0C)) 
    \result[4]_INST_0_i_16 
       (.I0(a[1]),
        .I1(a[3]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[4]_INST_0_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_2 
       (.I0(\result[4]_INST_0_i_9_n_0 ),
        .I1(\result[4]_INST_0_i_10_n_0 ),
        .I2(\result[4]_INST_0_i_11_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_12_n_0 ),
        .O(\result[4]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEAFFEAC0C0C0C0C0)) 
    \result[4]_INST_0_i_4 
       (.I0(alucontrol[1]),
        .I1(\result[31]_INST_0_i_5_n_0 ),
        .I2(\result[5]_INST_0_i_4_n_0 ),
        .I3(a[4]),
        .I4(b[4]),
        .I5(\result[4]_INST_0_i_14_n_0 ),
        .O(\result[4]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[4]_INST_0_i_5 
       (.I0(a[17]),
        .I1(a[25]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[9]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[4]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[4]_INST_0_i_6 
       (.I0(a[19]),
        .I1(a[27]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[11]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[4]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_7 
       (.I0(a[21]),
        .I1(a[29]),
        .I2(a[5]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[13]),
        .O(\result[4]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[4]_INST_0_i_8 
       (.I0(a[23]),
        .I1(a[31]),
        .I2(a[7]),
        .I3(b[4]),
        .I4(b[3]),
        .I5(a[15]),
        .O(\result[4]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hF0F0FAFAFCFCFFF0)) 
    \result[4]_INST_0_i_9 
       (.I0(a[16]),
        .I1(a[24]),
        .I2(\result[4]_INST_0_i_15_n_0 ),
        .I3(a[8]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[4]_INST_0_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[5]_INST_0_i_1 
       (.I0(\result[6]_INST_0_i_4_n_0 ),
        .I1(\result[4]_INST_0_i_1_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[5]_INST_0_i_3 
       (.I0(\result[5]_INST_0_i_4_n_0 ),
        .I1(\result[6]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[5]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F0CCAA)) 
    \result[5]_INST_0_i_4 
       (.I0(a[4]),
        .I1(a[2]),
        .I2(a[0]),
        .I3(b[1]),
        .I4(b[2]),
        .I5(\result[31]_INST_0_i_16_n_0 ),
        .O(\result[5]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[6]_INST_0_i_1 
       (.I0(\result[7]_INST_0_i_4_n_0 ),
        .I1(\result[6]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[6]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[6]_INST_0_i_3 
       (.I0(\result[6]_INST_0_i_5_n_0 ),
        .I1(\result[7]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[6]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[6]_INST_0_i_4 
       (.I0(\result[4]_INST_0_i_10_n_0 ),
        .I1(\result[12]_INST_0_i_6_n_0 ),
        .I2(\result[4]_INST_0_i_12_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_9_n_0 ),
        .O(\result[6]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000F0CCAA)) 
    \result[6]_INST_0_i_5 
       (.I0(a[5]),
        .I1(a[3]),
        .I2(a[1]),
        .I3(b[1]),
        .I4(b[2]),
        .I5(\result[31]_INST_0_i_16_n_0 ),
        .O(\result[6]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[7]_INST_0_i_1 
       (.I0(\result[8]_INST_0_i_4_n_0 ),
        .I1(\result[7]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[7]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[7]_INST_0_i_3 
       (.I0(\result[7]_INST_0_i_5_n_0 ),
        .I1(\result[8]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[7]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[7]_INST_0_i_4 
       (.I0(\result[4]_INST_0_i_6_n_0 ),
        .I1(\result[13]_INST_0_i_6_n_0 ),
        .I2(\result[4]_INST_0_i_8_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_5_n_0 ),
        .O(\result[7]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF44400400)) 
    \result[7]_INST_0_i_5 
       (.I0(\result[31]_INST_0_i_16_n_0 ),
        .I1(b[2]),
        .I2(b[1]),
        .I3(a[2]),
        .I4(a[0]),
        .I5(\result[7]_INST_0_i_6_n_0 ),
        .O(\result[7]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000A0C)) 
    \result[7]_INST_0_i_6 
       (.I0(a[4]),
        .I1(a[6]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[7]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[8]_INST_0_i_1 
       (.I0(\result[9]_INST_0_i_4_n_0 ),
        .I1(\result[8]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[8]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[8]_INST_0_i_3 
       (.I0(\result[8]_INST_0_i_5_n_0 ),
        .I1(\result[9]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[8]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[8]_INST_0_i_4 
       (.I0(\result[12]_INST_0_i_6_n_0 ),
        .I1(\result[14]_INST_0_i_6_n_0 ),
        .I2(\result[4]_INST_0_i_9_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_10_n_0 ),
        .O(\result[8]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF44400400)) 
    \result[8]_INST_0_i_5 
       (.I0(\result[31]_INST_0_i_16_n_0 ),
        .I1(b[2]),
        .I2(b[1]),
        .I3(a[3]),
        .I4(a[1]),
        .I5(\result[8]_INST_0_i_6_n_0 ),
        .O(\result[8]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000A0C)) 
    \result[8]_INST_0_i_6 
       (.I0(a[5]),
        .I1(a[7]),
        .I2(b[2]),
        .I3(b[1]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[8]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000A0000000C000)) 
    \result[9]_INST_0_i_1 
       (.I0(\result[10]_INST_0_i_4_n_0 ),
        .I1(\result[9]_INST_0_i_4_n_0 ),
        .I2(alucontrol[2]),
        .I3(alucontrol[0]),
        .I4(alucontrol[1]),
        .I5(b[0]),
        .O(\result[9]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000A0000000C0000)) 
    \result[9]_INST_0_i_3 
       (.I0(\result[9]_INST_0_i_5_n_0 ),
        .I1(\result[10]_INST_0_i_5_n_0 ),
        .I2(alucontrol[1]),
        .I3(alucontrol[2]),
        .I4(alucontrol[0]),
        .I5(b[0]),
        .O(\result[9]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFAAF0CC00AAF0)) 
    \result[9]_INST_0_i_4 
       (.I0(\result[13]_INST_0_i_6_n_0 ),
        .I1(\result[15]_INST_0_i_7_n_0 ),
        .I2(\result[4]_INST_0_i_5_n_0 ),
        .I3(b[2]),
        .I4(b[1]),
        .I5(\result[4]_INST_0_i_6_n_0 ),
        .O(\result[9]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAEAFAEAAAEAAAE)) 
    \result[9]_INST_0_i_5 
       (.I0(\result[9]_INST_0_i_6_n_0 ),
        .I1(\result[15]_INST_0_i_8_n_0 ),
        .I2(b[2]),
        .I3(b[1]),
        .I4(\result[31]_INST_0_i_16_n_0 ),
        .I5(a[6]),
        .O(\result[9]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000AC00)) 
    \result[9]_INST_0_i_6 
       (.I0(a[2]),
        .I1(a[4]),
        .I2(b[1]),
        .I3(b[2]),
        .I4(b[4]),
        .I5(b[3]),
        .O(\result[9]_INST_0_i_6_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
