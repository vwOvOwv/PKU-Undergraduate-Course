//Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
//Date        : Wed Jun 12 18:11:18 2024
//Host        : mechrev-td running 64-bit major release  (build 9200)
//Command     : generate_target singleriscv_bd_wrapper.bd
//Design      : singleriscv_bd_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module singleriscv_bd_wrapper
   (DataAdr,
    MemWrite,
    PortA,
    PortB,
    PortC,
    PortD,
    WriteData,
    clk,
    reset);
  output [31:0]DataAdr;
  output MemWrite;
  input [3:0]PortA;
  input [13:0]PortB;
  output [13:0]PortC;
  output [15:0]PortD;
  output [31:0]WriteData;
  input clk;
  input reset;

  wire [31:0]DataAdr;
  wire MemWrite;
  wire [3:0]PortA;
  wire [13:0]PortB;
  wire [13:0]PortC;
  wire [15:0]PortD;
  wire [31:0]WriteData;
  wire clk;
  wire reset;

  singleriscv_bd singleriscv_bd_i
       (.DataAdr(DataAdr),
        .MemWrite(MemWrite),
        .PortA(PortA),
        .PortB(PortB),
        .PortC(PortC),
        .PortD(PortD),
        .WriteData(WriteData),
        .clk(clk),
        .reset(reset));
endmodule
