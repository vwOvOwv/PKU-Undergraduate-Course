//Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
//Date        : Wed Jun 12 18:11:18 2024
//Host        : mechrev-td running 64-bit major release  (build 9200)
//Command     : generate_target singleriscv_bd.bd
//Design      : singleriscv_bd
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "singleriscv_bd,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=singleriscv_bd,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=24,numReposBlks=24,numNonXlnxBlks=14,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "singleriscv_bd.hwdef" *) 
module singleriscv_bd
   (DataAdr,
    MemWrite,
    PortA,
    PortB,
    PortC,
    PortD,
    WriteData,
    clk,
    reset);
  output [31:0]DataAdr;
  output MemWrite;
  input [3:0]PortA;
  input [13:0]PortB;
  output [13:0]PortC;
  output [15:0]PortD;
  output [31:0]WriteData;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, ASSOCIATED_RESET reset, CLK_DOMAIN singleriscv_bd_clk_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input reset;

  wire [3:0]PortA_0_1;
  wire [13:0]PortB_0_1;
  wire alu_lessthan;
  wire [31:0]alu_result;
  wire alu_zero;
  wire clk_1;
  wire [31:0]constant4_dout;
  wire [3:0]controller_ALUControl;
  wire controller_ALUSrc;
  wire controller_AUIPC;
  wire [1:0]controller_ImmSrc;
  wire controller_Jump;
  wire controller_JumpR;
  wire controller_MemWrite;
  wire controller_PCSrc;
  wire controller_RegWrite;
  wire [1:0]controller_ResultSrc;
  wire controller_UType;
  wire [13:0]dmem_io_0_PortC;
  wire [15:0]dmem_io_0_PortD;
  wire [31:0]dmem_io_0_ReadData;
  wire [31:0]extend_immext;
  wire [2:0]funct3_Dout;
  wire [0:0]funct7b5_Dout;
  wire [31:0]imem_rd;
  wire [24:0]imm25_Dout;
  wire [6:0]op_Dout;
  wire [31:0]pcnext_mux_y;
  wire [31:0]pcplus4_adder_y;
  wire [31:0]pcplus4liuaupic_mux2_y;
  wire [31:0]pcplus4lui_mux2_y;
  wire [31:0]pcreg_q;
  wire [31:0]pcresult_mux2_y;
  wire [31:0]pctarget_adder_y;
  wire [4:0]rd_Dout;
  wire [31:0]regfile_rd1;
  wire [31:0]regfile_rd2;
  wire reset_1;
  wire [31:0]result_mux3_y;
  wire [4:0]rs1_Dout;
  wire [4:0]rs2_Dout;
  wire [31:0]srcb_mux2_y;
  wire [29:0]xlslice_0_Dout;

  assign DataAdr[31:0] = alu_result;
  assign MemWrite = controller_MemWrite;
  assign PortA_0_1 = PortA[3:0];
  assign PortB_0_1 = PortB[13:0];
  assign PortC[13:0] = dmem_io_0_PortC;
  assign PortD[15:0] = dmem_io_0_PortD;
  assign WriteData[31:0] = regfile_rd2;
  assign clk_1 = clk;
  assign reset_1 = reset;
  singleriscv_bd_alu_0_0 alu
       (.a(regfile_rd1),
        .alucontrol(controller_ALUControl),
        .b(srcb_mux2_y),
        .lessthan(alu_lessthan),
        .result(alu_result),
        .zero(alu_zero));
  singleriscv_bd_xlconstant_0_0 constant4
       (.dout(constant4_dout));
  singleriscv_bd_controller_0_0 controller
       (.ALUControl(controller_ALUControl),
        .ALUSrc(controller_ALUSrc),
        .AUIPC(controller_AUIPC),
        .ImmSrc(controller_ImmSrc),
        .Jump(controller_Jump),
        .JumpR(controller_JumpR),
        .MemWrite(controller_MemWrite),
        .PCSrc(controller_PCSrc),
        .RegWrite(controller_RegWrite),
        .ResultSrc(controller_ResultSrc),
        .UType(controller_UType),
        .funct3(funct3_Dout),
        .funct7b5(funct7b5_Dout),
        .lessthan(alu_lessthan),
        .op(op_Dout),
        .zero(alu_zero));
  singleriscv_bd_dmem_io_0_0 dmem_io_0
       (.DataAddr(alu_result),
        .MemWrite(controller_MemWrite),
        .PortA(PortA_0_1),
        .PortB(PortB_0_1),
        .PortC(dmem_io_0_PortC),
        .PortD(dmem_io_0_PortD),
        .ReadData(dmem_io_0_ReadData),
        .WriteData(regfile_rd2),
        .clk(clk_1),
        .reset(reset_1));
  singleriscv_bd_extend_0_0 extend
       (.immext(extend_immext),
        .immsrc(controller_ImmSrc),
        .instr(imm25_Dout),
        .utype(controller_UType));
  singleriscv_bd_xlslice_0_6 funct3
       (.Din(imem_rd),
        .Dout(funct3_Dout));
  singleriscv_bd_xlslice_1_0 funct7b5
       (.Din(imem_rd),
        .Dout(funct7b5_Dout));
  singleriscv_bd_dist_mem_gen_0_3 imem_fpga
       (.a(xlslice_0_Dout[7:0]),
        .spo(imem_rd));
  singleriscv_bd_xlslice_0_3 imm25
       (.Din(imem_rd),
        .Dout(imm25_Dout));
  singleriscv_bd_xlslice_0_5 op
       (.Din(imem_rd),
        .Dout(op_Dout));
  singleriscv_bd_mux2_0_1 pcnext_mux2
       (.d0(pcplus4_adder_y),
        .d1(pcresult_mux2_y),
        .s(controller_PCSrc),
        .y(pcnext_mux_y));
  singleriscv_bd_adder_0_0 pcplus4_adder
       (.a(pcreg_q),
        .b(constant4_dout),
        .y(pcplus4_adder_y));
  singleriscv_bd_mux2_0_3 pcplus4liuauipc_mux2
       (.d0(pcplus4lui_mux2_y),
        .d1(pctarget_adder_y),
        .s(controller_AUIPC),
        .y(pcplus4liuaupic_mux2_y));
  singleriscv_bd_mux2_0_2 pcplus4lui_mux2
       (.d0(extend_immext),
        .d1(pcplus4_adder_y),
        .s(controller_Jump),
        .y(pcplus4lui_mux2_y));
  singleriscv_bd_flopr_0_0 pcreg
       (.clk(clk_1),
        .d(pcnext_mux_y),
        .q(pcreg_q),
        .reset(reset_1));
  singleriscv_bd_mux2_0_4 pcresult_mux2
       (.d0(pctarget_adder_y),
        .d1(alu_result),
        .s(controller_JumpR),
        .y(pcresult_mux2_y));
  singleriscv_bd_adder_0_1 pctarget_adder
       (.a(pcreg_q),
        .b(extend_immext),
        .y(pctarget_adder_y));
  singleriscv_bd_xlslice_0_2 rd
       (.Din(imem_rd),
        .Dout(rd_Dout));
  singleriscv_bd_regfile_0_0 regfile
       (.a1(rs1_Dout),
        .a2(rs2_Dout),
        .a3(rd_Dout),
        .clk(clk_1),
        .rd1(regfile_rd1),
        .rd2(regfile_rd2),
        .wd3(result_mux3_y),
        .we3(controller_RegWrite));
  singleriscv_bd_mux3_0_0 result_mux3
       (.d0(alu_result),
        .d1(dmem_io_0_ReadData),
        .d2(pcplus4liuaupic_mux2_y),
        .s(controller_ResultSrc),
        .y(result_mux3_y));
  singleriscv_bd_xlslice_0_0 rs1
       (.Din(imem_rd),
        .Dout(rs1_Dout));
  singleriscv_bd_xlslice_0_1 rs2
       (.Din(imem_rd),
        .Dout(rs2_Dout));
  singleriscv_bd_mux2_0_0 srcb_mux2
       (.d0(regfile_rd2),
        .d1(extend_immext),
        .s(controller_ALUSrc),
        .y(srcb_mux2_y));
  singleriscv_bd_xlslice_0_7 xlslice_0
       (.Din(pcreg_q),
        .Dout(xlslice_0_Dout));
endmodule
