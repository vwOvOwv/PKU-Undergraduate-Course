-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:23:04 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ singleriscv_bd_adder_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_adder_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_adder is
  port (
    y : out STD_LOGIC_VECTOR ( 31 downto 0 );
    a : in STD_LOGIC_VECTOR ( 31 downto 0 );
    b : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_adder;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_adder is
  signal \y[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[0]_INST_0_n_0\ : STD_LOGIC;
  signal \y[0]_INST_0_n_1\ : STD_LOGIC;
  signal \y[0]_INST_0_n_2\ : STD_LOGIC;
  signal \y[0]_INST_0_n_3\ : STD_LOGIC;
  signal \y[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[12]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[12]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[12]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[12]_INST_0_n_0\ : STD_LOGIC;
  signal \y[12]_INST_0_n_1\ : STD_LOGIC;
  signal \y[12]_INST_0_n_2\ : STD_LOGIC;
  signal \y[12]_INST_0_n_3\ : STD_LOGIC;
  signal \y[16]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[16]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[16]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[16]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[16]_INST_0_n_0\ : STD_LOGIC;
  signal \y[16]_INST_0_n_1\ : STD_LOGIC;
  signal \y[16]_INST_0_n_2\ : STD_LOGIC;
  signal \y[16]_INST_0_n_3\ : STD_LOGIC;
  signal \y[20]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[20]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[20]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[20]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[20]_INST_0_n_0\ : STD_LOGIC;
  signal \y[20]_INST_0_n_1\ : STD_LOGIC;
  signal \y[20]_INST_0_n_2\ : STD_LOGIC;
  signal \y[20]_INST_0_n_3\ : STD_LOGIC;
  signal \y[24]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[24]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[24]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[24]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[24]_INST_0_n_0\ : STD_LOGIC;
  signal \y[24]_INST_0_n_1\ : STD_LOGIC;
  signal \y[24]_INST_0_n_2\ : STD_LOGIC;
  signal \y[24]_INST_0_n_3\ : STD_LOGIC;
  signal \y[28]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[28]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[28]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[28]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[28]_INST_0_n_1\ : STD_LOGIC;
  signal \y[28]_INST_0_n_2\ : STD_LOGIC;
  signal \y[28]_INST_0_n_3\ : STD_LOGIC;
  signal \y[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[4]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[4]_INST_0_n_0\ : STD_LOGIC;
  signal \y[4]_INST_0_n_1\ : STD_LOGIC;
  signal \y[4]_INST_0_n_2\ : STD_LOGIC;
  signal \y[4]_INST_0_n_3\ : STD_LOGIC;
  signal \y[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \y[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \y[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \y[8]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \y[8]_INST_0_n_0\ : STD_LOGIC;
  signal \y[8]_INST_0_n_1\ : STD_LOGIC;
  signal \y[8]_INST_0_n_2\ : STD_LOGIC;
  signal \y[8]_INST_0_n_3\ : STD_LOGIC;
  signal \NLW_y[28]_INST_0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \y[0]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[12]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[16]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[20]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[24]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[28]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[4]_INST_0\ : label is 35;
  attribute ADDER_THRESHOLD of \y[8]_INST_0\ : label is 35;
begin
\y[0]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \y[0]_INST_0_n_0\,
      CO(2) => \y[0]_INST_0_n_1\,
      CO(1) => \y[0]_INST_0_n_2\,
      CO(0) => \y[0]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(3 downto 0),
      O(3 downto 0) => y(3 downto 0),
      S(3) => \y[0]_INST_0_i_1_n_0\,
      S(2) => \y[0]_INST_0_i_2_n_0\,
      S(1) => \y[0]_INST_0_i_3_n_0\,
      S(0) => \y[0]_INST_0_i_4_n_0\
    );
\y[0]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(3),
      I1 => b(3),
      O => \y[0]_INST_0_i_1_n_0\
    );
\y[0]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(2),
      I1 => b(2),
      O => \y[0]_INST_0_i_2_n_0\
    );
\y[0]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(1),
      I1 => b(1),
      O => \y[0]_INST_0_i_3_n_0\
    );
\y[0]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(0),
      I1 => b(0),
      O => \y[0]_INST_0_i_4_n_0\
    );
\y[12]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[8]_INST_0_n_0\,
      CO(3) => \y[12]_INST_0_n_0\,
      CO(2) => \y[12]_INST_0_n_1\,
      CO(1) => \y[12]_INST_0_n_2\,
      CO(0) => \y[12]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(15 downto 12),
      O(3 downto 0) => y(15 downto 12),
      S(3) => \y[12]_INST_0_i_1_n_0\,
      S(2) => \y[12]_INST_0_i_2_n_0\,
      S(1) => \y[12]_INST_0_i_3_n_0\,
      S(0) => \y[12]_INST_0_i_4_n_0\
    );
\y[12]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(15),
      I1 => b(15),
      O => \y[12]_INST_0_i_1_n_0\
    );
\y[12]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(14),
      I1 => b(14),
      O => \y[12]_INST_0_i_2_n_0\
    );
\y[12]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(13),
      I1 => b(13),
      O => \y[12]_INST_0_i_3_n_0\
    );
\y[12]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(12),
      I1 => b(12),
      O => \y[12]_INST_0_i_4_n_0\
    );
\y[16]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[12]_INST_0_n_0\,
      CO(3) => \y[16]_INST_0_n_0\,
      CO(2) => \y[16]_INST_0_n_1\,
      CO(1) => \y[16]_INST_0_n_2\,
      CO(0) => \y[16]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(19 downto 16),
      O(3 downto 0) => y(19 downto 16),
      S(3) => \y[16]_INST_0_i_1_n_0\,
      S(2) => \y[16]_INST_0_i_2_n_0\,
      S(1) => \y[16]_INST_0_i_3_n_0\,
      S(0) => \y[16]_INST_0_i_4_n_0\
    );
\y[16]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(19),
      I1 => b(19),
      O => \y[16]_INST_0_i_1_n_0\
    );
\y[16]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(18),
      I1 => b(18),
      O => \y[16]_INST_0_i_2_n_0\
    );
\y[16]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(17),
      I1 => b(17),
      O => \y[16]_INST_0_i_3_n_0\
    );
\y[16]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(16),
      I1 => b(16),
      O => \y[16]_INST_0_i_4_n_0\
    );
\y[20]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[16]_INST_0_n_0\,
      CO(3) => \y[20]_INST_0_n_0\,
      CO(2) => \y[20]_INST_0_n_1\,
      CO(1) => \y[20]_INST_0_n_2\,
      CO(0) => \y[20]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(23 downto 20),
      O(3 downto 0) => y(23 downto 20),
      S(3) => \y[20]_INST_0_i_1_n_0\,
      S(2) => \y[20]_INST_0_i_2_n_0\,
      S(1) => \y[20]_INST_0_i_3_n_0\,
      S(0) => \y[20]_INST_0_i_4_n_0\
    );
\y[20]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(23),
      I1 => b(23),
      O => \y[20]_INST_0_i_1_n_0\
    );
\y[20]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(22),
      I1 => b(22),
      O => \y[20]_INST_0_i_2_n_0\
    );
\y[20]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(21),
      I1 => b(21),
      O => \y[20]_INST_0_i_3_n_0\
    );
\y[20]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(20),
      I1 => b(20),
      O => \y[20]_INST_0_i_4_n_0\
    );
\y[24]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[20]_INST_0_n_0\,
      CO(3) => \y[24]_INST_0_n_0\,
      CO(2) => \y[24]_INST_0_n_1\,
      CO(1) => \y[24]_INST_0_n_2\,
      CO(0) => \y[24]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(27 downto 24),
      O(3 downto 0) => y(27 downto 24),
      S(3) => \y[24]_INST_0_i_1_n_0\,
      S(2) => \y[24]_INST_0_i_2_n_0\,
      S(1) => \y[24]_INST_0_i_3_n_0\,
      S(0) => \y[24]_INST_0_i_4_n_0\
    );
\y[24]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(27),
      I1 => b(27),
      O => \y[24]_INST_0_i_1_n_0\
    );
\y[24]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(26),
      I1 => b(26),
      O => \y[24]_INST_0_i_2_n_0\
    );
\y[24]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(25),
      I1 => b(25),
      O => \y[24]_INST_0_i_3_n_0\
    );
\y[24]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(24),
      I1 => b(24),
      O => \y[24]_INST_0_i_4_n_0\
    );
\y[28]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[24]_INST_0_n_0\,
      CO(3) => \NLW_y[28]_INST_0_CO_UNCONNECTED\(3),
      CO(2) => \y[28]_INST_0_n_1\,
      CO(1) => \y[28]_INST_0_n_2\,
      CO(0) => \y[28]_INST_0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => a(30 downto 28),
      O(3 downto 0) => y(31 downto 28),
      S(3) => \y[28]_INST_0_i_1_n_0\,
      S(2) => \y[28]_INST_0_i_2_n_0\,
      S(1) => \y[28]_INST_0_i_3_n_0\,
      S(0) => \y[28]_INST_0_i_4_n_0\
    );
\y[28]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(31),
      I1 => b(31),
      O => \y[28]_INST_0_i_1_n_0\
    );
\y[28]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(30),
      I1 => b(30),
      O => \y[28]_INST_0_i_2_n_0\
    );
\y[28]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(29),
      I1 => b(29),
      O => \y[28]_INST_0_i_3_n_0\
    );
\y[28]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(28),
      I1 => b(28),
      O => \y[28]_INST_0_i_4_n_0\
    );
\y[4]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[0]_INST_0_n_0\,
      CO(3) => \y[4]_INST_0_n_0\,
      CO(2) => \y[4]_INST_0_n_1\,
      CO(1) => \y[4]_INST_0_n_2\,
      CO(0) => \y[4]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(7 downto 4),
      O(3 downto 0) => y(7 downto 4),
      S(3) => \y[4]_INST_0_i_1_n_0\,
      S(2) => \y[4]_INST_0_i_2_n_0\,
      S(1) => \y[4]_INST_0_i_3_n_0\,
      S(0) => \y[4]_INST_0_i_4_n_0\
    );
\y[4]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(7),
      I1 => b(7),
      O => \y[4]_INST_0_i_1_n_0\
    );
\y[4]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(6),
      I1 => b(6),
      O => \y[4]_INST_0_i_2_n_0\
    );
\y[4]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(5),
      I1 => b(5),
      O => \y[4]_INST_0_i_3_n_0\
    );
\y[4]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(4),
      I1 => b(4),
      O => \y[4]_INST_0_i_4_n_0\
    );
\y[8]_INST_0\: unisim.vcomponents.CARRY4
     port map (
      CI => \y[4]_INST_0_n_0\,
      CO(3) => \y[8]_INST_0_n_0\,
      CO(2) => \y[8]_INST_0_n_1\,
      CO(1) => \y[8]_INST_0_n_2\,
      CO(0) => \y[8]_INST_0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(11 downto 8),
      O(3 downto 0) => y(11 downto 8),
      S(3) => \y[8]_INST_0_i_1_n_0\,
      S(2) => \y[8]_INST_0_i_2_n_0\,
      S(1) => \y[8]_INST_0_i_3_n_0\,
      S(0) => \y[8]_INST_0_i_4_n_0\
    );
\y[8]_INST_0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(11),
      I1 => b(11),
      O => \y[8]_INST_0_i_1_n_0\
    );
\y[8]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(10),
      I1 => b(10),
      O => \y[8]_INST_0_i_2_n_0\
    );
\y[8]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(9),
      I1 => b(9),
      O => \y[8]_INST_0_i_3_n_0\
    );
\y[8]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(8),
      I1 => b(8),
      O => \y[8]_INST_0_i_4_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    a : in STD_LOGIC_VECTOR ( 31 downto 0 );
    b : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "singleriscv_bd_adder_0_0,adder,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "adder,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_adder
     port map (
      a(31 downto 0) => a(31 downto 0),
      b(31 downto 0) => b(31 downto 0),
      y(31 downto 0) => y(31 downto 0)
    );
end STRUCTURE;
