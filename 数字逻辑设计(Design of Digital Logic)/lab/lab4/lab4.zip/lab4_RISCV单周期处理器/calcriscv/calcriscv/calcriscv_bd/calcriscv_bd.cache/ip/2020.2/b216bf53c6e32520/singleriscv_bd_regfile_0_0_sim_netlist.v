// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:23:13 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ singleriscv_bd_regfile_0_0_sim_netlist.v
// Design      : singleriscv_bd_regfile_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_regfile
   (rd1,
    rd2,
    a1,
    a2,
    clk,
    we3,
    wd3,
    a3);
  output [31:0]rd1;
  output [31:0]rd2;
  input [4:0]a1;
  input [4:0]a2;
  input clk;
  input we3;
  input [31:0]wd3;
  input [4:0]a3;

  wire [4:0]a1;
  wire [4:0]a2;
  wire [4:0]a3;
  wire clk;
  wire [31:0]rd1;
  wire [31:0]rd10;
  wire [31:0]rd2;
  wire [31:0]rd20;
  wire [31:0]wd3;
  wire we3;
  wire [1:0]NLW_rf_reg_r1_0_31_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_12_17_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_18_23_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_24_29_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_30_31_DOB_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_30_31_DOC_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_30_31_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r1_0_31_6_11_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_0_5_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_12_17_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_18_23_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_24_29_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_30_31_DOB_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_30_31_DOC_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_30_31_DOD_UNCONNECTED;
  wire [1:0]NLW_rf_reg_r2_0_31_6_11_DOD_UNCONNECTED;

  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[0]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[0]),
        .O(rd1[0]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[10]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[10]),
        .O(rd1[10]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[11]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[11]),
        .O(rd1[11]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[12]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[12]),
        .O(rd1[12]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[13]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[13]),
        .O(rd1[13]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[14]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[14]),
        .O(rd1[14]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[15]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[15]),
        .O(rd1[15]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[16]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[16]),
        .O(rd1[16]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[17]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[17]),
        .O(rd1[17]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[18]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[18]),
        .O(rd1[18]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[19]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[19]),
        .O(rd1[19]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[1]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[1]),
        .O(rd1[1]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[20]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[20]),
        .O(rd1[20]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[21]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[21]),
        .O(rd1[21]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[22]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[22]),
        .O(rd1[22]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[23]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[23]),
        .O(rd1[23]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[24]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[24]),
        .O(rd1[24]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[25]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[25]),
        .O(rd1[25]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[26]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[26]),
        .O(rd1[26]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[27]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[27]),
        .O(rd1[27]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[28]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[28]),
        .O(rd1[28]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[29]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[29]),
        .O(rd1[29]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[2]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[2]),
        .O(rd1[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[30]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[30]),
        .O(rd1[30]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[31]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[31]),
        .O(rd1[31]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[3]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[3]),
        .O(rd1[3]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[4]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[4]),
        .O(rd1[4]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[5]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[5]),
        .O(rd1[5]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[6]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[6]),
        .O(rd1[6]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[7]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[7]),
        .O(rd1[7]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[8]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[8]),
        .O(rd1[8]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd1[9]_INST_0 
       (.I0(a1[4]),
        .I1(a1[3]),
        .I2(a1[1]),
        .I3(a1[0]),
        .I4(a1[2]),
        .I5(rd10[9]),
        .O(rd1[9]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[0]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[0]),
        .O(rd2[0]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[10]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[10]),
        .O(rd2[10]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[11]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[11]),
        .O(rd2[11]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[12]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[12]),
        .O(rd2[12]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[13]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[13]),
        .O(rd2[13]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[14]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[14]),
        .O(rd2[14]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[15]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[15]),
        .O(rd2[15]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[16]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[16]),
        .O(rd2[16]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[17]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[17]),
        .O(rd2[17]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[18]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[18]),
        .O(rd2[18]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[19]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[19]),
        .O(rd2[19]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[1]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[1]),
        .O(rd2[1]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[20]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[20]),
        .O(rd2[20]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[21]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[21]),
        .O(rd2[21]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[22]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[22]),
        .O(rd2[22]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[23]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[23]),
        .O(rd2[23]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[24]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[24]),
        .O(rd2[24]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[25]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[25]),
        .O(rd2[25]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[26]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[26]),
        .O(rd2[26]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[27]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[27]),
        .O(rd2[27]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[28]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[28]),
        .O(rd2[28]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[29]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[29]),
        .O(rd2[29]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[2]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[2]),
        .O(rd2[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[30]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[30]),
        .O(rd2[30]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[31]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[31]),
        .O(rd2[31]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[3]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[3]),
        .O(rd2[3]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[4]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[4]),
        .O(rd2[4]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[5]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[5]),
        .O(rd2[5]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[6]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[6]),
        .O(rd2[6]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[7]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[7]),
        .O(rd2[7]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[8]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[8]),
        .O(rd2[8]));
  LUT6 #(
    .INIT(64'hFFFFFFFE00000000)) 
    \rd2[9]_INST_0 
       (.I0(a2[4]),
        .I1(a2[3]),
        .I2(a2[1]),
        .I3(a2[0]),
        .I4(a2[2]),
        .I5(rd20[9]),
        .O(rd2[9]));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "5" *) 
  RAM32M rf_reg_r1_0_31_0_5
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[1:0]),
        .DIB(wd3[3:2]),
        .DIC(wd3[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(rd10[1:0]),
        .DOB(rd10[3:2]),
        .DOC(rd10[5:4]),
        .DOD(NLW_rf_reg_r1_0_31_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "17" *) 
  RAM32M rf_reg_r1_0_31_12_17
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[13:12]),
        .DIB(wd3[15:14]),
        .DIC(wd3[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(rd10[13:12]),
        .DOB(rd10[15:14]),
        .DOC(rd10[17:16]),
        .DOD(NLW_rf_reg_r1_0_31_12_17_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "23" *) 
  RAM32M rf_reg_r1_0_31_18_23
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[19:18]),
        .DIB(wd3[21:20]),
        .DIC(wd3[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(rd10[19:18]),
        .DOB(rd10[21:20]),
        .DOC(rd10[23:22]),
        .DOD(NLW_rf_reg_r1_0_31_18_23_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "24" *) 
  (* ram_slice_end = "29" *) 
  RAM32M rf_reg_r1_0_31_24_29
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[25:24]),
        .DIB(wd3[27:26]),
        .DIC(wd3[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(rd10[25:24]),
        .DOB(rd10[27:26]),
        .DOC(rd10[29:28]),
        .DOD(NLW_rf_reg_r1_0_31_24_29_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "30" *) 
  (* ram_slice_end = "31" *) 
  RAM32M rf_reg_r1_0_31_30_31
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(rd10[31:30]),
        .DOB(NLW_rf_reg_r1_0_31_30_31_DOB_UNCONNECTED[1:0]),
        .DOC(NLW_rf_reg_r1_0_31_30_31_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_rf_reg_r1_0_31_30_31_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "11" *) 
  RAM32M rf_reg_r1_0_31_6_11
       (.ADDRA(a1),
        .ADDRB(a1),
        .ADDRC(a1),
        .ADDRD(a3),
        .DIA(wd3[7:6]),
        .DIB(wd3[9:8]),
        .DIC(wd3[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(rd10[7:6]),
        .DOB(rd10[9:8]),
        .DOC(rd10[11:10]),
        .DOD(NLW_rf_reg_r1_0_31_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "5" *) 
  RAM32M rf_reg_r2_0_31_0_5
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[1:0]),
        .DIB(wd3[3:2]),
        .DIC(wd3[5:4]),
        .DID({1'b0,1'b0}),
        .DOA(rd20[1:0]),
        .DOB(rd20[3:2]),
        .DOC(rd20[5:4]),
        .DOD(NLW_rf_reg_r2_0_31_0_5_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "17" *) 
  RAM32M rf_reg_r2_0_31_12_17
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[13:12]),
        .DIB(wd3[15:14]),
        .DIC(wd3[17:16]),
        .DID({1'b0,1'b0}),
        .DOA(rd20[13:12]),
        .DOB(rd20[15:14]),
        .DOC(rd20[17:16]),
        .DOD(NLW_rf_reg_r2_0_31_12_17_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "23" *) 
  RAM32M rf_reg_r2_0_31_18_23
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[19:18]),
        .DIB(wd3[21:20]),
        .DIC(wd3[23:22]),
        .DID({1'b0,1'b0}),
        .DOA(rd20[19:18]),
        .DOB(rd20[21:20]),
        .DOC(rd20[23:22]),
        .DOD(NLW_rf_reg_r2_0_31_18_23_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "24" *) 
  (* ram_slice_end = "29" *) 
  RAM32M rf_reg_r2_0_31_24_29
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[25:24]),
        .DIB(wd3[27:26]),
        .DIC(wd3[29:28]),
        .DID({1'b0,1'b0}),
        .DOA(rd20[25:24]),
        .DOB(rd20[27:26]),
        .DOC(rd20[29:28]),
        .DOD(NLW_rf_reg_r2_0_31_24_29_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "30" *) 
  (* ram_slice_end = "31" *) 
  RAM32M rf_reg_r2_0_31_30_31
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[31:30]),
        .DIB({1'b0,1'b0}),
        .DIC({1'b0,1'b0}),
        .DID({1'b0,1'b0}),
        .DOA(rd20[31:30]),
        .DOB(NLW_rf_reg_r2_0_31_30_31_DOB_UNCONNECTED[1:0]),
        .DOC(NLW_rf_reg_r2_0_31_30_31_DOC_UNCONNECTED[1:0]),
        .DOD(NLW_rf_reg_r2_0_31_30_31_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "1024" *) 
  (* RTL_RAM_NAME = "inst/rf" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "11" *) 
  RAM32M rf_reg_r2_0_31_6_11
       (.ADDRA(a2),
        .ADDRB(a2),
        .ADDRC(a2),
        .ADDRD(a3),
        .DIA(wd3[7:6]),
        .DIB(wd3[9:8]),
        .DIC(wd3[11:10]),
        .DID({1'b0,1'b0}),
        .DOA(rd20[7:6]),
        .DOB(rd20[9:8]),
        .DOC(rd20[11:10]),
        .DOD(NLW_rf_reg_r2_0_31_6_11_DOD_UNCONNECTED[1:0]),
        .WCLK(clk),
        .WE(we3));
endmodule

(* CHECK_LICENSE_TYPE = "singleriscv_bd_regfile_0_0,regfile,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "regfile,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    we3,
    a1,
    a2,
    a3,
    wd3,
    rd1,
    rd2);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN singleriscv_bd_clk_0, INSERT_VIP 0" *) input clk;
  input we3;
  input [4:0]a1;
  input [4:0]a2;
  input [4:0]a3;
  input [31:0]wd3;
  output [31:0]rd1;
  output [31:0]rd2;

  wire [4:0]a1;
  wire [4:0]a2;
  wire [4:0]a3;
  wire clk;
  wire [31:0]rd1;
  wire [31:0]rd2;
  wire [31:0]wd3;
  wire we3;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_regfile inst
       (.a1(a1),
        .a2(a2),
        .a3(a3),
        .clk(clk),
        .rd1(rd1),
        .rd2(rd2),
        .wd3(wd3),
        .we3(we3));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
