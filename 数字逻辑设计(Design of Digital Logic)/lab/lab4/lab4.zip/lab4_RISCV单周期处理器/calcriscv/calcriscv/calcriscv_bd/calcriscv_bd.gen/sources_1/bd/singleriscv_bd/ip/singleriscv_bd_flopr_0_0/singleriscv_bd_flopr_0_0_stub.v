// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:26:21 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top singleriscv_bd_flopr_0_0 -prefix
//               singleriscv_bd_flopr_0_0_ singleriscv_bd_flopr_0_0_stub.v
// Design      : singleriscv_bd_flopr_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "flopr,Vivado 2020.2" *)
module singleriscv_bd_flopr_0_0(clk, reset, d, q)
/* synthesis syn_black_box black_box_pad_pin="clk,reset,d[31:0],q[31:0]" */;
  input clk;
  input reset;
  input [31:0]d;
  output [31:0]q;
endmodule
