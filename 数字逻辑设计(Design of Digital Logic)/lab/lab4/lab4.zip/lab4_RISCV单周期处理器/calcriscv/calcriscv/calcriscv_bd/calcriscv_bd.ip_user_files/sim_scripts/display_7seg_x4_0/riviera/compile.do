vlib work
vlib riviera

vlib riviera/xil_defaultlib

vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xil_defaultlib  -sv2k12 \
"../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4.sv" \
"../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/sim/display_7seg_x4_0.sv" \


vlog -work xil_defaultlib \
"glbl.v"

