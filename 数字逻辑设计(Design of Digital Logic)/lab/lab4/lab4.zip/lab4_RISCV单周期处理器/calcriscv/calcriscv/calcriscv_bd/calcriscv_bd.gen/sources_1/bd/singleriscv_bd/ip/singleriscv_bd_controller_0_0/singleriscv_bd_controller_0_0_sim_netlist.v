// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:27:20 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top singleriscv_bd_controller_0_0 -prefix
//               singleriscv_bd_controller_0_0_ singleriscv_bd_controller_0_0_sim_netlist.v
// Design      : singleriscv_bd_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "singleriscv_bd_controller_0_0,controller,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module singleriscv_bd_controller_0_0
   (op,
    funct3,
    funct7b5,
    zero,
    lessthan,
    ResultSrc,
    MemWrite,
    PCSrc,
    ALUSrc,
    RegWrite,
    Jump,
    JumpR,
    UType,
    AUIPC,
    ImmSrc,
    ALUControl);
  input [6:0]op;
  input [2:0]funct3;
  input funct7b5;
  input zero;
  input lessthan;
  output [1:0]ResultSrc;
  output MemWrite;
  output PCSrc;
  output ALUSrc;
  output RegWrite;
  output Jump;
  output JumpR;
  output UType;
  output AUIPC;
  output [1:0]ImmSrc;
  output [3:0]ALUControl;

  wire [3:0]ALUControl;
  wire \ALUControl[3]_INST_0_i_1_n_0 ;
  wire ALUSrc;
  wire AUIPC;
  wire [1:0]ImmSrc;
  wire JumpR;
  wire MemWrite;
  wire PCSrc;
  wire PCSrc_INST_0_i_1_n_0;
  wire RegWrite;
  wire [0:0]\^ResultSrc ;
  wire UType;
  wire [2:0]funct3;
  wire funct7b5;
  wire lessthan;
  wire [6:0]op;
  wire zero;

  assign Jump = op[3];
  assign ResultSrc[1] = op[2];
  assign ResultSrc[0] = \^ResultSrc [0];
  LUT5 #(
    .INIT(32'h22223000)) 
    \ALUControl[0]_INST_0 
       (.I0(funct3[0]),
        .I1(op[2]),
        .I2(op[6]),
        .I3(funct3[2]),
        .I4(op[4]),
        .O(ALUControl[0]));
  LUT4 #(
    .INIT(16'h00CA)) 
    \ALUControl[1]_INST_0 
       (.I0(op[6]),
        .I1(funct3[1]),
        .I2(op[4]),
        .I3(op[2]),
        .O(ALUControl[1]));
  LUT3 #(
    .INIT(8'h40)) 
    \ALUControl[2]_INST_0 
       (.I0(op[2]),
        .I1(op[4]),
        .I2(funct3[2]),
        .O(ALUControl[2]));
  LUT6 #(
    .INIT(64'hCCCCCFCCCCCCEEEE)) 
    \ALUControl[3]_INST_0 
       (.I0(op[6]),
        .I1(\ALUControl[3]_INST_0_i_1_n_0 ),
        .I2(funct3[2]),
        .I3(funct3[1]),
        .I4(op[2]),
        .I5(op[4]),
        .O(ALUControl[3]));
  LUT5 #(
    .INIT(32'h00080000)) 
    \ALUControl[3]_INST_0_i_1 
       (.I0(op[5]),
        .I1(funct7b5),
        .I2(op[6]),
        .I3(op[2]),
        .I4(op[4]),
        .O(\ALUControl[3]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00550007)) 
    ALUSrc_INST_0
       (.I0(op[4]),
        .I1(op[5]),
        .I2(op[6]),
        .I3(op[3]),
        .I4(op[2]),
        .O(ALUSrc));
  LUT2 #(
    .INIT(4'h2)) 
    AUIPC_INST_0
       (.I0(op[2]),
        .I1(op[5]),
        .O(AUIPC));
  LUT3 #(
    .INIT(8'hF4)) 
    \ImmSrc[0]_INST_0 
       (.I0(op[6]),
        .I1(op[5]),
        .I2(op[3]),
        .O(ImmSrc[0]));
  LUT3 #(
    .INIT(8'hAC)) 
    \ImmSrc[1]_INST_0 
       (.I0(op[3]),
        .I1(op[6]),
        .I2(op[2]),
        .O(ImmSrc[1]));
  LUT3 #(
    .INIT(8'h40)) 
    JumpR_INST_0
       (.I0(op[3]),
        .I1(op[6]),
        .I2(op[2]),
        .O(JumpR));
  LUT3 #(
    .INIT(8'h04)) 
    MemWrite_INST_0
       (.I0(op[6]),
        .I1(op[5]),
        .I2(op[4]),
        .O(MemWrite));
  LUT4 #(
    .INIT(16'hFFF8)) 
    PCSrc_INST_0
       (.I0(op[2]),
        .I1(op[6]),
        .I2(PCSrc_INST_0_i_1_n_0),
        .I3(op[3]),
        .O(PCSrc));
  LUT6 #(
    .INIT(64'h5A5A003C00000000)) 
    PCSrc_INST_0_i_1
       (.I0(lessthan),
        .I1(zero),
        .I2(funct3[0]),
        .I3(funct3[1]),
        .I4(funct3[2]),
        .I5(op[6]),
        .O(PCSrc_INST_0_i_1_n_0));
  LUT3 #(
    .INIT(8'hFD)) 
    RegWrite_INST_0
       (.I0(op[5]),
        .I1(op[4]),
        .I2(op[2]),
        .O(RegWrite));
  LUT2 #(
    .INIT(4'h1)) 
    \ResultSrc[0]_INST_0 
       (.I0(op[4]),
        .I1(op[5]),
        .O(\^ResultSrc ));
  LUT2 #(
    .INIT(4'h2)) 
    UType_INST_0
       (.I0(op[2]),
        .I1(op[6]),
        .O(UType));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
