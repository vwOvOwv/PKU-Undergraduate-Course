// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:26:18 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top singleriscv_bd_mux2_0_4 -prefix
//               singleriscv_bd_mux2_0_4_ singleriscv_bd_mux2_0_1_stub.v
// Design      : singleriscv_bd_mux2_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "mux2,Vivado 2020.2" *)
module singleriscv_bd_mux2_0_4(d0, d1, s, y)
/* synthesis syn_black_box black_box_pad_pin="d0[31:0],d1[31:0],s,y[31:0]" */;
  input [31:0]d0;
  input [31:0]d1;
  input s;
  output [31:0]y;
endmodule
