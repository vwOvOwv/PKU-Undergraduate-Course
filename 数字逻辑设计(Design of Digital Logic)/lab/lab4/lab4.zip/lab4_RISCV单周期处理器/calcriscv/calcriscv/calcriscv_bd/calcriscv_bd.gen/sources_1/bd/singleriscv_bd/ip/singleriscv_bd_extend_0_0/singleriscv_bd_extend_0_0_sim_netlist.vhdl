-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:23:05 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top singleriscv_bd_extend_0_0 -prefix
--               singleriscv_bd_extend_0_0_ singleriscv_bd_extend_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_extend_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_extend_0_0_extend is
  port (
    immext : out STD_LOGIC_VECTOR ( 30 downto 0 );
    immsrc : in STD_LOGIC_VECTOR ( 1 downto 0 );
    instr : in STD_LOGIC_VECTOR ( 31 downto 7 );
    utype : in STD_LOGIC
  );
end singleriscv_bd_extend_0_0_extend;

architecture STRUCTURE of singleriscv_bd_extend_0_0_extend is
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \immext[10]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \immext[20]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \immext[21]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \immext[22]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \immext[23]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \immext[24]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \immext[25]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \immext[26]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \immext[27]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \immext[28]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \immext[29]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \immext[30]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \immext[6]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \immext[7]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \immext[8]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \immext[9]_INST_0\ : label is "soft_lutpair6";
begin
\immext[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005404"
    )
        port map (
      I0 => immsrc(1),
      I1 => instr(20),
      I2 => immsrc(0),
      I3 => instr(7),
      I4 => utype,
      O => immext(0)
    );
\immext[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(30),
      I1 => utype,
      O => immext(10)
    );
\immext[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000E2FFE200"
    )
        port map (
      I0 => instr(7),
      I1 => immsrc(0),
      I2 => instr(20),
      I3 => immsrc(1),
      I4 => instr(31),
      I5 => utype,
      O => immext(11)
    );
\immext[12]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(12),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(12)
    );
\immext[13]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(13),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(13)
    );
\immext[14]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(14),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(14)
    );
\immext[15]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(15),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(15)
    );
\immext[16]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(16),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(16)
    );
\immext[17]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(17),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(17)
    );
\immext[18]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(18),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(18)
    );
\immext[19]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CDDDC888"
    )
        port map (
      I0 => utype,
      I1 => instr(19),
      I2 => immsrc(0),
      I3 => immsrc(1),
      I4 => instr(31),
      O => immext(19)
    );
\immext[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B8E2"
    )
        port map (
      I0 => instr(21),
      I1 => immsrc(1),
      I2 => instr(8),
      I3 => immsrc(0),
      I4 => utype,
      O => immext(1)
    );
\immext[20]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(20),
      I1 => utype,
      I2 => instr(31),
      O => immext(20)
    );
\immext[21]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(21),
      I1 => utype,
      I2 => instr(31),
      O => immext(21)
    );
\immext[22]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(22),
      I1 => utype,
      I2 => instr(31),
      O => immext(22)
    );
\immext[23]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(23),
      I1 => utype,
      I2 => instr(31),
      O => immext(23)
    );
\immext[24]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(24),
      I1 => utype,
      I2 => instr(31),
      O => immext(24)
    );
\immext[25]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(25),
      I1 => utype,
      I2 => instr(31),
      O => immext(25)
    );
\immext[26]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(26),
      I1 => utype,
      I2 => instr(31),
      O => immext(26)
    );
\immext[27]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(27),
      I1 => utype,
      I2 => instr(31),
      O => immext(27)
    );
\immext[28]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(28),
      I1 => utype,
      I2 => instr(31),
      O => immext(28)
    );
\immext[29]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(29),
      I1 => utype,
      I2 => instr(31),
      O => immext(29)
    );
\immext[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B8E2"
    )
        port map (
      I0 => instr(22),
      I1 => immsrc(1),
      I2 => instr(9),
      I3 => immsrc(0),
      I4 => utype,
      O => immext(2)
    );
\immext[30]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => instr(30),
      I1 => utype,
      I2 => instr(31),
      O => immext(30)
    );
\immext[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B8E2"
    )
        port map (
      I0 => instr(23),
      I1 => immsrc(1),
      I2 => instr(10),
      I3 => immsrc(0),
      I4 => utype,
      O => immext(3)
    );
\immext[4]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000B8E2"
    )
        port map (
      I0 => instr(24),
      I1 => immsrc(1),
      I2 => instr(11),
      I3 => immsrc(0),
      I4 => utype,
      O => immext(4)
    );
\immext[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(25),
      I1 => utype,
      O => immext(5)
    );
\immext[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(26),
      I1 => utype,
      O => immext(6)
    );
\immext[7]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(27),
      I1 => utype,
      O => immext(7)
    );
\immext[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(28),
      I1 => utype,
      O => immext(8)
    );
\immext[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => instr(29),
      I1 => utype,
      O => immext(9)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_extend_0_0 is
  port (
    instr : in STD_LOGIC_VECTOR ( 31 downto 7 );
    immsrc : in STD_LOGIC_VECTOR ( 1 downto 0 );
    utype : in STD_LOGIC;
    immext : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of singleriscv_bd_extend_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of singleriscv_bd_extend_0_0 : entity is "singleriscv_bd_extend_0_0,extend,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of singleriscv_bd_extend_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of singleriscv_bd_extend_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of singleriscv_bd_extend_0_0 : entity is "extend,Vivado 2020.2";
end singleriscv_bd_extend_0_0;

architecture STRUCTURE of singleriscv_bd_extend_0_0 is
  signal \^immext\ : STD_LOGIC_VECTOR ( 30 downto 0 );
  signal \^instr\ : STD_LOGIC_VECTOR ( 31 downto 7 );
begin
  \^instr\(31 downto 7) <= instr(31 downto 7);
  immext(31) <= \^instr\(31);
  immext(30 downto 0) <= \^immext\(30 downto 0);
inst: entity work.singleriscv_bd_extend_0_0_extend
     port map (
      immext(30 downto 0) => \^immext\(30 downto 0),
      immsrc(1 downto 0) => immsrc(1 downto 0),
      instr(31 downto 7) => \^instr\(31 downto 7),
      utype => utype
    );
end STRUCTURE;
