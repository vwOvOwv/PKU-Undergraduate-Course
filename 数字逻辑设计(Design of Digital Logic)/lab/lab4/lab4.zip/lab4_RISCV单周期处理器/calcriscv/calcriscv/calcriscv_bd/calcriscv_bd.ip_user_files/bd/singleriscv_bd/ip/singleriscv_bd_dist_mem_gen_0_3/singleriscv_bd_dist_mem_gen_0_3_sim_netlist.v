// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:31:40 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/bd/singleriscv_bd/ip/singleriscv_bd_dist_mem_gen_0_3/singleriscv_bd_dist_mem_gen_0_3_sim_netlist.v
// Design      : singleriscv_bd_dist_mem_gen_0_3
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "singleriscv_bd_dist_mem_gen_0_3,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module singleriscv_bd_dist_mem_gen_0_3
   (a,
    spo);
  input [5:0]a;
  output [31:0]spo;

  wire \<const0> ;
  wire [5:0]a;
  wire [31:0]\^spo ;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;
  wire [19:19]NLW_U0_spo_UNCONNECTED;

  assign spo[31:20] = \^spo [31:20];
  assign spo[19] = \<const0> ;
  assign spo[18:0] = \^spo [18:0];
  GND GND
       (.G(\<const0> ));
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "6" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "64" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "singleriscv_bd_dist_mem_gen_0_3.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  (* is_du_within_envelope = "true" *) 
  singleriscv_bd_dist_mem_gen_0_3_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(\^spo ),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
AWk2+F/LLIwJ/3H70MT+p73z+MaZAUnylB9xu/zfH66xX8dAaOizqpslZkE4MXrWhxdHpghP7sIj
kwvWqhJ3gA==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
f3tnX2YCmmij/BT714m5fPTuG3pr/Sp1bWD1FpCFiwTkcUFmqMNcr7abCn+qa2HUp1VAs9a1kY1i
yU68W3C4ARAx1rnlow3CtMBZ+4vG1QDA+Ciu5T+MSJsiWTAoMU3jJunULwD6zEC9h/Y3bBf+ZNGj
RvbKgHQFYSq+EYUzleQ=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
C6xRmzJVnvguMc3Lt5tkoyg5+/u1VuxRooNBOmgUvD6c148xX9CV/zz4fw53vbCzqUg3WYMPAs5M
/tMrhPMrX5cqjMMHbC20NaFxsFGCfdbN+1Jiu6Ffu0obXLvBu7UGBCEaDTCY0wST3S+7NZ+HnAat
RIt5cVRmnWtLEj9MP8SxAk019LKc3+2AUY0eWFhWbTGvNoTLcRFak8vqIx8KBuqhc16O50jjNmM3
PJltfibMKzAmWpsf6xiOkaD+BvARuccAoYGgANLBAEQdJUza98//SuTN0KLZKbFSmy2WI5iAzkxJ
bhH9hPn6Ks1JkH9+j61hMSpdxSh8rM8X8Dppxw==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
pefxdCU7VwYHa7diZaenheQOVCFpIvDlVp0qUtYsCnfw3IK+d5+k4O7xc5MWvQPeJpwUWNg+c9U8
PcbHo1enWoVg9o1V4U5fg7wxYqKmubBjgGF3yJ5FYGt6FeiD7zcnIJcaP2puAYDdVnxtiJnNmFz2
OQ7UQsleDpBQo3E4NEsbtqgSaopjHREMjI4yjJ9l5XZYNPCWUzUV/mSGX/kF+vuSOZclwPm6w72e
TE0MyJZA2HPDY3HIy260pYSHuDTUpe8gTxi0s8JmpFjaMaibBcPzq2gqPSQe1d6pDE8cv0OxNYKL
gFy+uh/H5gpNjfWVBhRmUo/kFf8fs680z0B0IQ==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
q8meW/DFYsK3R2jTQ13P/a1BVQyF0Eb3aLhqxNSrqINAq7gQ0DvJ6JFuxd6Ce7TIpxqKUYX9026h
UujOPWt7f1brVrSWmt8cW5Um2Yy8tv+YSNv9Ig592u4GssTU6dF978RK/7L4ZuQObLOKvWLJqo3F
6gzw0VbqYS3g5aaGu+Y=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GVM7UoBz9uTOdnKd0CVM0lBuJK2N20FwcoiRGregMBQMsQuevbc7y03ZehM7mfGvEdERp1TciWoI
1b6cDAZYb0YBfSuch0bItCwhdftV3A4/R0nUF0HROsZ/rm/HV7DKDXxItqK0qcdOwqf7ju85NMa4
FJRP/Nuq/ya9IvX9BCpmUlT7tLkICG8cEL8/iJrJY3jRIBtKw85mL5OM+r22LQeYg1/3rb9Rk9BT
RZCTbDcVSUq2Awr+6f0L2NXlRwhFraBy+h9iSZKZ/U7uolyF0nB1+/BSgOl+rttZ2KxfLXe6g81N
FbxtrlpK7FNc9fx2jrKWh5bczyW6p0ATPX0ZbA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
rYkJ9a3QzTBGC5CITub5Su2Qs6nnM1m+OFLf4ykZkZGIsp11NQi6h5t8dsi/rX/MeEof1XLVJGEU
N+qLOHuLrttRAipPNBsj7yqH3Amnleqy/rjy8UcckD0gxIYzuIlc+2VKoAoyrEFgofTH5bKzBaaQ
q0JSt8PES8xuld4SvsKwr+0Q23qJIUpeNL3HvzxZDmYf5OhTkwlZPi/aLwSMoPZHKwetLUg5SdBm
7K4UmxvUPD3GNxo6GW6dkG2tFW/N9+ju7i//O1A74VUrDPo1OwQfEJazwHFFpHGjCJkv2CiPU3+I
TIVvzssQcs8IphMJulwZguc7fFiYv6aZyj/GrA==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2020_08", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
PqIVM68d++A6qxRgSePlX8JOoCfHcFLdhzsYr1BDYvLE5JJ5WKFO0Bie6pyEiAbsH8z6oUFGm/Qy
BLXAyWfv1fmbVAwztezaMaxBF0Lw4epvQlAFVdMGJVKgvxfU7ssvLc1KfpF6R/c1o5+4Vf7zn3X+
R8k67LVYgJoxhrPoY3XYr88CjSITfNW0jLDjh0jtDWf7H7nM6QYSXVbRYczQPcepXW2MOFcCZsbi
tdla+UNJ4NeKTUK5bdE9tNZx/8BYKrJtLhyvNdwHi7EdonKLjQu63ExIHoriUmiZScMNbtr2LUBc
YYGUTIENquQ/OhU+DAVXmKbIZcQhwGaqjYeaag==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
YMvD1GHkklhDlN9yur11SqhNZTItCRHxHobZtty993SsbvXTWJBbLeIJ+nQ/sv57gpjV5RswiJYh
Vu7QPlLUy2DbVjjcqxaxXlPvYaWV1eKD7BVBOV6HDzPAaAIaFvNjeRurYX0a9Dz1qkgkmttneZxB
s04mTyRdVOc7jIs5wjgXiF+iA0W50/g9JmIYyP6mMLkgEy0MbGyVfpbRfDMcrB3ACnucHTo8A0nT
V/rBUOGbTCYPmQ01tbuE2nqoEfTlmqHVKO6BZ93tQUEjrYoJdteva6yHUfH3dbV1vwwBtsdolICY
7x8cMlorxb6y2ZD7vQEYz6Q6iVnG/PmdaCkLSg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 10944)
`pragma protect data_block
4CmCP0U8m1mswh0ceQA3rk9W6ATUH8u55HuzYQ7gYlLB0spuEgB/kz+FT3NPNozGFicqzL0Q64+K
04i2GC3hiuCXKEwkgCsu7wzzhT8O45IKEys8QhD2BQ6ggxchBcVZtj4mFyCWJJ8HZ8z8c9qrz3N8
DYoDI7/WvVYrxiJRLnDwfyyQzT3EL8SCBkQay59h7MsLlqI6ANLQ9mKHC7GiDuPEmQm8HUGiHDKG
FRTIs5dLeU3rkxv3YFVPv3QDG8lFmOjXIHKJAhE8u+221AydLSsZgXC2id0q9fJ/P+VzGhk+hYW1
SeIdHskQkmNWoNhIfk5PghpCioA7IxxqTWFpnYZKA0BRSumOXooMd+MFL5kEcIL63rSNNd4doxEx
uuKx/6HYa4P5TLu8VIEdTrGxtLt6u1rxeUbFtu6g3dRcMFI+JRhmVbkEcIaawnztjPY/R5jMQyw9
8aa1wtNVP77vZ6moNXhVb39gyDwB6DVEQPgrH4fNPNTRKW+xlfxlA0snl9q10a1yH97G/BFvtcmR
ijisJotN11MzPsfdOqMwjXxNMrp0Fd4YNXWQD988prbgoUW+Rd6lDt2vsL3JtoYGnWNCdoK1WByS
TcyjTlH7BcDX0CnegqYeGiUUKWDbwxD5RKbiNUcEY2Hm3NCqwvotrQarCBT8RwHoo3+vxX+2jBAD
qkzUfK8OZ33BWnA/1Ou/NNcqKqTC1fEuz1a4kyAok/aps5Qon1avphXsOvihcG+ZLaVEdtt4Cqpc
V1RzIP0dn0kGO2ePxf0VjUJJZeaG0RfAmoE15nZBaAifA+0tpwEMgSdfLJGv5xu4BvI3v19F949I
UhHmyq0Si8pVgdsZROBprFGcqIlv+FWArxLlAMwGr7LVZFLPIAkBePtX3bj6+0tKAGS77Nwf0Fqi
+nqmLrg6cARzMkDUMn2Cx8gqp0YWoe7T5KTF0KgDBoa50C9M5DUJWAg5J8l5lBJbhjNdfFz7FK//
t1JrtDRPBAZ2plSI7CzDnpfQbYXNHmttNO5KRzmuuumHlDT3EiUWdBpjdmdsu1uLwohyoRLLTrJp
mL2TpqOzHqSBvXGV3AeK/S3nceAvH05zXnsC2BcUc4NDUbtqLURixKgv72/8qpMVLk0caaYVMizP
fm2a72iXuy8IVqetUYXwl8X58KD5ni00hATf/zslfIMHboJmo1CmEUP4DVDC3GMw1Mm2tw8lSjSj
Gen7BZVALsLnbV2/9LVcqET45gTJMdlKZr0NNeotxTcECMN9xckYs4UQ5FfLvPjpNE3SxTIG0mWK
jWcijRsJORu7/7eh6cFgnXzdEUDeX1oFAuhzrgVMbU4DEP6r3FB53gK8lmgI6YiG7Q2yPezjfBoR
03mqn72o6OwWIv1+D83bIse+4b68sKI7Sg9GhhheDausIXYf4Fzivwj7XtOFJAOXuu197t6cbfe8
shkHAGGkwmNSmH4K8zzsxhbo8SJNMLFCvQF49XeHPlJ87mI1h2rOYDWs6xpQ4ysMkbk/HT7N1DQL
dnQYUbCR9XB+ZxhSlpR/4213ZYhG86DvFFoT9YS0c+cn0KDL894NxehEyV5gqYNsdNfsMZjJtIzC
VrMTUK0szKs0BBBJpcUtQf+vWLeq1yD+efot+Aw+osUsypgjgyOMygu9iLDI+r0bIzdZpc8IBhxK
I0U/vBGxU8CuGpwPh2/TJYAw3GywAljQ+bkuAwp4ZRND3gYGlPL/CMV3lIKYfIuL3zOzVJc+zgY3
eI/g/7BAgBT7CjUuYqttjMk+yJQEz9YdIyrGV759lDsHXVluz2RSaHeJMjfFvKBznamGzjnlQKWA
RuGyl4N3Iqufjh5Zn+urz6UXaoB0q5wUihVkL16Ljq75Fb19J8C8ypj9fHHOrFLs/txEIFqH6xNb
/Vq6w21EH6398aordJmgE2rTIdZ9crNTbtzm8yX4umJV11eP1ghUWebgnY8OHm0DzY6ojtJLfeel
V3pmP9mpUcsLc8z5IxFfLNDWk67sbmfrs/OZBqfL6ljPRYIImNtJexJKnzpel5ypVmV9gD4volze
0F9PgfA6ANX9OKth89gW3FGQWQnsSZqLEXjTfDOZQBQ1HaQIvj9y/vIgp7nFcs4fNOuI7SdaE9uo
Fk3/KS5DIGAbvWOcuD/aQCfGh2Yb+wJ4z5tNMvuuWw0b4xYnTxaKRs4UReOIn4kbZfvIwv3/1N9W
HAo5/hRXepa2SmfOxoxtyGG9CROkRVIg8j8AAe3lRIAAVdOR4uSj8rpMEXRSv1BTQa7JhKF5ZD/U
1NC47E/DuN8/E7T1fgjnlpxer2TemiWkvTc/uAYxURd0bDMGRgJ7B/giKYBGtDqRY79/vwQUEW2M
oz04OEuUCXzF7DI+57wJY67A1GqtHlenoaDjr9lOPiG/bLamPiR5382K5RLYwzzZcBLxUvbXponm
F5UucHeKlDJAM8fGP1AVnW/s2bowYGlXkIdj+kbFkxeWx+D9nDLyREi0JCgmIOfIxYZ4KUnX3v3G
UU05ODZVR7tgqNnj7BalTUXmB8FzAxeu/rQa9OXawT4xCLLmnA/8r/R3+fel6mfD1a//8aws6AJl
nRsu4QAZvyb33R1Oay6DYbb+TiSShpf6kp/9/ZinvJLelU0SlqDfFRJl9oNvsv5DP7rz80B1Frpa
n07fixht2QE2/baz7svJZshPyq0arUGzxd9zPRnj2rhdAHNbfvwWGYhwrVRdqzFVevGk6Y2PidAY
JxeCc6QECCytuUmDHPBmhIT6y7OGldbZDbUf3PFzHJvSMhVgBnzsiu99TPlmg3Xs5TQ5eHu5o1NC
agM3Rr46rXBahQtRIBBcbfXtZ7sARRdCmDWH/1t5f82Upd8RDwKMPi8PqphBZA0uzWrQvFwWSrrS
ClLQ/ugwR7zMRm+v9JULjrQAR2pLIZcDpKJ9mFr8eyHRUtrcAtpxltG+/DrZ2PimQCBamZtZtGWo
YX9rbwIbfImhXELvMxF0ip5+Sl2TNwCW06fZCpcC3FxNOwnhGrneAIa88s4MTqXJ9P8sf7EEwTWi
pUUZdcuagcvJvIXJ9RJis7aw1EByFbR2s4WMyL9/QilYthZrRGWsg19rJew1/M2Dey9mEYPWDfC2
K4/khF8rg6T3dnDH90GlHCemv2YGKreR40DHFmETzJa+1Wn7Xbgb3rFpERCt0pdxtYOlw30HralQ
DfbuKL8enORClu/CAe9eUPfxnFr3wLTwZVPxs1XJo70gBRdCZaHJ/Vtj+DjO9q+ZeyWuWqb626Mn
9vcM/P4Q7o7SvO5fRGJQM3ekKXymEbu+v7EhSFrIbM65nIpE9vyvLeHfqjJllAtneysh9Oxd5jBv
TlqBD4+13XxuXfkN2W/LujNMsPdlUoxy9NEQPZMs7aRLVoCwTCYxMsNOEMUcjj8JWvQ1i4q1wi1H
L+ktFzc5WXKtWIZ1zCRnBti8vGJ2PvnhEeGeMfbKXUkclT9OjROiE9PsAOxFRd+G4FaFfszJy6i8
ACmOyzBgesrZgKqNvbX48X4/0XFK4IKJw2bi99oPS/50n5XPZzi2OBSvPfuW17u3TOHJCL0b9Bh/
4xsNFk1y5DiHSs7C6bFoKf28v8TylaxJGkRc/CpoomXGkXZXsR2E+eQIL9ne2QXqmj6OxUqA2cEq
wwQ8dj4R5iCuTWnxBMs94brB9kb2ncxGWdt+HTHNwC+97qrXr7ExUWWdf7C/+u0ou+1I0U0alOXV
tXulI1Fy0QMC1JL91nOSF2mMVjOZ6W03yL3A1B6kEu5QHYKPv2RGwBLmrjkQnYyCPAwjhRArSGq5
vt2RZvuGrPAoXBDNLyDU93xVfhqK6TIARSlfKiNVXCprVtE2WcpHF8LEV03J/9LInyDm26NGILAO
yY+ZL7P75iiHf6KooWCnAuUvyMwX7j1xfn+0VhoAlBVVDs2h2A72W7h7b3g4iPWzUWrbiMvujZJ4
qj7tJo7X9pbK8xLftshqf33JLZZsfkN5wMqCdaxnohtLJPoIIYBTQtF1GA01fIb8dDLgFoVI1StD
FMKiG+wD57V/4lTRbUKP83UuCLYL/Pwpy0l2tDqqZBNV3lqqpZwCvt/OtRcrrJOaYkDi5vYSPz8q
jW0oNVXPodlP609G2h63IEhh7YRCm4cNzHM9aja6sbDCl5x5YEoexAG2F0ehEfmS8Je2lJ9wlmvM
u/fY5T4KzZBJ4dxFKbk7wG2Gwl9BzqdLQNY5t+jJvuEaWw5vwEfw+3tciAFdeaaTw7vLAaEov+iF
f7MA/9kWihbBSc1YZdjByS9tFgtxhMdyXs6FEn+3D4Sz4SqwYLo4V/SeokgLerJ3LG4ZKATV2Oe+
bp/fbAEnpuqz28LreYw1qg1Yo3e9wZXYWnI0rEjQ18Q29jvdEllS2+12LHaLtDPlMxFTgcWKTqzg
m6iyamfWnfXKmEHIvFaNXOXx54wDRYJ6LDWKplJeg5FTBBexV94q0m0CqmNbV3d6+JCPDmciPWeX
3GttzuQAlar9NYwWSsA6xrq/pBlAySFSHn6VL24D3X6XSSuwQdWUwgztgtRypXvgfdRi6ive69HX
jwPAmmoiGkiZ8a4/77oVYxhO/OibkSuvPMNT2JcIWlFrl62CJpr+RS1HUx7xZvh38t1xbYxU+aXZ
HcQVCglAYBc28JGr63Gat3jvUzDAXUPa5XXhEqivcGJp594rQLnGin4diA0z3ZqCxKOht+W8wrK1
hASx70LjyeszFoGNkkBAs/TPdWUyhi0Js+KTm6/MMmcN2JvHY9RRwFcjlBMKz1newfm8770+J3lg
+8Xgtgbe7qgOj+XgUmGvIYbYzQ2cRjUeaxb6KveWCDceDhis58iolI0Wi+7HAnJwecEl6myBfvmx
+2HyCrIJwz7sNk3bldHAvF72bIH+7Bet26+ork/PoZzvDNGnTbayYwF3qqFbSi8+1AVhJDhWTnmy
mvCTsSkRJwloEhl7/oCyK3tpi03dIYOi9VwKuv7ajJh60mGoCf+BErWjNFSo0r+qBrt1a6fH/Ag/
UBJHMxbUdWo35ZofYILx6hitIu24xy7cUDBFDkDuGCC6tR2Q8HlBgovNxsbwp8urTzrGd5YT25R7
xTWw2AW3RnAijodqpw4mtZAAtFYGukNSuvnWtjqXJu7tpIseUjJ9Gulu241wTLu+O0qsMnxREhNU
LR69h+DUDyJW+auK6mKg+Co2SOW25BflbDb+CN3b+QJUBvQOpykriX3v4R1GTn+kCx4NWWtlabsc
FyCGwKJ5x9HTynDF3g/EN6O8IQC2hm0kasmAuqHkW5YPPQXAtgadk6wvpUuDo9mg+tnqHEbGdix+
kus4dRI+KstHV7VfVEbj4/3B6PUp85O4Zr6HpfpJ4gUK5BH7M8cNlHieKA8PoCJJtNP4c7/u9TS1
Yn7hS4Ss2H8jrwyETp61wNYK0BTZMfzyRzrXPHjuk9nY/Z8Qwc07M11vybEVISA7cEB4/RRJasL+
FT7OM60zxtLnyjeROyoGAhRO4MeE1qh5jTPRUGKY4YkWYFptmaUMjwaHkTcCDYiJuXxEJrDdeiXk
ezQSQgR+vPMMJix8C+ItihnqGait4BdoA0QWWpDdtjctiJRgPM7aFPq0JDQsovvLg5cfHWfXfwaW
fmJ7siDX62un9EJvUBucSp8klziOW0iuFdWXDLRbbdB2gSYwAX3Q7Ze23bHKfTtWKXfPbw4RLjLf
49W7askIr8Ghz1uDgA54c1TXVOI9QqSr5Jb5ZLK2eN2Hni+MS7n5vpvqDUyeKH44X9QFx8RT/Rzh
FRpHpYf3Kabpqv4qI0Ni2zeK6eH2eAh2l/WW86/cWXfuV+08J2zOWmHf9O0LvFxEluZ6FukXLvGR
Vok9tvWEg5BB3eiApH3ZDjSxkFAnvc0h4ohN4ZYRHTNO61qJMVWBTyTLQ+OJcKV9jw29/b5H+GcV
OEXqYytV/p79YWZrZRAqpnjT+953koOw0mxKYbJ6b5/EX8uF0ZXo+/UcL2OZTnv2iTC2XtW58HXh
dcfBTzVZO5f9x4b6sfTODuNHEOBhhXjcqPOn08TECFXg127KNUVpRRKDbO+XXPDX2MeOXBUIBRSu
as/Oe9imZfAii7ZkbiuLpkV1ipOW2i3UW7hqcEe3/ZQ8K207PAvhMyT6u0oszGVCaBcBlrUBX8nV
6wCsiP76s0hfDL/UmQ7Xk7eS3pLVssARIgfwyAmpeHIpuANSSQruUapdGuCRFCXx7DcyrZVcEn4l
ZLKUREcUDnz/Jl8/nG73uvansqB8U7wCpyurKPQiVy5TaTNoDnz7s8SyfR6UYyQGQa4+47GNmj82
v8NkWDC3KHe9wECjdE9Wq9mNOa1KovFPX+zTspqOKHpGrT5B8aq6Bd2qaIzHmhuWEhCnZqVboNHw
YcVHNWPJkN7nFfdoXJGPMKi7xAf6O5mO6YZXUsIRIn1LtMWhM2ntzee2PH46obvjk8s+3KCb4VuQ
u2jfE9NfGCIVLGird4+VF9exXXYeKZCBi1ChaIOcNrmLA5ryjwIWF7TYrPlB2fUFyBmMKuT4f+0z
hQkG2nuV5QuP+Bxho36vTtftmz3ikTmChbdJedUG1zJngT3zJyCaQEgeowpUV/sIo7zI64zPuLVb
vxm82NkVspYQcH1N7dQ7RmRPew9xQN9booeJylEs+O24ySUpr/lbhHlvKBmIkVavCpjRDgT8mRd2
wf2S3p5OGHfBgLz6tw3zVOSOQxCEISZv4wUbXGmQ2UJfyfVzrbTJLxBukGevlb2rDg9vdDgInKhX
kpyR/v6xFmb380cNe+ut7KNQ+6VnP7IY0SdnLdb0WZpBHBIR/1YNpou7qFANvmq9kZWYFiEPC//p
DypwYbXOXPqMc3g4jnlq92edCSxl+6MRjbwuwr9kbg+sbOsoxlzphm0d9NRqYE6T3pH82nkJBywZ
fyZq9YRPlNWSjc1cw74UWcD+Fiml65E9K5M61qkjEMahCm74Oy1rRLwbd5zsL2OGDgFvoNVDY3R3
kk/+bB4VjRUPjvoy96zoBnFli1IhqkkrZrrFW8KqhFAp6h/vFa+MA9OqIexDxRYiAIGD1JUIn7Tp
NwECWt1LpdUu1/exLBVXaukU60DWIyqFJ+uxPm2PaTVOlpMBRRQYTMwxrFjuKMdWY0vd9B+uXN/y
UOGT2KLJAQH87nNoZ+OqDHxj+PmJstQJ0KkBzpEDQ6SmmKCg8isrHAOU8+aiQ/zOsIvUeLFjniUP
zjNyaHWy/R+J5VMG6TsIJFoRfAnV3qOhYCb2IoO+KrHjoceNKfAy8hOykCwN3LxHWzuzNBNXagGK
yx7stGX4i7Mw1CChpCKvLYTf5y7MRAuyc7yZ8qnijtw7ZrB8P1dC+3HBONr8ogtC/tI6Kkb+CSr8
3MhgJXahyegIb19SOtmdDcUJJ+okRitjvi57gZ0s34nUNoJBeB1C2617fccVrCKrxQ9tMyYlrUUg
QHU9ia3/MJ2zP5xmKVTRznRlZmWgOkuoyJFsDkGC8jxJA443Sg3Hhx04thsiqlmPbxlqXmkf/HFY
M6ABj2y8Eg/7HNyKwx9F2HoFTauim20WdIXAqkT6F1OtEAX7C9z8xZxN9Fkn9P4FclhouxHF9A2e
uyoF1qqs/BVXQFUKSpOW6CukW7F2mqidyJpB9BRAgCW/6MPBsxrZSAearfo5dn6qyLoFdn1BTd2n
KUZj+r7ufn3LKZFVt5ly7rNS8SMhxFQzUJOvtAFEHC7qdNlbeNB4r24cZEUcKtKVvb2I9FiRMVnh
TMHG8I57sHOpsBpQwCok5hRyBR+NEYhjkiTD+62L3ro/ZAl6htW8infeRwfklFALCpJNflr0tJLx
UxmZgogtsJO1cHNKqH6ema1v4F4TlXCdBl8iLqv26JFSc/GsbBIL8Wz3mAZPaOhLA2opwlX4Km9B
sGlSCSmd+pohozr0L1pPQvksbmbMWXv4QWOrgbbYyfk73LUEFVGwvbr9SiIa+jNKm9MDVCIm8mJw
CqMB+rqvtcgFbeDFLJN+hOFdsigGEM+Kzr0IS3ieDjNt2lZh4/uPrIPL2CFJQy46rb5IrRhnmn7e
DJm7DvCcQgdH1JZpYAThsykxlnY5qhuuvvt9nsTqDaByJH29G0zUxIUfqNVyC0vpUcP6wVcB8Wfs
lHqNzAAgF0vXlsext70jvmO0DhCLIkVfA8icG5mB5KlFn88YHRaHeUmWO3XX01kPMfIO9mR0a89v
NZn7DyfmF7z7tbmQEzokyRF90KPhQWUbo9DeswKSh6gGygmO3kIVA3gX8BIeZi//nwvXgNaGlonu
N38TuOj9SKvzNx/OsXOnwsXLMOiaD7IA/7P6TUfE1xsEPdmRPkvbiJQ2uVpuHuX7wJdfjtnX4f8E
aFgYo50RGhrSWT6k71UaBD019eHnsKAFQjEeHzAoU9eZEQjpMfHop357OJfOpV5+9tCDB2O8EnzU
tsMUhEo/5icJrReNB8knvxGTvlJnYTCkPBoRitIuHlCnIkXDMqhNKOC34hJdpXUANK94VkWEixjB
L/1L6f1exfxkNlFXqoEPm18UYrMRvQJNO7fYCx9v4od0QwHOk+d5ZGPYNdo+XNgd4SAuxIoUkuaa
IqU1+xRYIYNpIUynI2HuUacSKNV3XHVwZTI2UhpCU4UEWZqreRhT6Zwka4Dx7vxJcTeSClviCm0R
DNIAY0raW0wS9o3KJmz5JgiVbqafZcK2UXzyNOiSbD68Iw3PlDG2aGGxuFmPZwHgT9H6Y+HLSzLA
7Rb8xU4ejU1xfBZFHxLBwt7vIiYKVE1QXIVDqiEzn8PduoPpNgFebyaCLL3cNiaK4ogVpG8m5xin
ySTk0UyehdKr42G0oUmzadpUEWx8/unC8/m7JZd/yq1USjR0LhAAvS6VwfBOFyvSrualPPtD5mWD
JVbfu7cS2+rF1jOpWPHbavYfEju8okAS/klTABbXPOwJ/nymOsYhh0OfK+wqqNnNtVGop6i/Ge+D
UBqiHzfHMvvKGAySRbxjOaqsjAE45HFTMvuGIL/MhUPrN+9FstBEIFEo/hNf2DV38ce0n4OEVGt9
s76DCpdOTGIAOHpbvuWxFvJWZcJiJZL2FYXCxUZLktt8ERnwsg/RYwn8DrMskmRRM5v1WzAaywi/
22G4wf7jGQK44qxGTmD34xFix8SHi+kViNMpuT5PaekySFx6vQzslpMEzEKivpcRCCYwFR/3yvcX
0VxEQZ4ivu8UyjPJDjnD8Es51H3VFuN+kz4SFS6t92BTdAkJn+v0uQDeWgywCbssc7fflHVUOZIu
UWkXETV5HJYgqVPDLn/zigqGCzHZInQCFNfetoelBbEuG+5Spxi3zRJHXxRrDQCWWWc5K/xKjvAX
MLPZDcmpmqWdgcxMgewYodc9NOTBLgAvC1d2YNan1RBb0EN9E8FbMPXc6Vu6MF4cETosrt1RMhza
wvd1hwMRvN54ZyoubuwLXXzgj6pUYmYW2ADocl/XIOgMKcdOaM4JHSkgF3/bNKuRIzuppsfvpb77
Iyp/cMW42ID+06cvc0rfsX5y5myfeHkxrYDb0LjYtjXSYvEQ6VdssYBqyMYke82LIsRcbKbm7bcS
kWpDQjtVt7jb3elBr9YetVNdelW9PGDbKOGf0OLNMOqDD6igOpwsZpzSWLk1QF5eIsAoMolz8tAJ
cRUourNN5hLNu2BUXKobh28586lUfjRqVY8zc0lS66WfFrreIgXyWZlVF5zuXDhikR56SjoN8mgS
764WxP2bGUFitWoY3/M3Q03dVTw+yktWCdVl2nXb8a3Yu7ZP5OqWoT2mAYZW/FEwNYyAg4W8oA+y
CL14r5RB/9l67KN92zd9g9iFfw+7yv/mQCfg7Xtdu74SCnjs6nbW/1GOFLrv009A+rmBe87wt7DP
Ans3uLwH2ie+uU/NdpesDEpGw7E3HIuAeayPCNhppJiTZ6ES6UqM4zAUNKKpmomTOW6l1yj26COu
EUBpgn86oEUJeaQBd8gtzX7TJ/nLRz5zbmeFcpEdwVI95xtS+p8SqmMFjuf6cCn7IjoVDDkmOOR0
kOJe0cZR670GsgijbmQT8QjqD+Bacpl+TVaD7MVLXahLe7bh9R06dwLErBPDk/1++SRpYWzAsWEC
XuadFHFBNpdHp4xsc216sI6vbtb41mnCg77Ahfnb8QW7Hv26QMOGhdnzp4EZIgWbsYQlN/R6Psxu
Rafhieu9ALVUSL5cDeG3w5xC3BukGke5pBcggxDD7yH84VSrn9VlTRWbnHT/XKS0tOxNxF7eUdel
TNAzHzNRQhaq+dNCLNG0xO+cu/XQDxiXI93JcsOgV/6Hjf9IOIdidd1DUjAbhuWZ/gfNrvQST8mb
Et6DGbc2ywa+B2Zbsmc3slB/MGZgw1c5zCScq5dVgWAE3NdpZW6ICGuryA9RE+DrW9D8/QSiy1/f
XBDG3MK8RGTlh/vGTVAu6vu07lVMGraYIahwF11/n4tQS+raxSCzq37BHWKOPxln46/nojS593CJ
yA8iwONTCg2JBG0uDtf/qg+KgLJs+ecM5+lrMrzvX4bkx07aucHFEpu7bnh86lJBkSAIqZlXL7hu
hcptUxRKrLgXGEomJBP3lhN6DKBT/6NIMLB6hFd6sGfH83pZUzt5R05prEjQEk0zl/Y2453ql8jD
zeFfPQw7PhM8KHBpIJpayOtpfjceZ9/3E6PD1ajOStLfYOH6izK/Zn6HNgGYUPclYPQsdFGsBzxd
ejsBz1srOzkCQVJFULWrJzSbMoxu4flD6IGj5/IiWkwGjERqXo4Ev3/hLDTPL2VOc26Ok3quhAvX
GOUpftxlNUz3mjsskCMWiMb8DE1wcSF4AFmZrCJuxdC6i8RJoj5YKMBZXIqMYGVICX7+oJsowXmk
XicOkWF8l3ntST4FJ8euoNtod104xLcIR1/dJX4jrBXcvSZ/8GdiHwI5MMy0heMhGlqXSVvDgGe+
qtdPzxOe1lNO7SpvarQOYsdJAW73BoBTfLRzOmhIcBcwm5KtXedfJ60I1Dyq4U1V4cqWWGGQEnCW
1WiixqSofmMkE09yKK4W8iSBajDOqoVC4XQrBTJm9KJfUjbleAMPJ5E3kmqAtA2Ip/2FC/EYUR4j
2lngOUbRMuYq5GxpalzDqcEEL6g3oWHUhVyzwdMlJSpfu9Ny02aVy3P/Zgj8f6kNXPiIzMTCKqhI
GCdkh+2oPqlfmW20BJucTcvVHGL9amCKIs8AAOr86jfFRTfuZyLpf3gEL8VxLrep+p53ywYH7Dmq
xMcFBGonHC7/YzSqZ3ZwOshkv5AERt5tWpYO8FDA54xE+EG4L09PdxgY+v0r+VgKRJrenAAIIQZs
WXZ2rfLxWAhv4C64YOeuWMuV+1YTzoJ6IgB4R6fZhilVUxXHgqRd75qRtk3Gi2Qpf333/3QCmv/M
INixjMVchE+3R2h5d1IL8r6VjWlodtFKiQNUltlWiUOR1A2Er9cxt8VsZMxlHTnIQjg9CsdAiVV2
pkq23zi0aoVVVFokL+UGqLRpmycarU17XOqQ8zq8idC1LlTa20/YDpSoxR/gfcuyWaT47fmILSP0
9IdyDRCJL56MzPPMzwoRvUuVjNSI56j/N7jtinxmeHvtWrYy4GmnAXchSNRYGrdhdUsgK9LS3Y+L
cxnDQf/mubgpfFQQbvwAAV+hOcXBvh8vHtt0421vOla8NS8XlEmfrrPz8sAkglCeqpB/RNJSfxpn
b5lKBh3sE7WCpNVUh4gqQsdVHDeoqTw8EberW/H+Qo9thcw0P6vTjSz4Xm3WDn65gtMTN8ZQatQu
35pFl/M0qS7WAx3AFPoMb19svpcU2NN5Ij00yBdq2QzTKosXvi6V9d5ceZtfaJyjgvAnv/RKP5fu
bHPO1c1+npTb5XGpAhvayuCtb9xov8RNcYOGrdtwh/GHQjur/xtwTvorthmSBev5upxfmncxbuS/
PUdAJgV9G+BF4/qrTv9qpPnrr3t46Fj/SF8W62kR07H4vwCWSnsnktKylKpD7JGKvlZzd3L5AULE
ibCe/4POkzDetmoXyZb7nAtFPNw1/zekNpYRqCDKzDhYAR7E2FOprTbwdmcY//RTlqI+Z19Ngx2S
XxQxz5KNHRVJuHeiwPsVO/x6SHrDoa0U/xUVSL4lZbkU6SbqfkPkQuif+LIkysDbJRp527HzUaf6
HCMJJpmH9MxwzxEaD39Toxe8E1rvwIa2yOlbx2kNo4B/z8dS86AHCJt6Vdsh++rJJe9T9sa9cMVC
7a/1dIlbng04+/mk1mcBGreXF7NWXaeukZ47rzoLwX9/Owd3ggpNaWzJt7r0jkcWBRZp9PTR5fv5
w6+sdXH84D/as3a3jQnn/qHlLHfveEVG4JFmTa/jr1wv+2emfA3igj1NJN8BM8o483fu4d3m6ZjX
SGY06NUf9KO8knVnWCwgoMUKw1z7emGMX2Gpc2xWUKcbMj+ddJJ+2sUs4LANlyQf70pgKENoekyc
M8QypIKXtnuHL1QXSTImMy57OEuLH9nHw9nx9/HUEAXJGP3cxxOxPWuDwwJXGOuEvfzdLTjvODrD
biE50h5oo6O+T1YfCnC6bHnxkmRC64Oa8xIg3hXEM5lRP4Qpi8dLg44qXm7C16dtSj6vBGk6ZGfz
2nDoDF30N9rHeCP6O2pmkOnMzh5QsM5LZAA48rTqL3o8K+NIiGKsz2eomSHMgdW8xsh0w6cKkI0V
TgogB6h+Cj25rEFWeX1CpCZXBdi5b3r+tOI7Lbpmgmmho7Z3hiPoS4kz2lAz/RSmuRrfP2uBWvJl
Mgy8FXoNDBdMwO/5Te9h+M0UnJcqV8HNxJUi+VcubFFf9HhFR7KoUCJDJ4Pc6hseFbaG26cn2oRh
3H6dFs62nO+xsDLYJ/ZWxAEVPysaYse9YUxPd6vGn1bFcjYFPHfmoXCOnuu6K9HYDHaUNQ9GDVvQ
6bs3yLLRX2X50hjuC7qn41nhItY5w+MXqnS7z1yn/Vs9yre4ibxDNPaZAm82TPiPU+hP/N0UTBSk
1BaB3+iEDxbc7xy9yVTrcN1FzfOvbNPdO/JJ4wEYHDWJTGPTKJ3GF4v4NJZVfg4zSsxIIb2LWSkm
QxhPgHSY4UOdv6bAHIWbXfmJSYETEzklKui8tccKusee/+yNBaFRxZz2l4q0XvHX02+bUx/a78VQ
TmJuHUv0z7bvu9neodVwGaUeM1bNtz4amttPntyYrU04n6IRtAAcHdreTs5o/+WQt4DaLyxyiDAD
PIPr0yybPBQ41tXCdJfCgWkYWBbCoycqdyX/aS78wJP1xRa1I1MiN8gB+c+ZmGa8Qs9o9ypFL9rt
mpSIGMKatCOtDdQjhc1ofe5teKldPdLBEOViaTnoVjVZFGnGcWXTER/jZJmc+zhiI+h7TmEBz8Zj
2qy4nhmYuOowN+fvvgsxfEHxTjxJ28cyb5CcIMUzIwU1gZkcJ6NoqFXs2D4go0wZ8Onjsi+DC+UA
YUC21hQqAEI/l3UiLSTbjvbAlmgmRRGBWtKYwLhJMbl5xAcwlGz1el4ZU0FNelKafreuqlQirBdD
fC/1STcaw2Q0JIeunbxzT432WYfbywnhdC7yYagIGGs0nlI24sJlbzWDAw+W7yv42uebR7Xv4FYr
0FbRccZsChP+3YnY9Zl/yRVvdPBQjU75VRalumippj0361ZCjDZWYMT0EfA2i/YSEXH2cVnBBhqb
dWsZz71JSbOw8vFvv4EXH7N1S3SQ37482IKPVonPYblkZ9kYQwoTmezOtQcN3B4YqyKarxAeaLyP
7G6bTw/iNbAYCWek8axHIqTPIeKCTx5RNqhZ8OlDZO0XDwEQoRksLsVQYcb0WkRbMcuA+nkzYLzU
DCWZDaBcqzrctjONROplSa3WHgeOKYbaRacmBiocC6A+MUtZaVzhc7Nt675XIb6bvRKm6ezJuNZn
vC2LfuB3PBNyhDVtrVaTm4BPuU8VnAM7uFcINN65g5ACmKp+5XxUP6u0QnSL0qz9BlvcdPremqLS
JQxuAjIRr1rdo7i5lQY8PkRSjOvcVegTcUJwAYD12jOeQI+m8NGVvL2yrlOd94xQ2AnVjNIVb/+z
SWIzg3CzeoveO239WwYF5YcMSzHv/5OyMtf4ZzXN+clbqW6Tm/s5Ln2L4NZ4z5yd7SUtz5buOtlg
K338/alyLscIlgllCZaAYulMKvKUcRtZtLXBNuLj+SYjoGkL6Hf9on90M8IapFvWlZSVxw8FniJl
OCniWH3m+OYMKxXhJu6WgMd9VZ51DMUOotLqcCiYRq/mwaDuP9NV7XsjDKjGMcyL42Waeu+X917x
LbGh4OH24Sh50jZAImi2T3PZSL/8nXfty2vv04xB71hi27YRTU3HbHTln1LUxJSZgen2srRq4Uj/
q2PwJUuJBY6g7ElNg9UJNmAK3w7i+OVI2N4wwToUP8ay8pcBocWR775p514aXlJLijKlSKnKqbhd
8p1Iz7UWzD7sJe3QNYeGC+9FEKGbKnY6RQQW7rUk/ajuU2pk2VmlJpQHwXm2597HGQUIM41G8xW0
KP3T+nPnnthc3gDVGw/z+dBfLWrQsQ7RBFfMJO6hJJulyke+7ulRl9N+Sm1tnrTlGoXOAtzUMq78
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
