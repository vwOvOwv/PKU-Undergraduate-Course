-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:27:20 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top singleriscv_bd_controller_0_0 -prefix
--               singleriscv_bd_controller_0_0_ singleriscv_bd_controller_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_controller_0_0 is
  port (
    op : in STD_LOGIC_VECTOR ( 6 downto 0 );
    funct3 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    funct7b5 : in STD_LOGIC;
    zero : in STD_LOGIC;
    lessthan : in STD_LOGIC;
    ResultSrc : out STD_LOGIC_VECTOR ( 1 downto 0 );
    MemWrite : out STD_LOGIC;
    PCSrc : out STD_LOGIC;
    ALUSrc : out STD_LOGIC;
    RegWrite : out STD_LOGIC;
    Jump : out STD_LOGIC;
    JumpR : out STD_LOGIC;
    UType : out STD_LOGIC;
    AUIPC : out STD_LOGIC;
    ImmSrc : out STD_LOGIC_VECTOR ( 1 downto 0 );
    ALUControl : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of singleriscv_bd_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of singleriscv_bd_controller_0_0 : entity is "singleriscv_bd_controller_0_0,controller,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of singleriscv_bd_controller_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of singleriscv_bd_controller_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of singleriscv_bd_controller_0_0 : entity is "controller,Vivado 2020.2";
end singleriscv_bd_controller_0_0;

architecture STRUCTURE of singleriscv_bd_controller_0_0 is
  signal \ALUControl[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal PCSrc_INST_0_i_1_n_0 : STD_LOGIC;
  signal \^resultsrc\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^op\ : STD_LOGIC_VECTOR ( 6 downto 0 );
begin
  Jump <= \^op\(3);
  ResultSrc(1) <= \^op\(2);
  ResultSrc(0) <= \^resultsrc\(0);
  \^op\(6 downto 2) <= op(6 downto 2);
\ALUControl[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22223000"
    )
        port map (
      I0 => funct3(0),
      I1 => \^op\(2),
      I2 => \^op\(6),
      I3 => funct3(2),
      I4 => \^op\(4),
      O => ALUControl(0)
    );
\ALUControl[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => \^op\(6),
      I1 => funct3(1),
      I2 => \^op\(4),
      I3 => \^op\(2),
      O => ALUControl(1)
    );
\ALUControl[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^op\(2),
      I1 => \^op\(4),
      I2 => funct3(2),
      O => ALUControl(2)
    );
\ALUControl[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCCFCCCCCCEEEE"
    )
        port map (
      I0 => \^op\(6),
      I1 => \ALUControl[3]_INST_0_i_1_n_0\,
      I2 => funct3(2),
      I3 => funct3(1),
      I4 => \^op\(2),
      I5 => \^op\(4),
      O => ALUControl(3)
    );
\ALUControl[3]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => \^op\(5),
      I1 => funct7b5,
      I2 => \^op\(6),
      I3 => \^op\(2),
      I4 => \^op\(4),
      O => \ALUControl[3]_INST_0_i_1_n_0\
    );
ALUSrc_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00550007"
    )
        port map (
      I0 => \^op\(4),
      I1 => \^op\(5),
      I2 => \^op\(6),
      I3 => \^op\(3),
      I4 => \^op\(2),
      O => ALUSrc
    );
AUIPC_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^op\(2),
      I1 => \^op\(5),
      O => AUIPC
    );
\ImmSrc[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"F4"
    )
        port map (
      I0 => \^op\(6),
      I1 => \^op\(5),
      I2 => \^op\(3),
      O => ImmSrc(0)
    );
\ImmSrc[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => \^op\(3),
      I1 => \^op\(6),
      I2 => \^op\(2),
      O => ImmSrc(1)
    );
JumpR_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \^op\(3),
      I1 => \^op\(6),
      I2 => \^op\(2),
      O => JumpR
    );
MemWrite_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^op\(6),
      I1 => \^op\(5),
      I2 => \^op\(4),
      O => MemWrite
    );
PCSrc_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \^op\(2),
      I1 => \^op\(6),
      I2 => PCSrc_INST_0_i_1_n_0,
      I3 => \^op\(3),
      O => PCSrc
    );
PCSrc_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5A5A003C00000000"
    )
        port map (
      I0 => lessthan,
      I1 => zero,
      I2 => funct3(0),
      I3 => funct3(1),
      I4 => funct3(2),
      I5 => \^op\(6),
      O => PCSrc_INST_0_i_1_n_0
    );
RegWrite_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => \^op\(5),
      I1 => \^op\(4),
      I2 => \^op\(2),
      O => RegWrite
    );
\ResultSrc[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^op\(4),
      I1 => \^op\(5),
      O => \^resultsrc\(0)
    );
UType_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^op\(2),
      I1 => \^op\(6),
      O => UType
    );
end STRUCTURE;
