-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:20:50 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4_0_stub.vhdl
-- Design      : display_7seg_x4_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity display_7seg_x4_0 is
  Port ( 
    CLK_1KHz : in STD_LOGIC;
    in3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an : out STD_LOGIC_VECTOR ( 0 to 3 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 )
  );

end display_7seg_x4_0;

architecture stub of display_7seg_x4_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK_1KHz,in3[3:0],in2[3:0],in1[3:0],in0[3:0],an[0:3],seg[0:6]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "display_7seg_x4,Vivado 2020.2";
begin
end;
