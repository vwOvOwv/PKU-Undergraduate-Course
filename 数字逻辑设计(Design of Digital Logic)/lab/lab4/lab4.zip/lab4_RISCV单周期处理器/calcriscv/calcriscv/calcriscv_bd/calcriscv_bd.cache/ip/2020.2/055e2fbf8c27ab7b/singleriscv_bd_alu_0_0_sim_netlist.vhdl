-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:23:09 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ singleriscv_bd_alu_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_alu_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_alu is
  port (
    result : out STD_LOGIC_VECTOR ( 31 downto 0 );
    lessthan : out STD_LOGIC;
    zero : out STD_LOGIC;
    a : in STD_LOGIC_VECTOR ( 31 downto 0 );
    b : in STD_LOGIC_VECTOR ( 31 downto 0 );
    alucontrol : in STD_LOGIC_VECTOR ( 3 downto 0 );
    result_31_sp_1 : in STD_LOGIC;
    \result[31]_0\ : in STD_LOGIC;
    \result[31]_1\ : in STD_LOGIC;
    \result[31]_2\ : in STD_LOGIC;
    \result[31]_3\ : in STD_LOGIC;
    result_0_sp_1 : in STD_LOGIC;
    \result[0]_0\ : in STD_LOGIC;
    \result[0]_1\ : in STD_LOGIC;
    \result[0]_2\ : in STD_LOGIC;
    result_1_sp_1 : in STD_LOGIC;
    \result[1]_0\ : in STD_LOGIC;
    result_2_sp_1 : in STD_LOGIC;
    \result[2]_0\ : in STD_LOGIC;
    result_3_sp_1 : in STD_LOGIC;
    \result[3]_0\ : in STD_LOGIC;
    result_4_sp_1 : in STD_LOGIC;
    \result[4]_0\ : in STD_LOGIC;
    result_5_sp_1 : in STD_LOGIC;
    \result[5]_0\ : in STD_LOGIC;
    \result[5]_1\ : in STD_LOGIC;
    result_6_sp_1 : in STD_LOGIC;
    \result[6]_0\ : in STD_LOGIC;
    result_7_sp_1 : in STD_LOGIC;
    \result[7]_0\ : in STD_LOGIC;
    \result[2]_1\ : in STD_LOGIC;
    \result[2]_2\ : in STD_LOGIC;
    \result[2]_3\ : in STD_LOGIC;
    \result[3]_1\ : in STD_LOGIC;
    \result[4]_INST_0_i_3_0\ : in STD_LOGIC;
    result_8_sp_1 : in STD_LOGIC;
    \result[8]_0\ : in STD_LOGIC;
    result_9_sp_1 : in STD_LOGIC;
    \result[9]_0\ : in STD_LOGIC;
    result_10_sp_1 : in STD_LOGIC;
    \result[10]_0\ : in STD_LOGIC;
    result_11_sp_1 : in STD_LOGIC;
    \result[11]_0\ : in STD_LOGIC;
    result_12_sp_1 : in STD_LOGIC;
    \result[12]_0\ : in STD_LOGIC;
    result_13_sp_1 : in STD_LOGIC;
    \result[13]_0\ : in STD_LOGIC;
    result_14_sp_1 : in STD_LOGIC;
    \result[14]_0\ : in STD_LOGIC;
    result_15_sp_1 : in STD_LOGIC;
    \result[15]_0\ : in STD_LOGIC;
    result_16_sp_1 : in STD_LOGIC;
    \result[16]_0\ : in STD_LOGIC;
    \result[16]_1\ : in STD_LOGIC;
    result_17_sp_1 : in STD_LOGIC;
    \result[17]_0\ : in STD_LOGIC;
    result_18_sp_1 : in STD_LOGIC;
    \result[18]_0\ : in STD_LOGIC;
    result_19_sp_1 : in STD_LOGIC;
    \result[19]_0\ : in STD_LOGIC;
    result_20_sp_1 : in STD_LOGIC;
    \result[20]_0\ : in STD_LOGIC;
    result_21_sp_1 : in STD_LOGIC;
    \result[21]_0\ : in STD_LOGIC;
    result_22_sp_1 : in STD_LOGIC;
    \result[22]_0\ : in STD_LOGIC;
    result_23_sp_1 : in STD_LOGIC;
    \result[23]_0\ : in STD_LOGIC;
    result_24_sp_1 : in STD_LOGIC;
    \result[24]_0\ : in STD_LOGIC;
    result_25_sp_1 : in STD_LOGIC;
    \result[25]_0\ : in STD_LOGIC;
    result_26_sp_1 : in STD_LOGIC;
    \result[26]_0\ : in STD_LOGIC;
    result_27_sp_1 : in STD_LOGIC;
    \result[27]_0\ : in STD_LOGIC;
    result_28_sp_1 : in STD_LOGIC;
    \result[28]_0\ : in STD_LOGIC;
    \result[28]_1\ : in STD_LOGIC;
    result_29_sp_1 : in STD_LOGIC;
    \result[29]_0\ : in STD_LOGIC;
    result_30_sp_1 : in STD_LOGIC;
    \result[1]_1\ : in STD_LOGIC;
    \result[1]_2\ : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_alu;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_alu is
  signal \^lessthan\ : STD_LOGIC;
  signal \result[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[28]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[29]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[6]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal result_0_sn_1 : STD_LOGIC;
  signal result_10_sn_1 : STD_LOGIC;
  signal result_11_sn_1 : STD_LOGIC;
  signal result_12_sn_1 : STD_LOGIC;
  signal result_13_sn_1 : STD_LOGIC;
  signal result_14_sn_1 : STD_LOGIC;
  signal result_15_sn_1 : STD_LOGIC;
  signal result_16_sn_1 : STD_LOGIC;
  signal result_17_sn_1 : STD_LOGIC;
  signal result_18_sn_1 : STD_LOGIC;
  signal result_19_sn_1 : STD_LOGIC;
  signal result_1_sn_1 : STD_LOGIC;
  signal result_20_sn_1 : STD_LOGIC;
  signal result_21_sn_1 : STD_LOGIC;
  signal result_22_sn_1 : STD_LOGIC;
  signal result_23_sn_1 : STD_LOGIC;
  signal result_24_sn_1 : STD_LOGIC;
  signal result_25_sn_1 : STD_LOGIC;
  signal result_26_sn_1 : STD_LOGIC;
  signal result_27_sn_1 : STD_LOGIC;
  signal result_28_sn_1 : STD_LOGIC;
  signal result_29_sn_1 : STD_LOGIC;
  signal result_2_sn_1 : STD_LOGIC;
  signal result_30_sn_1 : STD_LOGIC;
  signal result_31_sn_1 : STD_LOGIC;
  signal result_3_sn_1 : STD_LOGIC;
  signal result_4_sn_1 : STD_LOGIC;
  signal result_5_sn_1 : STD_LOGIC;
  signal result_6_sn_1 : STD_LOGIC;
  signal result_7_sn_1 : STD_LOGIC;
  signal result_8_sn_1 : STD_LOGIC;
  signal result_9_sn_1 : STD_LOGIC;
  signal \sum__93\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \sum_carry__0_n_0\ : STD_LOGIC;
  signal \sum_carry__0_n_1\ : STD_LOGIC;
  signal \sum_carry__0_n_2\ : STD_LOGIC;
  signal \sum_carry__0_n_3\ : STD_LOGIC;
  signal \sum_carry__1_n_0\ : STD_LOGIC;
  signal \sum_carry__1_n_1\ : STD_LOGIC;
  signal \sum_carry__1_n_2\ : STD_LOGIC;
  signal \sum_carry__1_n_3\ : STD_LOGIC;
  signal \sum_carry__2_n_0\ : STD_LOGIC;
  signal \sum_carry__2_n_1\ : STD_LOGIC;
  signal \sum_carry__2_n_2\ : STD_LOGIC;
  signal \sum_carry__2_n_3\ : STD_LOGIC;
  signal \sum_carry__3_n_0\ : STD_LOGIC;
  signal \sum_carry__3_n_1\ : STD_LOGIC;
  signal \sum_carry__3_n_2\ : STD_LOGIC;
  signal \sum_carry__3_n_3\ : STD_LOGIC;
  signal \sum_carry__4_n_0\ : STD_LOGIC;
  signal \sum_carry__4_n_1\ : STD_LOGIC;
  signal \sum_carry__4_n_2\ : STD_LOGIC;
  signal \sum_carry__4_n_3\ : STD_LOGIC;
  signal \sum_carry__5_n_0\ : STD_LOGIC;
  signal \sum_carry__5_n_1\ : STD_LOGIC;
  signal \sum_carry__5_n_2\ : STD_LOGIC;
  signal \sum_carry__5_n_3\ : STD_LOGIC;
  signal \sum_carry__6_n_1\ : STD_LOGIC;
  signal \sum_carry__6_n_2\ : STD_LOGIC;
  signal \sum_carry__6_n_3\ : STD_LOGIC;
  signal \sum_carry_i_1__0_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__1_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__2_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__3_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__4_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__5_n_0\ : STD_LOGIC;
  signal \sum_carry_i_1__6_n_0\ : STD_LOGIC;
  signal sum_carry_i_1_n_0 : STD_LOGIC;
  signal \sum_carry_i_2__0_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__1_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__2_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__3_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__4_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__5_n_0\ : STD_LOGIC;
  signal \sum_carry_i_2__6_n_0\ : STD_LOGIC;
  signal sum_carry_i_2_n_0 : STD_LOGIC;
  signal \sum_carry_i_3__0_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__1_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__2_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__3_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__4_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__5_n_0\ : STD_LOGIC;
  signal \sum_carry_i_3__6_n_0\ : STD_LOGIC;
  signal sum_carry_i_3_n_0 : STD_LOGIC;
  signal \sum_carry_i_4__0_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__1_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__2_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__3_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__4_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__5_n_0\ : STD_LOGIC;
  signal \sum_carry_i_4__6_n_0\ : STD_LOGIC;
  signal sum_carry_i_4_n_0 : STD_LOGIC;
  signal sum_carry_i_5_n_0 : STD_LOGIC;
  signal sum_carry_n_0 : STD_LOGIC;
  signal sum_carry_n_1 : STD_LOGIC;
  signal sum_carry_n_2 : STD_LOGIC;
  signal sum_carry_n_3 : STD_LOGIC;
  signal zero_INST_0_i_1_n_0 : STD_LOGIC;
  signal zero_INST_0_i_2_n_0 : STD_LOGIC;
  signal zero_INST_0_i_3_n_0 : STD_LOGIC;
  signal zero_INST_0_i_4_n_0 : STD_LOGIC;
  signal zero_INST_0_i_5_n_0 : STD_LOGIC;
  signal zero_INST_0_i_6_n_0 : STD_LOGIC;
  signal zero_INST_0_i_7_n_0 : STD_LOGIC;
  signal zero_INST_0_i_8_n_0 : STD_LOGIC;
  signal \NLW_sum_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of sum_carry : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_carry__6\ : label is 35;
begin
  lessthan <= \^lessthan\;
  result_0_sn_1 <= result_0_sp_1;
  result_10_sn_1 <= result_10_sp_1;
  result_11_sn_1 <= result_11_sp_1;
  result_12_sn_1 <= result_12_sp_1;
  result_13_sn_1 <= result_13_sp_1;
  result_14_sn_1 <= result_14_sp_1;
  result_15_sn_1 <= result_15_sp_1;
  result_16_sn_1 <= result_16_sp_1;
  result_17_sn_1 <= result_17_sp_1;
  result_18_sn_1 <= result_18_sp_1;
  result_19_sn_1 <= result_19_sp_1;
  result_1_sn_1 <= result_1_sp_1;
  result_20_sn_1 <= result_20_sp_1;
  result_21_sn_1 <= result_21_sp_1;
  result_22_sn_1 <= result_22_sp_1;
  result_23_sn_1 <= result_23_sp_1;
  result_24_sn_1 <= result_24_sp_1;
  result_25_sn_1 <= result_25_sp_1;
  result_26_sn_1 <= result_26_sp_1;
  result_27_sn_1 <= result_27_sp_1;
  result_28_sn_1 <= result_28_sp_1;
  result_29_sn_1 <= result_29_sp_1;
  result_2_sn_1 <= result_2_sp_1;
  result_30_sn_1 <= result_30_sp_1;
  result_31_sn_1 <= result_31_sp_1;
  result_3_sn_1 <= result_3_sp_1;
  result_4_sn_1 <= result_4_sp_1;
  result_5_sn_1 <= result_5_sp_1;
  result_6_sn_1 <= result_6_sp_1;
  result_7_sn_1 <= result_7_sp_1;
  result_8_sn_1 <= result_8_sp_1;
  result_9_sn_1 <= result_9_sp_1;
lessthan_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8EB28E8E8E8E8E8E"
    )
        port map (
      I0 => \sum__93\(31),
      I1 => a(31),
      I2 => b(31),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => alucontrol(1),
      O => \^lessthan\
    );
\result[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => result_0_sn_1,
      I1 => \result[0]_0\,
      I2 => \result[0]_1\,
      I3 => \result[0]_2\,
      I4 => \result[0]_INST_0_i_2_n_0\,
      I5 => \result[0]_INST_0_i_3_n_0\,
      O => result(0)
    );
\result[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF88888F888888"
    )
        port map (
      I0 => \result[2]_2\,
      I1 => \sum__93\(0),
      I2 => b(0),
      I3 => \result[3]_1\,
      I4 => a(0),
      I5 => \result[1]_2\,
      O => \result[0]_INST_0_i_2_n_0\
    );
\result[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA03A300A000A00"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \^lessthan\,
      I4 => a(0),
      I5 => b(0),
      O => \result[0]_INST_0_i_3_n_0\
    );
\result[10]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_10_sn_1,
      I1 => \result[10]_INST_0_i_2_n_0\,
      I2 => \result[10]_0\,
      I3 => b(10),
      I4 => a(10),
      I5 => \result[5]_1\,
      O => result(10)
    );
\result[10]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(10),
      I4 => a(10),
      I5 => b(10),
      O => \result[10]_INST_0_i_2_n_0\
    );
\result[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_11_sn_1,
      I1 => \result[11]_INST_0_i_2_n_0\,
      I2 => \result[11]_0\,
      I3 => b(11),
      I4 => a(11),
      I5 => \result[5]_1\,
      O => result(11)
    );
\result[11]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(11),
      I4 => a(11),
      I5 => b(11),
      O => \result[11]_INST_0_i_2_n_0\
    );
\result[12]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_12_sn_1,
      I1 => \result[12]_INST_0_i_2_n_0\,
      I2 => \result[12]_0\,
      I3 => b(12),
      I4 => a(12),
      I5 => \result[5]_1\,
      O => result(12)
    );
\result[12]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(12),
      I4 => a(12),
      I5 => b(12),
      O => \result[12]_INST_0_i_2_n_0\
    );
\result[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_13_sn_1,
      I1 => \result[13]_INST_0_i_2_n_0\,
      I2 => \result[13]_0\,
      I3 => b(13),
      I4 => a(13),
      I5 => \result[5]_1\,
      O => result(13)
    );
\result[13]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(13),
      I4 => a(13),
      I5 => b(13),
      O => \result[13]_INST_0_i_2_n_0\
    );
\result[14]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_14_sn_1,
      I1 => \result[14]_INST_0_i_2_n_0\,
      I2 => \result[14]_0\,
      I3 => b(14),
      I4 => a(14),
      I5 => \result[5]_1\,
      O => result(14)
    );
\result[14]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(14),
      I4 => a(14),
      I5 => b(14),
      O => \result[14]_INST_0_i_2_n_0\
    );
\result[15]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_15_sn_1,
      I1 => \result[15]_INST_0_i_2_n_0\,
      I2 => \result[15]_0\,
      I3 => b(15),
      I4 => a(15),
      I5 => \result[5]_1\,
      O => result(15)
    );
\result[15]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(15),
      I4 => a(15),
      I5 => b(15),
      O => \result[15]_INST_0_i_2_n_0\
    );
\result[16]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[16]_INST_0_i_1_n_0\,
      I1 => result_16_sn_1,
      I2 => \result[16]_0\,
      I3 => \result[0]_0\,
      I4 => \result[16]_1\,
      I5 => \result[0]_2\,
      O => result(16)
    );
\result[16]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(16),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(16),
      I5 => b(16),
      O => \result[16]_INST_0_i_1_n_0\
    );
\result[17]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[17]_INST_0_i_1_n_0\,
      I1 => result_17_sn_1,
      I2 => \result[17]_0\,
      I3 => \result[0]_0\,
      I4 => \result[16]_0\,
      I5 => \result[0]_2\,
      O => result(17)
    );
\result[17]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(17),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(17),
      I5 => b(17),
      O => \result[17]_INST_0_i_1_n_0\
    );
\result[18]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[18]_INST_0_i_1_n_0\,
      I1 => result_18_sn_1,
      I2 => \result[18]_0\,
      I3 => \result[0]_0\,
      I4 => \result[17]_0\,
      I5 => \result[0]_2\,
      O => result(18)
    );
\result[18]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(18),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(18),
      I5 => b(18),
      O => \result[18]_INST_0_i_1_n_0\
    );
\result[19]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[19]_INST_0_i_1_n_0\,
      I1 => result_19_sn_1,
      I2 => \result[19]_0\,
      I3 => \result[0]_0\,
      I4 => \result[18]_0\,
      I5 => \result[0]_2\,
      O => result(19)
    );
\result[19]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(19),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(19),
      I5 => b(19),
      O => \result[19]_INST_0_i_1_n_0\
    );
\result[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => result_1_sn_1,
      I1 => \result[0]_0\,
      I2 => result_0_sn_1,
      I3 => \result[0]_2\,
      I4 => \result[1]_INST_0_i_2_n_0\,
      I5 => \result[1]_0\,
      O => result(1)
    );
\result[1]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF888F888F888"
    )
        port map (
      I0 => \result[2]_2\,
      I1 => \sum__93\(1),
      I2 => \result[1]_1\,
      I3 => \result[31]_0\,
      I4 => a(1),
      I5 => \result[1]_2\,
      O => \result[1]_INST_0_i_2_n_0\
    );
\result[20]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[20]_INST_0_i_1_n_0\,
      I1 => result_20_sn_1,
      I2 => \result[20]_0\,
      I3 => \result[0]_0\,
      I4 => \result[19]_0\,
      I5 => \result[0]_2\,
      O => result(20)
    );
\result[20]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(20),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(20),
      I5 => b(20),
      O => \result[20]_INST_0_i_1_n_0\
    );
\result[21]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[21]_INST_0_i_1_n_0\,
      I1 => result_21_sn_1,
      I2 => \result[21]_0\,
      I3 => \result[0]_0\,
      I4 => \result[20]_0\,
      I5 => \result[0]_2\,
      O => result(21)
    );
\result[21]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(21),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(21),
      I5 => b(21),
      O => \result[21]_INST_0_i_1_n_0\
    );
\result[22]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[22]_INST_0_i_1_n_0\,
      I1 => result_22_sn_1,
      I2 => \result[22]_0\,
      I3 => \result[0]_0\,
      I4 => \result[21]_0\,
      I5 => \result[0]_2\,
      O => result(22)
    );
\result[22]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(22),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(22),
      I5 => b(22),
      O => \result[22]_INST_0_i_1_n_0\
    );
\result[23]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[23]_INST_0_i_1_n_0\,
      I1 => result_23_sn_1,
      I2 => \result[23]_0\,
      I3 => \result[0]_0\,
      I4 => \result[22]_0\,
      I5 => \result[0]_2\,
      O => result(23)
    );
\result[23]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(23),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(23),
      I5 => b(23),
      O => \result[23]_INST_0_i_1_n_0\
    );
\result[24]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[24]_INST_0_i_1_n_0\,
      I1 => result_24_sn_1,
      I2 => \result[24]_0\,
      I3 => \result[0]_0\,
      I4 => \result[23]_0\,
      I5 => \result[0]_2\,
      O => result(24)
    );
\result[24]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(24),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(24),
      I5 => b(24),
      O => \result[24]_INST_0_i_1_n_0\
    );
\result[25]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[25]_INST_0_i_1_n_0\,
      I1 => result_25_sn_1,
      I2 => \result[25]_0\,
      I3 => \result[0]_0\,
      I4 => \result[24]_0\,
      I5 => \result[0]_2\,
      O => result(25)
    );
\result[25]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(25),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(25),
      I5 => b(25),
      O => \result[25]_INST_0_i_1_n_0\
    );
\result[26]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[26]_INST_0_i_1_n_0\,
      I1 => result_26_sn_1,
      I2 => \result[26]_0\,
      I3 => \result[0]_0\,
      I4 => \result[25]_0\,
      I5 => \result[0]_2\,
      O => result(26)
    );
\result[26]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(26),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(26),
      I5 => b(26),
      O => \result[26]_INST_0_i_1_n_0\
    );
\result[27]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \result[27]_INST_0_i_1_n_0\,
      I1 => result_27_sn_1,
      I2 => \result[27]_0\,
      I3 => \result[0]_0\,
      I4 => \result[26]_0\,
      I5 => \result[0]_2\,
      O => result(27)
    );
\result[27]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(27),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(27),
      I5 => b(27),
      O => \result[27]_INST_0_i_1_n_0\
    );
\result[28]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEAEAEA"
    )
        port map (
      I0 => \result[28]_INST_0_i_1_n_0\,
      I1 => result_28_sn_1,
      I2 => \result[31]_0\,
      I3 => \result[28]_0\,
      I4 => \result[31]_2\,
      I5 => \result[28]_1\,
      O => result(28)
    );
\result[28]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(28),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(28),
      I5 => b(28),
      O => \result[28]_INST_0_i_1_n_0\
    );
\result[29]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEAEAEA"
    )
        port map (
      I0 => \result[29]_INST_0_i_1_n_0\,
      I1 => \result[28]_0\,
      I2 => \result[31]_0\,
      I3 => result_29_sn_1,
      I4 => \result[31]_2\,
      I5 => \result[29]_0\,
      O => result(29)
    );
\result[29]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(29),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(29),
      I5 => b(29),
      O => \result[29]_INST_0_i_1_n_0\
    );
\result[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => result_2_sn_1,
      I1 => \result[0]_0\,
      I2 => result_1_sn_1,
      I3 => \result[0]_2\,
      I4 => \result[2]_INST_0_i_2_n_0\,
      I5 => \result[2]_0\,
      O => result(2)
    );
\result[2]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFEAEAEA"
    )
        port map (
      I0 => \result[2]_1\,
      I1 => \result[2]_2\,
      I2 => \sum__93\(2),
      I3 => \result[31]_2\,
      I4 => \result[2]_3\,
      O => \result[2]_INST_0_i_2_n_0\
    );
\result[30]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEAEAEA"
    )
        port map (
      I0 => \result[30]_INST_0_i_1_n_0\,
      I1 => result_29_sn_1,
      I2 => \result[31]_0\,
      I3 => result_31_sn_1,
      I4 => \result[31]_2\,
      I5 => result_30_sn_1,
      O => result(30)
    );
\result[30]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0C200F200F20002"
    )
        port map (
      I0 => \sum__93\(30),
      I1 => alucontrol(1),
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => a(30),
      I5 => b(30),
      O => \result[30]_INST_0_i_1_n_0\
    );
\result[31]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFEAEAEA"
    )
        port map (
      I0 => \result[31]_INST_0_i_1_n_0\,
      I1 => result_31_sn_1,
      I2 => \result[31]_0\,
      I3 => \result[31]_1\,
      I4 => \result[31]_2\,
      I5 => \result[31]_3\,
      O => result(31)
    );
\result[31]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C0000000FC3C00AA"
    )
        port map (
      I0 => \sum__93\(31),
      I1 => a(31),
      I2 => b(31),
      I3 => alucontrol(1),
      I4 => alucontrol(2),
      I5 => alucontrol(0),
      O => \result[31]_INST_0_i_1_n_0\
    );
\result[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => result_3_sn_1,
      I1 => \result[0]_0\,
      I2 => result_2_sn_1,
      I3 => \result[0]_2\,
      I4 => \result[3]_INST_0_i_2_n_0\,
      I5 => \result[3]_0\,
      O => result(3)
    );
\result[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF8F888888"
    )
        port map (
      I0 => \result[31]_0\,
      I1 => \result[2]_3\,
      I2 => a(3),
      I3 => b(3),
      I4 => \result[3]_1\,
      I5 => \result[3]_INST_0_i_6_n_0\,
      O => \result[3]_INST_0_i_2_n_0\
    );
\result[3]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000002200F0"
    )
        port map (
      I0 => \result[4]_INST_0_i_3_0\,
      I1 => b(0),
      I2 => \sum__93\(3),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => alucontrol(1),
      O => \result[3]_INST_0_i_6_n_0\
    );
\result[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => result_4_sn_1,
      I1 => \result[0]_0\,
      I2 => result_3_sn_1,
      I3 => \result[0]_2\,
      I4 => \result[4]_INST_0_i_3_n_0\,
      I5 => \result[4]_0\,
      O => result(4)
    );
\result[4]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000008800F0"
    )
        port map (
      I0 => \result[4]_INST_0_i_3_0\,
      I1 => b(0),
      I2 => \sum__93\(4),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => alucontrol(1),
      O => \result[4]_INST_0_i_13_n_0\
    );
\result[4]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF8C000400"
    )
        port map (
      I0 => b(4),
      I1 => a(4),
      I2 => alucontrol(0),
      I3 => alucontrol(2),
      I4 => alucontrol(1),
      I5 => \result[4]_INST_0_i_13_n_0\,
      O => \result[4]_INST_0_i_3_n_0\
    );
\result[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_5_sn_1,
      I1 => \result[5]_INST_0_i_2_n_0\,
      I2 => \result[5]_0\,
      I3 => b(5),
      I4 => a(5),
      I5 => \result[5]_1\,
      O => result(5)
    );
\result[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(5),
      I4 => a(5),
      I5 => b(5),
      O => \result[5]_INST_0_i_2_n_0\
    );
\result[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_6_sn_1,
      I1 => \result[6]_INST_0_i_2_n_0\,
      I2 => \result[6]_0\,
      I3 => b(6),
      I4 => a(6),
      I5 => \result[5]_1\,
      O => result(6)
    );
\result[6]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(6),
      I4 => a(6),
      I5 => b(6),
      O => \result[6]_INST_0_i_2_n_0\
    );
\result[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_7_sn_1,
      I1 => \result[7]_INST_0_i_2_n_0\,
      I2 => \result[7]_0\,
      I3 => b(7),
      I4 => a(7),
      I5 => \result[5]_1\,
      O => result(7)
    );
\result[7]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(7),
      I4 => a(7),
      I5 => b(7),
      O => \result[7]_INST_0_i_2_n_0\
    );
\result[8]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_8_sn_1,
      I1 => \result[8]_INST_0_i_2_n_0\,
      I2 => \result[8]_0\,
      I3 => b(8),
      I4 => a(8),
      I5 => \result[5]_1\,
      O => result(8)
    );
\result[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(8),
      I4 => a(8),
      I5 => b(8),
      O => \result[8]_INST_0_i_2_n_0\
    );
\result[9]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFEFEFEFE"
    )
        port map (
      I0 => result_9_sn_1,
      I1 => \result[9]_INST_0_i_2_n_0\,
      I2 => \result[9]_0\,
      I3 => b(9),
      I4 => a(9),
      I5 => \result[5]_1\,
      O => result(9)
    );
\result[9]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A1A0313031300100"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(0),
      I2 => alucontrol(2),
      I3 => \sum__93\(9),
      I4 => a(9),
      I5 => b(9),
      O => \result[9]_INST_0_i_2_n_0\
    );
sum_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => sum_carry_n_0,
      CO(2) => sum_carry_n_1,
      CO(1) => sum_carry_n_2,
      CO(0) => sum_carry_n_3,
      CYINIT => \sum_carry_i_1__6_n_0\,
      DI(3 downto 0) => a(3 downto 0),
      O(3 downto 0) => \sum__93\(3 downto 0),
      S(3) => sum_carry_i_2_n_0,
      S(2) => sum_carry_i_3_n_0,
      S(1) => sum_carry_i_4_n_0,
      S(0) => sum_carry_i_5_n_0
    );
\sum_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => sum_carry_n_0,
      CO(3) => \sum_carry__0_n_0\,
      CO(2) => \sum_carry__0_n_1\,
      CO(1) => \sum_carry__0_n_2\,
      CO(0) => \sum_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(7 downto 4),
      O(3 downto 0) => \sum__93\(7 downto 4),
      S(3) => \sum_carry_i_1__0_n_0\,
      S(2) => \sum_carry_i_2__0_n_0\,
      S(1) => \sum_carry_i_3__0_n_0\,
      S(0) => \sum_carry_i_4__0_n_0\
    );
\sum_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__0_n_0\,
      CO(3) => \sum_carry__1_n_0\,
      CO(2) => \sum_carry__1_n_1\,
      CO(1) => \sum_carry__1_n_2\,
      CO(0) => \sum_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(11 downto 8),
      O(3 downto 0) => \sum__93\(11 downto 8),
      S(3) => \sum_carry_i_1__1_n_0\,
      S(2) => \sum_carry_i_2__1_n_0\,
      S(1) => \sum_carry_i_3__1_n_0\,
      S(0) => \sum_carry_i_4__1_n_0\
    );
\sum_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__1_n_0\,
      CO(3) => \sum_carry__2_n_0\,
      CO(2) => \sum_carry__2_n_1\,
      CO(1) => \sum_carry__2_n_2\,
      CO(0) => \sum_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(15 downto 12),
      O(3 downto 0) => \sum__93\(15 downto 12),
      S(3) => \sum_carry_i_1__2_n_0\,
      S(2) => \sum_carry_i_2__2_n_0\,
      S(1) => \sum_carry_i_3__2_n_0\,
      S(0) => \sum_carry_i_4__2_n_0\
    );
\sum_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__2_n_0\,
      CO(3) => \sum_carry__3_n_0\,
      CO(2) => \sum_carry__3_n_1\,
      CO(1) => \sum_carry__3_n_2\,
      CO(0) => \sum_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(19 downto 16),
      O(3 downto 0) => \sum__93\(19 downto 16),
      S(3) => \sum_carry_i_1__3_n_0\,
      S(2) => \sum_carry_i_2__3_n_0\,
      S(1) => \sum_carry_i_3__3_n_0\,
      S(0) => \sum_carry_i_4__3_n_0\
    );
\sum_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__3_n_0\,
      CO(3) => \sum_carry__4_n_0\,
      CO(2) => \sum_carry__4_n_1\,
      CO(1) => \sum_carry__4_n_2\,
      CO(0) => \sum_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(23 downto 20),
      O(3 downto 0) => \sum__93\(23 downto 20),
      S(3) => \sum_carry_i_1__4_n_0\,
      S(2) => \sum_carry_i_2__4_n_0\,
      S(1) => \sum_carry_i_3__4_n_0\,
      S(0) => \sum_carry_i_4__4_n_0\
    );
\sum_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__4_n_0\,
      CO(3) => \sum_carry__5_n_0\,
      CO(2) => \sum_carry__5_n_1\,
      CO(1) => \sum_carry__5_n_2\,
      CO(0) => \sum_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => a(27 downto 24),
      O(3 downto 0) => \sum__93\(27 downto 24),
      S(3) => \sum_carry_i_1__5_n_0\,
      S(2) => \sum_carry_i_2__5_n_0\,
      S(1) => \sum_carry_i_3__5_n_0\,
      S(0) => \sum_carry_i_4__5_n_0\
    );
\sum_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_carry__5_n_0\,
      CO(3) => \NLW_sum_carry__6_CO_UNCONNECTED\(3),
      CO(2) => \sum_carry__6_n_1\,
      CO(1) => \sum_carry__6_n_2\,
      CO(0) => \sum_carry__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2 downto 0) => a(30 downto 28),
      O(3 downto 0) => \sum__93\(31 downto 28),
      S(3) => sum_carry_i_1_n_0,
      S(2) => \sum_carry_i_2__6_n_0\,
      S(1) => \sum_carry_i_3__6_n_0\,
      S(0) => \sum_carry_i_4__6_n_0\
    );
sum_carry_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => b(31),
      I1 => a(31),
      I2 => alucontrol(3),
      O => sum_carry_i_1_n_0
    );
\sum_carry_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(7),
      I1 => b(7),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__0_n_0\
    );
\sum_carry_i_1__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(11),
      I1 => b(11),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__1_n_0\
    );
\sum_carry_i_1__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(15),
      I1 => b(15),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__2_n_0\
    );
\sum_carry_i_1__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(19),
      I1 => b(19),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__3_n_0\
    );
\sum_carry_i_1__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(23),
      I1 => b(23),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__4_n_0\
    );
\sum_carry_i_1__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(27),
      I1 => b(27),
      I2 => alucontrol(3),
      O => \sum_carry_i_1__5_n_0\
    );
\sum_carry_i_1__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => alucontrol(3),
      I1 => b(0),
      O => \sum_carry_i_1__6_n_0\
    );
sum_carry_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(3),
      I1 => b(3),
      I2 => alucontrol(3),
      O => sum_carry_i_2_n_0
    );
\sum_carry_i_2__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(6),
      I1 => b(6),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__0_n_0\
    );
\sum_carry_i_2__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(10),
      I1 => b(10),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__1_n_0\
    );
\sum_carry_i_2__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(14),
      I1 => b(14),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__2_n_0\
    );
\sum_carry_i_2__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(18),
      I1 => b(18),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__3_n_0\
    );
\sum_carry_i_2__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(22),
      I1 => b(22),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__4_n_0\
    );
\sum_carry_i_2__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(26),
      I1 => b(26),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__5_n_0\
    );
\sum_carry_i_2__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(30),
      I1 => b(30),
      I2 => alucontrol(3),
      O => \sum_carry_i_2__6_n_0\
    );
sum_carry_i_3: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(2),
      I1 => b(2),
      I2 => alucontrol(3),
      O => sum_carry_i_3_n_0
    );
\sum_carry_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(5),
      I1 => b(5),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__0_n_0\
    );
\sum_carry_i_3__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(9),
      I1 => b(9),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__1_n_0\
    );
\sum_carry_i_3__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(13),
      I1 => b(13),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__2_n_0\
    );
\sum_carry_i_3__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(17),
      I1 => b(17),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__3_n_0\
    );
\sum_carry_i_3__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(21),
      I1 => b(21),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__4_n_0\
    );
\sum_carry_i_3__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(25),
      I1 => b(25),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__5_n_0\
    );
\sum_carry_i_3__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(29),
      I1 => b(29),
      I2 => alucontrol(3),
      O => \sum_carry_i_3__6_n_0\
    );
sum_carry_i_4: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(1),
      I1 => b(1),
      I2 => alucontrol(3),
      O => sum_carry_i_4_n_0
    );
\sum_carry_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(4),
      I1 => b(4),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__0_n_0\
    );
\sum_carry_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(8),
      I1 => b(8),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__1_n_0\
    );
\sum_carry_i_4__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(12),
      I1 => b(12),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__2_n_0\
    );
\sum_carry_i_4__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(16),
      I1 => b(16),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__3_n_0\
    );
\sum_carry_i_4__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(20),
      I1 => b(20),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__4_n_0\
    );
\sum_carry_i_4__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(24),
      I1 => b(24),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__5_n_0\
    );
\sum_carry_i_4__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => a(28),
      I1 => b(28),
      I2 => alucontrol(3),
      O => \sum_carry_i_4__6_n_0\
    );
sum_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => a(0),
      I1 => alucontrol(3),
      O => sum_carry_i_5_n_0
    );
zero_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => zero_INST_0_i_1_n_0,
      I1 => zero_INST_0_i_2_n_0,
      I2 => zero_INST_0_i_3_n_0,
      I3 => zero_INST_0_i_4_n_0,
      O => zero
    );
zero_INST_0_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \sum__93\(12),
      I1 => \sum__93\(13),
      I2 => \sum__93\(14),
      I3 => \sum__93\(15),
      I4 => zero_INST_0_i_5_n_0,
      O => zero_INST_0_i_1_n_0
    );
zero_INST_0_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \sum__93\(2),
      I1 => \sum__93\(3),
      I2 => \sum__93\(0),
      I3 => \sum__93\(1),
      I4 => zero_INST_0_i_6_n_0,
      O => zero_INST_0_i_2_n_0
    );
zero_INST_0_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \sum__93\(28),
      I1 => \sum__93\(29),
      I2 => \sum__93\(30),
      I3 => \sum__93\(31),
      I4 => zero_INST_0_i_7_n_0,
      O => zero_INST_0_i_3_n_0
    );
zero_INST_0_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \sum__93\(18),
      I1 => \sum__93\(19),
      I2 => \sum__93\(16),
      I3 => \sum__93\(17),
      I4 => zero_INST_0_i_8_n_0,
      O => zero_INST_0_i_4_n_0
    );
zero_INST_0_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \sum__93\(11),
      I1 => \sum__93\(10),
      I2 => \sum__93\(9),
      I3 => \sum__93\(8),
      O => zero_INST_0_i_5_n_0
    );
zero_INST_0_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \sum__93\(7),
      I1 => \sum__93\(6),
      I2 => \sum__93\(5),
      I3 => \sum__93\(4),
      O => zero_INST_0_i_6_n_0
    );
zero_INST_0_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \sum__93\(27),
      I1 => \sum__93\(26),
      I2 => \sum__93\(25),
      I3 => \sum__93\(24),
      O => zero_INST_0_i_7_n_0
    );
zero_INST_0_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \sum__93\(23),
      I1 => \sum__93\(22),
      I2 => \sum__93\(21),
      I3 => \sum__93\(20),
      O => zero_INST_0_i_8_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    a : in STD_LOGIC_VECTOR ( 31 downto 0 );
    b : in STD_LOGIC_VECTOR ( 31 downto 0 );
    alucontrol : in STD_LOGIC_VECTOR ( 3 downto 0 );
    result : out STD_LOGIC_VECTOR ( 31 downto 0 );
    zero : out STD_LOGIC;
    lessthan : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "singleriscv_bd_alu_0_0,alu,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "alu,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \result[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[0]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[10]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[11]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[12]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[13]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[14]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[15]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[16]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[17]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[18]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[19]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[1]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[20]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[21]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[22]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[23]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[24]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[25]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[26]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \result[27]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \result[28]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[28]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[28]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[28]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[29]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[29]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[29]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[29]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[2]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[30]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_17_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_18_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \result[31]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[3]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \result[4]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \result[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[5]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[5]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[6]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[6]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[6]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[7]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[8]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \result[9]_INST_0_i_6_n_0\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \result[13]_INST_0_i_7\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \result[14]_INST_0_i_7\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \result[15]_INST_0_i_4\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \result[15]_INST_0_i_8\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \result[16]_INST_0_i_6\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \result[17]_INST_0_i_6\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \result[18]_INST_0_i_6\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \result[19]_INST_0_i_6\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \result[1]_INST_0_i_3\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \result[20]_INST_0_i_6\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \result[21]_INST_0_i_6\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \result[22]_INST_0_i_6\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \result[23]_INST_0_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \result[24]_INST_0_i_6\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \result[25]_INST_0_i_6\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \result[26]_INST_0_i_6\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \result[26]_INST_0_i_7\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \result[27]_INST_0_i_10\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \result[27]_INST_0_i_4\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \result[27]_INST_0_i_6\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \result[27]_INST_0_i_9\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \result[28]_INST_0_i_4\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \result[29]_INST_0_i_4\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \result[2]_INST_0_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \result[2]_INST_0_i_3\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \result[2]_INST_0_i_6\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \result[2]_INST_0_i_8\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \result[30]_INST_0_i_4\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \result[30]_INST_0_i_5\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \result[30]_INST_0_i_6\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \result[30]_INST_0_i_7\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \result[31]_INST_0_i_15\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \result[31]_INST_0_i_16\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \result[31]_INST_0_i_3\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \result[31]_INST_0_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \result[3]_INST_0_i_3\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \result[4]_INST_0_i_14\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \result[4]_INST_0_i_15\ : label is "soft_lutpair10";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_alu
     port map (
      a(31 downto 0) => a(31 downto 0),
      alucontrol(3 downto 0) => alucontrol(3 downto 0),
      b(31 downto 0) => b(31 downto 0),
      lessthan => lessthan,
      result(31 downto 0) => result(31 downto 0),
      \result[0]_0\ => \result[27]_INST_0_i_4_n_0\,
      \result[0]_1\ => \result[0]_INST_0_i_1_n_0\,
      \result[0]_2\ => \result[27]_INST_0_i_6_n_0\,
      \result[10]_0\ => \result[10]_INST_0_i_3_n_0\,
      \result[11]_0\ => \result[11]_INST_0_i_3_n_0\,
      \result[12]_0\ => \result[12]_INST_0_i_3_n_0\,
      \result[13]_0\ => \result[13]_INST_0_i_3_n_0\,
      \result[14]_0\ => \result[14]_INST_0_i_3_n_0\,
      \result[15]_0\ => \result[15]_INST_0_i_3_n_0\,
      \result[16]_0\ => \result[17]_INST_0_i_3_n_0\,
      \result[16]_1\ => \result[16]_INST_0_i_3_n_0\,
      \result[17]_0\ => \result[18]_INST_0_i_3_n_0\,
      \result[18]_0\ => \result[19]_INST_0_i_3_n_0\,
      \result[19]_0\ => \result[20]_INST_0_i_3_n_0\,
      \result[1]_0\ => \result[1]_INST_0_i_3_n_0\,
      \result[1]_1\ => \result[1]_INST_0_i_6_n_0\,
      \result[1]_2\ => \result[1]_INST_0_i_7_n_0\,
      \result[20]_0\ => \result[21]_INST_0_i_3_n_0\,
      \result[21]_0\ => \result[22]_INST_0_i_3_n_0\,
      \result[22]_0\ => \result[23]_INST_0_i_3_n_0\,
      \result[23]_0\ => \result[24]_INST_0_i_3_n_0\,
      \result[24]_0\ => \result[25]_INST_0_i_3_n_0\,
      \result[25]_0\ => \result[26]_INST_0_i_3_n_0\,
      \result[26]_0\ => \result[27]_INST_0_i_5_n_0\,
      \result[27]_0\ => \result[27]_INST_0_i_3_n_0\,
      \result[28]_0\ => \result[29]_INST_0_i_2_n_0\,
      \result[28]_1\ => \result[28]_INST_0_i_3_n_0\,
      \result[29]_0\ => \result[29]_INST_0_i_3_n_0\,
      \result[2]_0\ => \result[2]_INST_0_i_3_n_0\,
      \result[2]_1\ => \result[2]_INST_0_i_5_n_0\,
      \result[2]_2\ => \result[2]_INST_0_i_6_n_0\,
      \result[2]_3\ => \result[3]_INST_0_i_5_n_0\,
      \result[31]_0\ => \result[31]_INST_0_i_3_n_0\,
      \result[31]_1\ => \result[31]_INST_0_i_4_n_0\,
      \result[31]_2\ => \result[31]_INST_0_i_5_n_0\,
      \result[31]_3\ => \result[31]_INST_0_i_6_n_0\,
      \result[3]_0\ => \result[3]_INST_0_i_3_n_0\,
      \result[3]_1\ => \result[4]_INST_0_i_14_n_0\,
      \result[4]_0\ => \result[4]_INST_0_i_4_n_0\,
      \result[4]_INST_0_i_3_0\ => \result[4]_INST_0_i_16_n_0\,
      \result[5]_0\ => \result[5]_INST_0_i_3_n_0\,
      \result[5]_1\ => \result[15]_INST_0_i_4_n_0\,
      \result[6]_0\ => \result[6]_INST_0_i_3_n_0\,
      \result[7]_0\ => \result[7]_INST_0_i_3_n_0\,
      \result[8]_0\ => \result[8]_INST_0_i_3_n_0\,
      \result[9]_0\ => \result[9]_INST_0_i_3_n_0\,
      result_0_sp_1 => \result[1]_INST_0_i_1_n_0\,
      result_10_sp_1 => \result[10]_INST_0_i_1_n_0\,
      result_11_sp_1 => \result[11]_INST_0_i_1_n_0\,
      result_12_sp_1 => \result[12]_INST_0_i_1_n_0\,
      result_13_sp_1 => \result[13]_INST_0_i_1_n_0\,
      result_14_sp_1 => \result[14]_INST_0_i_1_n_0\,
      result_15_sp_1 => \result[15]_INST_0_i_1_n_0\,
      result_16_sp_1 => \result[16]_INST_0_i_2_n_0\,
      result_17_sp_1 => \result[17]_INST_0_i_2_n_0\,
      result_18_sp_1 => \result[18]_INST_0_i_2_n_0\,
      result_19_sp_1 => \result[19]_INST_0_i_2_n_0\,
      result_1_sp_1 => \result[2]_INST_0_i_1_n_0\,
      result_20_sp_1 => \result[20]_INST_0_i_2_n_0\,
      result_21_sp_1 => \result[21]_INST_0_i_2_n_0\,
      result_22_sp_1 => \result[22]_INST_0_i_2_n_0\,
      result_23_sp_1 => \result[23]_INST_0_i_2_n_0\,
      result_24_sp_1 => \result[24]_INST_0_i_2_n_0\,
      result_25_sp_1 => \result[25]_INST_0_i_2_n_0\,
      result_26_sp_1 => \result[26]_INST_0_i_2_n_0\,
      result_27_sp_1 => \result[27]_INST_0_i_2_n_0\,
      result_28_sp_1 => \result[28]_INST_0_i_2_n_0\,
      result_29_sp_1 => \result[30]_INST_0_i_2_n_0\,
      result_2_sp_1 => \result[3]_INST_0_i_1_n_0\,
      result_30_sp_1 => \result[30]_INST_0_i_3_n_0\,
      result_31_sp_1 => \result[31]_INST_0_i_2_n_0\,
      result_3_sp_1 => \result[4]_INST_0_i_2_n_0\,
      result_4_sp_1 => \result[4]_INST_0_i_1_n_0\,
      result_5_sp_1 => \result[5]_INST_0_i_1_n_0\,
      result_6_sp_1 => \result[6]_INST_0_i_1_n_0\,
      result_7_sp_1 => \result[7]_INST_0_i_1_n_0\,
      result_8_sp_1 => \result[8]_INST_0_i_1_n_0\,
      result_9_sp_1 => \result[9]_INST_0_i_1_n_0\,
      zero => zero
    );
\result[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEFECECEC"
    )
        port map (
      I0 => \result[2]_INST_0_i_4_n_0\,
      I1 => \result[0]_INST_0_i_4_n_0\,
      I2 => b(1),
      I3 => b(2),
      I4 => \result[4]_INST_0_i_11_n_0\,
      I5 => \result[0]_INST_0_i_5_n_0\,
      O => \result[0]_INST_0_i_1_n_0\
    );
\result[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(24),
      I1 => a(16),
      I2 => b(3),
      I3 => b(4),
      I4 => b(2),
      I5 => b(1),
      O => \result[0]_INST_0_i_4_n_0\
    );
\result[0]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000A0000000C"
    )
        port map (
      I0 => a(8),
      I1 => a(0),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[0]_INST_0_i_5_n_0\
    );
\result[10]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[11]_INST_0_i_4_n_0\,
      I1 => \result[10]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[10]_INST_0_i_1_n_0\
    );
\result[10]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[10]_INST_0_i_5_n_0\,
      I1 => \result[11]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[10]_INST_0_i_3_n_0\
    );
\result[10]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[14]_INST_0_i_6_n_0\,
      I1 => \result[16]_INST_0_i_5_n_0\,
      I2 => \result[4]_INST_0_i_10_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[12]_INST_0_i_6_n_0\,
      O => \result[10]_INST_0_i_4_n_0\
    );
\result[10]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAEAFAEAAAEAAAE"
    )
        port map (
      I0 => \result[10]_INST_0_i_6_n_0\,
      I1 => \result[16]_INST_0_i_6_n_0\,
      I2 => b(2),
      I3 => b(1),
      I4 => \result[31]_INST_0_i_16_n_0\,
      I5 => a(7),
      O => \result[10]_INST_0_i_5_n_0\
    );
\result[10]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(3),
      I1 => a(5),
      I2 => b(1),
      I3 => b(2),
      I4 => b(4),
      I5 => b(3),
      O => \result[10]_INST_0_i_6_n_0\
    );
\result[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[12]_INST_0_i_4_n_0\,
      I1 => \result[11]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[11]_INST_0_i_1_n_0\
    );
\result[11]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[11]_INST_0_i_5_n_0\,
      I1 => \result[12]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[11]_INST_0_i_3_n_0\
    );
\result[11]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[15]_INST_0_i_7_n_0\,
      I1 => \result[17]_INST_0_i_5_n_0\,
      I2 => \result[4]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[13]_INST_0_i_6_n_0\,
      O => \result[11]_INST_0_i_4_n_0\
    );
\result[11]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFAEAAAE"
    )
        port map (
      I0 => \result[11]_INST_0_i_6_n_0\,
      I1 => \result[17]_INST_0_i_6_n_0\,
      I2 => b(2),
      I3 => b(1),
      I4 => \result[15]_INST_0_i_8_n_0\,
      O => \result[11]_INST_0_i_5_n_0\
    );
\result[11]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(4),
      I1 => a(6),
      I2 => b(1),
      I3 => b(2),
      I4 => b(4),
      I5 => b(3),
      O => \result[11]_INST_0_i_6_n_0\
    );
\result[12]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[13]_INST_0_i_4_n_0\,
      I1 => \result[12]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[12]_INST_0_i_1_n_0\
    );
\result[12]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[12]_INST_0_i_5_n_0\,
      I1 => \result[13]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[12]_INST_0_i_3_n_0\
    );
\result[12]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[16]_INST_0_i_5_n_0\,
      I1 => \result[18]_INST_0_i_5_n_0\,
      I2 => \result[12]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[14]_INST_0_i_6_n_0\,
      O => \result[12]_INST_0_i_4_n_0\
    );
\result[12]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFAEAAAE"
    )
        port map (
      I0 => \result[12]_INST_0_i_7_n_0\,
      I1 => \result[18]_INST_0_i_6_n_0\,
      I2 => b(2),
      I3 => b(1),
      I4 => \result[16]_INST_0_i_6_n_0\,
      O => \result[12]_INST_0_i_5_n_0\
    );
\result[12]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(20),
      I1 => a(28),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(12),
      I4 => b(4),
      I5 => b(3),
      O => \result[12]_INST_0_i_6_n_0\
    );
\result[12]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(5),
      I1 => a(7),
      I2 => b(1),
      I3 => b(2),
      I4 => b(4),
      I5 => b(3),
      O => \result[12]_INST_0_i_7_n_0\
    );
\result[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[14]_INST_0_i_4_n_0\,
      I1 => \result[13]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[13]_INST_0_i_1_n_0\
    );
\result[13]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[13]_INST_0_i_5_n_0\,
      I1 => \result[14]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[13]_INST_0_i_3_n_0\
    );
\result[13]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[17]_INST_0_i_5_n_0\,
      I1 => \result[19]_INST_0_i_5_n_0\,
      I2 => \result[13]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[15]_INST_0_i_7_n_0\,
      O => \result[13]_INST_0_i_4_n_0\
    );
\result[13]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFEEFCCCCCEEFC"
    )
        port map (
      I0 => \result[15]_INST_0_i_8_n_0\,
      I1 => \result[13]_INST_0_i_7_n_0\,
      I2 => \result[19]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[17]_INST_0_i_6_n_0\,
      O => \result[13]_INST_0_i_5_n_0\
    );
\result[13]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(21),
      I1 => a(29),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(13),
      I4 => b(4),
      I5 => b(3),
      O => \result[13]_INST_0_i_6_n_0\
    );
\result[13]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10000000"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => b(1),
      I3 => b(2),
      I4 => a(6),
      O => \result[13]_INST_0_i_7_n_0\
    );
\result[14]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[15]_INST_0_i_5_n_0\,
      I1 => \result[14]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[14]_INST_0_i_1_n_0\
    );
\result[14]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[14]_INST_0_i_5_n_0\,
      I1 => \result[15]_INST_0_i_6_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[14]_INST_0_i_3_n_0\
    );
\result[14]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[18]_INST_0_i_5_n_0\,
      I1 => \result[20]_INST_0_i_5_n_0\,
      I2 => \result[14]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[16]_INST_0_i_5_n_0\,
      O => \result[14]_INST_0_i_4_n_0\
    );
\result[14]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFEEFCCCCCEEFC"
    )
        port map (
      I0 => \result[16]_INST_0_i_6_n_0\,
      I1 => \result[14]_INST_0_i_7_n_0\,
      I2 => \result[20]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[18]_INST_0_i_6_n_0\,
      O => \result[14]_INST_0_i_5_n_0\
    );
\result[14]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(22),
      I1 => a(30),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(14),
      I4 => b(4),
      I5 => b(3),
      O => \result[14]_INST_0_i_6_n_0\
    );
\result[14]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10000000"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => b(1),
      I3 => b(2),
      I4 => a(7),
      O => \result[14]_INST_0_i_7_n_0\
    );
\result[15]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[16]_INST_0_i_3_n_0\,
      I1 => \result[15]_INST_0_i_5_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[15]_INST_0_i_1_n_0\
    );
\result[15]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[15]_INST_0_i_6_n_0\,
      I1 => \result[16]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[15]_INST_0_i_3_n_0\
    );
\result[15]_INST_0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => alucontrol(0),
      I1 => alucontrol(2),
      I2 => alucontrol(1),
      O => \result[15]_INST_0_i_4_n_0\
    );
\result[15]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[19]_INST_0_i_5_n_0\,
      I1 => \result[21]_INST_0_i_5_n_0\,
      I2 => \result[15]_INST_0_i_7_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[17]_INST_0_i_5_n_0\,
      O => \result[15]_INST_0_i_5_n_0\
    );
\result[15]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[17]_INST_0_i_6_n_0\,
      I1 => \result[15]_INST_0_i_8_n_0\,
      I2 => \result[21]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[19]_INST_0_i_6_n_0\,
      O => \result[15]_INST_0_i_6_n_0\
    );
\result[15]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EF232F23EC202C20"
    )
        port map (
      I0 => a(23),
      I1 => b(4),
      I2 => b(3),
      I3 => a(31),
      I4 => b(30),
      I5 => a(15),
      O => \result[15]_INST_0_i_7_n_0\
    );
\result[15]_INST_0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(0),
      I1 => b(3),
      I2 => b(4),
      I3 => a(8),
      O => \result[15]_INST_0_i_8_n_0\
    );
\result[16]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[16]_INST_0_i_4_n_0\,
      I1 => \result[17]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[16]_INST_0_i_2_n_0\
    );
\result[16]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[20]_INST_0_i_5_n_0\,
      I1 => \result[22]_INST_0_i_5_n_0\,
      I2 => \result[16]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[18]_INST_0_i_5_n_0\,
      O => \result[16]_INST_0_i_3_n_0\
    );
\result[16]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[18]_INST_0_i_6_n_0\,
      I1 => \result[16]_INST_0_i_6_n_0\,
      I2 => \result[22]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[20]_INST_0_i_6_n_0\,
      O => \result[16]_INST_0_i_4_n_0\
    );
\result[16]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(16),
      I3 => a(24),
      I4 => b(3),
      I5 => b(4),
      O => \result[16]_INST_0_i_5_n_0\
    );
\result[16]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(1),
      I1 => b(3),
      I2 => b(4),
      I3 => a(9),
      O => \result[16]_INST_0_i_6_n_0\
    );
\result[17]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[17]_INST_0_i_4_n_0\,
      I1 => \result[18]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[17]_INST_0_i_2_n_0\
    );
\result[17]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[21]_INST_0_i_5_n_0\,
      I1 => \result[23]_INST_0_i_5_n_0\,
      I2 => \result[17]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[19]_INST_0_i_5_n_0\,
      O => \result[17]_INST_0_i_3_n_0\
    );
\result[17]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[19]_INST_0_i_6_n_0\,
      I1 => \result[17]_INST_0_i_6_n_0\,
      I2 => \result[23]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[21]_INST_0_i_6_n_0\,
      O => \result[17]_INST_0_i_4_n_0\
    );
\result[17]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(17),
      I3 => a(25),
      I4 => b(3),
      I5 => b(4),
      O => \result[17]_INST_0_i_5_n_0\
    );
\result[17]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(2),
      I1 => b(3),
      I2 => b(4),
      I3 => a(10),
      O => \result[17]_INST_0_i_6_n_0\
    );
\result[18]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[18]_INST_0_i_4_n_0\,
      I1 => \result[19]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[18]_INST_0_i_2_n_0\
    );
\result[18]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[22]_INST_0_i_5_n_0\,
      I1 => \result[24]_INST_0_i_5_n_0\,
      I2 => \result[18]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[20]_INST_0_i_5_n_0\,
      O => \result[18]_INST_0_i_3_n_0\
    );
\result[18]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[20]_INST_0_i_6_n_0\,
      I1 => \result[18]_INST_0_i_6_n_0\,
      I2 => \result[24]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[22]_INST_0_i_6_n_0\,
      O => \result[18]_INST_0_i_4_n_0\
    );
\result[18]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(18),
      I3 => a(26),
      I4 => b(3),
      I5 => b(4),
      O => \result[18]_INST_0_i_5_n_0\
    );
\result[18]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(3),
      I1 => b(3),
      I2 => b(4),
      I3 => a(11),
      O => \result[18]_INST_0_i_6_n_0\
    );
\result[19]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[19]_INST_0_i_4_n_0\,
      I1 => \result[20]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[19]_INST_0_i_2_n_0\
    );
\result[19]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[23]_INST_0_i_5_n_0\,
      I1 => \result[25]_INST_0_i_5_n_0\,
      I2 => \result[19]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[21]_INST_0_i_5_n_0\,
      O => \result[19]_INST_0_i_3_n_0\
    );
\result[19]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[21]_INST_0_i_6_n_0\,
      I1 => \result[19]_INST_0_i_6_n_0\,
      I2 => \result[25]_INST_0_i_6_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[23]_INST_0_i_6_n_0\,
      O => \result[19]_INST_0_i_4_n_0\
    );
\result[19]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(19),
      I3 => a(27),
      I4 => b(3),
      I5 => b(4),
      O => \result[19]_INST_0_i_5_n_0\
    );
\result[19]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(4),
      I1 => b(3),
      I2 => b(4),
      I3 => a(12),
      O => \result[19]_INST_0_i_6_n_0\
    );
\result[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEFECECEC"
    )
        port map (
      I0 => \result[3]_INST_0_i_4_n_0\,
      I1 => \result[1]_INST_0_i_4_n_0\,
      I2 => b(1),
      I3 => b(2),
      I4 => \result[4]_INST_0_i_7_n_0\,
      I5 => \result[1]_INST_0_i_5_n_0\,
      O => \result[1]_INST_0_i_1_n_0\
    );
\result[1]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8E000600"
    )
        port map (
      I0 => a(1),
      I1 => b(1),
      I2 => alucontrol(0),
      I3 => alucontrol(2),
      I4 => alucontrol(1),
      O => \result[1]_INST_0_i_3_n_0\
    );
\result[1]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(25),
      I1 => a(17),
      I2 => b(3),
      I3 => b(4),
      I4 => b(2),
      I5 => b(1),
      O => \result[1]_INST_0_i_4_n_0\
    );
\result[1]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000A0000000C"
    )
        port map (
      I0 => a(9),
      I1 => a(1),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[1]_INST_0_i_5_n_0\
    );
\result[1]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => b(1),
      I3 => b(2),
      I4 => a(0),
      O => \result[1]_INST_0_i_6_n_0\
    );
\result[1]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00000002"
    )
        port map (
      I0 => \result[31]_INST_0_i_5_n_0\,
      I1 => b(2),
      I2 => b(1),
      I3 => b(4),
      I4 => b(3),
      I5 => \result[15]_INST_0_i_4_n_0\,
      O => \result[1]_INST_0_i_7_n_0\
    );
\result[20]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[20]_INST_0_i_4_n_0\,
      I1 => \result[21]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[20]_INST_0_i_2_n_0\
    );
\result[20]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[24]_INST_0_i_5_n_0\,
      I1 => \result[26]_INST_0_i_5_n_0\,
      I2 => \result[20]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[22]_INST_0_i_5_n_0\,
      O => \result[20]_INST_0_i_3_n_0\
    );
\result[20]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[22]_INST_0_i_6_n_0\,
      I1 => \result[20]_INST_0_i_6_n_0\,
      I2 => \result[26]_INST_0_i_7_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[24]_INST_0_i_6_n_0\,
      O => \result[20]_INST_0_i_4_n_0\
    );
\result[20]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(20),
      I3 => a(28),
      I4 => b(3),
      I5 => b(4),
      O => \result[20]_INST_0_i_5_n_0\
    );
\result[20]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(5),
      I1 => b(3),
      I2 => b(4),
      I3 => a(13),
      O => \result[20]_INST_0_i_6_n_0\
    );
\result[21]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[21]_INST_0_i_4_n_0\,
      I1 => \result[22]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[21]_INST_0_i_2_n_0\
    );
\result[21]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[25]_INST_0_i_5_n_0\,
      I1 => \result[27]_INST_0_i_8_n_0\,
      I2 => \result[21]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[23]_INST_0_i_5_n_0\,
      O => \result[21]_INST_0_i_3_n_0\
    );
\result[21]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[23]_INST_0_i_6_n_0\,
      I1 => \result[21]_INST_0_i_6_n_0\,
      I2 => \result[27]_INST_0_i_10_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[25]_INST_0_i_6_n_0\,
      O => \result[21]_INST_0_i_4_n_0\
    );
\result[21]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(21),
      I3 => a(29),
      I4 => b(3),
      I5 => b(4),
      O => \result[21]_INST_0_i_5_n_0\
    );
\result[21]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(6),
      I1 => b(3),
      I2 => b(4),
      I3 => a(14),
      O => \result[21]_INST_0_i_6_n_0\
    );
\result[22]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[22]_INST_0_i_4_n_0\,
      I1 => \result[23]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[22]_INST_0_i_2_n_0\
    );
\result[22]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[26]_INST_0_i_5_n_0\,
      I1 => \result[26]_INST_0_i_6_n_0\,
      I2 => \result[22]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[24]_INST_0_i_5_n_0\,
      O => \result[22]_INST_0_i_3_n_0\
    );
\result[22]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[24]_INST_0_i_6_n_0\,
      I1 => \result[22]_INST_0_i_6_n_0\,
      I2 => \result[28]_INST_0_i_4_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[26]_INST_0_i_7_n_0\,
      O => \result[22]_INST_0_i_4_n_0\
    );
\result[22]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888FF00F0F0"
    )
        port map (
      I0 => a(31),
      I1 => b(30),
      I2 => a(22),
      I3 => a(30),
      I4 => b(3),
      I5 => b(4),
      O => \result[22]_INST_0_i_5_n_0\
    );
\result[22]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B08"
    )
        port map (
      I0 => a(7),
      I1 => b(3),
      I2 => b(4),
      I3 => a(15),
      O => \result[22]_INST_0_i_6_n_0\
    );
\result[23]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[23]_INST_0_i_4_n_0\,
      I1 => \result[24]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[23]_INST_0_i_2_n_0\
    );
\result[23]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[27]_INST_0_i_8_n_0\,
      I1 => \result[27]_INST_0_i_9_n_0\,
      I2 => \result[23]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[25]_INST_0_i_5_n_0\,
      O => \result[23]_INST_0_i_3_n_0\
    );
\result[23]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[25]_INST_0_i_6_n_0\,
      I1 => \result[23]_INST_0_i_6_n_0\,
      I2 => \result[29]_INST_0_i_4_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[27]_INST_0_i_10_n_0\,
      O => \result[23]_INST_0_i_4_n_0\
    );
\result[23]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0F0CC"
    )
        port map (
      I0 => b(30),
      I1 => a(23),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[23]_INST_0_i_5_n_0\
    );
\result[23]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(16),
      I1 => a(8),
      I2 => a(0),
      I3 => b(4),
      I4 => b(3),
      O => \result[23]_INST_0_i_6_n_0\
    );
\result[24]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[24]_INST_0_i_4_n_0\,
      I1 => \result[25]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[24]_INST_0_i_2_n_0\
    );
\result[24]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[26]_INST_0_i_6_n_0\,
      I1 => \result[30]_INST_0_i_7_n_0\,
      I2 => \result[24]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[26]_INST_0_i_5_n_0\,
      O => \result[24]_INST_0_i_3_n_0\
    );
\result[24]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[26]_INST_0_i_7_n_0\,
      I1 => \result[24]_INST_0_i_6_n_0\,
      I2 => \result[30]_INST_0_i_4_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[28]_INST_0_i_4_n_0\,
      O => \result[24]_INST_0_i_4_n_0\
    );
\result[24]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(24),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[24]_INST_0_i_5_n_0\
    );
\result[24]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(17),
      I1 => a(9),
      I2 => a(1),
      I3 => b(4),
      I4 => b(3),
      O => \result[24]_INST_0_i_6_n_0\
    );
\result[25]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[25]_INST_0_i_4_n_0\,
      I1 => \result[26]_INST_0_i_4_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[25]_INST_0_i_2_n_0\
    );
\result[25]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[27]_INST_0_i_9_n_0\,
      I1 => \result[30]_INST_0_i_5_n_0\,
      I2 => \result[25]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[27]_INST_0_i_8_n_0\,
      O => \result[25]_INST_0_i_3_n_0\
    );
\result[25]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[27]_INST_0_i_10_n_0\,
      I1 => \result[25]_INST_0_i_6_n_0\,
      I2 => \result[27]_INST_0_i_11_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[29]_INST_0_i_4_n_0\,
      O => \result[25]_INST_0_i_4_n_0\
    );
\result[25]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(25),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[25]_INST_0_i_5_n_0\
    );
\result[25]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(18),
      I1 => a(10),
      I2 => a(2),
      I3 => b(4),
      I4 => b(3),
      O => \result[25]_INST_0_i_6_n_0\
    );
\result[26]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[26]_INST_0_i_4_n_0\,
      I1 => \result[27]_INST_0_i_7_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[26]_INST_0_i_2_n_0\
    );
\result[26]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[30]_INST_0_i_7_n_0\,
      I1 => \result[30]_INST_0_i_6_n_0\,
      I2 => \result[26]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[26]_INST_0_i_6_n_0\,
      O => \result[26]_INST_0_i_3_n_0\
    );
\result[26]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[28]_INST_0_i_4_n_0\,
      I1 => \result[26]_INST_0_i_7_n_0\,
      I2 => \result[28]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[30]_INST_0_i_4_n_0\,
      O => \result[26]_INST_0_i_4_n_0\
    );
\result[26]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(26),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[26]_INST_0_i_5_n_0\
    );
\result[26]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(28),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[26]_INST_0_i_6_n_0\
    );
\result[26]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(19),
      I1 => a(11),
      I2 => a(3),
      I3 => b(4),
      I4 => b(3),
      O => \result[26]_INST_0_i_7_n_0\
    );
\result[27]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(20),
      I1 => a(12),
      I2 => a(4),
      I3 => b(4),
      I4 => b(3),
      O => \result[27]_INST_0_i_10_n_0\
    );
\result[27]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(8),
      I1 => a(0),
      I2 => a(24),
      I3 => b(4),
      I4 => b(3),
      I5 => a(16),
      O => \result[27]_INST_0_i_11_n_0\
    );
\result[27]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[27]_INST_0_i_7_n_0\,
      I1 => \result[28]_INST_0_i_2_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[27]_INST_0_i_2_n_0\
    );
\result[27]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEAE00005404"
    )
        port map (
      I0 => \result[31]_INST_0_i_16_n_0\,
      I1 => a(28),
      I2 => b(1),
      I3 => a(30),
      I4 => b(2),
      I5 => \result[30]_INST_0_i_6_n_0\,
      O => \result[27]_INST_0_i_3_n_0\
    );
\result[27]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => alucontrol(2),
      I1 => alucontrol(0),
      I2 => alucontrol(1),
      I3 => b(0),
      O => \result[27]_INST_0_i_4_n_0\
    );
\result[27]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[30]_INST_0_i_5_n_0\,
      I1 => \result[30]_INST_0_i_6_n_0\,
      I2 => \result[27]_INST_0_i_8_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[27]_INST_0_i_9_n_0\,
      O => \result[27]_INST_0_i_5_n_0\
    );
\result[27]_INST_0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0008"
    )
        port map (
      I0 => alucontrol(2),
      I1 => alucontrol(0),
      I2 => alucontrol(1),
      I3 => b(0),
      O => \result[27]_INST_0_i_6_n_0\
    );
\result[27]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[29]_INST_0_i_4_n_0\,
      I1 => \result[27]_INST_0_i_10_n_0\,
      I2 => \result[31]_INST_0_i_9_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[27]_INST_0_i_11_n_0\,
      O => \result[27]_INST_0_i_7_n_0\
    );
\result[27]_INST_0_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(27),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[27]_INST_0_i_8_n_0\
    );
\result[27]_INST_0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(29),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[27]_INST_0_i_9_n_0\
    );
\result[28]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[30]_INST_0_i_4_n_0\,
      I1 => \result[28]_INST_0_i_4_n_0\,
      I2 => \result[31]_INST_0_i_13_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[28]_INST_0_i_5_n_0\,
      O => \result[28]_INST_0_i_2_n_0\
    );
\result[28]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[29]_INST_0_i_5_n_0\,
      I1 => \result[27]_INST_0_i_3_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[28]_INST_0_i_3_n_0\
    );
\result[28]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(21),
      I1 => a(13),
      I2 => a(5),
      I3 => b(4),
      I4 => b(3),
      O => \result[28]_INST_0_i_4_n_0\
    );
\result[28]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(9),
      I1 => a(1),
      I2 => a(25),
      I3 => b(4),
      I4 => b(3),
      I5 => a(17),
      O => \result[28]_INST_0_i_5_n_0\
    );
\result[29]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0AACCAA"
    )
        port map (
      I0 => \result[31]_INST_0_i_7_n_0\,
      I1 => \result[31]_INST_0_i_9_n_0\,
      I2 => \result[29]_INST_0_i_4_n_0\,
      I3 => b(1),
      I4 => b(2),
      O => \result[29]_INST_0_i_2_n_0\
    );
\result[29]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB800B800B800"
    )
        port map (
      I0 => \result[30]_INST_0_i_6_n_0\,
      I1 => \result[31]_INST_0_i_15_n_0\,
      I2 => \result[30]_INST_0_i_7_n_0\,
      I3 => \result[27]_INST_0_i_4_n_0\,
      I4 => \result[29]_INST_0_i_5_n_0\,
      I5 => \result[27]_INST_0_i_6_n_0\,
      O => \result[29]_INST_0_i_3_n_0\
    );
\result[29]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(22),
      I1 => a(14),
      I2 => a(6),
      I3 => b(4),
      I4 => b(3),
      O => \result[29]_INST_0_i_4_n_0\
    );
\result[29]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFE005400040004"
    )
        port map (
      I0 => \result[31]_INST_0_i_16_n_0\,
      I1 => a(29),
      I2 => b(1),
      I3 => b(2),
      I4 => b(30),
      I5 => a(31),
      O => \result[29]_INST_0_i_5_n_0\
    );
\result[2]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0AACCAA"
    )
        port map (
      I0 => \result[2]_INST_0_i_4_n_0\,
      I1 => \result[4]_INST_0_i_11_n_0\,
      I2 => \result[4]_INST_0_i_9_n_0\,
      I3 => b(1),
      I4 => b(2),
      O => \result[2]_INST_0_i_1_n_0\
    );
\result[2]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8E000400"
    )
        port map (
      I0 => b(2),
      I1 => a(2),
      I2 => alucontrol(0),
      I3 => alucontrol(2),
      I4 => alucontrol(1),
      O => \result[2]_INST_0_i_3_n_0\
    );
\result[2]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABAAAAABAAAAA"
    )
        port map (
      I0 => \result[2]_INST_0_i_7_n_0\,
      I1 => b(2),
      I2 => b(4),
      I3 => b(3),
      I4 => a(18),
      I5 => a(26),
      O => \result[2]_INST_0_i_4_n_0\
    );
\result[2]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF08080808080808"
    )
        port map (
      I0 => \result[4]_INST_0_i_14_n_0\,
      I1 => b(2),
      I2 => a(2),
      I3 => \result[31]_INST_0_i_3_n_0\,
      I4 => \result[2]_INST_0_i_8_n_0\,
      I5 => a(1),
      O => \result[2]_INST_0_i_5_n_0\
    );
\result[2]_INST_0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => alucontrol(2),
      I1 => alucontrol(0),
      I2 => alucontrol(1),
      O => \result[2]_INST_0_i_6_n_0\
    );
\result[2]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF321000003210"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => a(2),
      I3 => a(10),
      I4 => b(2),
      I5 => \result[4]_INST_0_i_12_n_0\,
      O => \result[2]_INST_0_i_7_n_0\
    );
\result[2]_INST_0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => b(2),
      I1 => b(1),
      I2 => b(4),
      I3 => b(3),
      O => \result[2]_INST_0_i_8_n_0\
    );
\result[30]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0AACCAA"
    )
        port map (
      I0 => \result[31]_INST_0_i_11_n_0\,
      I1 => \result[31]_INST_0_i_13_n_0\,
      I2 => \result[30]_INST_0_i_4_n_0\,
      I3 => b(1),
      I4 => b(2),
      O => \result[30]_INST_0_i_2_n_0\
    );
\result[30]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFF088C088C088"
    )
        port map (
      I0 => \result[30]_INST_0_i_5_n_0\,
      I1 => \result[27]_INST_0_i_4_n_0\,
      I2 => \result[30]_INST_0_i_6_n_0\,
      I3 => \result[31]_INST_0_i_15_n_0\,
      I4 => \result[30]_INST_0_i_7_n_0\,
      I5 => \result[27]_INST_0_i_6_n_0\,
      O => \result[30]_INST_0_i_3_n_0\
    );
\result[30]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00CCF0AA"
    )
        port map (
      I0 => a(23),
      I1 => a(15),
      I2 => a(7),
      I3 => b(4),
      I4 => b(3),
      O => \result[30]_INST_0_i_4_n_0\
    );
\result[30]_INST_0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"888C"
    )
        port map (
      I0 => b(30),
      I1 => a(31),
      I2 => b(3),
      I3 => b(4),
      O => \result[30]_INST_0_i_5_n_0\
    );
\result[30]_INST_0_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => b(30),
      I1 => a(31),
      O => \result[30]_INST_0_i_6_n_0\
    );
\result[30]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C0C0C0AA"
    )
        port map (
      I0 => a(30),
      I1 => b(30),
      I2 => a(31),
      I3 => b(3),
      I4 => b(4),
      O => \result[30]_INST_0_i_7_n_0\
    );
\result[31]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000A0000000C"
    )
        port map (
      I0 => a(22),
      I1 => a(30),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[31]_INST_0_i_10_n_0\
    );
\result[31]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABAAAAABAAAAA"
    )
        port map (
      I0 => \result[31]_INST_0_i_18_n_0\,
      I1 => b(2),
      I2 => b(4),
      I3 => b(3),
      I4 => a(13),
      I5 => a(5),
      O => \result[31]_INST_0_i_11_n_0\
    );
\result[31]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(7),
      I1 => a(15),
      I2 => b(3),
      I3 => b(4),
      I4 => b(2),
      I5 => b(1),
      O => \result[31]_INST_0_i_12_n_0\
    );
\result[31]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(11),
      I1 => a(3),
      I2 => a(27),
      I3 => b(4),
      I4 => b(3),
      I5 => a(19),
      O => \result[31]_INST_0_i_13_n_0\
    );
\result[31]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000A0000000C"
    )
        port map (
      I0 => a(23),
      I1 => a(31),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[31]_INST_0_i_14_n_0\
    );
\result[31]_INST_0_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => b(1),
      I1 => b(2),
      O => \result[31]_INST_0_i_15_n_0\
    );
\result[31]_INST_0_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      O => \result[31]_INST_0_i_16_n_0\
    );
\result[31]_INST_0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF321000003210"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => a(28),
      I3 => a(20),
      I4 => b(2),
      I5 => \result[27]_INST_0_i_11_n_0\,
      O => \result[31]_INST_0_i_17_n_0\
    );
\result[31]_INST_0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF321000003210"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => a(29),
      I3 => a(21),
      I4 => b(2),
      I5 => \result[28]_INST_0_i_5_n_0\,
      O => \result[31]_INST_0_i_18_n_0\
    );
\result[31]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEFECECEC"
    )
        port map (
      I0 => \result[31]_INST_0_i_7_n_0\,
      I1 => \result[31]_INST_0_i_8_n_0\,
      I2 => b(1),
      I3 => b(2),
      I4 => \result[31]_INST_0_i_9_n_0\,
      I5 => \result[31]_INST_0_i_10_n_0\,
      O => \result[31]_INST_0_i_2_n_0\
    );
\result[31]_INST_0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(2),
      I2 => alucontrol(0),
      I3 => b(0),
      O => \result[31]_INST_0_i_3_n_0\
    );
\result[31]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFEFECECEC"
    )
        port map (
      I0 => \result[31]_INST_0_i_11_n_0\,
      I1 => \result[31]_INST_0_i_12_n_0\,
      I2 => b(1),
      I3 => b(2),
      I4 => \result[31]_INST_0_i_13_n_0\,
      I5 => \result[31]_INST_0_i_14_n_0\,
      O => \result[31]_INST_0_i_4_n_0\
    );
\result[31]_INST_0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => alucontrol(1),
      I1 => alucontrol(2),
      I2 => alucontrol(0),
      I3 => b(0),
      O => \result[31]_INST_0_i_5_n_0\
    );
\result[31]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F000F300A000A000"
    )
        port map (
      I0 => \result[27]_INST_0_i_4_n_0\,
      I1 => \result[31]_INST_0_i_15_n_0\,
      I2 => b(30),
      I3 => a(31),
      I4 => \result[31]_INST_0_i_16_n_0\,
      I5 => \result[27]_INST_0_i_6_n_0\,
      O => \result[31]_INST_0_i_6_n_0\
    );
\result[31]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABAAAAABAAAAA"
    )
        port map (
      I0 => \result[31]_INST_0_i_17_n_0\,
      I1 => b(2),
      I2 => b(4),
      I3 => b(3),
      I4 => a(12),
      I5 => a(4),
      O => \result[31]_INST_0_i_7_n_0\
    );
\result[31]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(6),
      I1 => a(14),
      I2 => b(3),
      I3 => b(4),
      I4 => b(2),
      I5 => b(1),
      O => \result[31]_INST_0_i_8_n_0\
    );
\result[31]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(10),
      I1 => a(2),
      I2 => a(26),
      I3 => b(4),
      I4 => b(3),
      I5 => a(18),
      O => \result[31]_INST_0_i_9_n_0\
    );
\result[3]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0AACCAA"
    )
        port map (
      I0 => \result[3]_INST_0_i_4_n_0\,
      I1 => \result[4]_INST_0_i_7_n_0\,
      I2 => \result[4]_INST_0_i_5_n_0\,
      I3 => b(1),
      I4 => b(2),
      O => \result[3]_INST_0_i_1_n_0\
    );
\result[3]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8E000400"
    )
        port map (
      I0 => b(3),
      I1 => a(3),
      I2 => alucontrol(0),
      I3 => alucontrol(2),
      I4 => alucontrol(1),
      O => \result[3]_INST_0_i_3_n_0\
    );
\result[3]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABAAAAABAAAAA"
    )
        port map (
      I0 => \result[3]_INST_0_i_7_n_0\,
      I1 => b(2),
      I2 => b(4),
      I3 => b(3),
      I4 => a(19),
      I5 => a(27),
      O => \result[3]_INST_0_i_4_n_0\
    );
\result[3]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000A0C"
    )
        port map (
      I0 => a(0),
      I1 => a(2),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[3]_INST_0_i_5_n_0\
    );
\result[3]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF321000003210"
    )
        port map (
      I0 => b(3),
      I1 => b(4),
      I2 => a(3),
      I3 => a(11),
      I4 => b(2),
      I5 => \result[4]_INST_0_i_8_n_0\,
      O => \result[3]_INST_0_i_7_n_0\
    );
\result[4]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[4]_INST_0_i_5_n_0\,
      I1 => \result[4]_INST_0_i_6_n_0\,
      I2 => \result[4]_INST_0_i_7_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_8_n_0\,
      O => \result[4]_INST_0_i_1_n_0\
    );
\result[4]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(18),
      I1 => a(26),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(10),
      I4 => b(4),
      I5 => b(3),
      O => \result[4]_INST_0_i_10_n_0\
    );
\result[4]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(20),
      I1 => a(28),
      I2 => a(4),
      I3 => b(4),
      I4 => b(3),
      I5 => a(12),
      O => \result[4]_INST_0_i_11_n_0\
    );
\result[4]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(22),
      I1 => a(30),
      I2 => a(6),
      I3 => b(4),
      I4 => b(3),
      I5 => a(14),
      O => \result[4]_INST_0_i_12_n_0\
    );
\result[4]_INST_0_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => alucontrol(2),
      I1 => alucontrol(0),
      O => \result[4]_INST_0_i_14_n_0\
    );
\result[4]_INST_0_i_15\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => b(4),
      I1 => b(3),
      I2 => a(31),
      I3 => b(30),
      O => \result[4]_INST_0_i_15_n_0\
    );
\result[4]_INST_0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000A0C"
    )
        port map (
      I0 => a(1),
      I1 => a(3),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[4]_INST_0_i_16_n_0\
    );
\result[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[4]_INST_0_i_9_n_0\,
      I1 => \result[4]_INST_0_i_10_n_0\,
      I2 => \result[4]_INST_0_i_11_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_12_n_0\,
      O => \result[4]_INST_0_i_2_n_0\
    );
\result[4]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAFFEAC0C0C0C0C0"
    )
        port map (
      I0 => alucontrol(1),
      I1 => \result[31]_INST_0_i_5_n_0\,
      I2 => \result[5]_INST_0_i_4_n_0\,
      I3 => a(4),
      I4 => b(4),
      I5 => \result[4]_INST_0_i_14_n_0\,
      O => \result[4]_INST_0_i_4_n_0\
    );
\result[4]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(17),
      I1 => a(25),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(9),
      I4 => b(4),
      I5 => b(3),
      O => \result[4]_INST_0_i_5_n_0\
    );
\result[4]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(19),
      I1 => a(27),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(11),
      I4 => b(4),
      I5 => b(3),
      O => \result[4]_INST_0_i_6_n_0\
    );
\result[4]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(21),
      I1 => a(29),
      I2 => a(5),
      I3 => b(4),
      I4 => b(3),
      I5 => a(13),
      O => \result[4]_INST_0_i_7_n_0\
    );
\result[4]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => a(23),
      I1 => a(31),
      I2 => a(7),
      I3 => b(4),
      I4 => b(3),
      I5 => a(15),
      O => \result[4]_INST_0_i_8_n_0\
    );
\result[4]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F0FAFAFCFCFFF0"
    )
        port map (
      I0 => a(16),
      I1 => a(24),
      I2 => \result[4]_INST_0_i_15_n_0\,
      I3 => a(8),
      I4 => b(4),
      I5 => b(3),
      O => \result[4]_INST_0_i_9_n_0\
    );
\result[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[6]_INST_0_i_4_n_0\,
      I1 => \result[4]_INST_0_i_1_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[5]_INST_0_i_1_n_0\
    );
\result[5]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[5]_INST_0_i_4_n_0\,
      I1 => \result[6]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[5]_INST_0_i_3_n_0\
    );
\result[5]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F0CCAA"
    )
        port map (
      I0 => a(4),
      I1 => a(2),
      I2 => a(0),
      I3 => b(1),
      I4 => b(2),
      I5 => \result[31]_INST_0_i_16_n_0\,
      O => \result[5]_INST_0_i_4_n_0\
    );
\result[6]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[7]_INST_0_i_4_n_0\,
      I1 => \result[6]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[6]_INST_0_i_1_n_0\
    );
\result[6]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[6]_INST_0_i_5_n_0\,
      I1 => \result[7]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[6]_INST_0_i_3_n_0\
    );
\result[6]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[4]_INST_0_i_10_n_0\,
      I1 => \result[12]_INST_0_i_6_n_0\,
      I2 => \result[4]_INST_0_i_12_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_9_n_0\,
      O => \result[6]_INST_0_i_4_n_0\
    );
\result[6]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000F0CCAA"
    )
        port map (
      I0 => a(5),
      I1 => a(3),
      I2 => a(1),
      I3 => b(1),
      I4 => b(2),
      I5 => \result[31]_INST_0_i_16_n_0\,
      O => \result[6]_INST_0_i_5_n_0\
    );
\result[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[8]_INST_0_i_4_n_0\,
      I1 => \result[7]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[7]_INST_0_i_1_n_0\
    );
\result[7]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[7]_INST_0_i_5_n_0\,
      I1 => \result[8]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[7]_INST_0_i_3_n_0\
    );
\result[7]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[4]_INST_0_i_6_n_0\,
      I1 => \result[13]_INST_0_i_6_n_0\,
      I2 => \result[4]_INST_0_i_8_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_5_n_0\,
      O => \result[7]_INST_0_i_4_n_0\
    );
\result[7]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF44400400"
    )
        port map (
      I0 => \result[31]_INST_0_i_16_n_0\,
      I1 => b(2),
      I2 => b(1),
      I3 => a(2),
      I4 => a(0),
      I5 => \result[7]_INST_0_i_6_n_0\,
      O => \result[7]_INST_0_i_5_n_0\
    );
\result[7]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000A0C"
    )
        port map (
      I0 => a(4),
      I1 => a(6),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[7]_INST_0_i_6_n_0\
    );
\result[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[9]_INST_0_i_4_n_0\,
      I1 => \result[8]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[8]_INST_0_i_1_n_0\
    );
\result[8]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[8]_INST_0_i_5_n_0\,
      I1 => \result[9]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[8]_INST_0_i_3_n_0\
    );
\result[8]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[12]_INST_0_i_6_n_0\,
      I1 => \result[14]_INST_0_i_6_n_0\,
      I2 => \result[4]_INST_0_i_9_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_10_n_0\,
      O => \result[8]_INST_0_i_4_n_0\
    );
\result[8]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF44400400"
    )
        port map (
      I0 => \result[31]_INST_0_i_16_n_0\,
      I1 => b(2),
      I2 => b(1),
      I3 => a(3),
      I4 => a(1),
      I5 => \result[8]_INST_0_i_6_n_0\,
      O => \result[8]_INST_0_i_5_n_0\
    );
\result[8]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000A0C"
    )
        port map (
      I0 => a(5),
      I1 => a(7),
      I2 => b(2),
      I3 => b(1),
      I4 => b(4),
      I5 => b(3),
      O => \result[8]_INST_0_i_6_n_0\
    );
\result[9]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A0000000C000"
    )
        port map (
      I0 => \result[10]_INST_0_i_4_n_0\,
      I1 => \result[9]_INST_0_i_4_n_0\,
      I2 => alucontrol(2),
      I3 => alucontrol(0),
      I4 => alucontrol(1),
      I5 => b(0),
      O => \result[9]_INST_0_i_1_n_0\
    );
\result[9]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000A0000000C0000"
    )
        port map (
      I0 => \result[9]_INST_0_i_5_n_0\,
      I1 => \result[10]_INST_0_i_5_n_0\,
      I2 => alucontrol(1),
      I3 => alucontrol(2),
      I4 => alucontrol(0),
      I5 => b(0),
      O => \result[9]_INST_0_i_3_n_0\
    );
\result[9]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFAAF0CC00AAF0"
    )
        port map (
      I0 => \result[13]_INST_0_i_6_n_0\,
      I1 => \result[15]_INST_0_i_7_n_0\,
      I2 => \result[4]_INST_0_i_5_n_0\,
      I3 => b(2),
      I4 => b(1),
      I5 => \result[4]_INST_0_i_6_n_0\,
      O => \result[9]_INST_0_i_4_n_0\
    );
\result[9]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAEAFAEAAAEAAAE"
    )
        port map (
      I0 => \result[9]_INST_0_i_6_n_0\,
      I1 => \result[15]_INST_0_i_8_n_0\,
      I2 => b(2),
      I3 => b(1),
      I4 => \result[31]_INST_0_i_16_n_0\,
      I5 => a(6),
      O => \result[9]_INST_0_i_5_n_0\
    );
\result[9]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000AC00"
    )
        port map (
      I0 => a(2),
      I1 => a(4),
      I2 => b(1),
      I3 => b(2),
      I4 => b(4),
      I5 => b(3),
      O => \result[9]_INST_0_i_6_n_0\
    );
end STRUCTURE;
