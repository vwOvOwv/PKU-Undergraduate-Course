-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:20:31 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ BCD2bin_0_sim_netlist.vhdl
-- Design      : BCD2bin_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    bcd3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bin : out STD_LOGIC_VECTOR ( 13 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "BCD2bin_0,BCD2bin,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "BCD2bin,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \^bcd0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^bin\ : STD_LOGIC_VECTOR ( 13 downto 1 );
  signal \bin[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[11]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_17_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_18_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_19_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_20_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_21_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_22_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bin[13]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bin[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[5]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[5]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin[5]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bin[7]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bin[8]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal p_0_in0 : STD_LOGIC;
  signal shifter : STD_LOGIC_VECTOR ( 17 downto 15 );
  signal shifter1_out0_out : STD_LOGIC_VECTOR ( 22 to 22 );
  signal shifter20 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \bin[11]_INST_0_i_4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_11\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_3\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_7\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bin[13]_INST_0_i_8\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bin[4]_INST_0_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bin[5]_INST_0_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bin[5]_INST_0_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bin[7]_INST_0_i_12\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bin[7]_INST_0_i_7\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bin[8]_INST_0_i_3\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \bin[8]_INST_0_i_4\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bin[8]_INST_0_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bin[8]_INST_0_i_6\ : label is "soft_lutpair1";
begin
  \^bcd0\(3 downto 0) <= bcd0(3 downto 0);
  bin(13 downto 1) <= \^bin\(13 downto 1);
  bin(0) <= \^bcd0\(0);
\bin[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[13]_INST_0_i_4_n_0\,
      I1 => \bin[13]_INST_0_i_2_n_0\,
      O => \^bin\(10)
    );
\bin[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"366C9933C99366CC"
    )
        port map (
      I0 => \bin[13]_INST_0_i_4_n_0\,
      I1 => \bin[11]_INST_0_i_1_n_0\,
      I2 => \bin[11]_INST_0_i_2_n_0\,
      I3 => \bin[11]_INST_0_i_3_n_0\,
      I4 => \bin[11]_INST_0_i_4_n_0\,
      I5 => \bin[13]_INST_0_i_6_n_0\,
      O => \^bin\(11)
    );
\bin[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA8AAA880000000"
    )
        port map (
      I0 => \bin[8]_INST_0_i_1_n_0\,
      I1 => \bin[13]_INST_0_i_16_n_0\,
      I2 => \bin[7]_INST_0_i_3_n_0\,
      I3 => \bin[7]_INST_0_i_2_n_0\,
      I4 => \bin[7]_INST_0_i_1_n_0\,
      I5 => \bin[7]_INST_0_i_4_n_0\,
      O => \bin[11]_INST_0_i_1_n_0\
    );
\bin[11]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A085051F7AFAE0A0"
    )
        port map (
      I0 => \bin[8]_INST_0_i_1_n_0\,
      I1 => \bin[7]_INST_0_i_1_n_0\,
      I2 => \bin[7]_INST_0_i_2_n_0\,
      I3 => \bin[7]_INST_0_i_3_n_0\,
      I4 => \bin[13]_INST_0_i_16_n_0\,
      I5 => \bin[7]_INST_0_i_4_n_0\,
      O => \bin[11]_INST_0_i_2_n_0\
    );
\bin[11]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"46666622662262AA"
    )
        port map (
      I0 => \bin[8]_INST_0_i_1_n_0\,
      I1 => \bin[7]_INST_0_i_4_n_0\,
      I2 => \bin[7]_INST_0_i_1_n_0\,
      I3 => \bin[7]_INST_0_i_2_n_0\,
      I4 => \bin[7]_INST_0_i_3_n_0\,
      I5 => \bin[13]_INST_0_i_16_n_0\,
      O => \bin[11]_INST_0_i_3_n_0\
    );
\bin[11]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin[13]_INST_0_i_14_n_0\,
      O => \bin[11]_INST_0_i_4_n_0\
    );
\bin[12]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => shifter20,
      I1 => \bin[12]_INST_0_i_1_n_0\,
      O => \^bin\(12)
    );
\bin[12]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin[13]_INST_0_i_6_n_0\,
      I1 => \bin[11]_INST_0_i_3_n_0\,
      I2 => \bin[11]_INST_0_i_2_n_0\,
      I3 => \bin[11]_INST_0_i_1_n_0\,
      I4 => \bin[11]_INST_0_i_4_n_0\,
      I5 => \bin[13]_INST_0_i_4_n_0\,
      O => \bin[12]_INST_0_i_1_n_0\
    );
\bin[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A805015F7FAAEA00"
    )
        port map (
      I0 => shifter20,
      I1 => \bin[13]_INST_0_i_2_n_0\,
      I2 => \bin[13]_INST_0_i_3_n_0\,
      I3 => \bin[13]_INST_0_i_4_n_0\,
      I4 => \bin[13]_INST_0_i_5_n_0\,
      I5 => \bin[13]_INST_0_i_6_n_0\,
      O => \^bin\(13)
    );
\bin[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin[13]_INST_0_i_8_n_0\,
      I2 => \bin[13]_INST_0_i_9_n_0\,
      I3 => \bin[13]_INST_0_i_10_n_0\,
      I4 => \bin[13]_INST_0_i_11_n_0\,
      I5 => \bin[13]_INST_0_i_12_n_0\,
      O => shifter20
    );
\bin[13]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin[8]_INST_0_i_3_n_0\,
      I1 => \bin[5]_INST_0_i_3_n_0\,
      I2 => \bin[5]_INST_0_i_5_n_0\,
      I3 => \bin[5]_INST_0_i_4_n_0\,
      I4 => \bin[13]_INST_0_i_19_n_0\,
      I5 => \bin[7]_INST_0_i_8_n_0\,
      O => \bin[13]_INST_0_i_10_n_0\
    );
\bin[13]_INST_0_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin[13]_INST_0_i_20_n_0\,
      I1 => bcd3(3),
      I2 => \bin[13]_INST_0_i_21_n_0\,
      O => \bin[13]_INST_0_i_11_n_0\
    );
\bin[13]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => \bin[8]_INST_0_i_3_n_0\,
      I1 => \bin[7]_INST_0_i_8_n_0\,
      I2 => \bin[5]_INST_0_i_3_n_0\,
      I3 => \bin[5]_INST_0_i_5_n_0\,
      I4 => \bin[5]_INST_0_i_4_n_0\,
      I5 => \bin[13]_INST_0_i_19_n_0\,
      O => \bin[13]_INST_0_i_12_n_0\
    );
\bin[13]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAB9AAB9FFFFFFFF"
    )
        port map (
      I0 => \bin[7]_INST_0_i_4_n_0\,
      I1 => \bin[13]_INST_0_i_16_n_0\,
      I2 => \bin[7]_INST_0_i_3_n_0\,
      I3 => \bin[7]_INST_0_i_2_n_0\,
      I4 => \bin[7]_INST_0_i_1_n_0\,
      I5 => \bin[8]_INST_0_i_1_n_0\,
      O => \bin[13]_INST_0_i_13_n_0\
    );
\bin[13]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin[13]_INST_0_i_8_n_0\,
      I1 => \bin[8]_INST_0_i_4_n_0\,
      I2 => \bin[8]_INST_0_i_5_n_0\,
      I3 => \bin[8]_INST_0_i_3_n_0\,
      I4 => \bin[8]_INST_0_i_6_n_0\,
      I5 => \bin[13]_INST_0_i_11_n_0\,
      O => \bin[13]_INST_0_i_14_n_0\
    );
\bin[13]_INST_0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin[13]_INST_0_i_8_n_0\,
      I1 => \bin[8]_INST_0_i_6_n_0\,
      I2 => \bin[8]_INST_0_i_3_n_0\,
      I3 => \bin[8]_INST_0_i_5_n_0\,
      I4 => \bin[8]_INST_0_i_4_n_0\,
      I5 => \bin[13]_INST_0_i_11_n_0\,
      O => \bin[13]_INST_0_i_15_n_0\
    );
\bin[13]_INST_0_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bin[13]_INST_0_i_22_n_0\,
      I1 => \bin[5]_INST_0_i_1_n_0\,
      O => \bin[13]_INST_0_i_16_n_0\
    );
\bin[13]_INST_0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBABA9A9FFFFFFFF"
    )
        port map (
      I0 => bcd3(1),
      I1 => bcd2(3),
      I2 => bcd3(0),
      I3 => bcd2(1),
      I4 => bcd2(2),
      I5 => bcd3(2),
      O => \bin[13]_INST_0_i_17_n_0\
    );
\bin[13]_INST_0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => bcd3(2),
      I1 => bcd3(1),
      I2 => bcd2(2),
      I3 => bcd2(1),
      I4 => bcd3(0),
      I5 => bcd2(3),
      O => \bin[13]_INST_0_i_18_n_0\
    );
\bin[13]_INST_0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666606066600000"
    )
        port map (
      I0 => bcd3(0),
      I1 => bcd2(1),
      I2 => bcd1(2),
      I3 => bcd1(1),
      I4 => bcd2(0),
      I5 => bcd1(3),
      O => \bin[13]_INST_0_i_19_n_0\
    );
\bin[13]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin[11]_INST_0_i_2_n_0\,
      I1 => \bin[11]_INST_0_i_4_n_0\,
      I2 => \bin[11]_INST_0_i_3_n_0\,
      O => \bin[13]_INST_0_i_2_n_0\
    );
\bin[13]_INST_0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => bcd3(2),
      I1 => bcd2(2),
      I2 => bcd2(1),
      I3 => bcd3(0),
      I4 => bcd2(3),
      I5 => bcd3(1),
      O => \bin[13]_INST_0_i_20_n_0\
    );
\bin[13]_INST_0_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => bcd3(2),
      I1 => bcd2(3),
      I2 => bcd3(0),
      I3 => bcd2(1),
      I4 => bcd2(2),
      I5 => bcd3(1),
      O => \bin[13]_INST_0_i_21_n_0\
    );
\bin[13]_INST_0_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F666666666666060"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => \bin[5]_INST_0_i_5_n_0\,
      I2 => shifter(17),
      I3 => shifter(15),
      I4 => shifter(16),
      I5 => \bin[7]_INST_0_i_7_n_0\,
      O => \bin[13]_INST_0_i_22_n_0\
    );
\bin[13]_INST_0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin[11]_INST_0_i_4_n_0\,
      I1 => \bin[13]_INST_0_i_13_n_0\,
      I2 => \bin[11]_INST_0_i_1_n_0\,
      O => \bin[13]_INST_0_i_3_n_0\
    );
\bin[13]_INST_0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin[13]_INST_0_i_14_n_0\,
      I1 => p_0_in0,
      I2 => \bin[13]_INST_0_i_15_n_0\,
      O => \bin[13]_INST_0_i_4_n_0\
    );
\bin[13]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAA80000"
    )
        port map (
      I0 => \bin[8]_INST_0_i_1_n_0\,
      I1 => \bin[7]_INST_0_i_2_n_0\,
      I2 => \bin[13]_INST_0_i_16_n_0\,
      I3 => \bin[7]_INST_0_i_4_n_0\,
      I4 => \bin[11]_INST_0_i_4_n_0\,
      O => \bin[13]_INST_0_i_5_n_0\
    );
\bin[13]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin[13]_INST_0_i_12_n_0\,
      I2 => \bin[13]_INST_0_i_11_n_0\,
      I3 => \bin[13]_INST_0_i_10_n_0\,
      I4 => \bin[13]_INST_0_i_9_n_0\,
      I5 => \bin[13]_INST_0_i_8_n_0\,
      O => \bin[13]_INST_0_i_6_n_0\
    );
\bin[13]_INST_0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"C4"
    )
        port map (
      I0 => \bin[13]_INST_0_i_17_n_0\,
      I1 => bcd3(3),
      I2 => \bin[13]_INST_0_i_18_n_0\,
      O => p_0_in0
    );
\bin[13]_INST_0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => bcd3(3),
      I1 => \bin[13]_INST_0_i_17_n_0\,
      I2 => \bin[13]_INST_0_i_18_n_0\,
      O => \bin[13]_INST_0_i_8_n_0\
    );
\bin[13]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin[8]_INST_0_i_3_n_0\,
      I1 => \bin[13]_INST_0_i_19_n_0\,
      I2 => \bin[5]_INST_0_i_4_n_0\,
      I3 => \bin[5]_INST_0_i_5_n_0\,
      I4 => \bin[5]_INST_0_i_3_n_0\,
      I5 => \bin[7]_INST_0_i_8_n_0\,
      O => \bin[13]_INST_0_i_9_n_0\
    );
\bin[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^bcd0\(1),
      I1 => bcd1(0),
      O => \^bin\(1)
    );
\bin[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => bcd1(1),
      I1 => bcd2(0),
      I2 => \^bcd0\(2),
      I3 => bcd1(0),
      I4 => \^bcd0\(1),
      O => \^bin\(2)
    );
\bin[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8778788778878778"
    )
        port map (
      I0 => bcd1(1),
      I1 => bcd2(0),
      I2 => bcd1(2),
      I3 => bcd3(0),
      I4 => bcd2(1),
      I5 => shifter(15),
      O => \^bin\(3)
    );
\bin[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F6609F9F099F6060"
    )
        port map (
      I0 => bcd2(0),
      I1 => bcd1(1),
      I2 => \^bcd0\(2),
      I3 => \^bcd0\(1),
      I4 => bcd1(0),
      I5 => \^bcd0\(3),
      O => shifter(15)
    );
\bin[4]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[4]_INST_0_i_1_n_0\,
      I1 => \bin[4]_INST_0_i_2_n_0\,
      O => \^bin\(4)
    );
\bin[4]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"78878778"
    )
        port map (
      I0 => bcd2(1),
      I1 => bcd3(0),
      I2 => bcd2(2),
      I3 => bcd3(1),
      I4 => \bin[5]_INST_0_i_5_n_0\,
      O => \bin[4]_INST_0_i_1_n_0\
    );
\bin[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A801055F7FEAAA00"
    )
        port map (
      I0 => \bin[7]_INST_0_i_7_n_0\,
      I1 => \^bcd0\(1),
      I2 => \^bcd0\(2),
      I3 => \^bcd0\(3),
      I4 => bcd1(0),
      I5 => \bin[4]_INST_0_i_3_n_0\,
      O => \bin[4]_INST_0_i_2_n_0\
    );
\bin[4]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd2(0),
      I1 => bcd1(1),
      O => \bin[4]_INST_0_i_3_n_0\
    );
\bin[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[5]_INST_0_i_1_n_0\,
      I1 => \bin[5]_INST_0_i_2_n_0\,
      O => \^bin\(5)
    );
\bin[5]_INST_0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => \bin[7]_INST_0_i_8_n_0\,
      I1 => \bin[5]_INST_0_i_3_n_0\,
      I2 => \bin[5]_INST_0_i_4_n_0\,
      I3 => \bin[5]_INST_0_i_5_n_0\,
      O => \bin[5]_INST_0_i_1_n_0\
    );
\bin[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F069690F9696F0F0"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => \bin[5]_INST_0_i_5_n_0\,
      I2 => shifter(17),
      I3 => shifter(15),
      I4 => shifter(16),
      I5 => \bin[7]_INST_0_i_7_n_0\,
      O => \bin[5]_INST_0_i_2_n_0\
    );
\bin[5]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9906900690669666"
    )
        port map (
      I0 => bcd3(0),
      I1 => bcd2(1),
      I2 => bcd1(3),
      I3 => bcd2(0),
      I4 => bcd1(1),
      I5 => bcd1(2),
      O => \bin[5]_INST_0_i_3_n_0\
    );
\bin[5]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => bcd3(1),
      I1 => bcd2(2),
      I2 => bcd3(0),
      I3 => bcd2(1),
      O => \bin[5]_INST_0_i_4_n_0\
    );
\bin[5]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F069690F9696F0F0"
    )
        port map (
      I0 => bcd3(0),
      I1 => bcd2(1),
      I2 => bcd1(3),
      I3 => bcd1(1),
      I4 => bcd1(2),
      I5 => bcd2(0),
      O => \bin[5]_INST_0_i_5_n_0\
    );
\bin[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[7]_INST_0_i_2_n_0\,
      I1 => \bin[7]_INST_0_i_1_n_0\,
      O => \^bin\(6)
    );
\bin[7]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \bin[7]_INST_0_i_1_n_0\,
      I1 => \bin[7]_INST_0_i_2_n_0\,
      I2 => \bin[7]_INST_0_i_3_n_0\,
      I3 => \bin[7]_INST_0_i_4_n_0\,
      O => \^bin\(7)
    );
\bin[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin[5]_INST_0_i_1_n_0\,
      I1 => shifter(16),
      I2 => shifter(15),
      I3 => shifter(17),
      I4 => \bin[7]_INST_0_i_7_n_0\,
      I5 => \bin[4]_INST_0_i_1_n_0\,
      O => \bin[7]_INST_0_i_1_n_0\
    );
\bin[7]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => bcd1(2),
      I2 => bcd1(1),
      I3 => bcd2(0),
      I4 => bcd1(3),
      I5 => shifter1_out0_out(22),
      O => \bin[7]_INST_0_i_10_n_0\
    );
\bin[7]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => shifter1_out0_out(22),
      I2 => bcd1(2),
      I3 => bcd1(1),
      I4 => bcd2(0),
      I5 => bcd1(3),
      O => \bin[7]_INST_0_i_11_n_0\
    );
\bin[7]_INST_0_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd3(0),
      I1 => bcd2(1),
      O => shifter1_out0_out(22)
    );
\bin[7]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[8]_INST_0_i_3_n_0\,
      I1 => \bin[8]_INST_0_i_5_n_0\,
      O => \bin[7]_INST_0_i_2_n_0\
    );
\bin[7]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545446422AAAAAAA"
    )
        port map (
      I0 => \bin[5]_INST_0_i_1_n_0\,
      I1 => \bin[7]_INST_0_i_7_n_0\,
      I2 => shifter(16),
      I3 => shifter(15),
      I4 => shifter(17),
      I5 => \bin[4]_INST_0_i_1_n_0\,
      O => \bin[7]_INST_0_i_3_n_0\
    );
\bin[7]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => \bin[13]_INST_0_i_11_n_0\,
      I1 => \bin[7]_INST_0_i_8_n_0\,
      I2 => \bin[7]_INST_0_i_9_n_0\,
      I3 => \bin[7]_INST_0_i_10_n_0\,
      I4 => \bin[7]_INST_0_i_11_n_0\,
      I5 => \bin[8]_INST_0_i_3_n_0\,
      O => \bin[7]_INST_0_i_4_n_0\
    );
\bin[7]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9096960690069666"
    )
        port map (
      I0 => bcd2(0),
      I1 => bcd1(1),
      I2 => bcd1(0),
      I3 => \^bcd0\(3),
      I4 => \^bcd0\(2),
      I5 => \^bcd0\(1),
      O => shifter(16)
    );
\bin[7]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666666066000000"
    )
        port map (
      I0 => bcd2(0),
      I1 => bcd1(1),
      I2 => \^bcd0\(1),
      I3 => \^bcd0\(2),
      I4 => \^bcd0\(3),
      I5 => bcd1(0),
      O => shifter(17)
    );
\bin[7]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => bcd2(1),
      I1 => bcd3(0),
      I2 => bcd1(2),
      I3 => bcd2(0),
      I4 => bcd1(1),
      O => \bin[7]_INST_0_i_7_n_0\
    );
\bin[7]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => bcd3(2),
      I1 => bcd3(0),
      I2 => bcd2(2),
      I3 => bcd2(1),
      I4 => bcd2(3),
      I5 => bcd3(1),
      O => \bin[7]_INST_0_i_8_n_0\
    );
\bin[7]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => bcd1(3),
      I2 => bcd2(0),
      I3 => bcd1(1),
      I4 => bcd1(2),
      I5 => shifter1_out0_out(22),
      O => \bin[7]_INST_0_i_9_n_0\
    );
\bin[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[8]_INST_0_i_1_n_0\,
      I1 => \bin[8]_INST_0_i_2_n_0\,
      O => \^bin\(8)
    );
\bin[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => \bin[13]_INST_0_i_8_n_0\,
      I1 => \bin[8]_INST_0_i_3_n_0\,
      I2 => \bin[8]_INST_0_i_4_n_0\,
      I3 => \bin[8]_INST_0_i_5_n_0\,
      I4 => \bin[8]_INST_0_i_6_n_0\,
      I5 => \bin[13]_INST_0_i_11_n_0\,
      O => \bin[8]_INST_0_i_1_n_0\
    );
\bin[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin[7]_INST_0_i_4_n_0\,
      I1 => \bin[8]_INST_0_i_7_n_0\,
      I2 => \bin[5]_INST_0_i_2_n_0\,
      I3 => \bin[8]_INST_0_i_8_n_0\,
      I4 => \bin[5]_INST_0_i_1_n_0\,
      I5 => \bin[7]_INST_0_i_2_n_0\,
      O => \bin[8]_INST_0_i_2_n_0\
    );
\bin[8]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd3(3),
      I1 => \bin[13]_INST_0_i_20_n_0\,
      O => \bin[8]_INST_0_i_3_n_0\
    );
\bin[8]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"52424A6A"
    )
        port map (
      I0 => \bin[7]_INST_0_i_8_n_0\,
      I1 => \bin[13]_INST_0_i_19_n_0\,
      I2 => \bin[5]_INST_0_i_4_n_0\,
      I3 => \bin[5]_INST_0_i_5_n_0\,
      I4 => \bin[5]_INST_0_i_3_n_0\,
      O => \bin[8]_INST_0_i_4_n_0\
    );
\bin[8]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C99366CC"
    )
        port map (
      I0 => \bin[7]_INST_0_i_8_n_0\,
      I1 => \bin[13]_INST_0_i_19_n_0\,
      I2 => \bin[5]_INST_0_i_5_n_0\,
      I3 => \bin[5]_INST_0_i_3_n_0\,
      I4 => \bin[5]_INST_0_i_4_n_0\,
      O => \bin[8]_INST_0_i_5_n_0\
    );
\bin[8]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA88A800"
    )
        port map (
      I0 => \bin[7]_INST_0_i_8_n_0\,
      I1 => \bin[5]_INST_0_i_3_n_0\,
      I2 => \bin[5]_INST_0_i_5_n_0\,
      I3 => \bin[5]_INST_0_i_4_n_0\,
      I4 => \bin[13]_INST_0_i_19_n_0\,
      O => \bin[8]_INST_0_i_6_n_0\
    );
\bin[8]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9096900696069666"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => \bin[5]_INST_0_i_5_n_0\,
      I2 => \bin[7]_INST_0_i_7_n_0\,
      I3 => shifter(17),
      I4 => shifter(15),
      I5 => shifter(16),
      O => \bin[8]_INST_0_i_7_n_0\
    );
\bin[8]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666666060600000"
    )
        port map (
      I0 => \bin[5]_INST_0_i_4_n_0\,
      I1 => \bin[5]_INST_0_i_5_n_0\,
      I2 => shifter(16),
      I3 => shifter(15),
      I4 => shifter(17),
      I5 => \bin[7]_INST_0_i_7_n_0\,
      O => \bin[8]_INST_0_i_8_n_0\
    );
\bin[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin[11]_INST_0_i_4_n_0\,
      I1 => \bin[11]_INST_0_i_2_n_0\,
      O => \^bin\(9)
    );
end STRUCTURE;
