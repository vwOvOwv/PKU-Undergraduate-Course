// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:20:50 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/ddca_lab_td/calcriscv/calcriscv_bd/calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4_0_stub.v
// Design      : display_7seg_x4_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "display_7seg_x4,Vivado 2020.2" *)
module display_7seg_x4_0(CLK_1KHz, in3, in2, in1, in0, an, seg)
/* synthesis syn_black_box black_box_pad_pin="CLK_1KHz,in3[3:0],in2[3:0],in1[3:0],in0[3:0],an[0:3],seg[0:6]" */;
  input CLK_1KHz;
  input [3:0]in3;
  input [3:0]in2;
  input [3:0]in1;
  input [3:0]in0;
  output [0:3]an;
  output [0:6]seg;
endmodule
