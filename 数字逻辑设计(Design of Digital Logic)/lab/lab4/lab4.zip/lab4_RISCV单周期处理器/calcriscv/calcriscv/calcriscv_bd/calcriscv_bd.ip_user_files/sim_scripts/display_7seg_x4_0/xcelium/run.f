-makelib xcelium_lib/xil_defaultlib -sv \
  "../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/display_7seg_x4.sv" \
  "../../../../calcriscv_bd.gen/sources_1/ip/display_7seg_x4_0/sim/display_7seg_x4_0.sv" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

