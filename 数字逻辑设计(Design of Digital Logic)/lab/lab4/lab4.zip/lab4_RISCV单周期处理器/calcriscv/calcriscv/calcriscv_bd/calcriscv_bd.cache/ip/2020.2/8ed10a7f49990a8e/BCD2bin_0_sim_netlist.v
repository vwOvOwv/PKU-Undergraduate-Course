// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:20:31 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ BCD2bin_0_sim_netlist.v
// Design      : BCD2bin_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "BCD2bin_0,BCD2bin,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "BCD2bin,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (bcd3,
    bcd2,
    bcd1,
    bcd0,
    bin);
  input [3:0]bcd3;
  input [3:0]bcd2;
  input [3:0]bcd1;
  input [3:0]bcd0;
  output [13:0]bin;

  wire [3:0]bcd0;
  wire [3:0]bcd1;
  wire [3:0]bcd2;
  wire [3:0]bcd3;
  wire [13:1]\^bin ;
  wire \bin[11]_INST_0_i_1_n_0 ;
  wire \bin[11]_INST_0_i_2_n_0 ;
  wire \bin[11]_INST_0_i_3_n_0 ;
  wire \bin[11]_INST_0_i_4_n_0 ;
  wire \bin[12]_INST_0_i_1_n_0 ;
  wire \bin[13]_INST_0_i_10_n_0 ;
  wire \bin[13]_INST_0_i_11_n_0 ;
  wire \bin[13]_INST_0_i_12_n_0 ;
  wire \bin[13]_INST_0_i_13_n_0 ;
  wire \bin[13]_INST_0_i_14_n_0 ;
  wire \bin[13]_INST_0_i_15_n_0 ;
  wire \bin[13]_INST_0_i_16_n_0 ;
  wire \bin[13]_INST_0_i_17_n_0 ;
  wire \bin[13]_INST_0_i_18_n_0 ;
  wire \bin[13]_INST_0_i_19_n_0 ;
  wire \bin[13]_INST_0_i_20_n_0 ;
  wire \bin[13]_INST_0_i_21_n_0 ;
  wire \bin[13]_INST_0_i_22_n_0 ;
  wire \bin[13]_INST_0_i_2_n_0 ;
  wire \bin[13]_INST_0_i_3_n_0 ;
  wire \bin[13]_INST_0_i_4_n_0 ;
  wire \bin[13]_INST_0_i_5_n_0 ;
  wire \bin[13]_INST_0_i_6_n_0 ;
  wire \bin[13]_INST_0_i_8_n_0 ;
  wire \bin[13]_INST_0_i_9_n_0 ;
  wire \bin[4]_INST_0_i_1_n_0 ;
  wire \bin[4]_INST_0_i_2_n_0 ;
  wire \bin[4]_INST_0_i_3_n_0 ;
  wire \bin[5]_INST_0_i_1_n_0 ;
  wire \bin[5]_INST_0_i_2_n_0 ;
  wire \bin[5]_INST_0_i_3_n_0 ;
  wire \bin[5]_INST_0_i_4_n_0 ;
  wire \bin[5]_INST_0_i_5_n_0 ;
  wire \bin[7]_INST_0_i_10_n_0 ;
  wire \bin[7]_INST_0_i_11_n_0 ;
  wire \bin[7]_INST_0_i_1_n_0 ;
  wire \bin[7]_INST_0_i_2_n_0 ;
  wire \bin[7]_INST_0_i_3_n_0 ;
  wire \bin[7]_INST_0_i_4_n_0 ;
  wire \bin[7]_INST_0_i_7_n_0 ;
  wire \bin[7]_INST_0_i_8_n_0 ;
  wire \bin[7]_INST_0_i_9_n_0 ;
  wire \bin[8]_INST_0_i_1_n_0 ;
  wire \bin[8]_INST_0_i_2_n_0 ;
  wire \bin[8]_INST_0_i_3_n_0 ;
  wire \bin[8]_INST_0_i_4_n_0 ;
  wire \bin[8]_INST_0_i_5_n_0 ;
  wire \bin[8]_INST_0_i_6_n_0 ;
  wire \bin[8]_INST_0_i_7_n_0 ;
  wire \bin[8]_INST_0_i_8_n_0 ;
  wire p_0_in0;
  wire [17:15]shifter;
  wire [22:22]shifter1_out0_out;
  wire shifter20;

  assign bin[13:1] = \^bin [13:1];
  assign bin[0] = bcd0[0];
  LUT2 #(
    .INIT(4'h6)) 
    \bin[10]_INST_0 
       (.I0(\bin[13]_INST_0_i_4_n_0 ),
        .I1(\bin[13]_INST_0_i_2_n_0 ),
        .O(\^bin [10]));
  LUT6 #(
    .INIT(64'h366C9933C99366CC)) 
    \bin[11]_INST_0 
       (.I0(\bin[13]_INST_0_i_4_n_0 ),
        .I1(\bin[11]_INST_0_i_1_n_0 ),
        .I2(\bin[11]_INST_0_i_2_n_0 ),
        .I3(\bin[11]_INST_0_i_3_n_0 ),
        .I4(\bin[11]_INST_0_i_4_n_0 ),
        .I5(\bin[13]_INST_0_i_6_n_0 ),
        .O(\^bin [11]));
  LUT6 #(
    .INIT(64'hAAA8AAA880000000)) 
    \bin[11]_INST_0_i_1 
       (.I0(\bin[8]_INST_0_i_1_n_0 ),
        .I1(\bin[13]_INST_0_i_16_n_0 ),
        .I2(\bin[7]_INST_0_i_3_n_0 ),
        .I3(\bin[7]_INST_0_i_2_n_0 ),
        .I4(\bin[7]_INST_0_i_1_n_0 ),
        .I5(\bin[7]_INST_0_i_4_n_0 ),
        .O(\bin[11]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA085051F7AFAE0A0)) 
    \bin[11]_INST_0_i_2 
       (.I0(\bin[8]_INST_0_i_1_n_0 ),
        .I1(\bin[7]_INST_0_i_1_n_0 ),
        .I2(\bin[7]_INST_0_i_2_n_0 ),
        .I3(\bin[7]_INST_0_i_3_n_0 ),
        .I4(\bin[13]_INST_0_i_16_n_0 ),
        .I5(\bin[7]_INST_0_i_4_n_0 ),
        .O(\bin[11]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h46666622662262AA)) 
    \bin[11]_INST_0_i_3 
       (.I0(\bin[8]_INST_0_i_1_n_0 ),
        .I1(\bin[7]_INST_0_i_4_n_0 ),
        .I2(\bin[7]_INST_0_i_1_n_0 ),
        .I3(\bin[7]_INST_0_i_2_n_0 ),
        .I4(\bin[7]_INST_0_i_3_n_0 ),
        .I5(\bin[13]_INST_0_i_16_n_0 ),
        .O(\bin[11]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bin[11]_INST_0_i_4 
       (.I0(p_0_in0),
        .I1(\bin[13]_INST_0_i_14_n_0 ),
        .O(\bin[11]_INST_0_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[12]_INST_0 
       (.I0(shifter20),
        .I1(\bin[12]_INST_0_i_1_n_0 ),
        .O(\^bin [12]));
  LUT6 #(
    .INIT(64'hA80111777FEAAA00)) 
    \bin[12]_INST_0_i_1 
       (.I0(\bin[13]_INST_0_i_6_n_0 ),
        .I1(\bin[11]_INST_0_i_3_n_0 ),
        .I2(\bin[11]_INST_0_i_2_n_0 ),
        .I3(\bin[11]_INST_0_i_1_n_0 ),
        .I4(\bin[11]_INST_0_i_4_n_0 ),
        .I5(\bin[13]_INST_0_i_4_n_0 ),
        .O(\bin[12]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA805015F7FAAEA00)) 
    \bin[13]_INST_0 
       (.I0(shifter20),
        .I1(\bin[13]_INST_0_i_2_n_0 ),
        .I2(\bin[13]_INST_0_i_3_n_0 ),
        .I3(\bin[13]_INST_0_i_4_n_0 ),
        .I4(\bin[13]_INST_0_i_5_n_0 ),
        .I5(\bin[13]_INST_0_i_6_n_0 ),
        .O(\^bin [13]));
  LUT6 #(
    .INIT(64'hA888888888888080)) 
    \bin[13]_INST_0_i_1 
       (.I0(p_0_in0),
        .I1(\bin[13]_INST_0_i_8_n_0 ),
        .I2(\bin[13]_INST_0_i_9_n_0 ),
        .I3(\bin[13]_INST_0_i_10_n_0 ),
        .I4(\bin[13]_INST_0_i_11_n_0 ),
        .I5(\bin[13]_INST_0_i_12_n_0 ),
        .O(shifter20));
  LUT6 #(
    .INIT(64'hA81101777FAAEA00)) 
    \bin[13]_INST_0_i_10 
       (.I0(\bin[8]_INST_0_i_3_n_0 ),
        .I1(\bin[5]_INST_0_i_3_n_0 ),
        .I2(\bin[5]_INST_0_i_5_n_0 ),
        .I3(\bin[5]_INST_0_i_4_n_0 ),
        .I4(\bin[13]_INST_0_i_19_n_0 ),
        .I5(\bin[7]_INST_0_i_8_n_0 ),
        .O(\bin[13]_INST_0_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bin[13]_INST_0_i_11 
       (.I0(\bin[13]_INST_0_i_20_n_0 ),
        .I1(bcd3[3]),
        .I2(\bin[13]_INST_0_i_21_n_0 ),
        .O(\bin[13]_INST_0_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hA888888888888080)) 
    \bin[13]_INST_0_i_12 
       (.I0(\bin[8]_INST_0_i_3_n_0 ),
        .I1(\bin[7]_INST_0_i_8_n_0 ),
        .I2(\bin[5]_INST_0_i_3_n_0 ),
        .I3(\bin[5]_INST_0_i_5_n_0 ),
        .I4(\bin[5]_INST_0_i_4_n_0 ),
        .I5(\bin[13]_INST_0_i_19_n_0 ),
        .O(\bin[13]_INST_0_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hEAB9AAB9FFFFFFFF)) 
    \bin[13]_INST_0_i_13 
       (.I0(\bin[7]_INST_0_i_4_n_0 ),
        .I1(\bin[13]_INST_0_i_16_n_0 ),
        .I2(\bin[7]_INST_0_i_3_n_0 ),
        .I3(\bin[7]_INST_0_i_2_n_0 ),
        .I4(\bin[7]_INST_0_i_1_n_0 ),
        .I5(\bin[8]_INST_0_i_1_n_0 ),
        .O(\bin[13]_INST_0_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hA81101777FAAEA00)) 
    \bin[13]_INST_0_i_14 
       (.I0(\bin[13]_INST_0_i_8_n_0 ),
        .I1(\bin[8]_INST_0_i_4_n_0 ),
        .I2(\bin[8]_INST_0_i_5_n_0 ),
        .I3(\bin[8]_INST_0_i_3_n_0 ),
        .I4(\bin[8]_INST_0_i_6_n_0 ),
        .I5(\bin[13]_INST_0_i_11_n_0 ),
        .O(\bin[13]_INST_0_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h545452422AAAAAAA)) 
    \bin[13]_INST_0_i_15 
       (.I0(\bin[13]_INST_0_i_8_n_0 ),
        .I1(\bin[8]_INST_0_i_6_n_0 ),
        .I2(\bin[8]_INST_0_i_3_n_0 ),
        .I3(\bin[8]_INST_0_i_5_n_0 ),
        .I4(\bin[8]_INST_0_i_4_n_0 ),
        .I5(\bin[13]_INST_0_i_11_n_0 ),
        .O(\bin[13]_INST_0_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \bin[13]_INST_0_i_16 
       (.I0(\bin[13]_INST_0_i_22_n_0 ),
        .I1(\bin[5]_INST_0_i_1_n_0 ),
        .O(\bin[13]_INST_0_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hEBABA9A9FFFFFFFF)) 
    \bin[13]_INST_0_i_17 
       (.I0(bcd3[1]),
        .I1(bcd2[3]),
        .I2(bcd3[0]),
        .I3(bcd2[1]),
        .I4(bcd2[2]),
        .I5(bcd3[2]),
        .O(\bin[13]_INST_0_i_17_n_0 ));
  LUT6 #(
    .INIT(64'hA888888888888080)) 
    \bin[13]_INST_0_i_18 
       (.I0(bcd3[2]),
        .I1(bcd3[1]),
        .I2(bcd2[2]),
        .I3(bcd2[1]),
        .I4(bcd3[0]),
        .I5(bcd2[3]),
        .O(\bin[13]_INST_0_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h6666606066600000)) 
    \bin[13]_INST_0_i_19 
       (.I0(bcd3[0]),
        .I1(bcd2[1]),
        .I2(bcd1[2]),
        .I3(bcd1[1]),
        .I4(bcd2[0]),
        .I5(bcd1[3]),
        .O(\bin[13]_INST_0_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bin[13]_INST_0_i_2 
       (.I0(\bin[11]_INST_0_i_2_n_0 ),
        .I1(\bin[11]_INST_0_i_4_n_0 ),
        .I2(\bin[11]_INST_0_i_3_n_0 ),
        .O(\bin[13]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hA81101777FAAEA00)) 
    \bin[13]_INST_0_i_20 
       (.I0(bcd3[2]),
        .I1(bcd2[2]),
        .I2(bcd2[1]),
        .I3(bcd3[0]),
        .I4(bcd2[3]),
        .I5(bcd3[1]),
        .O(\bin[13]_INST_0_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h545452422AAAAAAA)) 
    \bin[13]_INST_0_i_21 
       (.I0(bcd3[2]),
        .I1(bcd2[3]),
        .I2(bcd3[0]),
        .I3(bcd2[1]),
        .I4(bcd2[2]),
        .I5(bcd3[1]),
        .O(\bin[13]_INST_0_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hF666666666666060)) 
    \bin[13]_INST_0_i_22 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(\bin[5]_INST_0_i_5_n_0 ),
        .I2(shifter[17]),
        .I3(shifter[15]),
        .I4(shifter[16]),
        .I5(\bin[7]_INST_0_i_7_n_0 ),
        .O(\bin[13]_INST_0_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bin[13]_INST_0_i_3 
       (.I0(\bin[11]_INST_0_i_4_n_0 ),
        .I1(\bin[13]_INST_0_i_13_n_0 ),
        .I2(\bin[11]_INST_0_i_1_n_0 ),
        .O(\bin[13]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bin[13]_INST_0_i_4 
       (.I0(\bin[13]_INST_0_i_14_n_0 ),
        .I1(p_0_in0),
        .I2(\bin[13]_INST_0_i_15_n_0 ),
        .O(\bin[13]_INST_0_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAAA80000)) 
    \bin[13]_INST_0_i_5 
       (.I0(\bin[8]_INST_0_i_1_n_0 ),
        .I1(\bin[7]_INST_0_i_2_n_0 ),
        .I2(\bin[13]_INST_0_i_16_n_0 ),
        .I3(\bin[7]_INST_0_i_4_n_0 ),
        .I4(\bin[11]_INST_0_i_4_n_0 ),
        .O(\bin[13]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h545452422AAAAAAA)) 
    \bin[13]_INST_0_i_6 
       (.I0(p_0_in0),
        .I1(\bin[13]_INST_0_i_12_n_0 ),
        .I2(\bin[13]_INST_0_i_11_n_0 ),
        .I3(\bin[13]_INST_0_i_10_n_0 ),
        .I4(\bin[13]_INST_0_i_9_n_0 ),
        .I5(\bin[13]_INST_0_i_8_n_0 ),
        .O(\bin[13]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hC4)) 
    \bin[13]_INST_0_i_7 
       (.I0(\bin[13]_INST_0_i_17_n_0 ),
        .I1(bcd3[3]),
        .I2(\bin[13]_INST_0_i_18_n_0 ),
        .O(p_0_in0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \bin[13]_INST_0_i_8 
       (.I0(bcd3[3]),
        .I1(\bin[13]_INST_0_i_17_n_0 ),
        .I2(\bin[13]_INST_0_i_18_n_0 ),
        .O(\bin[13]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h545452422AAAAAAA)) 
    \bin[13]_INST_0_i_9 
       (.I0(\bin[8]_INST_0_i_3_n_0 ),
        .I1(\bin[13]_INST_0_i_19_n_0 ),
        .I2(\bin[5]_INST_0_i_4_n_0 ),
        .I3(\bin[5]_INST_0_i_5_n_0 ),
        .I4(\bin[5]_INST_0_i_3_n_0 ),
        .I5(\bin[7]_INST_0_i_8_n_0 ),
        .O(\bin[13]_INST_0_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[1]_INST_0 
       (.I0(bcd0[1]),
        .I1(bcd1[0]),
        .O(\^bin [1]));
  LUT5 #(
    .INIT(32'h69969696)) 
    \bin[2]_INST_0 
       (.I0(bcd1[1]),
        .I1(bcd2[0]),
        .I2(bcd0[2]),
        .I3(bcd1[0]),
        .I4(bcd0[1]),
        .O(\^bin [2]));
  LUT6 #(
    .INIT(64'h8778788778878778)) 
    \bin[3]_INST_0 
       (.I0(bcd1[1]),
        .I1(bcd2[0]),
        .I2(bcd1[2]),
        .I3(bcd3[0]),
        .I4(bcd2[1]),
        .I5(shifter[15]),
        .O(\^bin [3]));
  LUT6 #(
    .INIT(64'hF6609F9F099F6060)) 
    \bin[3]_INST_0_i_1 
       (.I0(bcd2[0]),
        .I1(bcd1[1]),
        .I2(bcd0[2]),
        .I3(bcd0[1]),
        .I4(bcd1[0]),
        .I5(bcd0[3]),
        .O(shifter[15]));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[4]_INST_0 
       (.I0(\bin[4]_INST_0_i_1_n_0 ),
        .I1(\bin[4]_INST_0_i_2_n_0 ),
        .O(\^bin [4]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h78878778)) 
    \bin[4]_INST_0_i_1 
       (.I0(bcd2[1]),
        .I1(bcd3[0]),
        .I2(bcd2[2]),
        .I3(bcd3[1]),
        .I4(\bin[5]_INST_0_i_5_n_0 ),
        .O(\bin[4]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA801055F7FEAAA00)) 
    \bin[4]_INST_0_i_2 
       (.I0(\bin[7]_INST_0_i_7_n_0 ),
        .I1(bcd0[1]),
        .I2(bcd0[2]),
        .I3(bcd0[3]),
        .I4(bcd1[0]),
        .I5(\bin[4]_INST_0_i_3_n_0 ),
        .O(\bin[4]_INST_0_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[4]_INST_0_i_3 
       (.I0(bcd2[0]),
        .I1(bcd1[1]),
        .O(\bin[4]_INST_0_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[5]_INST_0 
       (.I0(\bin[5]_INST_0_i_1_n_0 ),
        .I1(\bin[5]_INST_0_i_2_n_0 ),
        .O(\^bin [5]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h9666)) 
    \bin[5]_INST_0_i_1 
       (.I0(\bin[7]_INST_0_i_8_n_0 ),
        .I1(\bin[5]_INST_0_i_3_n_0 ),
        .I2(\bin[5]_INST_0_i_4_n_0 ),
        .I3(\bin[5]_INST_0_i_5_n_0 ),
        .O(\bin[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF069690F9696F0F0)) 
    \bin[5]_INST_0_i_2 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(\bin[5]_INST_0_i_5_n_0 ),
        .I2(shifter[17]),
        .I3(shifter[15]),
        .I4(shifter[16]),
        .I5(\bin[7]_INST_0_i_7_n_0 ),
        .O(\bin[5]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h9906900690669666)) 
    \bin[5]_INST_0_i_3 
       (.I0(bcd3[0]),
        .I1(bcd2[1]),
        .I2(bcd1[3]),
        .I3(bcd2[0]),
        .I4(bcd1[1]),
        .I5(bcd1[2]),
        .O(\bin[5]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h9666)) 
    \bin[5]_INST_0_i_4 
       (.I0(bcd3[1]),
        .I1(bcd2[2]),
        .I2(bcd3[0]),
        .I3(bcd2[1]),
        .O(\bin[5]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hF069690F9696F0F0)) 
    \bin[5]_INST_0_i_5 
       (.I0(bcd3[0]),
        .I1(bcd2[1]),
        .I2(bcd1[3]),
        .I3(bcd1[1]),
        .I4(bcd1[2]),
        .I5(bcd2[0]),
        .O(\bin[5]_INST_0_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[6]_INST_0 
       (.I0(\bin[7]_INST_0_i_2_n_0 ),
        .I1(\bin[7]_INST_0_i_1_n_0 ),
        .O(\^bin [6]));
  LUT4 #(
    .INIT(16'h8778)) 
    \bin[7]_INST_0 
       (.I0(\bin[7]_INST_0_i_1_n_0 ),
        .I1(\bin[7]_INST_0_i_2_n_0 ),
        .I2(\bin[7]_INST_0_i_3_n_0 ),
        .I3(\bin[7]_INST_0_i_4_n_0 ),
        .O(\^bin [7]));
  LUT6 #(
    .INIT(64'hA80111777FEAAA00)) 
    \bin[7]_INST_0_i_1 
       (.I0(\bin[5]_INST_0_i_1_n_0 ),
        .I1(shifter[16]),
        .I2(shifter[15]),
        .I3(shifter[17]),
        .I4(\bin[7]_INST_0_i_7_n_0 ),
        .I5(\bin[4]_INST_0_i_1_n_0 ),
        .O(\bin[7]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA81101777FAAEA00)) 
    \bin[7]_INST_0_i_10 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(bcd1[2]),
        .I2(bcd1[1]),
        .I3(bcd2[0]),
        .I4(bcd1[3]),
        .I5(shifter1_out0_out),
        .O(\bin[7]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hA888888888888080)) 
    \bin[7]_INST_0_i_11 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(shifter1_out0_out),
        .I2(bcd1[2]),
        .I3(bcd1[1]),
        .I4(bcd2[0]),
        .I5(bcd1[3]),
        .O(\bin[7]_INST_0_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bin[7]_INST_0_i_12 
       (.I0(bcd3[0]),
        .I1(bcd2[1]),
        .O(shifter1_out0_out));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[7]_INST_0_i_2 
       (.I0(\bin[8]_INST_0_i_3_n_0 ),
        .I1(\bin[8]_INST_0_i_5_n_0 ),
        .O(\bin[7]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h545446422AAAAAAA)) 
    \bin[7]_INST_0_i_3 
       (.I0(\bin[5]_INST_0_i_1_n_0 ),
        .I1(\bin[7]_INST_0_i_7_n_0 ),
        .I2(shifter[16]),
        .I3(shifter[15]),
        .I4(shifter[17]),
        .I5(\bin[4]_INST_0_i_1_n_0 ),
        .O(\bin[7]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h65699A965999A666)) 
    \bin[7]_INST_0_i_4 
       (.I0(\bin[13]_INST_0_i_11_n_0 ),
        .I1(\bin[7]_INST_0_i_8_n_0 ),
        .I2(\bin[7]_INST_0_i_9_n_0 ),
        .I3(\bin[7]_INST_0_i_10_n_0 ),
        .I4(\bin[7]_INST_0_i_11_n_0 ),
        .I5(\bin[8]_INST_0_i_3_n_0 ),
        .O(\bin[7]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h9096960690069666)) 
    \bin[7]_INST_0_i_5 
       (.I0(bcd2[0]),
        .I1(bcd1[1]),
        .I2(bcd1[0]),
        .I3(bcd0[3]),
        .I4(bcd0[2]),
        .I5(bcd0[1]),
        .O(shifter[16]));
  LUT6 #(
    .INIT(64'h6666666066000000)) 
    \bin[7]_INST_0_i_6 
       (.I0(bcd2[0]),
        .I1(bcd1[1]),
        .I2(bcd0[1]),
        .I3(bcd0[2]),
        .I4(bcd0[3]),
        .I5(bcd1[0]),
        .O(shifter[17]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h69969696)) 
    \bin[7]_INST_0_i_7 
       (.I0(bcd2[1]),
        .I1(bcd3[0]),
        .I2(bcd1[2]),
        .I3(bcd2[0]),
        .I4(bcd1[1]),
        .O(\bin[7]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h65699A965999A666)) 
    \bin[7]_INST_0_i_8 
       (.I0(bcd3[2]),
        .I1(bcd3[0]),
        .I2(bcd2[2]),
        .I3(bcd2[1]),
        .I4(bcd2[3]),
        .I5(bcd3[1]),
        .O(\bin[7]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h545452422AAAAAAA)) 
    \bin[7]_INST_0_i_9 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(bcd1[3]),
        .I2(bcd2[0]),
        .I3(bcd1[1]),
        .I4(bcd1[2]),
        .I5(shifter1_out0_out),
        .O(\bin[7]_INST_0_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[8]_INST_0 
       (.I0(\bin[8]_INST_0_i_1_n_0 ),
        .I1(\bin[8]_INST_0_i_2_n_0 ),
        .O(\^bin [8]));
  LUT6 #(
    .INIT(64'h65699A965999A666)) 
    \bin[8]_INST_0_i_1 
       (.I0(\bin[13]_INST_0_i_8_n_0 ),
        .I1(\bin[8]_INST_0_i_3_n_0 ),
        .I2(\bin[8]_INST_0_i_4_n_0 ),
        .I3(\bin[8]_INST_0_i_5_n_0 ),
        .I4(\bin[8]_INST_0_i_6_n_0 ),
        .I5(\bin[13]_INST_0_i_11_n_0 ),
        .O(\bin[8]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hA80111777FEAAA00)) 
    \bin[8]_INST_0_i_2 
       (.I0(\bin[7]_INST_0_i_4_n_0 ),
        .I1(\bin[8]_INST_0_i_7_n_0 ),
        .I2(\bin[5]_INST_0_i_2_n_0 ),
        .I3(\bin[8]_INST_0_i_8_n_0 ),
        .I4(\bin[5]_INST_0_i_1_n_0 ),
        .I5(\bin[7]_INST_0_i_2_n_0 ),
        .O(\bin[8]_INST_0_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bin[8]_INST_0_i_3 
       (.I0(bcd3[3]),
        .I1(\bin[13]_INST_0_i_20_n_0 ),
        .O(\bin[8]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h52424A6A)) 
    \bin[8]_INST_0_i_4 
       (.I0(\bin[7]_INST_0_i_8_n_0 ),
        .I1(\bin[13]_INST_0_i_19_n_0 ),
        .I2(\bin[5]_INST_0_i_4_n_0 ),
        .I3(\bin[5]_INST_0_i_5_n_0 ),
        .I4(\bin[5]_INST_0_i_3_n_0 ),
        .O(\bin[8]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hC99366CC)) 
    \bin[8]_INST_0_i_5 
       (.I0(\bin[7]_INST_0_i_8_n_0 ),
        .I1(\bin[13]_INST_0_i_19_n_0 ),
        .I2(\bin[5]_INST_0_i_5_n_0 ),
        .I3(\bin[5]_INST_0_i_3_n_0 ),
        .I4(\bin[5]_INST_0_i_4_n_0 ),
        .O(\bin[8]_INST_0_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hAA88A800)) 
    \bin[8]_INST_0_i_6 
       (.I0(\bin[7]_INST_0_i_8_n_0 ),
        .I1(\bin[5]_INST_0_i_3_n_0 ),
        .I2(\bin[5]_INST_0_i_5_n_0 ),
        .I3(\bin[5]_INST_0_i_4_n_0 ),
        .I4(\bin[13]_INST_0_i_19_n_0 ),
        .O(\bin[8]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h9096900696069666)) 
    \bin[8]_INST_0_i_7 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(\bin[5]_INST_0_i_5_n_0 ),
        .I2(\bin[7]_INST_0_i_7_n_0 ),
        .I3(shifter[17]),
        .I4(shifter[15]),
        .I5(shifter[16]),
        .O(\bin[8]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h6666666060600000)) 
    \bin[8]_INST_0_i_8 
       (.I0(\bin[5]_INST_0_i_4_n_0 ),
        .I1(\bin[5]_INST_0_i_5_n_0 ),
        .I2(shifter[16]),
        .I3(shifter[15]),
        .I4(shifter[17]),
        .I5(\bin[7]_INST_0_i_7_n_0 ),
        .O(\bin[8]_INST_0_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bin[9]_INST_0 
       (.I0(\bin[11]_INST_0_i_4_n_0 ),
        .I1(\bin[11]_INST_0_i_2_n_0 ),
        .O(\^bin [9]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
