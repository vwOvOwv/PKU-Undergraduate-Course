module BCD2bin(
  input logic [3:0] bcd3,
  input logic [3:0] bcd2,
  input logic [3:0] bcd1,
  input logic [3:0] bcd0, 
  output logic [13:0] bin
  ); 
  
  logic [29:0] shifter; 
  integer i;
 
  always_comb
  begin 
    shifter[13:0] = 0;
    shifter[29:14] = {bcd3, bcd2, bcd1, bcd0}; 
    
    for (i = 0; i< 14; i = i+1) 
    begin 
      shifter = shifter  >> 1;    

      if (shifter[17:14] >= 8) 
        shifter[17:14] = shifter[17:14] - 3; 

      if (shifter[21:18] >= 8)             
        shifter[21:18] = shifter[21:18] - 3;

      if (shifter[25:22] >= 8)             
        shifter[25:22] = shifter[25:22] - 3;

      if (shifter[29:26] >= 8)              
        shifter[29:26] = shifter[29:26] - 3; 
    end  
  end

  assign  bin = shifter[13:0];
endmodule
