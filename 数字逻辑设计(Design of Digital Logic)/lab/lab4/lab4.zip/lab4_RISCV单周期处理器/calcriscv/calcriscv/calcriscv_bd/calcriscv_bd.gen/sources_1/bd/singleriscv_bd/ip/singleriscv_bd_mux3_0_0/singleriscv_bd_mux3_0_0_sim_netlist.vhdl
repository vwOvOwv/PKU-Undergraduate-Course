-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Fri Jun  3 06:26:22 2022
-- Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top singleriscv_bd_mux3_0_0 -prefix
--               singleriscv_bd_mux3_0_0_ singleriscv_bd_mux3_0_0_sim_netlist.vhdl
-- Design      : singleriscv_bd_mux3_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_mux3_0_0_mux3 is
  port (
    y : out STD_LOGIC_VECTOR ( 31 downto 0 );
    d2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    d1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d0 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end singleriscv_bd_mux3_0_0_mux3;

architecture STRUCTURE of singleriscv_bd_mux3_0_0_mux3 is
begin
\y[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(0),
      I1 => s(1),
      I2 => d1(0),
      I3 => s(0),
      I4 => d0(0),
      O => y(0)
    );
\y[10]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(10),
      I1 => s(1),
      I2 => d1(10),
      I3 => s(0),
      I4 => d0(10),
      O => y(10)
    );
\y[11]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(11),
      I1 => s(1),
      I2 => d1(11),
      I3 => s(0),
      I4 => d0(11),
      O => y(11)
    );
\y[12]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(12),
      I1 => s(1),
      I2 => d1(12),
      I3 => s(0),
      I4 => d0(12),
      O => y(12)
    );
\y[13]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(13),
      I1 => s(1),
      I2 => d1(13),
      I3 => s(0),
      I4 => d0(13),
      O => y(13)
    );
\y[14]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(14),
      I1 => s(1),
      I2 => d1(14),
      I3 => s(0),
      I4 => d0(14),
      O => y(14)
    );
\y[15]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(15),
      I1 => s(1),
      I2 => d1(15),
      I3 => s(0),
      I4 => d0(15),
      O => y(15)
    );
\y[16]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(16),
      I1 => s(1),
      I2 => d1(16),
      I3 => s(0),
      I4 => d0(16),
      O => y(16)
    );
\y[17]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(17),
      I1 => s(1),
      I2 => d1(17),
      I3 => s(0),
      I4 => d0(17),
      O => y(17)
    );
\y[18]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(18),
      I1 => s(1),
      I2 => d1(18),
      I3 => s(0),
      I4 => d0(18),
      O => y(18)
    );
\y[19]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(19),
      I1 => s(1),
      I2 => d1(19),
      I3 => s(0),
      I4 => d0(19),
      O => y(19)
    );
\y[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(1),
      I1 => s(1),
      I2 => d1(1),
      I3 => s(0),
      I4 => d0(1),
      O => y(1)
    );
\y[20]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(20),
      I1 => s(1),
      I2 => d1(20),
      I3 => s(0),
      I4 => d0(20),
      O => y(20)
    );
\y[21]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(21),
      I1 => s(1),
      I2 => d1(21),
      I3 => s(0),
      I4 => d0(21),
      O => y(21)
    );
\y[22]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(22),
      I1 => s(1),
      I2 => d1(22),
      I3 => s(0),
      I4 => d0(22),
      O => y(22)
    );
\y[23]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(23),
      I1 => s(1),
      I2 => d1(23),
      I3 => s(0),
      I4 => d0(23),
      O => y(23)
    );
\y[24]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(24),
      I1 => s(1),
      I2 => d1(24),
      I3 => s(0),
      I4 => d0(24),
      O => y(24)
    );
\y[25]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(25),
      I1 => s(1),
      I2 => d1(25),
      I3 => s(0),
      I4 => d0(25),
      O => y(25)
    );
\y[26]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(26),
      I1 => s(1),
      I2 => d1(26),
      I3 => s(0),
      I4 => d0(26),
      O => y(26)
    );
\y[27]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(27),
      I1 => s(1),
      I2 => d1(27),
      I3 => s(0),
      I4 => d0(27),
      O => y(27)
    );
\y[28]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(28),
      I1 => s(1),
      I2 => d1(28),
      I3 => s(0),
      I4 => d0(28),
      O => y(28)
    );
\y[29]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(29),
      I1 => s(1),
      I2 => d1(29),
      I3 => s(0),
      I4 => d0(29),
      O => y(29)
    );
\y[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(2),
      I1 => s(1),
      I2 => d1(2),
      I3 => s(0),
      I4 => d0(2),
      O => y(2)
    );
\y[30]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(30),
      I1 => s(1),
      I2 => d1(30),
      I3 => s(0),
      I4 => d0(30),
      O => y(30)
    );
\y[31]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(31),
      I1 => s(1),
      I2 => d1(31),
      I3 => s(0),
      I4 => d0(31),
      O => y(31)
    );
\y[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(3),
      I1 => s(1),
      I2 => d1(3),
      I3 => s(0),
      I4 => d0(3),
      O => y(3)
    );
\y[4]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(4),
      I1 => s(1),
      I2 => d1(4),
      I3 => s(0),
      I4 => d0(4),
      O => y(4)
    );
\y[5]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(5),
      I1 => s(1),
      I2 => d1(5),
      I3 => s(0),
      I4 => d0(5),
      O => y(5)
    );
\y[6]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(6),
      I1 => s(1),
      I2 => d1(6),
      I3 => s(0),
      I4 => d0(6),
      O => y(6)
    );
\y[7]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(7),
      I1 => s(1),
      I2 => d1(7),
      I3 => s(0),
      I4 => d0(7),
      O => y(7)
    );
\y[8]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(8),
      I1 => s(1),
      I2 => d1(8),
      I3 => s(0),
      I4 => d0(8),
      O => y(8)
    );
\y[9]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => d2(9),
      I1 => s(1),
      I2 => d1(9),
      I3 => s(0),
      I4 => d0(9),
      O => y(9)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity singleriscv_bd_mux3_0_0 is
  port (
    d0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    d2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    y : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of singleriscv_bd_mux3_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of singleriscv_bd_mux3_0_0 : entity is "singleriscv_bd_mux3_0_0,mux3,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of singleriscv_bd_mux3_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of singleriscv_bd_mux3_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of singleriscv_bd_mux3_0_0 : entity is "mux3,Vivado 2020.2";
end singleriscv_bd_mux3_0_0;

architecture STRUCTURE of singleriscv_bd_mux3_0_0 is
begin
inst: entity work.singleriscv_bd_mux3_0_0_mux3
     port map (
      d0(31 downto 0) => d0(31 downto 0),
      d1(31 downto 0) => d1(31 downto 0),
      d2(31 downto 0) => d2(31 downto 0),
      s(1 downto 0) => s(1 downto 0),
      y(31 downto 0) => y(31 downto 0)
    );
end STRUCTURE;
