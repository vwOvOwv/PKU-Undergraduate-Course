// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:23:05 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top singleriscv_bd_extend_0_0 -prefix
//               singleriscv_bd_extend_0_0_ singleriscv_bd_extend_0_0_stub.v
// Design      : singleriscv_bd_extend_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "extend,Vivado 2020.2" *)
module singleriscv_bd_extend_0_0(instr, immsrc, utype, immext)
/* synthesis syn_black_box black_box_pad_pin="instr[31:7],immsrc[1:0],utype,immext[31:0]" */;
  input [31:7]instr;
  input [1:0]immsrc;
  input utype;
  output [31:0]immext;
endmodule
