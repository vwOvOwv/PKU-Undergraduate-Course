// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Fri Jun  3 06:23:05 2022
// Host        : DESKTOP-Q9VOCDI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top singleriscv_bd_extend_0_0 -prefix
//               singleriscv_bd_extend_0_0_ singleriscv_bd_extend_0_0_sim_netlist.v
// Design      : singleriscv_bd_extend_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module singleriscv_bd_extend_0_0_extend
   (immext,
    immsrc,
    instr,
    utype);
  output [30:0]immext;
  input [1:0]immsrc;
  input [31:7]instr;
  input utype;

  wire [30:0]immext;
  wire [1:0]immsrc;
  wire [31:7]instr;
  wire utype;

  LUT5 #(
    .INIT(32'h00005404)) 
    \immext[0]_INST_0 
       (.I0(immsrc[1]),
        .I1(instr[20]),
        .I2(immsrc[0]),
        .I3(instr[7]),
        .I4(utype),
        .O(immext[0]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \immext[10]_INST_0 
       (.I0(instr[30]),
        .I1(utype),
        .O(immext[10]));
  LUT6 #(
    .INIT(64'h00000000E2FFE200)) 
    \immext[11]_INST_0 
       (.I0(instr[7]),
        .I1(immsrc[0]),
        .I2(instr[20]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .I5(utype),
        .O(immext[11]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[12]_INST_0 
       (.I0(utype),
        .I1(instr[12]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[12]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[13]_INST_0 
       (.I0(utype),
        .I1(instr[13]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[13]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[14]_INST_0 
       (.I0(utype),
        .I1(instr[14]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[14]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[15]_INST_0 
       (.I0(utype),
        .I1(instr[15]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[15]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[16]_INST_0 
       (.I0(utype),
        .I1(instr[16]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[16]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[17]_INST_0 
       (.I0(utype),
        .I1(instr[17]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[17]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[18]_INST_0 
       (.I0(utype),
        .I1(instr[18]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[18]));
  LUT5 #(
    .INIT(32'hCDDDC888)) 
    \immext[19]_INST_0 
       (.I0(utype),
        .I1(instr[19]),
        .I2(immsrc[0]),
        .I3(immsrc[1]),
        .I4(instr[31]),
        .O(immext[19]));
  LUT5 #(
    .INIT(32'h0000B8E2)) 
    \immext[1]_INST_0 
       (.I0(instr[21]),
        .I1(immsrc[1]),
        .I2(instr[8]),
        .I3(immsrc[0]),
        .I4(utype),
        .O(immext[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[20]_INST_0 
       (.I0(instr[20]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[20]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[21]_INST_0 
       (.I0(instr[21]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[21]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[22]_INST_0 
       (.I0(instr[22]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[22]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[23]_INST_0 
       (.I0(instr[23]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[23]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[24]_INST_0 
       (.I0(instr[24]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[24]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[25]_INST_0 
       (.I0(instr[25]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[25]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[26]_INST_0 
       (.I0(instr[26]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[26]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[27]_INST_0 
       (.I0(instr[27]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[27]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[28]_INST_0 
       (.I0(instr[28]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[28]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[29]_INST_0 
       (.I0(instr[29]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[29]));
  LUT5 #(
    .INIT(32'h0000B8E2)) 
    \immext[2]_INST_0 
       (.I0(instr[22]),
        .I1(immsrc[1]),
        .I2(instr[9]),
        .I3(immsrc[0]),
        .I4(utype),
        .O(immext[2]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \immext[30]_INST_0 
       (.I0(instr[30]),
        .I1(utype),
        .I2(instr[31]),
        .O(immext[30]));
  LUT5 #(
    .INIT(32'h0000B8E2)) 
    \immext[3]_INST_0 
       (.I0(instr[23]),
        .I1(immsrc[1]),
        .I2(instr[10]),
        .I3(immsrc[0]),
        .I4(utype),
        .O(immext[3]));
  LUT5 #(
    .INIT(32'h0000B8E2)) 
    \immext[4]_INST_0 
       (.I0(instr[24]),
        .I1(immsrc[1]),
        .I2(instr[11]),
        .I3(immsrc[0]),
        .I4(utype),
        .O(immext[4]));
  LUT2 #(
    .INIT(4'h2)) 
    \immext[5]_INST_0 
       (.I0(instr[25]),
        .I1(utype),
        .O(immext[5]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \immext[6]_INST_0 
       (.I0(instr[26]),
        .I1(utype),
        .O(immext[6]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \immext[7]_INST_0 
       (.I0(instr[27]),
        .I1(utype),
        .O(immext[7]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \immext[8]_INST_0 
       (.I0(instr[28]),
        .I1(utype),
        .O(immext[8]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \immext[9]_INST_0 
       (.I0(instr[29]),
        .I1(utype),
        .O(immext[9]));
endmodule

(* CHECK_LICENSE_TYPE = "singleriscv_bd_extend_0_0,extend,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "extend,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module singleriscv_bd_extend_0_0
   (instr,
    immsrc,
    utype,
    immext);
  input [31:7]instr;
  input [1:0]immsrc;
  input utype;
  output [31:0]immext;

  wire [30:0]\^immext ;
  wire [1:0]immsrc;
  wire [31:7]instr;
  wire utype;

  assign immext[31] = instr[31];
  assign immext[30:0] = \^immext [30:0];
  singleriscv_bd_extend_0_0_extend inst
       (.immext(\^immext ),
        .immsrc(immsrc),
        .instr(instr),
        .utype(utype));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
