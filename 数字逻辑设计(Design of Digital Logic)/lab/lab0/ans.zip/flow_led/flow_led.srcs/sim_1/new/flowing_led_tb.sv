`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/06 14:40:20
// Design Name: 
// Module Name: flowing_led_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module flowing_led_tb(

    );
logic clk;
logic rst;
logic[3:0]led;
flowing_led u0(
.clk(clk),
.rst(rst),
.led(led));
parameter PERIOD = 10;
always begin
clk = 1'b0;
#(PERIOD/2) clk = 1'b1;
#(PERIOD/2);
end
initial begin
clk = 1'b0;
rst = 1'b0;
#100;
rst = 1'b1;
#100;
rst = 1'b0;
end
endmodule
