`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/06 14:05:01
// Design Name: 
// Module Name: flowing_led
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module flowing_led(
    input clk,
    input rst,
    output [15:0] led
    );
    
    logic[23:0]cnt_reg;
    logic[15:0]light_reg;
    
    always_ff@(posedge clk)
        begin
            if(rst)
                cnt_reg<=0;
            else
                cnt_reg<=cnt_reg+1;
        end
    
    always_ff@(posedge clk)
        begin
            if(rst)
                light_reg<=16'h0001;
            else if(cnt_reg==24'hffffff)
                begin
                    if(light_reg == 16'h8000)
                        light_reg<=16'h0001;
                    else
                        light_reg<=light_reg<<1;
                end
        end
    
    assign led = light_reg;
    
endmodule
