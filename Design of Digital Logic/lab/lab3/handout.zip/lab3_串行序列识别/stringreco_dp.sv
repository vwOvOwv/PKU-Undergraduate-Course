module stringreco_dp (
    input  logic clk_fsm, 
    input  logic clr_bnt, en_bnt,
    input  logic fsm_en, count_en,
    input  logic [15:0] sw,
    output logic [15:0] count
    );
    
    logic [15:0] shifter;
    
    //16-bit left-shifter
    always_ff @(posedge clk_fsm)
    begin
      if (clr_bnt) shifter <= 0;
      else if (en_bnt) shifter <= sw;
      else if (fsm_en) shifter <= {shifter[14:0], 1'b0};
    end
    
    //string recognization
    stringreco_fsm u_stringreco_fsm(
	.Clk(clk_fsm), 
	.X(shifter[15]),
	.Reset(clr_bnt), 
	.Enable(fsm_en),
	.Z(reco)
    );
    
    // 16-bit count output
    always_ff @(posedge clk_fsm)
    begin
      if (clr_bnt) count <= 0;
      else if (reco && count_en) count <= count + 1;
    end
endmodule

// Synchronous Mealy FSM
module stringreco_fsm(
	input logic Clk, Reset, Enable,
	input logic X,
	output logic Z
	);
    
    // �޸�״̬����
    typedef enum logic [2:0] {S0, S1, S2, S3, S4, S5, S6} statetype;
    statetype state, nextstate;
    logic Z_mealy;

    always_ff @(posedge Clk) begin
        if (Reset) begin
            state = S0;
            Z = 0;
        end 
        else if (Enable) begin
            state = nextstate;
            Z = Z_mealy;
        end
    end

    always_comb begin
        case (state)
	    S0: begin 	
	            if (X) begin nextstate <= S2; Z_mealy <= 0; end
	            else begin nextstate <= S1; Z_mealy <= 0; end
		end
	//  ���������״̬�����
	
        default:;
        endcase
    end
endmodule
