onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+stopwatch_lpy -L xil_defaultlib -L xlconcat_v2_1_4 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.stopwatch_lpy xil_defaultlib.glbl

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure

do {stopwatch_lpy.udo}

run -all

endsim

quit -force
