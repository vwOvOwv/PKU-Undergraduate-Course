vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/xlconcat_v2_1_4

vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap xlconcat_v2_1_4 modelsim_lib/msim/xlconcat_v2_1_4

vlog -work xil_defaultlib  -incr -mfcu -sv \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ipshared/86b3/clk_div_lpy.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_clk_div_lpy_0_0/sim/stopwatch_lpy_clk_div_lpy_0_0.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ipshared/c482/display_7seg_x4_lpy.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_display_7seg_x4_lpy_0_0/sim/stopwatch_lpy_display_7seg_x4_lpy_0_0.sv" \

vlog -work xlconcat_v2_1_4  -incr -mfcu \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ipshared/4b67/hdl/xlconcat_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -incr -mfcu \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_xlconcat_0_0/sim/stopwatch_lpy_xlconcat_0_0.v" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_xlconcat_0_1/sim/stopwatch_lpy_xlconcat_0_1.v" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_xlconcat_1_0/sim/stopwatch_lpy_xlconcat_1_0.v" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_xlconcat_2_0/sim/stopwatch_lpy_xlconcat_2_0.v" \

vlog -work xil_defaultlib  -incr -mfcu -sv \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ipshared/eaeb/counter163_lpy.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_counter163_lpy_0_0/sim/stopwatch_lpy_counter163_lpy_0_0.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_counter163_lpy_0_1/sim/stopwatch_lpy_counter163_lpy_0_1.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_counter163_lpy_0_2/sim/stopwatch_lpy_counter163_lpy_0_2.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_counter163_lpy_0_3/sim/stopwatch_lpy_counter163_lpy_0_3.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_clk_div_lpy_1_0/sim/stopwatch_lpy_clk_div_lpy_1_0.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ipshared/e6bb/stopwatch_ctrl_lpy.sv" \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_stopwatch_ctrl_lpy_0_0/sim/stopwatch_lpy_stopwatch_ctrl_lpy_0_0.sv" \

vlog -work xil_defaultlib  -incr -mfcu \
"../../../../stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/sim/stopwatch_lpy.v" \

vlog -work xil_defaultlib \
"glbl.v"

