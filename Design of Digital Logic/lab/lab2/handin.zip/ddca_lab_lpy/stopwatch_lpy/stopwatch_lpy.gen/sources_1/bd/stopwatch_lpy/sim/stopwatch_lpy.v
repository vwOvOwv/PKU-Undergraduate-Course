//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
//Date        : Tue Apr 29 13:45:19 2025
//Host        : A14 running 64-bit major release  (build 9200)
//Command     : generate_target stopwatch_lpy.bd
//Design      : stopwatch_lpy
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "stopwatch_lpy,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=stopwatch_lpy,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=12,numReposBlks=12,numNonXlnxBlks=8,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "stopwatch_lpy.hwdef" *) 
module stopwatch_lpy
   (an,
    btnC,
    btnD,
    clk,
    seg);
  output [0:3]an;
  input btnC;
  input btnD;
  input clk;
  output [0:6]seg;

  wire btnC_0_1;
  wire btnD_0_1;
  wire clk_100MHz_lpy_0_1;
  wire clk_div_lpy_0_clk_sys_lpy;
  wire clk_div_lpy_1_clk_sys_lpy;
  wire counter163_lpy_0_QA_lpy;
  wire counter163_lpy_0_QB_lpy;
  wire counter163_lpy_0_QC_lpy;
  wire counter163_lpy_0_QD_lpy;
  wire counter163_lpy_1_QA_lpy;
  wire counter163_lpy_1_QB_lpy;
  wire counter163_lpy_1_QC_lpy;
  wire counter163_lpy_1_QD_lpy;
  wire counter163_lpy_2_QA_lpy;
  wire counter163_lpy_2_QB_lpy;
  wire counter163_lpy_2_QC_lpy;
  wire counter163_lpy_2_QD_lpy;
  wire counter163_lpy_3_QA_lpy;
  wire counter163_lpy_3_QB_lpy;
  wire counter163_lpy_3_QC_lpy;
  wire counter163_lpy_3_QD_lpy;
  wire [0:3]display_7seg_x4_lpy_0_an_lpy;
  wire [0:6]display_7seg_x4_lpy_0_seg_lpy;
  wire stopwatch_ctrl_lpy_0_min1_clr;
  wire stopwatch_ctrl_lpy_0_min1_en;
  wire stopwatch_ctrl_lpy_0_min1_load;
  wire stopwatch_ctrl_lpy_0_ms100_clr;
  wire stopwatch_ctrl_lpy_0_ms100_en;
  wire stopwatch_ctrl_lpy_0_ms100_load;
  wire stopwatch_ctrl_lpy_0_sec10_clr;
  wire stopwatch_ctrl_lpy_0_sec10_en;
  wire stopwatch_ctrl_lpy_0_sec10_load;
  wire stopwatch_ctrl_lpy_0_sec1_clr;
  wire stopwatch_ctrl_lpy_0_sec1_en;
  wire stopwatch_ctrl_lpy_0_sec1_load;
  wire [3:0]xlconcat_0_dout;
  wire [3:0]xlconcat_1_dout;
  wire [3:0]xlconcat_2_dout;
  wire [3:0]xlconcat_3_dout;

  assign an[0:3] = display_7seg_x4_lpy_0_an_lpy;
  assign btnC_0_1 = btnC;
  assign btnD_0_1 = btnD;
  assign clk_100MHz_lpy_0_1 = clk;
  assign seg[0:6] = display_7seg_x4_lpy_0_seg_lpy;
  stopwatch_lpy_clk_div_lpy_0_0 clk_div_lpy_0
       (.clk_100MHz_lpy(clk_100MHz_lpy_0_1),
        .clk_sys_lpy(clk_div_lpy_0_clk_sys_lpy));
  stopwatch_lpy_clk_div_lpy_1_0 clk_div_lpy_1
       (.clk_100MHz_lpy(clk_100MHz_lpy_0_1),
        .clk_sys_lpy(clk_div_lpy_1_clk_sys_lpy));
  stopwatch_lpy_counter163_lpy_0_0 counter163_lpy_0
       (.A_lpy(1'b0),
        .B_lpy(1'b0),
        .CLK_lpy(clk_div_lpy_1_clk_sys_lpy),
        .CLR_lpy(stopwatch_ctrl_lpy_0_ms100_clr),
        .C_lpy(1'b0),
        .D_lpy(1'b0),
        .EN_lpy(stopwatch_ctrl_lpy_0_ms100_en),
        .LOAD_lpy(stopwatch_ctrl_lpy_0_ms100_load),
        .QA_lpy(counter163_lpy_0_QA_lpy),
        .QB_lpy(counter163_lpy_0_QB_lpy),
        .QC_lpy(counter163_lpy_0_QC_lpy),
        .QD_lpy(counter163_lpy_0_QD_lpy));
  stopwatch_lpy_counter163_lpy_0_1 counter163_lpy_1
       (.A_lpy(1'b0),
        .B_lpy(1'b0),
        .CLK_lpy(clk_div_lpy_1_clk_sys_lpy),
        .CLR_lpy(stopwatch_ctrl_lpy_0_sec1_clr),
        .C_lpy(1'b0),
        .D_lpy(1'b0),
        .EN_lpy(stopwatch_ctrl_lpy_0_sec1_en),
        .LOAD_lpy(stopwatch_ctrl_lpy_0_sec1_load),
        .QA_lpy(counter163_lpy_1_QA_lpy),
        .QB_lpy(counter163_lpy_1_QB_lpy),
        .QC_lpy(counter163_lpy_1_QC_lpy),
        .QD_lpy(counter163_lpy_1_QD_lpy));
  stopwatch_lpy_counter163_lpy_0_2 counter163_lpy_2
       (.A_lpy(1'b0),
        .B_lpy(1'b0),
        .CLK_lpy(clk_div_lpy_1_clk_sys_lpy),
        .CLR_lpy(stopwatch_ctrl_lpy_0_sec10_clr),
        .C_lpy(1'b0),
        .D_lpy(1'b0),
        .EN_lpy(stopwatch_ctrl_lpy_0_sec10_en),
        .LOAD_lpy(stopwatch_ctrl_lpy_0_sec10_load),
        .QA_lpy(counter163_lpy_2_QA_lpy),
        .QB_lpy(counter163_lpy_2_QB_lpy),
        .QC_lpy(counter163_lpy_2_QC_lpy),
        .QD_lpy(counter163_lpy_2_QD_lpy));
  stopwatch_lpy_counter163_lpy_0_3 counter163_lpy_3
       (.A_lpy(1'b0),
        .B_lpy(1'b0),
        .CLK_lpy(clk_div_lpy_1_clk_sys_lpy),
        .CLR_lpy(stopwatch_ctrl_lpy_0_min1_clr),
        .C_lpy(1'b0),
        .D_lpy(1'b0),
        .EN_lpy(stopwatch_ctrl_lpy_0_min1_en),
        .LOAD_lpy(stopwatch_ctrl_lpy_0_min1_load),
        .QA_lpy(counter163_lpy_3_QA_lpy),
        .QB_lpy(counter163_lpy_3_QB_lpy),
        .QC_lpy(counter163_lpy_3_QC_lpy),
        .QD_lpy(counter163_lpy_3_QD_lpy));
  stopwatch_lpy_display_7seg_x4_lpy_0_0 display_7seg_x4_lpy_0
       (.CLK_1KHz_lpy(clk_div_lpy_0_clk_sys_lpy),
        .an_lpy(display_7seg_x4_lpy_0_an_lpy),
        .in0_lpy(xlconcat_0_dout),
        .in1_lpy(xlconcat_1_dout),
        .in2_lpy(xlconcat_2_dout),
        .in3_lpy(xlconcat_3_dout),
        .seg_lpy(display_7seg_x4_lpy_0_seg_lpy));
  stopwatch_lpy_stopwatch_ctrl_lpy_0_0 stopwatch_ctrl_lpy_0
       (.btnC(btnC_0_1),
        .btnD(btnD_0_1),
        .clk_10Hz(clk_div_lpy_1_clk_sys_lpy),
        .min1_clr(stopwatch_ctrl_lpy_0_min1_clr),
        .min1_cnt(xlconcat_3_dout),
        .min1_en(stopwatch_ctrl_lpy_0_min1_en),
        .min1_load(stopwatch_ctrl_lpy_0_min1_load),
        .ms100_clr(stopwatch_ctrl_lpy_0_ms100_clr),
        .ms100_cnt(xlconcat_0_dout),
        .ms100_en(stopwatch_ctrl_lpy_0_ms100_en),
        .ms100_load(stopwatch_ctrl_lpy_0_ms100_load),
        .sec10_clr(stopwatch_ctrl_lpy_0_sec10_clr),
        .sec10_cnt(xlconcat_2_dout),
        .sec10_en(stopwatch_ctrl_lpy_0_sec10_en),
        .sec10_load(stopwatch_ctrl_lpy_0_sec10_load),
        .sec1_clr(stopwatch_ctrl_lpy_0_sec1_clr),
        .sec1_cnt(xlconcat_1_dout),
        .sec1_en(stopwatch_ctrl_lpy_0_sec1_en),
        .sec1_load(stopwatch_ctrl_lpy_0_sec1_load));
  stopwatch_lpy_xlconcat_0_0 xlconcat_0
       (.In0(counter163_lpy_0_QA_lpy),
        .In1(counter163_lpy_0_QB_lpy),
        .In2(counter163_lpy_0_QC_lpy),
        .In3(counter163_lpy_0_QD_lpy),
        .dout(xlconcat_0_dout));
  stopwatch_lpy_xlconcat_0_1 xlconcat_1
       (.In0(counter163_lpy_1_QA_lpy),
        .In1(counter163_lpy_1_QB_lpy),
        .In2(counter163_lpy_1_QC_lpy),
        .In3(counter163_lpy_1_QD_lpy),
        .dout(xlconcat_1_dout));
  stopwatch_lpy_xlconcat_1_0 xlconcat_2
       (.In0(counter163_lpy_2_QA_lpy),
        .In1(counter163_lpy_2_QB_lpy),
        .In2(counter163_lpy_2_QC_lpy),
        .In3(counter163_lpy_2_QD_lpy),
        .dout(xlconcat_2_dout));
  stopwatch_lpy_xlconcat_2_0 xlconcat_3
       (.In0(counter163_lpy_3_QA_lpy),
        .In1(counter163_lpy_3_QB_lpy),
        .In2(counter163_lpy_3_QC_lpy),
        .In3(counter163_lpy_3_QD_lpy),
        .dout(xlconcat_3_dout));
endmodule
