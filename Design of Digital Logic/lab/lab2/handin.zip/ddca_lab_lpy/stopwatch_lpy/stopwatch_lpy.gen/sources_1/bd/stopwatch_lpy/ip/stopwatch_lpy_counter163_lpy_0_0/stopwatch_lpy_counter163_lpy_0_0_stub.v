// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Tue Apr 29 13:45:50 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/22426/Desktop/ddca_lab_lpy/stopwatch_lpy/stopwatch_lpy.gen/sources_1/bd/stopwatch_lpy/ip/stopwatch_lpy_counter163_lpy_0_0/stopwatch_lpy_counter163_lpy_0_0_stub.v
// Design      : stopwatch_lpy_counter163_lpy_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "counter163_lpy,Vivado 2022.1.2" *)
module stopwatch_lpy_counter163_lpy_0_0(EN_lpy, D_lpy, C_lpy, B_lpy, A_lpy, LOAD_lpy, 
  CLK_lpy, CLR_lpy, ECO_lpy, QD_lpy, QC_lpy, QB_lpy, QA_lpy)
/* synthesis syn_black_box black_box_pad_pin="EN_lpy,D_lpy,C_lpy,B_lpy,A_lpy,LOAD_lpy,CLK_lpy,CLR_lpy,ECO_lpy,QD_lpy,QC_lpy,QB_lpy,QA_lpy" */;
  input EN_lpy;
  input D_lpy;
  input C_lpy;
  input B_lpy;
  input A_lpy;
  input LOAD_lpy;
  input CLK_lpy;
  input CLR_lpy;
  output ECO_lpy;
  output QD_lpy;
  output QC_lpy;
  output QB_lpy;
  output QA_lpy;
endmodule
