// (c) Copyright 1995-2025 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: cs.pku.edu.cn:DDCA:stopwatch_ctrl_lpy:1.0
// IP Revision: 2

(* X_CORE_INFO = "stopwatch_ctrl_lpy,Vivado 2022.1.2" *)
(* CHECK_LICENSE_TYPE = "stopwatch_lpy_stopwatch_ctrl_lpy_0_0,stopwatch_ctrl_lpy,{}" *)
(* IP_DEFINITION_SOURCE = "package_project" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module stopwatch_lpy_stopwatch_ctrl_lpy_0_0 (
  clk_10Hz,
  btnC,
  btnD,
  min1_cnt,
  sec10_cnt,
  sec1_cnt,
  ms100_cnt,
  min1_clr,
  sec10_clr,
  sec1_clr,
  ms100_clr,
  min1_load,
  sec10_load,
  sec1_load,
  ms100_load,
  min1_en,
  sec10_en,
  sec1_en,
  ms100_en
);

input wire clk_10Hz;
input wire btnC;
input wire btnD;
input wire [3 : 0] min1_cnt;
input wire [3 : 0] sec10_cnt;
input wire [3 : 0] sec1_cnt;
input wire [3 : 0] ms100_cnt;
output wire min1_clr;
output wire sec10_clr;
output wire sec1_clr;
output wire ms100_clr;
output wire min1_load;
output wire sec10_load;
output wire sec1_load;
output wire ms100_load;
output wire min1_en;
output wire sec10_en;
output wire sec1_en;
output wire ms100_en;

  stopwatch_ctrl_lpy inst (
    .clk_10Hz(clk_10Hz),
    .btnC(btnC),
    .btnD(btnD),
    .min1_cnt(min1_cnt),
    .sec10_cnt(sec10_cnt),
    .sec1_cnt(sec1_cnt),
    .ms100_cnt(ms100_cnt),
    .min1_clr(min1_clr),
    .sec10_clr(sec10_clr),
    .sec1_clr(sec1_clr),
    .ms100_clr(ms100_clr),
    .min1_load(min1_load),
    .sec10_load(sec10_load),
    .sec1_load(sec1_load),
    .ms100_load(ms100_load),
    .min1_en(min1_en),
    .sec10_en(sec10_en),
    .sec1_en(sec1_en),
    .ms100_en(ms100_en)
  );
endmodule
