-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Tue Apr 29 13:45:49 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top stopwatch_lpy_counter163_lpy_0_2 -prefix
--               stopwatch_lpy_counter163_lpy_0_2_ stopwatch_lpy_counter163_lpy_0_0_stub.vhdl
-- Design      : stopwatch_lpy_counter163_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity stopwatch_lpy_counter163_lpy_0_2 is
  Port ( 
    EN_lpy : in STD_LOGIC;
    D_lpy : in STD_LOGIC;
    C_lpy : in STD_LOGIC;
    B_lpy : in STD_LOGIC;
    A_lpy : in STD_LOGIC;
    LOAD_lpy : in STD_LOGIC;
    CLK_lpy : in STD_LOGIC;
    CLR_lpy : in STD_LOGIC;
    ECO_lpy : out STD_LOGIC;
    QD_lpy : out STD_LOGIC;
    QC_lpy : out STD_LOGIC;
    QB_lpy : out STD_LOGIC;
    QA_lpy : out STD_LOGIC
  );

end stopwatch_lpy_counter163_lpy_0_2;

architecture stub of stopwatch_lpy_counter163_lpy_0_2 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "EN_lpy,D_lpy,C_lpy,B_lpy,A_lpy,LOAD_lpy,CLK_lpy,CLR_lpy,ECO_lpy,QD_lpy,QC_lpy,QB_lpy,QA_lpy";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "counter163_lpy,Vivado 2022.1.2";
begin
end;
