// (c) Copyright 1995-2025 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: cs.pku.edu.cn:DDCA:counter163_lpy:1.0
// IP Revision: 10

(* X_CORE_INFO = "counter163_lpy,Vivado 2022.1.2" *)
(* CHECK_LICENSE_TYPE = "stopwatch_lpy_counter163_lpy_0_2,counter163_lpy,{}" *)
(* IP_DEFINITION_SOURCE = "package_project" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module stopwatch_lpy_counter163_lpy_0_2 (
  EN_lpy,
  D_lpy,
  C_lpy,
  B_lpy,
  A_lpy,
  LOAD_lpy,
  CLK_lpy,
  CLR_lpy,
  ECO_lpy,
  QD_lpy,
  QC_lpy,
  QB_lpy,
  QA_lpy
);

input wire EN_lpy;
input wire D_lpy;
input wire C_lpy;
input wire B_lpy;
input wire A_lpy;
input wire LOAD_lpy;
input wire CLK_lpy;
input wire CLR_lpy;
output wire ECO_lpy;
output wire QD_lpy;
output wire QC_lpy;
output wire QB_lpy;
output wire QA_lpy;

  counter163_lpy inst (
    .EN_lpy(EN_lpy),
    .D_lpy(D_lpy),
    .C_lpy(C_lpy),
    .B_lpy(B_lpy),
    .A_lpy(A_lpy),
    .LOAD_lpy(LOAD_lpy),
    .CLK_lpy(CLK_lpy),
    .CLR_lpy(CLR_lpy),
    .ECO_lpy(ECO_lpy),
    .QD_lpy(QD_lpy),
    .QC_lpy(QC_lpy),
    .QB_lpy(QB_lpy),
    .QA_lpy(QA_lpy)
  );
endmodule
