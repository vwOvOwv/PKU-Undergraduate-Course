//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
//Date        : Tue Apr 29 13:45:19 2025
//Host        : A14 running 64-bit major release  (build 9200)
//Command     : generate_target stopwatch_lpy_wrapper.bd
//Design      : stopwatch_lpy_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module stopwatch_lpy_wrapper
   (an,
    btnC,
    btnD,
    clk,
    seg);
  output [0:3]an;
  input btnC;
  input btnD;
  input clk;
  output [0:6]seg;

  wire [0:3]an;
  wire btnC;
  wire btnD;
  wire clk;
  wire [0:6]seg;

  stopwatch_lpy stopwatch_lpy_i
       (.an(an),
        .btnC(btnC),
        .btnD(btnD),
        .clk(clk),
        .seg(seg));
endmodule
