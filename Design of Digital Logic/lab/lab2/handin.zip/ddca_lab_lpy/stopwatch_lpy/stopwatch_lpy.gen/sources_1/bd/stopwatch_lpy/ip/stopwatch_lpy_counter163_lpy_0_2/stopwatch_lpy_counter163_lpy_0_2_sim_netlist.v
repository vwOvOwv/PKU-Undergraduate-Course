// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Tue Apr 29 13:45:49 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top stopwatch_lpy_counter163_lpy_0_2 -prefix
//               stopwatch_lpy_counter163_lpy_0_2_ stopwatch_lpy_counter163_lpy_0_0_sim_netlist.v
// Design      : stopwatch_lpy_counter163_lpy_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module stopwatch_lpy_counter163_lpy_0_2_counter163_lpy
   (Q,
    ECO_lpy,
    CLR_lpy,
    CLK_lpy,
    EN_lpy,
    LOAD_lpy,
    A_lpy,
    B_lpy,
    D_lpy,
    C_lpy);
  output [3:0]Q;
  output ECO_lpy;
  input CLR_lpy;
  input CLK_lpy;
  input EN_lpy;
  input LOAD_lpy;
  input A_lpy;
  input B_lpy;
  input D_lpy;
  input C_lpy;

  wire A_lpy;
  wire B_lpy;
  wire CLK_lpy;
  wire CLR_lpy;
  wire C_lpy;
  wire D_lpy;
  wire ECO_lpy;
  wire EN_lpy;
  wire LOAD_lpy;
  wire [3:0]Q;
  wire \out_lpy[3]_i_1_n_0 ;
  wire [3:0]p_0_in;

  LUT5 #(
    .INIT(32'h80000000)) 
    ECO_lpy0
       (.I0(EN_lpy),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(ECO_lpy));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h8B)) 
    \out_lpy[0]_i_1 
       (.I0(A_lpy),
        .I1(LOAD_lpy),
        .I2(Q[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h8BB8)) 
    \out_lpy[1]_i_1 
       (.I0(B_lpy),
        .I1(LOAD_lpy),
        .I2(Q[0]),
        .I3(Q[1]),
        .O(p_0_in[1]));
  LUT5 #(
    .INIT(32'h8BBBB888)) 
    \out_lpy[2]_i_1 
       (.I0(C_lpy),
        .I1(LOAD_lpy),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(Q[2]),
        .O(p_0_in[2]));
  LUT2 #(
    .INIT(4'hE)) 
    \out_lpy[3]_i_1 
       (.I0(LOAD_lpy),
        .I1(EN_lpy),
        .O(\out_lpy[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8BBBBBBBB8888888)) 
    \out_lpy[3]_i_2 
       (.I0(D_lpy),
        .I1(LOAD_lpy),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[3]),
        .O(p_0_in[3]));
  FDRE #(
    .INIT(1'b0)) 
    \out_lpy_reg[0] 
       (.C(CLK_lpy),
        .CE(\out_lpy[3]_i_1_n_0 ),
        .D(p_0_in[0]),
        .Q(Q[0]),
        .R(CLR_lpy));
  FDRE #(
    .INIT(1'b0)) 
    \out_lpy_reg[1] 
       (.C(CLK_lpy),
        .CE(\out_lpy[3]_i_1_n_0 ),
        .D(p_0_in[1]),
        .Q(Q[1]),
        .R(CLR_lpy));
  FDRE #(
    .INIT(1'b0)) 
    \out_lpy_reg[2] 
       (.C(CLK_lpy),
        .CE(\out_lpy[3]_i_1_n_0 ),
        .D(p_0_in[2]),
        .Q(Q[2]),
        .R(CLR_lpy));
  FDRE #(
    .INIT(1'b0)) 
    \out_lpy_reg[3] 
       (.C(CLK_lpy),
        .CE(\out_lpy[3]_i_1_n_0 ),
        .D(p_0_in[3]),
        .Q(Q[3]),
        .R(CLR_lpy));
endmodule

(* CHECK_LICENSE_TYPE = "stopwatch_lpy_counter163_lpy_0_0,counter163_lpy,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "counter163_lpy,Vivado 2022.1.2" *) 
(* NotValidForBitStream *)
module stopwatch_lpy_counter163_lpy_0_2
   (EN_lpy,
    D_lpy,
    C_lpy,
    B_lpy,
    A_lpy,
    LOAD_lpy,
    CLK_lpy,
    CLR_lpy,
    ECO_lpy,
    QD_lpy,
    QC_lpy,
    QB_lpy,
    QA_lpy);
  input EN_lpy;
  input D_lpy;
  input C_lpy;
  input B_lpy;
  input A_lpy;
  input LOAD_lpy;
  input CLK_lpy;
  input CLR_lpy;
  output ECO_lpy;
  output QD_lpy;
  output QC_lpy;
  output QB_lpy;
  output QA_lpy;

  wire A_lpy;
  wire B_lpy;
  wire CLK_lpy;
  wire CLR_lpy;
  wire C_lpy;
  wire D_lpy;
  wire ECO_lpy;
  wire EN_lpy;
  wire LOAD_lpy;
  wire QA_lpy;
  wire QB_lpy;
  wire QC_lpy;
  wire QD_lpy;

  stopwatch_lpy_counter163_lpy_0_2_counter163_lpy inst
       (.A_lpy(A_lpy),
        .B_lpy(B_lpy),
        .CLK_lpy(CLK_lpy),
        .CLR_lpy(CLR_lpy),
        .C_lpy(C_lpy),
        .D_lpy(D_lpy),
        .ECO_lpy(ECO_lpy),
        .EN_lpy(EN_lpy),
        .LOAD_lpy(LOAD_lpy),
        .Q({QD_lpy,QC_lpy,QB_lpy,QA_lpy}));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
