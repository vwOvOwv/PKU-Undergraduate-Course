-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Tue Apr 29 13:45:49 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top stopwatch_lpy_counter163_lpy_0_2 -prefix
--               stopwatch_lpy_counter163_lpy_0_2_ stopwatch_lpy_counter163_lpy_0_0_sim_netlist.vhdl
-- Design      : stopwatch_lpy_counter163_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity stopwatch_lpy_counter163_lpy_0_2_counter163_lpy is
  port (
    Q : out STD_LOGIC_VECTOR ( 3 downto 0 );
    ECO_lpy : out STD_LOGIC;
    CLR_lpy : in STD_LOGIC;
    CLK_lpy : in STD_LOGIC;
    EN_lpy : in STD_LOGIC;
    LOAD_lpy : in STD_LOGIC;
    A_lpy : in STD_LOGIC;
    B_lpy : in STD_LOGIC;
    D_lpy : in STD_LOGIC;
    C_lpy : in STD_LOGIC
  );
end stopwatch_lpy_counter163_lpy_0_2_counter163_lpy;

architecture STRUCTURE of stopwatch_lpy_counter163_lpy_0_2_counter163_lpy is
  signal \^q\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \out_lpy[3]_i_1_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \out_lpy[0]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \out_lpy[1]_i_1\ : label is "soft_lutpair0";
begin
  Q(3 downto 0) <= \^q\(3 downto 0);
ECO_lpy0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => EN_lpy,
      I1 => \^q\(1),
      I2 => \^q\(0),
      I3 => \^q\(2),
      I4 => \^q\(3),
      O => ECO_lpy
    );
\out_lpy[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8B"
    )
        port map (
      I0 => A_lpy,
      I1 => LOAD_lpy,
      I2 => \^q\(0),
      O => p_0_in(0)
    );
\out_lpy[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8BB8"
    )
        port map (
      I0 => B_lpy,
      I1 => LOAD_lpy,
      I2 => \^q\(0),
      I3 => \^q\(1),
      O => p_0_in(1)
    );
\out_lpy[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8BBBB888"
    )
        port map (
      I0 => C_lpy,
      I1 => LOAD_lpy,
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \^q\(2),
      O => p_0_in(2)
    );
\out_lpy[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => LOAD_lpy,
      I1 => EN_lpy,
      O => \out_lpy[3]_i_1_n_0\
    );
\out_lpy[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8BBBBBBBB8888888"
    )
        port map (
      I0 => D_lpy,
      I1 => LOAD_lpy,
      I2 => \^q\(1),
      I3 => \^q\(0),
      I4 => \^q\(2),
      I5 => \^q\(3),
      O => p_0_in(3)
    );
\out_lpy_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_lpy,
      CE => \out_lpy[3]_i_1_n_0\,
      D => p_0_in(0),
      Q => \^q\(0),
      R => CLR_lpy
    );
\out_lpy_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_lpy,
      CE => \out_lpy[3]_i_1_n_0\,
      D => p_0_in(1),
      Q => \^q\(1),
      R => CLR_lpy
    );
\out_lpy_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_lpy,
      CE => \out_lpy[3]_i_1_n_0\,
      D => p_0_in(2),
      Q => \^q\(2),
      R => CLR_lpy
    );
\out_lpy_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK_lpy,
      CE => \out_lpy[3]_i_1_n_0\,
      D => p_0_in(3),
      Q => \^q\(3),
      R => CLR_lpy
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity stopwatch_lpy_counter163_lpy_0_2 is
  port (
    EN_lpy : in STD_LOGIC;
    D_lpy : in STD_LOGIC;
    C_lpy : in STD_LOGIC;
    B_lpy : in STD_LOGIC;
    A_lpy : in STD_LOGIC;
    LOAD_lpy : in STD_LOGIC;
    CLK_lpy : in STD_LOGIC;
    CLR_lpy : in STD_LOGIC;
    ECO_lpy : out STD_LOGIC;
    QD_lpy : out STD_LOGIC;
    QC_lpy : out STD_LOGIC;
    QB_lpy : out STD_LOGIC;
    QA_lpy : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of stopwatch_lpy_counter163_lpy_0_2 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of stopwatch_lpy_counter163_lpy_0_2 : entity is "stopwatch_lpy_counter163_lpy_0_0,counter163_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of stopwatch_lpy_counter163_lpy_0_2 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of stopwatch_lpy_counter163_lpy_0_2 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stopwatch_lpy_counter163_lpy_0_2 : entity is "counter163_lpy,Vivado 2022.1.2";
end stopwatch_lpy_counter163_lpy_0_2;

architecture STRUCTURE of stopwatch_lpy_counter163_lpy_0_2 is
begin
inst: entity work.stopwatch_lpy_counter163_lpy_0_2_counter163_lpy
     port map (
      A_lpy => A_lpy,
      B_lpy => B_lpy,
      CLK_lpy => CLK_lpy,
      CLR_lpy => CLR_lpy,
      C_lpy => C_lpy,
      D_lpy => D_lpy,
      ECO_lpy => ECO_lpy,
      EN_lpy => EN_lpy,
      LOAD_lpy => LOAD_lpy,
      Q(3) => QD_lpy,
      Q(2) => QC_lpy,
      Q(1) => QB_lpy,
      Q(0) => QA_lpy
    );
end STRUCTURE;
