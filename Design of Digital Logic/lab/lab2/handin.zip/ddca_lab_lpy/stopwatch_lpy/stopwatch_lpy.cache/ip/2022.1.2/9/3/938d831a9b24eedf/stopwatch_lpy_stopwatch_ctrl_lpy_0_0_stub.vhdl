-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Tue Apr 29 13:45:49 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_stopwatch_ctrl_lpy_0_0_stub.vhdl
-- Design      : stopwatch_lpy_stopwatch_ctrl_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clk_10Hz : in STD_LOGIC;
    btnC : in STD_LOGIC;
    btnD : in STD_LOGIC;
    min1_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec10_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec1_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ms100_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    min1_clr : out STD_LOGIC;
    sec10_clr : out STD_LOGIC;
    sec1_clr : out STD_LOGIC;
    ms100_clr : out STD_LOGIC;
    min1_load : out STD_LOGIC;
    sec10_load : out STD_LOGIC;
    sec1_load : out STD_LOGIC;
    ms100_load : out STD_LOGIC;
    min1_en : out STD_LOGIC;
    sec10_en : out STD_LOGIC;
    sec1_en : out STD_LOGIC;
    ms100_en : out STD_LOGIC
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk_10Hz,btnC,btnD,min1_cnt[3:0],sec10_cnt[3:0],sec1_cnt[3:0],ms100_cnt[3:0],min1_clr,sec10_clr,sec1_clr,ms100_clr,min1_load,sec10_load,sec1_load,ms100_load,min1_en,sec10_en,sec1_en,ms100_en";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "stopwatch_ctrl_lpy,Vivado 2022.1.2";
begin
end;
