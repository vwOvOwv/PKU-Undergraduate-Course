-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Tue Apr 29 13:45:49 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_stopwatch_ctrl_lpy_0_0_sim_netlist.vhdl
-- Design      : stopwatch_lpy_stopwatch_ctrl_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy is
  port (
    en_reg_0 : out STD_LOGIC;
    ms100_clr : out STD_LOGIC;
    sec1_clr : out STD_LOGIC;
    ms100_cnt_3_sp_1 : out STD_LOGIC;
    sec10_clr : out STD_LOGIC;
    min1_clr : out STD_LOGIC;
    min1_en : out STD_LOGIC;
    sec10_en : out STD_LOGIC;
    btnC : in STD_LOGIC;
    clk_10Hz : in STD_LOGIC;
    btnD : in STD_LOGIC;
    ms100_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec1_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec10_en0 : in STD_LOGIC;
    min1_en0 : in STD_LOGIC;
    min10_en0 : in STD_LOGIC;
    sec10_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy is
  signal en_i_1_n_0 : STD_LOGIC;
  signal \^en_reg_0\ : STD_LOGIC;
  signal ms100_cnt_3_sn_1 : STD_LOGIC;
  signal p_3_in : STD_LOGIC;
  signal sync_clr0 : STD_LOGIC;
  signal sync_clr1 : STD_LOGIC;
  signal sync_en0 : STD_LOGIC;
  signal sync_en1 : STD_LOGIC;
  signal sync_en2 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of en_i_1 : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of sec1_clr_INST_0_i_1 : label is "soft_lutpair0";
begin
  en_reg_0 <= \^en_reg_0\;
  ms100_cnt_3_sp_1 <= ms100_cnt_3_sn_1;
en_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"000000A6"
    )
        port map (
      I0 => \^en_reg_0\,
      I1 => sync_en2,
      I2 => sync_en1,
      I3 => sync_clr1,
      I4 => btnC,
      O => en_i_1_n_0
    );
en_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => en_i_1_n_0,
      Q => \^en_reg_0\,
      R => '0'
    );
min1_clr_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEEEEEEEEEEEEEEE"
    )
        port map (
      I0 => sync_clr1,
      I1 => btnC,
      I2 => min1_en0,
      I3 => ms100_cnt_3_sn_1,
      I4 => sec10_en0,
      I5 => min10_en0,
      O => min1_clr
    );
min1_en_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0008000000000000"
    )
        port map (
      I0 => sec10_cnt(2),
      I1 => sec10_cnt(0),
      I2 => sec10_cnt(1),
      I3 => sec10_cnt(3),
      I4 => ms100_cnt_3_sn_1,
      I5 => sec10_en0,
      O => min1_en
    );
ms100_clr_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAEAAAAAAAAAAAA"
    )
        port map (
      I0 => p_3_in,
      I1 => \^en_reg_0\,
      I2 => ms100_cnt(1),
      I3 => ms100_cnt(2),
      I4 => ms100_cnt(0),
      I5 => ms100_cnt(3),
      O => ms100_clr
    );
sec10_clr_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEEEEEEE"
    )
        port map (
      I0 => sync_clr1,
      I1 => btnC,
      I2 => sec10_en0,
      I3 => ms100_cnt_3_sn_1,
      I4 => min1_en0,
      O => sec10_clr
    );
sec10_en_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => sec1_cnt(3),
      I1 => sec1_cnt(0),
      I2 => sec1_cnt(2),
      I3 => sec1_cnt(1),
      I4 => ms100_cnt_3_sn_1,
      O => sec10_en
    );
sec1_clr_INST_0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAEAAAAAAAAAAAA"
    )
        port map (
      I0 => p_3_in,
      I1 => ms100_cnt_3_sn_1,
      I2 => sec1_cnt(1),
      I3 => sec1_cnt(2),
      I4 => sec1_cnt(0),
      I5 => sec1_cnt(3),
      O => sec1_clr
    );
sec1_clr_INST_0_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => btnC,
      I1 => sync_clr1,
      O => p_3_in
    );
sec1_en_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => ms100_cnt(3),
      I1 => ms100_cnt(0),
      I2 => ms100_cnt(2),
      I3 => ms100_cnt(1),
      I4 => \^en_reg_0\,
      O => ms100_cnt_3_sn_1
    );
sync_clr0_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => btnC,
      Q => sync_clr0,
      R => '0'
    );
sync_clr1_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => sync_clr0,
      Q => sync_clr1,
      R => '0'
    );
sync_en0_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => btnD,
      Q => sync_en0,
      R => '0'
    );
sync_en1_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => sync_en0,
      Q => sync_en1,
      R => '0'
    );
sync_en2_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_10Hz,
      CE => '1',
      D => sync_en1,
      Q => sync_en2,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clk_10Hz : in STD_LOGIC;
    btnC : in STD_LOGIC;
    btnD : in STD_LOGIC;
    min1_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec10_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    sec1_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ms100_cnt : in STD_LOGIC_VECTOR ( 3 downto 0 );
    min1_clr : out STD_LOGIC;
    sec10_clr : out STD_LOGIC;
    sec1_clr : out STD_LOGIC;
    ms100_clr : out STD_LOGIC;
    min1_load : out STD_LOGIC;
    sec10_load : out STD_LOGIC;
    sec1_load : out STD_LOGIC;
    ms100_load : out STD_LOGIC;
    min1_en : out STD_LOGIC;
    sec10_en : out STD_LOGIC;
    sec1_en : out STD_LOGIC;
    ms100_en : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "stopwatch_lpy_stopwatch_ctrl_lpy_0_0,stopwatch_ctrl_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "stopwatch_ctrl_lpy,Vivado 2022.1.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal min10_en0 : STD_LOGIC;
  signal min1_en0 : STD_LOGIC;
  signal sec10_en0 : STD_LOGIC;
begin
  min1_load <= \<const0>\;
  ms100_load <= \<const0>\;
  sec10_load <= \<const0>\;
  sec1_load <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy
     port map (
      btnC => btnC,
      btnD => btnD,
      clk_10Hz => clk_10Hz,
      en_reg_0 => ms100_en,
      min10_en0 => min10_en0,
      min1_clr => min1_clr,
      min1_en => min1_en,
      min1_en0 => min1_en0,
      ms100_clr => ms100_clr,
      ms100_cnt(3 downto 0) => ms100_cnt(3 downto 0),
      ms100_cnt_3_sp_1 => sec1_en,
      sec10_clr => sec10_clr,
      sec10_cnt(3 downto 0) => sec10_cnt(3 downto 0),
      sec10_en => sec10_en,
      sec10_en0 => sec10_en0,
      sec1_clr => sec1_clr,
      sec1_cnt(3 downto 0) => sec1_cnt(3 downto 0)
    );
min1_clr_INST_0_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => sec10_cnt(3),
      I1 => sec10_cnt(1),
      I2 => sec10_cnt(0),
      I3 => sec10_cnt(2),
      O => min1_en0
    );
min1_clr_INST_0_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => sec1_cnt(1),
      I1 => sec1_cnt(2),
      I2 => sec1_cnt(0),
      I3 => sec1_cnt(3),
      O => sec10_en0
    );
min1_clr_INST_0_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => min1_cnt(1),
      I1 => min1_cnt(2),
      I2 => min1_cnt(0),
      I3 => min1_cnt(3),
      O => min10_en0
    );
end STRUCTURE;
