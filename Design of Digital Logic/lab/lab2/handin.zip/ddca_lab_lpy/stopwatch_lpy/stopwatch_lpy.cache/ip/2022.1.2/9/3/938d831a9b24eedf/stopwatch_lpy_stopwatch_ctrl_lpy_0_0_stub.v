// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Tue Apr 29 13:45:49 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_stopwatch_ctrl_lpy_0_0_stub.v
// Design      : stopwatch_lpy_stopwatch_ctrl_lpy_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "stopwatch_ctrl_lpy,Vivado 2022.1.2" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(clk_10Hz, btnC, btnD, min1_cnt, sec10_cnt, 
  sec1_cnt, ms100_cnt, min1_clr, sec10_clr, sec1_clr, ms100_clr, min1_load, sec10_load, sec1_load, 
  ms100_load, min1_en, sec10_en, sec1_en, ms100_en)
/* synthesis syn_black_box black_box_pad_pin="clk_10Hz,btnC,btnD,min1_cnt[3:0],sec10_cnt[3:0],sec1_cnt[3:0],ms100_cnt[3:0],min1_clr,sec10_clr,sec1_clr,ms100_clr,min1_load,sec10_load,sec1_load,ms100_load,min1_en,sec10_en,sec1_en,ms100_en" */;
  input clk_10Hz;
  input btnC;
  input btnD;
  input [3:0]min1_cnt;
  input [3:0]sec10_cnt;
  input [3:0]sec1_cnt;
  input [3:0]ms100_cnt;
  output min1_clr;
  output sec10_clr;
  output sec1_clr;
  output ms100_clr;
  output min1_load;
  output sec10_load;
  output sec1_load;
  output ms100_load;
  output min1_en;
  output sec10_en;
  output sec1_en;
  output ms100_en;
endmodule
