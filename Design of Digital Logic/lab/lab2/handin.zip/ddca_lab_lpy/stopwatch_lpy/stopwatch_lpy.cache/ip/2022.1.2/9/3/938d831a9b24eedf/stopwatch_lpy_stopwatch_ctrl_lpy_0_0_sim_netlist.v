// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Tue Apr 29 13:45:49 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_stopwatch_ctrl_lpy_0_0_sim_netlist.v
// Design      : stopwatch_lpy_stopwatch_ctrl_lpy_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy
   (en_reg_0,
    ms100_clr,
    sec1_clr,
    ms100_cnt_3_sp_1,
    sec10_clr,
    min1_clr,
    min1_en,
    sec10_en,
    btnC,
    clk_10Hz,
    btnD,
    ms100_cnt,
    sec1_cnt,
    sec10_en0,
    min1_en0,
    min10_en0,
    sec10_cnt);
  output en_reg_0;
  output ms100_clr;
  output sec1_clr;
  output ms100_cnt_3_sp_1;
  output sec10_clr;
  output min1_clr;
  output min1_en;
  output sec10_en;
  input btnC;
  input clk_10Hz;
  input btnD;
  input [3:0]ms100_cnt;
  input [3:0]sec1_cnt;
  input sec10_en0;
  input min1_en0;
  input min10_en0;
  input [3:0]sec10_cnt;

  wire btnC;
  wire btnD;
  wire clk_10Hz;
  wire en_i_1_n_0;
  wire en_reg_0;
  wire min10_en0;
  wire min1_clr;
  wire min1_en;
  wire min1_en0;
  wire ms100_clr;
  wire [3:0]ms100_cnt;
  wire ms100_cnt_3_sn_1;
  wire p_3_in;
  wire sec10_clr;
  wire [3:0]sec10_cnt;
  wire sec10_en;
  wire sec10_en0;
  wire sec1_clr;
  wire [3:0]sec1_cnt;
  wire sync_clr0;
  wire sync_clr1;
  wire sync_en0;
  wire sync_en1;
  wire sync_en2;

  assign ms100_cnt_3_sp_1 = ms100_cnt_3_sn_1;
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h000000A6)) 
    en_i_1
       (.I0(en_reg_0),
        .I1(sync_en2),
        .I2(sync_en1),
        .I3(sync_clr1),
        .I4(btnC),
        .O(en_i_1_n_0));
  FDRE en_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(en_i_1_n_0),
        .Q(en_reg_0),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFEEEEEEEEEEEEEEE)) 
    min1_clr_INST_0
       (.I0(sync_clr1),
        .I1(btnC),
        .I2(min1_en0),
        .I3(ms100_cnt_3_sn_1),
        .I4(sec10_en0),
        .I5(min10_en0),
        .O(min1_clr));
  LUT6 #(
    .INIT(64'h0008000000000000)) 
    min1_en_INST_0
       (.I0(sec10_cnt[2]),
        .I1(sec10_cnt[0]),
        .I2(sec10_cnt[1]),
        .I3(sec10_cnt[3]),
        .I4(ms100_cnt_3_sn_1),
        .I5(sec10_en0),
        .O(min1_en));
  LUT6 #(
    .INIT(64'hAAAEAAAAAAAAAAAA)) 
    ms100_clr_INST_0
       (.I0(p_3_in),
        .I1(en_reg_0),
        .I2(ms100_cnt[1]),
        .I3(ms100_cnt[2]),
        .I4(ms100_cnt[0]),
        .I5(ms100_cnt[3]),
        .O(ms100_clr));
  LUT5 #(
    .INIT(32'hFEEEEEEE)) 
    sec10_clr_INST_0
       (.I0(sync_clr1),
        .I1(btnC),
        .I2(sec10_en0),
        .I3(ms100_cnt_3_sn_1),
        .I4(min1_en0),
        .O(sec10_clr));
  LUT5 #(
    .INIT(32'h00080000)) 
    sec10_en_INST_0
       (.I0(sec1_cnt[3]),
        .I1(sec1_cnt[0]),
        .I2(sec1_cnt[2]),
        .I3(sec1_cnt[1]),
        .I4(ms100_cnt_3_sn_1),
        .O(sec10_en));
  LUT6 #(
    .INIT(64'hAAAEAAAAAAAAAAAA)) 
    sec1_clr_INST_0
       (.I0(p_3_in),
        .I1(ms100_cnt_3_sn_1),
        .I2(sec1_cnt[1]),
        .I3(sec1_cnt[2]),
        .I4(sec1_cnt[0]),
        .I5(sec1_cnt[3]),
        .O(sec1_clr));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'hE)) 
    sec1_clr_INST_0_i_1
       (.I0(btnC),
        .I1(sync_clr1),
        .O(p_3_in));
  LUT5 #(
    .INIT(32'h00080000)) 
    sec1_en_INST_0
       (.I0(ms100_cnt[3]),
        .I1(ms100_cnt[0]),
        .I2(ms100_cnt[2]),
        .I3(ms100_cnt[1]),
        .I4(en_reg_0),
        .O(ms100_cnt_3_sn_1));
  FDRE sync_clr0_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(btnC),
        .Q(sync_clr0),
        .R(1'b0));
  FDRE sync_clr1_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(sync_clr0),
        .Q(sync_clr1),
        .R(1'b0));
  FDRE sync_en0_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(btnD),
        .Q(sync_en0),
        .R(1'b0));
  FDRE sync_en1_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(sync_en0),
        .Q(sync_en1),
        .R(1'b0));
  FDRE sync_en2_reg
       (.C(clk_10Hz),
        .CE(1'b1),
        .D(sync_en1),
        .Q(sync_en2),
        .R(1'b0));
endmodule

(* CHECK_LICENSE_TYPE = "stopwatch_lpy_stopwatch_ctrl_lpy_0_0,stopwatch_ctrl_lpy,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "stopwatch_ctrl_lpy,Vivado 2022.1.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk_10Hz,
    btnC,
    btnD,
    min1_cnt,
    sec10_cnt,
    sec1_cnt,
    ms100_cnt,
    min1_clr,
    sec10_clr,
    sec1_clr,
    ms100_clr,
    min1_load,
    sec10_load,
    sec1_load,
    ms100_load,
    min1_en,
    sec10_en,
    sec1_en,
    ms100_en);
  input clk_10Hz;
  input btnC;
  input btnD;
  input [3:0]min1_cnt;
  input [3:0]sec10_cnt;
  input [3:0]sec1_cnt;
  input [3:0]ms100_cnt;
  output min1_clr;
  output sec10_clr;
  output sec1_clr;
  output ms100_clr;
  output min1_load;
  output sec10_load;
  output sec1_load;
  output ms100_load;
  output min1_en;
  output sec10_en;
  output sec1_en;
  output ms100_en;

  wire \<const0> ;
  wire btnC;
  wire btnD;
  wire clk_10Hz;
  wire min10_en0;
  wire min1_clr;
  wire [3:0]min1_cnt;
  wire min1_en;
  wire min1_en0;
  wire ms100_clr;
  wire [3:0]ms100_cnt;
  wire ms100_en;
  wire sec10_clr;
  wire [3:0]sec10_cnt;
  wire sec10_en;
  wire sec10_en0;
  wire sec1_clr;
  wire [3:0]sec1_cnt;
  wire sec1_en;

  assign min1_load = \<const0> ;
  assign ms100_load = \<const0> ;
  assign sec10_load = \<const0> ;
  assign sec1_load = \<const0> ;
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_stopwatch_ctrl_lpy inst
       (.btnC(btnC),
        .btnD(btnD),
        .clk_10Hz(clk_10Hz),
        .en_reg_0(ms100_en),
        .min10_en0(min10_en0),
        .min1_clr(min1_clr),
        .min1_en(min1_en),
        .min1_en0(min1_en0),
        .ms100_clr(ms100_clr),
        .ms100_cnt(ms100_cnt),
        .ms100_cnt_3_sp_1(sec1_en),
        .sec10_clr(sec10_clr),
        .sec10_cnt(sec10_cnt),
        .sec10_en(sec10_en),
        .sec10_en0(sec10_en0),
        .sec1_clr(sec1_clr),
        .sec1_cnt(sec1_cnt));
  LUT4 #(
    .INIT(16'h1000)) 
    min1_clr_INST_0_i_1
       (.I0(sec10_cnt[3]),
        .I1(sec10_cnt[1]),
        .I2(sec10_cnt[0]),
        .I3(sec10_cnt[2]),
        .O(min1_en0));
  LUT4 #(
    .INIT(16'h1000)) 
    min1_clr_INST_0_i_2
       (.I0(sec1_cnt[1]),
        .I1(sec1_cnt[2]),
        .I2(sec1_cnt[0]),
        .I3(sec1_cnt[3]),
        .O(sec10_en0));
  LUT4 #(
    .INIT(16'h1000)) 
    min1_clr_INST_0_i_3
       (.I0(min1_cnt[1]),
        .I1(min1_cnt[2]),
        .I2(min1_cnt[0]),
        .I3(min1_cnt[3]),
        .O(min10_en0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
