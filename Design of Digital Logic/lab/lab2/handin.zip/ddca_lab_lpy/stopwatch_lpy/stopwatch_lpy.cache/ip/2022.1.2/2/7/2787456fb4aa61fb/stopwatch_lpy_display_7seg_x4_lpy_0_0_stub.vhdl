-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Tue Apr 29 13:45:49 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_display_7seg_x4_lpy_0_0_stub.vhdl
-- Design      : stopwatch_lpy_display_7seg_x4_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    CLK_1KHz_lpy : in STD_LOGIC;
    in3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an_lpy : out STD_LOGIC_VECTOR ( 0 to 3 );
    seg_lpy : out STD_LOGIC_VECTOR ( 0 to 6 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK_1KHz_lpy,in3_lpy[3:0],in2_lpy[3:0],in1_lpy[3:0],in0_lpy[3:0],an_lpy[0:3],seg_lpy[0:6]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "display_7seg_x4_lpy,Vivado 2022.1.2";
begin
end;
