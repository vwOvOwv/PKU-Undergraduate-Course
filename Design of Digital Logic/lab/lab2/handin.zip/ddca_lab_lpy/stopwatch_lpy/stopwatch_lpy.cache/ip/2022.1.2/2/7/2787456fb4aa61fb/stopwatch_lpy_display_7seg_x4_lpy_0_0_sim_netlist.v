// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Tue Apr 29 13:45:49 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ stopwatch_lpy_display_7seg_x4_lpy_0_0_sim_netlist.v
// Design      : stopwatch_lpy_display_7seg_x4_lpy_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy
   (seg_lpy,
    an_lpy,
    CLK_1KHz_lpy,
    in1_lpy,
    in0_lpy,
    in3_lpy,
    in2_lpy);
  output [0:6]seg_lpy;
  output [0:3]an_lpy;
  input CLK_1KHz_lpy;
  input [3:0]in1_lpy;
  input [3:0]in0_lpy;
  input [3:0]in3_lpy;
  input [3:0]in2_lpy;

  wire CLK_1KHz_lpy;
  wire [0:3]an_lpy;
  wire [3:0]in0_lpy;
  wire [3:0]in1_lpy;
  wire [3:0]in2_lpy;
  wire [3:0]in3_lpy;
  wire [1:0]p_0_in;
  wire [0:6]seg_lpy;
  wire [3:0]sel0;
  wire [1:0]sel_lpy;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \an_lpy[0]_INST_0 
       (.I0(sel_lpy[1]),
        .I1(sel_lpy[0]),
        .O(an_lpy[0]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an_lpy[1]_INST_0 
       (.I0(sel_lpy[1]),
        .I1(sel_lpy[0]),
        .O(an_lpy[1]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an_lpy[2]_INST_0 
       (.I0(sel_lpy[0]),
        .I1(sel_lpy[1]),
        .O(an_lpy[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \an_lpy[3]_INST_0 
       (.I0(sel_lpy[1]),
        .I1(sel_lpy[0]),
        .O(an_lpy[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0014)) 
    \seg_lpy[0]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[0]),
        .I2(sel0[2]),
        .I3(sel0[3]),
        .O(seg_lpy[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg_lpy[0]_INST_0_i_1 
       (.I0(in1_lpy[1]),
        .I1(in0_lpy[1]),
        .I2(in3_lpy[1]),
        .I3(sel_lpy[0]),
        .I4(sel_lpy[1]),
        .I5(in2_lpy[1]),
        .O(sel0[1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg_lpy[0]_INST_0_i_2 
       (.I0(in1_lpy[0]),
        .I1(in0_lpy[0]),
        .I2(in3_lpy[0]),
        .I3(sel_lpy[0]),
        .I4(sel_lpy[1]),
        .I5(in2_lpy[0]),
        .O(sel0[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg_lpy[0]_INST_0_i_3 
       (.I0(in1_lpy[2]),
        .I1(in0_lpy[2]),
        .I2(in3_lpy[2]),
        .I3(sel_lpy[0]),
        .I4(sel_lpy[1]),
        .I5(in2_lpy[2]),
        .O(sel0[2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \seg_lpy[0]_INST_0_i_4 
       (.I0(in1_lpy[3]),
        .I1(in0_lpy[3]),
        .I2(in3_lpy[3]),
        .I3(sel_lpy[0]),
        .I4(sel_lpy[1]),
        .I5(in2_lpy[3]),
        .O(sel0[3]));
  LUT4 #(
    .INIT(16'hAEC8)) 
    \seg_lpy[1]_INST_0 
       (.I0(sel0[3]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[1]),
        .O(seg_lpy[1]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hAAB0)) 
    \seg_lpy[2]_INST_0 
       (.I0(sel0[3]),
        .I1(sel0[0]),
        .I2(sel0[1]),
        .I3(sel0[2]),
        .O(seg_lpy[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0094)) 
    \seg_lpy[3]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[0]),
        .I2(sel0[2]),
        .I3(sel0[3]),
        .O(seg_lpy[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h5710)) 
    \seg_lpy[4]_INST_0 
       (.I0(sel0[3]),
        .I1(sel0[1]),
        .I2(sel0[2]),
        .I3(sel0[0]),
        .O(seg_lpy[4]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h008E)) 
    \seg_lpy[5]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[0]),
        .I2(sel0[2]),
        .I3(sel0[3]),
        .O(seg_lpy[5]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0091)) 
    \seg_lpy[6]_INST_0 
       (.I0(sel0[1]),
        .I1(sel0[2]),
        .I2(sel0[0]),
        .I3(sel0[3]),
        .O(seg_lpy[6]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \sel_lpy[0]_i_1 
       (.I0(sel_lpy[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \sel_lpy[1]_i_1 
       (.I0(sel_lpy[0]),
        .I1(sel_lpy[1]),
        .O(p_0_in[1]));
  FDRE \sel_lpy_reg[0] 
       (.C(CLK_1KHz_lpy),
        .CE(1'b1),
        .D(p_0_in[0]),
        .Q(sel_lpy[0]),
        .R(1'b0));
  FDRE \sel_lpy_reg[1] 
       (.C(CLK_1KHz_lpy),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(sel_lpy[1]),
        .R(1'b0));
endmodule

(* CHECK_LICENSE_TYPE = "stopwatch_lpy_display_7seg_x4_lpy_0_0,display_7seg_x4_lpy,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "display_7seg_x4_lpy,Vivado 2022.1.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (CLK_1KHz_lpy,
    in3_lpy,
    in2_lpy,
    in1_lpy,
    in0_lpy,
    an_lpy,
    seg_lpy);
  input CLK_1KHz_lpy;
  input [3:0]in3_lpy;
  input [3:0]in2_lpy;
  input [3:0]in1_lpy;
  input [3:0]in0_lpy;
  output [0:3]an_lpy;
  output [0:6]seg_lpy;

  wire CLK_1KHz_lpy;
  wire [0:3]an_lpy;
  wire [3:0]in0_lpy;
  wire [3:0]in1_lpy;
  wire [3:0]in2_lpy;
  wire [3:0]in3_lpy;
  wire [0:6]seg_lpy;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy inst
       (.CLK_1KHz_lpy(CLK_1KHz_lpy),
        .an_lpy(an_lpy),
        .in0_lpy(in0_lpy),
        .in1_lpy(in1_lpy),
        .in2_lpy(in2_lpy),
        .in3_lpy(in3_lpy),
        .seg_lpy(seg_lpy));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
