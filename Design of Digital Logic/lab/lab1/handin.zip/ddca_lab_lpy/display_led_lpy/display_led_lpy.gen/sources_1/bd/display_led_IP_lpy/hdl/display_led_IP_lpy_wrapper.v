//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
//Date        : Sat Apr 12 11:12:47 2025
//Host        : A14 running 64-bit major release  (build 9200)
//Command     : generate_target display_led_IP_lpy_wrapper.bd
//Design      : display_led_IP_lpy_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module display_led_IP_lpy_wrapper
   (an,
    clk,
    seg,
    sw);
  output [0:3]an;
  input clk;
  output [0:6]seg;
  input [15:0]sw;

  wire [0:3]an;
  wire clk;
  wire [0:6]seg;
  wire [15:0]sw;

  display_led_IP_lpy display_led_IP_lpy_i
       (.an(an),
        .clk(clk),
        .seg(seg),
        .sw(sw));
endmodule
