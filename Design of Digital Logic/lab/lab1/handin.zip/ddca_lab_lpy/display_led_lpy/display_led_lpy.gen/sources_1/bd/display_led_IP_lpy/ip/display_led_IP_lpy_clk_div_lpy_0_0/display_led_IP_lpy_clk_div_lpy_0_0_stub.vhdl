-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:07:12 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/22426/Desktop/ddca_lab_lpy/display_led_lpy/display_led_lpy.gen/sources_1/bd/display_led_IP_lpy/ip/display_led_IP_lpy_clk_div_lpy_0_0/display_led_IP_lpy_clk_div_lpy_0_0_stub.vhdl
-- Design      : display_led_IP_lpy_clk_div_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity display_led_IP_lpy_clk_div_lpy_0_0 is
  Port ( 
    clk_100MHz_lpy : in STD_LOGIC;
    clk_sys_lpy : out STD_LOGIC
  );

end display_led_IP_lpy_clk_div_lpy_0_0;

architecture stub of display_led_IP_lpy_clk_div_lpy_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk_100MHz_lpy,clk_sys_lpy";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "clk_div_lpy,Vivado 2022.1.2";
begin
end;
