-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:07:12 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/22426/Desktop/ddca_lab_lpy/display_led_lpy/display_led_lpy.gen/sources_1/bd/display_led_IP_lpy/ip/display_led_IP_lpy_display_7seg_x4_lpy_0_0/display_led_IP_lpy_display_7seg_x4_lpy_0_0_stub.vhdl
-- Design      : display_led_IP_lpy_display_7seg_x4_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity display_led_IP_lpy_display_7seg_x4_lpy_0_0 is
  Port ( 
    CLK_1KHz_lpy : in STD_LOGIC;
    in3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an_lpy : out STD_LOGIC_VECTOR ( 0 to 3 );
    seg_lpy : out STD_LOGIC_VECTOR ( 0 to 6 )
  );

end display_led_IP_lpy_display_7seg_x4_lpy_0_0;

architecture stub of display_led_IP_lpy_display_7seg_x4_lpy_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "CLK_1KHz_lpy,in3_lpy[3:0],in2_lpy[3:0],in1_lpy[3:0],in0_lpy[3:0],an_lpy[0:3],seg_lpy[0:6]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "display_7seg_x4_lpy,Vivado 2022.1.2";
begin
end;
