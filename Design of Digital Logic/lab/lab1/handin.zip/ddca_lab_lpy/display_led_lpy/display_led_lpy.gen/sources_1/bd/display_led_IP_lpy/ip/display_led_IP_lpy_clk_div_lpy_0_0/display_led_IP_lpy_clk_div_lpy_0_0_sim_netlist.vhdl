-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:07:12 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/22426/Desktop/ddca_lab_lpy/display_led_lpy/display_led_lpy.gen/sources_1/bd/display_led_IP_lpy/ip/display_led_IP_lpy_clk_div_lpy_0_0/display_led_IP_lpy_clk_div_lpy_0_0_sim_netlist.vhdl
-- Design      : display_led_IP_lpy_clk_div_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity display_led_IP_lpy_clk_div_lpy_0_0_clk_div_lpy is
  port (
    clk_sys_lpy : out STD_LOGIC;
    clk_100MHz_lpy : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of display_led_IP_lpy_clk_div_lpy_0_0_clk_div_lpy : entity is "clk_div_lpy";
end display_led_IP_lpy_clk_div_lpy_0_0_clk_div_lpy;

architecture STRUCTURE of display_led_IP_lpy_clk_div_lpy_0_0_clk_div_lpy is
  signal clk_div_lpy : STD_LOGIC;
  signal clk_div_lpy_i_1_n_0 : STD_LOGIC;
  signal data0 : STD_LOGIC_VECTOR ( 26 downto 1 );
  signal div_counter_lpy : STD_LOGIC_VECTOR ( 26 downto 0 );
  signal \div_counter_lpy0_carry__0_n_0\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__0_n_1\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__0_n_2\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__0_n_3\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__1_n_0\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__1_n_1\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__1_n_2\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__1_n_3\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__2_n_0\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__2_n_1\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__2_n_2\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__2_n_3\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__3_n_0\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__3_n_1\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__3_n_2\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__3_n_3\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__4_n_0\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__4_n_1\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__4_n_2\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__4_n_3\ : STD_LOGIC;
  signal \div_counter_lpy0_carry__5_n_3\ : STD_LOGIC;
  signal div_counter_lpy0_carry_n_0 : STD_LOGIC;
  signal div_counter_lpy0_carry_n_1 : STD_LOGIC;
  signal div_counter_lpy0_carry_n_2 : STD_LOGIC;
  signal div_counter_lpy0_carry_n_3 : STD_LOGIC;
  signal \div_counter_lpy[0]_i_2_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_3_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_4_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_5_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_6_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_7_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[0]_i_8_n_0\ : STD_LOGIC;
  signal \div_counter_lpy[26]_i_1_n_0\ : STD_LOGIC;
  signal div_counter_lpy_0 : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_div_counter_lpy0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_div_counter_lpy0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute BOX_TYPE : string;
  attribute BOX_TYPE of CLK0_BUFG_INST : label is "PRIMITIVE";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of clk_div_lpy_i_1 : label is "soft_lutpair0";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of div_counter_lpy0_carry : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \div_counter_lpy0_carry__5\ : label is 35;
  attribute SOFT_HLUTNM of \div_counter_lpy[0]_i_1\ : label is "soft_lutpair0";
begin
CLK0_BUFG_INST: unisim.vcomponents.BUFG
     port map (
      I => clk_div_lpy,
      O => clk_sys_lpy
    );
clk_div_lpy_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => div_counter_lpy(0),
      I1 => \div_counter_lpy[0]_i_2_n_0\,
      I2 => clk_div_lpy,
      O => clk_div_lpy_i_1_n_0
    );
clk_div_lpy_reg: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => clk_div_lpy_i_1_n_0,
      Q => clk_div_lpy,
      R => '0'
    );
div_counter_lpy0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => div_counter_lpy0_carry_n_0,
      CO(2) => div_counter_lpy0_carry_n_1,
      CO(1) => div_counter_lpy0_carry_n_2,
      CO(0) => div_counter_lpy0_carry_n_3,
      CYINIT => div_counter_lpy(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => div_counter_lpy(4 downto 1)
    );
\div_counter_lpy0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => div_counter_lpy0_carry_n_0,
      CO(3) => \div_counter_lpy0_carry__0_n_0\,
      CO(2) => \div_counter_lpy0_carry__0_n_1\,
      CO(1) => \div_counter_lpy0_carry__0_n_2\,
      CO(0) => \div_counter_lpy0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => div_counter_lpy(8 downto 5)
    );
\div_counter_lpy0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \div_counter_lpy0_carry__0_n_0\,
      CO(3) => \div_counter_lpy0_carry__1_n_0\,
      CO(2) => \div_counter_lpy0_carry__1_n_1\,
      CO(1) => \div_counter_lpy0_carry__1_n_2\,
      CO(0) => \div_counter_lpy0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => div_counter_lpy(12 downto 9)
    );
\div_counter_lpy0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \div_counter_lpy0_carry__1_n_0\,
      CO(3) => \div_counter_lpy0_carry__2_n_0\,
      CO(2) => \div_counter_lpy0_carry__2_n_1\,
      CO(1) => \div_counter_lpy0_carry__2_n_2\,
      CO(0) => \div_counter_lpy0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => div_counter_lpy(16 downto 13)
    );
\div_counter_lpy0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \div_counter_lpy0_carry__2_n_0\,
      CO(3) => \div_counter_lpy0_carry__3_n_0\,
      CO(2) => \div_counter_lpy0_carry__3_n_1\,
      CO(1) => \div_counter_lpy0_carry__3_n_2\,
      CO(0) => \div_counter_lpy0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(20 downto 17),
      S(3 downto 0) => div_counter_lpy(20 downto 17)
    );
\div_counter_lpy0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \div_counter_lpy0_carry__3_n_0\,
      CO(3) => \div_counter_lpy0_carry__4_n_0\,
      CO(2) => \div_counter_lpy0_carry__4_n_1\,
      CO(1) => \div_counter_lpy0_carry__4_n_2\,
      CO(0) => \div_counter_lpy0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(24 downto 21),
      S(3 downto 0) => div_counter_lpy(24 downto 21)
    );
\div_counter_lpy0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \div_counter_lpy0_carry__4_n_0\,
      CO(3 downto 1) => \NLW_div_counter_lpy0_carry__5_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \div_counter_lpy0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_div_counter_lpy0_carry__5_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => data0(26 downto 25),
      S(3 downto 2) => B"00",
      S(1 downto 0) => div_counter_lpy(26 downto 25)
    );
\div_counter_lpy[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \div_counter_lpy[0]_i_2_n_0\,
      I1 => div_counter_lpy(0),
      O => div_counter_lpy_0(0)
    );
\div_counter_lpy[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \div_counter_lpy[0]_i_3_n_0\,
      I1 => \div_counter_lpy[0]_i_4_n_0\,
      I2 => \div_counter_lpy[0]_i_5_n_0\,
      I3 => \div_counter_lpy[0]_i_6_n_0\,
      I4 => \div_counter_lpy[0]_i_7_n_0\,
      I5 => \div_counter_lpy[0]_i_8_n_0\,
      O => \div_counter_lpy[0]_i_2_n_0\
    );
\div_counter_lpy[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => div_counter_lpy(16),
      I1 => div_counter_lpy(15),
      I2 => div_counter_lpy(18),
      I3 => div_counter_lpy(17),
      O => \div_counter_lpy[0]_i_3_n_0\
    );
\div_counter_lpy[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => div_counter_lpy(20),
      I1 => div_counter_lpy(19),
      I2 => div_counter_lpy(22),
      I3 => div_counter_lpy(21),
      O => \div_counter_lpy[0]_i_4_n_0\
    );
\div_counter_lpy[0]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => div_counter_lpy(8),
      I1 => div_counter_lpy(7),
      I2 => div_counter_lpy(9),
      I3 => div_counter_lpy(10),
      O => \div_counter_lpy[0]_i_5_n_0\
    );
\div_counter_lpy[0]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => div_counter_lpy(12),
      I1 => div_counter_lpy(11),
      I2 => div_counter_lpy(14),
      I3 => div_counter_lpy(13),
      O => \div_counter_lpy[0]_i_6_n_0\
    );
\div_counter_lpy[0]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => div_counter_lpy(3),
      I1 => div_counter_lpy(4),
      I2 => div_counter_lpy(6),
      I3 => div_counter_lpy(5),
      O => \div_counter_lpy[0]_i_7_n_0\
    );
\div_counter_lpy[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => div_counter_lpy(25),
      I1 => div_counter_lpy(26),
      I2 => div_counter_lpy(23),
      I3 => div_counter_lpy(24),
      I4 => div_counter_lpy(2),
      I5 => div_counter_lpy(1),
      O => \div_counter_lpy[0]_i_8_n_0\
    );
\div_counter_lpy[26]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => div_counter_lpy(0),
      I1 => \div_counter_lpy[0]_i_2_n_0\,
      O => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => div_counter_lpy_0(0),
      Q => div_counter_lpy(0),
      R => '0'
    );
\div_counter_lpy_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(10),
      Q => div_counter_lpy(10),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(11),
      Q => div_counter_lpy(11),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(12),
      Q => div_counter_lpy(12),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(13),
      Q => div_counter_lpy(13),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(14),
      Q => div_counter_lpy(14),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(15),
      Q => div_counter_lpy(15),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(16),
      Q => div_counter_lpy(16),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(17),
      Q => div_counter_lpy(17),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(18),
      Q => div_counter_lpy(18),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(19),
      Q => div_counter_lpy(19),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(1),
      Q => div_counter_lpy(1),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(20),
      Q => div_counter_lpy(20),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(21),
      Q => div_counter_lpy(21),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(22),
      Q => div_counter_lpy(22),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(23),
      Q => div_counter_lpy(23),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(24),
      Q => div_counter_lpy(24),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(25),
      Q => div_counter_lpy(25),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(26),
      Q => div_counter_lpy(26),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(2),
      Q => div_counter_lpy(2),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(3),
      Q => div_counter_lpy(3),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(4),
      Q => div_counter_lpy(4),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(5),
      Q => div_counter_lpy(5),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(6),
      Q => div_counter_lpy(6),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(7),
      Q => div_counter_lpy(7),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(8),
      Q => div_counter_lpy(8),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
\div_counter_lpy_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk_100MHz_lpy,
      CE => '1',
      D => data0(9),
      Q => div_counter_lpy(9),
      R => \div_counter_lpy[26]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity display_led_IP_lpy_clk_div_lpy_0_0 is
  port (
    clk_100MHz_lpy : in STD_LOGIC;
    clk_sys_lpy : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of display_led_IP_lpy_clk_div_lpy_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of display_led_IP_lpy_clk_div_lpy_0_0 : entity is "display_led_IP_lpy_clk_div_lpy_0_0,clk_div_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of display_led_IP_lpy_clk_div_lpy_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of display_led_IP_lpy_clk_div_lpy_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of display_led_IP_lpy_clk_div_lpy_0_0 : entity is "clk_div_lpy,Vivado 2022.1.2";
end display_led_IP_lpy_clk_div_lpy_0_0;

architecture STRUCTURE of display_led_IP_lpy_clk_div_lpy_0_0 is
begin
inst: entity work.display_led_IP_lpy_clk_div_lpy_0_0_clk_div_lpy
     port map (
      clk_100MHz_lpy => clk_100MHz_lpy,
      clk_sys_lpy => clk_sys_lpy
    );
end STRUCTURE;
