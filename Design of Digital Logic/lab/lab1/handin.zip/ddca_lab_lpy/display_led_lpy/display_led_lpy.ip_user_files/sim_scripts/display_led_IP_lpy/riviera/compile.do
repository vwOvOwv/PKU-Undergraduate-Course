vlib work
vlib riviera

vlib riviera/xil_defaultlib
vlib riviera/xlslice_v1_0_2

vmap xil_defaultlib riviera/xil_defaultlib
vmap xlslice_v1_0_2 riviera/xlslice_v1_0_2

vlog -work xil_defaultlib  -sv2k12 \
"../../../bd/display_led_IP_lpy/ipshared/86b3/clk_div_lpy.sv" \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_clk_div_lpy_0_0/sim/display_led_IP_lpy_clk_div_lpy_0_0.sv" \
"../../../bd/display_led_IP_lpy/ipshared/c482/display_7seg_x4_lpy.sv" \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_display_7seg_x4_lpy_0_0/sim/display_led_IP_lpy_display_7seg_x4_lpy_0_0.sv" \

vlog -work xlslice_v1_0_2  -v2k5 \
"../../../../display_led_lpy.gen/sources_1/bd/display_led_IP_lpy/ipshared/11d0/hdl/xlslice_v1_0_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_xlslice_0_0/sim/display_led_IP_lpy_xlslice_0_0.v" \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_xlslice_1_0/sim/display_led_IP_lpy_xlslice_1_0.v" \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_xlslice_2_0/sim/display_led_IP_lpy_xlslice_2_0.v" \
"../../../bd/display_led_IP_lpy/ip/display_led_IP_lpy_xlslice_3_0/sim/display_led_IP_lpy_xlslice_3_0.v" \
"../../../bd/display_led_IP_lpy/sim/display_led_IP_lpy.v" \

vlog -work xil_defaultlib \
"glbl.v"

