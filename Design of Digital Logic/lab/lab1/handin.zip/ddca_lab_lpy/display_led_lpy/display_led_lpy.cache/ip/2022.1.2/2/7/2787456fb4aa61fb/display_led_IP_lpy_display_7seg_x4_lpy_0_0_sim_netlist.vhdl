-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:07:12 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ display_led_IP_lpy_display_7seg_x4_lpy_0_0_sim_netlist.vhdl
-- Design      : display_led_IP_lpy_display_7seg_x4_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy is
  port (
    seg_lpy : out STD_LOGIC_VECTOR ( 0 to 6 );
    an_lpy : out STD_LOGIC_VECTOR ( 0 to 3 );
    CLK_1KHz_lpy : in STD_LOGIC;
    in1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy is
  signal p_0_in : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal sel0 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal sel_lpy : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \an_lpy[0]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \an_lpy[1]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an_lpy[2]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an_lpy[3]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \seg_lpy[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg_lpy[2]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \seg_lpy[3]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg_lpy[4]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \seg_lpy[5]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg_lpy[6]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \sel_lpy[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \sel_lpy[1]_i_1\ : label is "soft_lutpair3";
begin
\an_lpy[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => sel_lpy(1),
      I1 => sel_lpy(0),
      O => an_lpy(0)
    );
\an_lpy[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => sel_lpy(1),
      I1 => sel_lpy(0),
      O => an_lpy(1)
    );
\an_lpy[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => sel_lpy(0),
      I1 => sel_lpy(1),
      O => an_lpy(2)
    );
\an_lpy[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => sel_lpy(1),
      I1 => sel_lpy(0),
      O => an_lpy(3)
    );
\seg_lpy[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0014"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(0),
      I2 => sel0(2),
      I3 => sel0(3),
      O => seg_lpy(0)
    );
\seg_lpy[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1_lpy(1),
      I1 => in0_lpy(1),
      I2 => in3_lpy(1),
      I3 => sel_lpy(0),
      I4 => sel_lpy(1),
      I5 => in2_lpy(1),
      O => sel0(1)
    );
\seg_lpy[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1_lpy(0),
      I1 => in0_lpy(0),
      I2 => in3_lpy(0),
      I3 => sel_lpy(0),
      I4 => sel_lpy(1),
      I5 => in2_lpy(0),
      O => sel0(0)
    );
\seg_lpy[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1_lpy(2),
      I1 => in0_lpy(2),
      I2 => in3_lpy(2),
      I3 => sel_lpy(0),
      I4 => sel_lpy(1),
      I5 => in2_lpy(2),
      O => sel0(2)
    );
\seg_lpy[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFAACCF000AACC"
    )
        port map (
      I0 => in1_lpy(3),
      I1 => in0_lpy(3),
      I2 => in3_lpy(3),
      I3 => sel_lpy(0),
      I4 => sel_lpy(1),
      I5 => in2_lpy(3),
      O => sel0(3)
    );
\seg_lpy[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AEC8"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(1),
      O => seg_lpy(1)
    );
\seg_lpy[2]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAB0"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(0),
      I2 => sel0(1),
      I3 => sel0(2),
      O => seg_lpy(2)
    );
\seg_lpy[3]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0094"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(0),
      I2 => sel0(2),
      I3 => sel0(3),
      O => seg_lpy(3)
    );
\seg_lpy[4]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5710"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(1),
      I2 => sel0(2),
      I3 => sel0(0),
      O => seg_lpy(4)
    );
\seg_lpy[5]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"008E"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(0),
      I2 => sel0(2),
      I3 => sel0(3),
      O => seg_lpy(5)
    );
\seg_lpy[6]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0091"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(2),
      I2 => sel0(0),
      I3 => sel0(3),
      O => seg_lpy(6)
    );
\sel_lpy[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => sel_lpy(0),
      O => p_0_in(0)
    );
\sel_lpy[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel_lpy(0),
      I1 => sel_lpy(1),
      O => p_0_in(1)
    );
\sel_lpy_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_1KHz_lpy,
      CE => '1',
      D => p_0_in(0),
      Q => sel_lpy(0),
      R => '0'
    );
\sel_lpy_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK_1KHz_lpy,
      CE => '1',
      D => p_0_in(1),
      Q => sel_lpy(1),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    CLK_1KHz_lpy : in STD_LOGIC;
    in3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    in0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an_lpy : out STD_LOGIC_VECTOR ( 0 to 3 );
    seg_lpy : out STD_LOGIC_VECTOR ( 0 to 6 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "display_led_IP_lpy_display_7seg_x4_lpy_0_0,display_7seg_x4_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "display_7seg_x4_lpy,Vivado 2022.1.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_display_7seg_x4_lpy
     port map (
      CLK_1KHz_lpy => CLK_1KHz_lpy,
      an_lpy(0 to 3) => an_lpy(0 to 3),
      in0_lpy(3 downto 0) => in0_lpy(3 downto 0),
      in1_lpy(3 downto 0) => in1_lpy(3 downto 0),
      in2_lpy(3 downto 0) => in2_lpy(3 downto 0),
      in3_lpy(3 downto 0) => in3_lpy(3 downto 0),
      seg_lpy(0 to 6) => seg_lpy(0 to 6)
    );
end STRUCTURE;
