// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Sat Apr 12 11:07:12 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ display_led_IP_lpy_clk_div_lpy_0_0_sim_netlist.v
// Design      : display_led_IP_lpy_clk_div_lpy_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_clk_div_lpy
   (clk_sys_lpy,
    clk_100MHz_lpy);
  output clk_sys_lpy;
  input clk_100MHz_lpy;

  wire clk_100MHz_lpy;
  wire clk_div_lpy;
  wire clk_div_lpy_i_1_n_0;
  wire clk_sys_lpy;
  wire [26:1]data0;
  wire [26:0]div_counter_lpy;
  wire div_counter_lpy0_carry__0_n_0;
  wire div_counter_lpy0_carry__0_n_1;
  wire div_counter_lpy0_carry__0_n_2;
  wire div_counter_lpy0_carry__0_n_3;
  wire div_counter_lpy0_carry__1_n_0;
  wire div_counter_lpy0_carry__1_n_1;
  wire div_counter_lpy0_carry__1_n_2;
  wire div_counter_lpy0_carry__1_n_3;
  wire div_counter_lpy0_carry__2_n_0;
  wire div_counter_lpy0_carry__2_n_1;
  wire div_counter_lpy0_carry__2_n_2;
  wire div_counter_lpy0_carry__2_n_3;
  wire div_counter_lpy0_carry__3_n_0;
  wire div_counter_lpy0_carry__3_n_1;
  wire div_counter_lpy0_carry__3_n_2;
  wire div_counter_lpy0_carry__3_n_3;
  wire div_counter_lpy0_carry__4_n_0;
  wire div_counter_lpy0_carry__4_n_1;
  wire div_counter_lpy0_carry__4_n_2;
  wire div_counter_lpy0_carry__4_n_3;
  wire div_counter_lpy0_carry__5_n_3;
  wire div_counter_lpy0_carry_n_0;
  wire div_counter_lpy0_carry_n_1;
  wire div_counter_lpy0_carry_n_2;
  wire div_counter_lpy0_carry_n_3;
  wire \div_counter_lpy[0]_i_2_n_0 ;
  wire \div_counter_lpy[0]_i_3_n_0 ;
  wire \div_counter_lpy[0]_i_4_n_0 ;
  wire \div_counter_lpy[0]_i_5_n_0 ;
  wire \div_counter_lpy[0]_i_6_n_0 ;
  wire \div_counter_lpy[0]_i_7_n_0 ;
  wire \div_counter_lpy[0]_i_8_n_0 ;
  wire \div_counter_lpy[26]_i_1_n_0 ;
  wire [0:0]div_counter_lpy_0;
  wire [3:1]NLW_div_counter_lpy0_carry__5_CO_UNCONNECTED;
  wire [3:2]NLW_div_counter_lpy0_carry__5_O_UNCONNECTED;

  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG CLK0_BUFG_INST
       (.I(clk_div_lpy),
        .O(clk_sys_lpy));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hE1)) 
    clk_div_lpy_i_1
       (.I0(div_counter_lpy[0]),
        .I1(\div_counter_lpy[0]_i_2_n_0 ),
        .I2(clk_div_lpy),
        .O(clk_div_lpy_i_1_n_0));
  FDRE clk_div_lpy_reg
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(clk_div_lpy_i_1_n_0),
        .Q(clk_div_lpy),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry
       (.CI(1'b0),
        .CO({div_counter_lpy0_carry_n_0,div_counter_lpy0_carry_n_1,div_counter_lpy0_carry_n_2,div_counter_lpy0_carry_n_3}),
        .CYINIT(div_counter_lpy[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(div_counter_lpy[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__0
       (.CI(div_counter_lpy0_carry_n_0),
        .CO({div_counter_lpy0_carry__0_n_0,div_counter_lpy0_carry__0_n_1,div_counter_lpy0_carry__0_n_2,div_counter_lpy0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(div_counter_lpy[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__1
       (.CI(div_counter_lpy0_carry__0_n_0),
        .CO({div_counter_lpy0_carry__1_n_0,div_counter_lpy0_carry__1_n_1,div_counter_lpy0_carry__1_n_2,div_counter_lpy0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(div_counter_lpy[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__2
       (.CI(div_counter_lpy0_carry__1_n_0),
        .CO({div_counter_lpy0_carry__2_n_0,div_counter_lpy0_carry__2_n_1,div_counter_lpy0_carry__2_n_2,div_counter_lpy0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(div_counter_lpy[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__3
       (.CI(div_counter_lpy0_carry__2_n_0),
        .CO({div_counter_lpy0_carry__3_n_0,div_counter_lpy0_carry__3_n_1,div_counter_lpy0_carry__3_n_2,div_counter_lpy0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[20:17]),
        .S(div_counter_lpy[20:17]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__4
       (.CI(div_counter_lpy0_carry__3_n_0),
        .CO({div_counter_lpy0_carry__4_n_0,div_counter_lpy0_carry__4_n_1,div_counter_lpy0_carry__4_n_2,div_counter_lpy0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[24:21]),
        .S(div_counter_lpy[24:21]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 div_counter_lpy0_carry__5
       (.CI(div_counter_lpy0_carry__4_n_0),
        .CO({NLW_div_counter_lpy0_carry__5_CO_UNCONNECTED[3:1],div_counter_lpy0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_div_counter_lpy0_carry__5_O_UNCONNECTED[3:2],data0[26:25]}),
        .S({1'b0,1'b0,div_counter_lpy[26:25]}));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \div_counter_lpy[0]_i_1 
       (.I0(\div_counter_lpy[0]_i_2_n_0 ),
        .I1(div_counter_lpy[0]),
        .O(div_counter_lpy_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \div_counter_lpy[0]_i_2 
       (.I0(\div_counter_lpy[0]_i_3_n_0 ),
        .I1(\div_counter_lpy[0]_i_4_n_0 ),
        .I2(\div_counter_lpy[0]_i_5_n_0 ),
        .I3(\div_counter_lpy[0]_i_6_n_0 ),
        .I4(\div_counter_lpy[0]_i_7_n_0 ),
        .I5(\div_counter_lpy[0]_i_8_n_0 ),
        .O(\div_counter_lpy[0]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \div_counter_lpy[0]_i_3 
       (.I0(div_counter_lpy[16]),
        .I1(div_counter_lpy[15]),
        .I2(div_counter_lpy[18]),
        .I3(div_counter_lpy[17]),
        .O(\div_counter_lpy[0]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \div_counter_lpy[0]_i_4 
       (.I0(div_counter_lpy[20]),
        .I1(div_counter_lpy[19]),
        .I2(div_counter_lpy[22]),
        .I3(div_counter_lpy[21]),
        .O(\div_counter_lpy[0]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFF7F)) 
    \div_counter_lpy[0]_i_5 
       (.I0(div_counter_lpy[8]),
        .I1(div_counter_lpy[7]),
        .I2(div_counter_lpy[9]),
        .I3(div_counter_lpy[10]),
        .O(\div_counter_lpy[0]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFD)) 
    \div_counter_lpy[0]_i_6 
       (.I0(div_counter_lpy[12]),
        .I1(div_counter_lpy[11]),
        .I2(div_counter_lpy[14]),
        .I3(div_counter_lpy[13]),
        .O(\div_counter_lpy[0]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hFFFD)) 
    \div_counter_lpy[0]_i_7 
       (.I0(div_counter_lpy[3]),
        .I1(div_counter_lpy[4]),
        .I2(div_counter_lpy[6]),
        .I3(div_counter_lpy[5]),
        .O(\div_counter_lpy[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \div_counter_lpy[0]_i_8 
       (.I0(div_counter_lpy[25]),
        .I1(div_counter_lpy[26]),
        .I2(div_counter_lpy[23]),
        .I3(div_counter_lpy[24]),
        .I4(div_counter_lpy[2]),
        .I5(div_counter_lpy[1]),
        .O(\div_counter_lpy[0]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \div_counter_lpy[26]_i_1 
       (.I0(div_counter_lpy[0]),
        .I1(\div_counter_lpy[0]_i_2_n_0 ),
        .O(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[0] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(div_counter_lpy_0),
        .Q(div_counter_lpy[0]),
        .R(1'b0));
  FDRE \div_counter_lpy_reg[10] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[10]),
        .Q(div_counter_lpy[10]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[11] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[11]),
        .Q(div_counter_lpy[11]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[12] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[12]),
        .Q(div_counter_lpy[12]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[13] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[13]),
        .Q(div_counter_lpy[13]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[14] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[14]),
        .Q(div_counter_lpy[14]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[15] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[15]),
        .Q(div_counter_lpy[15]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[16] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[16]),
        .Q(div_counter_lpy[16]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[17] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[17]),
        .Q(div_counter_lpy[17]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[18] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[18]),
        .Q(div_counter_lpy[18]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[19] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[19]),
        .Q(div_counter_lpy[19]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[1] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[1]),
        .Q(div_counter_lpy[1]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[20] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[20]),
        .Q(div_counter_lpy[20]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[21] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[21]),
        .Q(div_counter_lpy[21]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[22] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[22]),
        .Q(div_counter_lpy[22]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[23] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[23]),
        .Q(div_counter_lpy[23]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[24] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[24]),
        .Q(div_counter_lpy[24]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[25] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[25]),
        .Q(div_counter_lpy[25]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[26] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[26]),
        .Q(div_counter_lpy[26]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[2] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[2]),
        .Q(div_counter_lpy[2]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[3] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[3]),
        .Q(div_counter_lpy[3]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[4] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[4]),
        .Q(div_counter_lpy[4]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[5] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[5]),
        .Q(div_counter_lpy[5]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[6] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[6]),
        .Q(div_counter_lpy[6]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[7] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[7]),
        .Q(div_counter_lpy[7]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[8] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[8]),
        .Q(div_counter_lpy[8]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
  FDRE \div_counter_lpy_reg[9] 
       (.C(clk_100MHz_lpy),
        .CE(1'b1),
        .D(data0[9]),
        .Q(div_counter_lpy[9]),
        .R(\div_counter_lpy[26]_i_1_n_0 ));
endmodule

(* CHECK_LICENSE_TYPE = "display_led_IP_lpy_clk_div_lpy_0_0,clk_div_lpy,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "clk_div_lpy,Vivado 2022.1.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk_100MHz_lpy,
    clk_sys_lpy);
  input clk_100MHz_lpy;
  output clk_sys_lpy;

  wire clk_100MHz_lpy;
  wire clk_sys_lpy;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_clk_div_lpy inst
       (.clk_100MHz_lpy(clk_100MHz_lpy),
        .clk_sys_lpy(clk_sys_lpy));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
