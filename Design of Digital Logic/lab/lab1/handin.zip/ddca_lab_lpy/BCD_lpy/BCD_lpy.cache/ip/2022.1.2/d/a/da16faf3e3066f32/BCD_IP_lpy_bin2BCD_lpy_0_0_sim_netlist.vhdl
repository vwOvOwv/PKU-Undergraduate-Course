-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:31:00 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ BCD_IP_lpy_bin2BCD_lpy_0_0_sim_netlist.vhdl
-- Design      : BCD_IP_lpy_bin2BCD_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    bin_lpy : in STD_LOGIC_VECTOR ( 13 downto 0 );
    bcd3_lpy : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2_lpy : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1_lpy : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0_lpy : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "BCD_IP_lpy_bin2BCD_lpy_0_0,bin2BCD_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "bin2BCD_lpy,Vivado 2022.1.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \^bcd0_lpy\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \bcd1_lpy[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd1_lpy[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd1_lpy[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bcd2_lpy[0]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[0]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_17_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_18_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_19_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_20_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_21_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bcd3_lpy[3]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \^bin_lpy\ : STD_LOGIC_VECTOR ( 13 downto 0 );
  signal shifter_lpy1_out : STD_LOGIC_VECTOR ( 21 to 21 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \bcd2_lpy[0]_INST_0_i_10\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bcd2_lpy[0]_INST_0_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bcd2_lpy[0]_INST_0_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bcd2_lpy[0]_INST_0_i_5\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bcd3_lpy[0]_INST_0_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bcd3_lpy[0]_INST_0_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_10\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_13\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_21\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_3\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_5\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bcd3_lpy[3]_INST_0_i_7\ : label is "soft_lutpair3";
begin
  \^bin_lpy\(13 downto 0) <= bin_lpy(13 downto 0);
  bcd0_lpy(3 downto 1) <= \^bcd0_lpy\(3 downto 1);
  bcd0_lpy(0) <= \^bin_lpy\(0);
\bcd0_lpy[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"900924094BF6DBB4"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd1_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd1_lpy[0]_INST_0_i_2_n_0\,
      I3 => \bcd1_lpy[0]_INST_0_i_3_n_0\,
      I4 => \^bin_lpy\(2),
      I5 => \^bin_lpy\(1),
      O => \^bcd0_lpy\(1)
    );
\bcd0_lpy[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00FFFF004B2409B4"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd1_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd1_lpy[0]_INST_0_i_2_n_0\,
      I3 => \^bin_lpy\(2),
      I4 => \bcd1_lpy[0]_INST_0_i_3_n_0\,
      I5 => \^bin_lpy\(1),
      O => \^bcd0_lpy\(2)
    );
\bcd0_lpy[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0942909066429066"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd1_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd1_lpy[0]_INST_0_i_2_n_0\,
      I3 => \^bin_lpy\(2),
      I4 => \bcd1_lpy[0]_INST_0_i_3_n_0\,
      I5 => \^bin_lpy\(1),
      O => \^bcd0_lpy\(3)
    );
\bcd1_lpy[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2D4BD2D24B4BD2B4"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd1_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd1_lpy[0]_INST_0_i_2_n_0\,
      I3 => \^bin_lpy\(2),
      I4 => \bcd1_lpy[0]_INST_0_i_3_n_0\,
      I5 => \^bin_lpy\(1),
      O => bcd1_lpy(0)
    );
\bcd1_lpy[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin_lpy\(4),
      I1 => \bcd2_lpy[0]_INST_0_i_7_n_0\,
      I2 => \^bin_lpy\(5),
      I3 => \bcd2_lpy[0]_INST_0_i_8_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_9_n_0\,
      I5 => \^bin_lpy\(3),
      O => \bcd1_lpy[0]_INST_0_i_1_n_0\
    );
\bcd1_lpy[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_12_n_0\,
      I1 => \bcd2_lpy[0]_INST_0_i_11_n_0\,
      I2 => \^bin_lpy\(6),
      I3 => \bcd2_lpy[0]_INST_0_i_10_n_0\,
      I4 => \^bin_lpy\(5),
      I5 => \^bin_lpy\(4),
      O => \bcd1_lpy[0]_INST_0_i_2_n_0\
    );
\bcd1_lpy[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd2_lpy[0]_INST_0_i_13_n_0\,
      I2 => \^bin_lpy\(4),
      I3 => \bcd2_lpy[0]_INST_0_i_14_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_15_n_0\,
      I5 => \^bin_lpy\(2),
      O => \bcd1_lpy[0]_INST_0_i_3_n_0\
    );
\bcd1_lpy[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_5_n_0\,
      I1 => \bcd2_lpy[0]_INST_0_i_4_n_0\,
      I2 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_2_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_1_n_0\,
      I5 => \bcd2_lpy[0]_INST_0_i_6_n_0\,
      O => bcd1_lpy(1)
    );
\bcd1_lpy[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"195495664251A58A"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_1_n_0\,
      I1 => \bcd2_lpy[0]_INST_0_i_2_n_0\,
      I2 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_4_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_5_n_0\,
      I5 => \bcd2_lpy[0]_INST_0_i_6_n_0\,
      O => bcd1_lpy(2)
    );
\bcd1_lpy[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4101204807A00AD0"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_1_n_0\,
      I1 => \bcd2_lpy[0]_INST_0_i_2_n_0\,
      I2 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_4_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_5_n_0\,
      I5 => \bcd2_lpy[0]_INST_0_i_6_n_0\,
      O => bcd1_lpy(3)
    );
\bcd2_lpy[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_1_n_0\,
      I1 => \bcd2_lpy[0]_INST_0_i_2_n_0\,
      I2 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_4_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_5_n_0\,
      I5 => \bcd2_lpy[0]_INST_0_i_6_n_0\,
      O => bcd2_lpy(0)
    );
\bcd2_lpy[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin_lpy\(4),
      I1 => \bcd2_lpy[0]_INST_0_i_7_n_0\,
      I2 => \^bin_lpy\(5),
      I3 => \bcd2_lpy[0]_INST_0_i_8_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_9_n_0\,
      I5 => \^bin_lpy\(3),
      O => \bcd2_lpy[0]_INST_0_i_1_n_0\
    );
\bcd2_lpy[0]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3C623C46"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I1 => \^bin_lpy\(8),
      I2 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I3 => \^bin_lpy\(7),
      I4 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      O => \bcd2_lpy[0]_INST_0_i_10_n_0\
    );
\bcd2_lpy[0]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin_lpy\(7),
      I1 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I2 => \^bin_lpy\(8),
      I3 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      I5 => \^bin_lpy\(6),
      O => \bcd2_lpy[0]_INST_0_i_11_n_0\
    );
\bcd2_lpy[0]_INST_0_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"481137EC"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I2 => \^bin_lpy\(8),
      I3 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I4 => \^bin_lpy\(7),
      O => \bcd2_lpy[0]_INST_0_i_12_n_0\
    );
\bcd2_lpy[0]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2299545A449A2592"
    )
        port map (
      I0 => \^bin_lpy\(6),
      I1 => \^bin_lpy\(7),
      I2 => \bcd3_lpy[3]_INST_0_i_16_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_17_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_18_n_0\,
      I5 => \^bin_lpy\(5),
      O => \bcd2_lpy[0]_INST_0_i_13_n_0\
    );
\bcd2_lpy[0]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5FA53AFC5B0530EC"
    )
        port map (
      I0 => \^bin_lpy\(5),
      I1 => \bcd2_lpy[0]_INST_0_i_10_n_0\,
      I2 => \^bin_lpy\(6),
      I3 => \bcd2_lpy[0]_INST_0_i_11_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_12_n_0\,
      I5 => \^bin_lpy\(4),
      O => \bcd2_lpy[0]_INST_0_i_14_n_0\
    );
\bcd2_lpy[0]_INST_0_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_8_n_0\,
      I1 => \^bin_lpy\(5),
      O => \bcd2_lpy[0]_INST_0_i_15_n_0\
    );
\bcd2_lpy[0]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B4"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_9_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_10_n_0\,
      O => \bcd2_lpy[0]_INST_0_i_2_n_0\
    );
\bcd2_lpy[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin_lpy\(5),
      I1 => \bcd2_lpy[0]_INST_0_i_10_n_0\,
      I2 => \^bin_lpy\(6),
      I3 => \bcd2_lpy[0]_INST_0_i_11_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_12_n_0\,
      I5 => \^bin_lpy\(4),
      O => \bcd2_lpy[0]_INST_0_i_3_n_0\
    );
\bcd2_lpy[0]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DF5E7A7A"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_7_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_9_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_10_n_0\,
      O => \bcd2_lpy[0]_INST_0_i_4_n_0\
    );
\bcd2_lpy[0]_INST_0_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_9_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      O => \bcd2_lpy[0]_INST_0_i_5_n_0\
    );
\bcd2_lpy[0]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin_lpy\(3),
      I1 => \bcd2_lpy[0]_INST_0_i_13_n_0\,
      I2 => \^bin_lpy\(4),
      I3 => \bcd2_lpy[0]_INST_0_i_14_n_0\,
      I4 => \bcd2_lpy[0]_INST_0_i_15_n_0\,
      I5 => \^bin_lpy\(2),
      O => \bcd2_lpy[0]_INST_0_i_6_n_0\
    );
\bcd2_lpy[0]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"195495664251A58A"
    )
        port map (
      I0 => \^bin_lpy\(7),
      I1 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I2 => \^bin_lpy\(8),
      I3 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      I5 => \^bin_lpy\(6),
      O => \bcd2_lpy[0]_INST_0_i_7_n_0\
    );
\bcd2_lpy[0]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772379EC660371C8"
    )
        port map (
      I0 => \^bin_lpy\(6),
      I1 => \^bin_lpy\(7),
      I2 => \bcd3_lpy[3]_INST_0_i_16_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_17_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_18_n_0\,
      I5 => \^bin_lpy\(5),
      O => \bcd2_lpy[0]_INST_0_i_8_n_0\
    );
\bcd2_lpy[0]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C2836425195893CA"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I2 => \^bin_lpy\(8),
      I3 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I4 => \^bin_lpy\(7),
      I5 => \^bin_lpy\(6),
      O => \bcd2_lpy[0]_INST_0_i_9_n_0\
    );
\bcd2_lpy[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"23895472"
    )
        port map (
      I0 => \bcd3_lpy[0]_INST_0_i_3_n_0\,
      I1 => \bcd3_lpy[0]_INST_0_i_2_n_0\,
      I2 => \bcd3_lpy[0]_INST_0_i_1_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I4 => \bcd3_lpy[0]_INST_0_i_4_n_0\,
      O => bcd2_lpy(1)
    );
\bcd2_lpy[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5466518A"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd3_lpy[0]_INST_0_i_2_n_0\,
      I3 => \bcd3_lpy[0]_INST_0_i_3_n_0\,
      I4 => \bcd3_lpy[0]_INST_0_i_4_n_0\,
      O => bcd2_lpy(2)
    );
\bcd2_lpy[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0148A0D0"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd3_lpy[0]_INST_0_i_2_n_0\,
      I3 => \bcd3_lpy[0]_INST_0_i_3_n_0\,
      I4 => \bcd3_lpy[0]_INST_0_i_4_n_0\,
      O => bcd2_lpy(3)
    );
\bcd3_lpy[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A17C01EC"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[0]_INST_0_i_1_n_0\,
      I2 => \bcd3_lpy[0]_INST_0_i_2_n_0\,
      I3 => \bcd3_lpy[0]_INST_0_i_3_n_0\,
      I4 => \bcd3_lpy[0]_INST_0_i_4_n_0\,
      O => bcd3_lpy(0)
    );
\bcd3_lpy[0]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"41201804"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I2 => shifter_lpy1_out(21),
      I3 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => \bcd3_lpy[0]_INST_0_i_1_n_0\
    );
\bcd3_lpy[0]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C3611C86"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I1 => shifter_lpy1_out(21),
      I2 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => \bcd3_lpy[0]_INST_0_i_2_n_0\
    );
\bcd3_lpy[0]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"249A45A2"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I2 => shifter_lpy1_out(21),
      I3 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => \bcd3_lpy[0]_INST_0_i_3_n_0\
    );
\bcd3_lpy[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_7_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_9_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_10_n_0\,
      I5 => \bcd2_lpy[0]_INST_0_i_1_n_0\,
      O => \bcd3_lpy[0]_INST_0_i_4_n_0\
    );
\bcd3_lpy[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E83F01C1002F33C"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I2 => shifter_lpy1_out(21),
      I3 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I5 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => bcd3_lpy(1)
    );
\bcd3_lpy[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C330332CD330300C"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I2 => shifter_lpy1_out(21),
      I3 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I5 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => bcd3_lpy(2)
    );
\bcd3_lpy[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300C0000200C04C0"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_1_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_2_n_0\,
      I2 => shifter_lpy1_out(21),
      I3 => \bcd3_lpy[3]_INST_0_i_4_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_5_n_0\,
      I5 => \bcd3_lpy[3]_INST_0_i_6_n_0\,
      O => bcd3_lpy(3)
    );
\bcd3_lpy[3]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95565A5A"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_7_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_9_n_0\,
      I3 => \bcd2_lpy[0]_INST_0_i_3_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_10_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_1_n_0\
    );
\bcd3_lpy[3]_INST_0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"23895472"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_15_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_10_n_0\
    );
\bcd3_lpy[3]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300C0000200C04C0"
    )
        port map (
      I0 => \^bin_lpy\(8),
      I1 => \^bin_lpy\(12),
      I2 => \^bin_lpy\(13),
      I3 => \^bin_lpy\(11),
      I4 => \^bin_lpy\(10),
      I5 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_11_n_0\
    );
\bcd3_lpy[3]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E83F01C1002F33C"
    )
        port map (
      I0 => \^bin_lpy\(8),
      I1 => \^bin_lpy\(12),
      I2 => \^bin_lpy\(13),
      I3 => \^bin_lpy\(11),
      I4 => \^bin_lpy\(10),
      I5 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_12_n_0\
    );
\bcd3_lpy[3]_INST_0_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"95565A5A"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I1 => \^bin_lpy\(8),
      I2 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I3 => \^bin_lpy\(7),
      I4 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_13_n_0\
    );
\bcd3_lpy[3]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C330332CD330300C"
    )
        port map (
      I0 => \^bin_lpy\(8),
      I1 => \^bin_lpy\(12),
      I2 => \^bin_lpy\(13),
      I3 => \^bin_lpy\(11),
      I4 => \^bin_lpy\(10),
      I5 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_14_n_0\
    );
\bcd3_lpy[3]_INST_0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4DA13A7C4B0130EC"
    )
        port map (
      I0 => \^bin_lpy\(7),
      I1 => \bcd3_lpy[3]_INST_0_i_19_n_0\,
      I2 => \^bin_lpy\(8),
      I3 => \bcd3_lpy[3]_INST_0_i_20_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_21_n_0\,
      I5 => \^bin_lpy\(6),
      O => \bcd3_lpy[3]_INST_0_i_15_n_0\
    );
\bcd3_lpy[3]_INST_0_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2142081008104284"
    )
        port map (
      I0 => \^bin_lpy\(9),
      I1 => \^bin_lpy\(10),
      I2 => \^bin_lpy\(11),
      I3 => \^bin_lpy\(13),
      I4 => \^bin_lpy\(12),
      I5 => \^bin_lpy\(8),
      O => \bcd3_lpy[3]_INST_0_i_16_n_0\
    );
\bcd3_lpy[3]_INST_0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A2599A4545A2249A"
    )
        port map (
      I0 => \^bin_lpy\(12),
      I1 => \^bin_lpy\(13),
      I2 => \^bin_lpy\(11),
      I3 => \^bin_lpy\(10),
      I4 => \^bin_lpy\(9),
      I5 => \^bin_lpy\(8),
      O => \bcd3_lpy[3]_INST_0_i_17_n_0\
    );
\bcd3_lpy[3]_INST_0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9429A54AA54A2952"
    )
        port map (
      I0 => \^bin_lpy\(9),
      I1 => \^bin_lpy\(10),
      I2 => \^bin_lpy\(11),
      I3 => \^bin_lpy\(13),
      I4 => \^bin_lpy\(12),
      I5 => \^bin_lpy\(8),
      O => \bcd3_lpy[3]_INST_0_i_18_n_0\
    );
\bcd3_lpy[3]_INST_0_i_19\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"249A45A2"
    )
        port map (
      I0 => \^bin_lpy\(10),
      I1 => \^bin_lpy\(11),
      I2 => \^bin_lpy\(13),
      I3 => \^bin_lpy\(12),
      I4 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_19_n_0\
    );
\bcd3_lpy[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3C303C303C3038F0"
    )
        port map (
      I0 => \^bin_lpy\(8),
      I1 => \^bin_lpy\(12),
      I2 => \^bin_lpy\(13),
      I3 => \^bin_lpy\(11),
      I4 => \^bin_lpy\(10),
      I5 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_2_n_0\
    );
\bcd3_lpy[3]_INST_0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3973CE9C31638C18"
    )
        port map (
      I0 => \^bin_lpy\(9),
      I1 => \^bin_lpy\(10),
      I2 => \^bin_lpy\(11),
      I3 => \^bin_lpy\(13),
      I4 => \^bin_lpy\(12),
      I5 => \^bin_lpy\(8),
      O => \bcd3_lpy[3]_INST_0_i_20_n_0\
    );
\bcd3_lpy[3]_INST_0_i_21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C3611C86"
    )
        port map (
      I0 => \^bin_lpy\(12),
      I1 => \^bin_lpy\(13),
      I2 => \^bin_lpy\(11),
      I3 => \^bin_lpy\(10),
      I4 => \^bin_lpy\(9),
      O => \bcd3_lpy[3]_INST_0_i_21_n_0\
    );
\bcd3_lpy[3]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F000E000"
    )
        port map (
      I0 => \^bin_lpy\(9),
      I1 => \^bin_lpy\(10),
      I2 => \^bin_lpy\(12),
      I3 => \^bin_lpy\(13),
      I4 => \^bin_lpy\(11),
      O => shifter_lpy1_out(21)
    );
\bcd3_lpy[3]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56AA"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_4_n_0\
    );
\bcd3_lpy[3]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A17C01EC"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_15_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_5_n_0\
    );
\bcd3_lpy[3]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772319EC660331C8"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_15_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      I5 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_6_n_0\
    );
\bcd3_lpy[3]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5466518A"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_15_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_7_n_0\
    );
\bcd3_lpy[3]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772319EC660331C8"
    )
        port map (
      I0 => \^bin_lpy\(6),
      I1 => \^bin_lpy\(7),
      I2 => \bcd3_lpy[3]_INST_0_i_16_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_17_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_18_n_0\,
      I5 => \^bin_lpy\(5),
      O => \bcd3_lpy[3]_INST_0_i_8_n_0\
    );
\bcd3_lpy[3]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"772379EC660371C8"
    )
        port map (
      I0 => \bcd3_lpy[3]_INST_0_i_15_n_0\,
      I1 => \bcd3_lpy[3]_INST_0_i_13_n_0\,
      I2 => \bcd3_lpy[3]_INST_0_i_11_n_0\,
      I3 => \bcd3_lpy[3]_INST_0_i_12_n_0\,
      I4 => \bcd3_lpy[3]_INST_0_i_14_n_0\,
      I5 => \bcd3_lpy[3]_INST_0_i_8_n_0\,
      O => \bcd3_lpy[3]_INST_0_i_9_n_0\
    );
end STRUCTURE;
