// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Sat Apr 12 11:30:59 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ BCD_IP_lpy_BCD2bin_lpy_0_0_stub.v
// Design      : BCD_IP_lpy_BCD2bin_lpy_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "BCD2bin_lpy,Vivado 2022.1.2" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(bcd3_lpy, bcd2_lpy, bcd1_lpy, bcd0_lpy, bin_lpy)
/* synthesis syn_black_box black_box_pad_pin="bcd3_lpy[3:0],bcd2_lpy[3:0],bcd1_lpy[3:0],bcd0_lpy[3:0],bin_lpy[13:0]" */;
  input [3:0]bcd3_lpy;
  input [3:0]bcd2_lpy;
  input [3:0]bcd1_lpy;
  input [3:0]bcd0_lpy;
  output [13:0]bin_lpy;
endmodule
