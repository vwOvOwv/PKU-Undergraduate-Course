// (c) Copyright 1995-2025 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: cs.pku.edu.cn:DDCA:bin2BCD_lpy:1.0
// IP Revision: 2

(* X_CORE_INFO = "bin2BCD_lpy,Vivado 2022.1.2" *)
(* CHECK_LICENSE_TYPE = "BCD_IP_lpy_bin2BCD_lpy_0_0,bin2BCD_lpy,{}" *)
(* IP_DEFINITION_SOURCE = "package_project" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module BCD_IP_lpy_bin2BCD_lpy_0_0 (
  bin_lpy,
  bcd3_lpy,
  bcd2_lpy,
  bcd1_lpy,
  bcd0_lpy
);

input wire [13 : 0] bin_lpy;
output wire [3 : 0] bcd3_lpy;
output wire [3 : 0] bcd2_lpy;
output wire [3 : 0] bcd1_lpy;
output wire [3 : 0] bcd0_lpy;

  bin2BCD_lpy inst (
    .bin_lpy(bin_lpy),
    .bcd3_lpy(bcd3_lpy),
    .bcd2_lpy(bcd2_lpy),
    .bcd1_lpy(bcd1_lpy),
    .bcd0_lpy(bcd0_lpy)
  );
endmodule
