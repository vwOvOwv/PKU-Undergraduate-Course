//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
//Date        : Sat Apr 12 11:30:30 2025
//Host        : A14 running 64-bit major release  (build 9200)
//Command     : generate_target BCD_IP_lpy.bd
//Design      : BCD_IP_lpy
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "BCD_IP_lpy,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=BCD_IP_lpy,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=8,numReposBlks=8,numNonXlnxBlks=4,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "BCD_IP_lpy.hwdef" *) 
module BCD_IP_lpy
   (an,
    clk,
    seg,
    sw);
  output [0:3]an;
  input clk;
  output [0:6]seg;
  input [15:0]sw;

  wire [13:0]BCD2bin_lpy_0_bin_lpy;
  wire [15:0]Din_0_1;
  wire [3:0]bin2BCD_lpy_0_bcd0_lpy;
  wire [3:0]bin2BCD_lpy_0_bcd1_lpy;
  wire [3:0]bin2BCD_lpy_0_bcd2_lpy;
  wire [3:0]bin2BCD_lpy_0_bcd3_lpy;
  wire clk_100MHz_lpy_0_1;
  wire clk_div_lpy_0_clk_sys_lpy;
  wire [0:3]display_7seg_x4_lpy_0_an_lpy;
  wire [0:6]display_7seg_x4_lpy_0_seg_lpy;
  wire [3:0]xlslice_0_Dout;
  wire [3:0]xlslice_1_Dout;
  wire [3:0]xlslice_2_Dout;
  wire [3:0]xlslice_3_Dout;

  assign Din_0_1 = sw[15:0];
  assign an[0:3] = display_7seg_x4_lpy_0_an_lpy;
  assign clk_100MHz_lpy_0_1 = clk;
  assign seg[0:6] = display_7seg_x4_lpy_0_seg_lpy;
  BCD_IP_lpy_BCD2bin_lpy_0_0 BCD2bin_lpy_0
       (.bcd0_lpy(xlslice_0_Dout),
        .bcd1_lpy(xlslice_1_Dout),
        .bcd2_lpy(xlslice_2_Dout),
        .bcd3_lpy(xlslice_3_Dout),
        .bin_lpy(BCD2bin_lpy_0_bin_lpy));
  BCD_IP_lpy_bin2BCD_lpy_0_0 bin2BCD_lpy_0
       (.bcd0_lpy(bin2BCD_lpy_0_bcd0_lpy),
        .bcd1_lpy(bin2BCD_lpy_0_bcd1_lpy),
        .bcd2_lpy(bin2BCD_lpy_0_bcd2_lpy),
        .bcd3_lpy(bin2BCD_lpy_0_bcd3_lpy),
        .bin_lpy(BCD2bin_lpy_0_bin_lpy));
  BCD_IP_lpy_clk_div_lpy_0_0 clk_div_lpy_0
       (.clk_100MHz_lpy(clk_100MHz_lpy_0_1),
        .clk_sys_lpy(clk_div_lpy_0_clk_sys_lpy));
  BCD_IP_lpy_display_7seg_x4_lpy_0_0 display_7seg_x4_lpy_0
       (.CLK_1KHz_lpy(clk_div_lpy_0_clk_sys_lpy),
        .an_lpy(display_7seg_x4_lpy_0_an_lpy),
        .in0_lpy(bin2BCD_lpy_0_bcd0_lpy),
        .in1_lpy(bin2BCD_lpy_0_bcd1_lpy),
        .in2_lpy(bin2BCD_lpy_0_bcd2_lpy),
        .in3_lpy(bin2BCD_lpy_0_bcd3_lpy),
        .seg_lpy(display_7seg_x4_lpy_0_seg_lpy));
  BCD_IP_lpy_xlslice_0_0 xlslice_0
       (.Din(Din_0_1),
        .Dout(xlslice_0_Dout));
  BCD_IP_lpy_xlslice_1_0 xlslice_1
       (.Din(Din_0_1),
        .Dout(xlslice_1_Dout));
  BCD_IP_lpy_xlslice_2_0 xlslice_2
       (.Din(Din_0_1),
        .Dout(xlslice_2_Dout));
  BCD_IP_lpy_xlslice_3_0 xlslice_3
       (.Din(Din_0_1),
        .Dout(xlslice_3_Dout));
endmodule
