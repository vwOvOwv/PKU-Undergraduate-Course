-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:30:59 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/22426/Desktop/ddca_lab_lpy/BCD_lpy/BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ip/BCD_IP_lpy_BCD2bin_lpy_0_0/BCD_IP_lpy_BCD2bin_lpy_0_0_sim_netlist.vhdl
-- Design      : BCD_IP_lpy_BCD2bin_lpy_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity BCD_IP_lpy_BCD2bin_lpy_0_0 is
  port (
    bcd3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bin_lpy : out STD_LOGIC_VECTOR ( 13 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of BCD_IP_lpy_BCD2bin_lpy_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of BCD_IP_lpy_BCD2bin_lpy_0_0 : entity is "BCD_IP_lpy_BCD2bin_lpy_0_0,BCD2bin_lpy,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of BCD_IP_lpy_BCD2bin_lpy_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of BCD_IP_lpy_BCD2bin_lpy_0_0 : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of BCD_IP_lpy_BCD2bin_lpy_0_0 : entity is "BCD2bin_lpy,Vivado 2022.1.2";
end BCD_IP_lpy_BCD2bin_lpy_0_0;

architecture STRUCTURE of BCD_IP_lpy_BCD2bin_lpy_0_0 is
  signal \^bcd0_lpy\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^bin_lpy\ : STD_LOGIC_VECTOR ( 13 downto 1 );
  signal \bin_lpy[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[11]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin_lpy[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_12_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_13_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_14_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_15_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_16_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_17_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_18_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_19_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_20_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_21_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_22_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bin_lpy[13]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bin_lpy[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[5]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[5]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin_lpy[5]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_10_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_11_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal \bin_lpy[7]_INST_0_i_9_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_6_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_7_n_0\ : STD_LOGIC;
  signal \bin_lpy[8]_INST_0_i_8_n_0\ : STD_LOGIC;
  signal p_0_in0 : STD_LOGIC;
  signal shifter_lpy : STD_LOGIC_VECTOR ( 17 downto 15 );
  signal shifter_lpy1_out0_out : STD_LOGIC_VECTOR ( 22 to 22 );
  signal shifter_lpy20 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \bin_lpy[11]_INST_0_i_4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_11\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_3\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_7\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bin_lpy[13]_INST_0_i_8\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \bin_lpy[4]_INST_0_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bin_lpy[5]_INST_0_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bin_lpy[5]_INST_0_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \bin_lpy[7]_INST_0_i_12\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bin_lpy[7]_INST_0_i_7\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \bin_lpy[8]_INST_0_i_3\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \bin_lpy[8]_INST_0_i_4\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bin_lpy[8]_INST_0_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \bin_lpy[8]_INST_0_i_6\ : label is "soft_lutpair1";
begin
  \^bcd0_lpy\(3 downto 0) <= bcd0_lpy(3 downto 0);
  bin_lpy(13 downto 1) <= \^bin_lpy\(13 downto 1);
  bin_lpy(0) <= \^bcd0_lpy\(0);
\bin_lpy[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_2_n_0\,
      O => \^bin_lpy\(10)
    );
\bin_lpy[11]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"366C9933C99366CC"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[11]_INST_0_i_1_n_0\,
      I2 => \bin_lpy[11]_INST_0_i_2_n_0\,
      I3 => \bin_lpy[11]_INST_0_i_3_n_0\,
      I4 => \bin_lpy[11]_INST_0_i_4_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_6_n_0\,
      O => \^bin_lpy\(11)
    );
\bin_lpy[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA8AAA880000000"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_16_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I4 => \bin_lpy[7]_INST_0_i_1_n_0\,
      I5 => \bin_lpy[7]_INST_0_i_4_n_0\,
      O => \bin_lpy[11]_INST_0_i_1_n_0\
    );
\bin_lpy[11]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A085051F7AFAE0A0"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_1_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_3_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_16_n_0\,
      I5 => \bin_lpy[7]_INST_0_i_4_n_0\,
      O => \bin_lpy[11]_INST_0_i_2_n_0\
    );
\bin_lpy[11]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"46666622662262AA"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_4_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_1_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I4 => \bin_lpy[7]_INST_0_i_3_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_16_n_0\,
      O => \bin_lpy[11]_INST_0_i_3_n_0\
    );
\bin_lpy[11]_INST_0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin_lpy[13]_INST_0_i_14_n_0\,
      O => \bin_lpy[11]_INST_0_i_4_n_0\
    );
\bin_lpy[12]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => shifter_lpy20,
      I1 => \bin_lpy[12]_INST_0_i_1_n_0\,
      O => \^bin_lpy\(12)
    );
\bin_lpy[12]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_6_n_0\,
      I1 => \bin_lpy[11]_INST_0_i_3_n_0\,
      I2 => \bin_lpy[11]_INST_0_i_2_n_0\,
      I3 => \bin_lpy[11]_INST_0_i_1_n_0\,
      I4 => \bin_lpy[11]_INST_0_i_4_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_4_n_0\,
      O => \bin_lpy[12]_INST_0_i_1_n_0\
    );
\bin_lpy[13]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A805015F7FAAEA00"
    )
        port map (
      I0 => shifter_lpy20,
      I1 => \bin_lpy[13]_INST_0_i_2_n_0\,
      I2 => \bin_lpy[13]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[13]_INST_0_i_4_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_5_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_6_n_0\,
      O => \^bin_lpy\(13)
    );
\bin_lpy[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin_lpy[13]_INST_0_i_8_n_0\,
      I2 => \bin_lpy[13]_INST_0_i_9_n_0\,
      I3 => \bin_lpy[13]_INST_0_i_10_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_11_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_12_n_0\,
      O => shifter_lpy20
    );
\bin_lpy[13]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_19_n_0\,
      I5 => \bin_lpy[7]_INST_0_i_8_n_0\,
      O => \bin_lpy[13]_INST_0_i_10_n_0\
    );
\bin_lpy[13]_INST_0_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_20_n_0\,
      I1 => bcd3_lpy(3),
      I2 => \bin_lpy[13]_INST_0_i_21_n_0\,
      O => \bin_lpy[13]_INST_0_i_11_n_0\
    );
\bin_lpy[13]_INST_0_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I4 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_19_n_0\,
      O => \bin_lpy[13]_INST_0_i_12_n_0\
    );
\bin_lpy[13]_INST_0_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EAB9AAB9FFFFFFFF"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_16_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I4 => \bin_lpy[7]_INST_0_i_1_n_0\,
      I5 => \bin_lpy[8]_INST_0_i_1_n_0\,
      O => \bin_lpy[13]_INST_0_i_13_n_0\
    );
\bin_lpy[13]_INST_0_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_4_n_0\,
      I2 => \bin_lpy[8]_INST_0_i_5_n_0\,
      I3 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I4 => \bin_lpy[8]_INST_0_i_6_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_11_n_0\,
      O => \bin_lpy[13]_INST_0_i_14_n_0\
    );
\bin_lpy[13]_INST_0_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_6_n_0\,
      I2 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[8]_INST_0_i_5_n_0\,
      I4 => \bin_lpy[8]_INST_0_i_4_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_11_n_0\,
      O => \bin_lpy[13]_INST_0_i_15_n_0\
    );
\bin_lpy[13]_INST_0_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_22_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_1_n_0\,
      O => \bin_lpy[13]_INST_0_i_16_n_0\
    );
\bin_lpy[13]_INST_0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBABA9A9FFFFFFFF"
    )
        port map (
      I0 => bcd3_lpy(1),
      I1 => bcd2_lpy(3),
      I2 => bcd3_lpy(0),
      I3 => bcd2_lpy(1),
      I4 => bcd2_lpy(2),
      I5 => bcd3_lpy(2),
      O => \bin_lpy[13]_INST_0_i_17_n_0\
    );
\bin_lpy[13]_INST_0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => bcd3_lpy(2),
      I1 => bcd3_lpy(1),
      I2 => bcd2_lpy(2),
      I3 => bcd2_lpy(1),
      I4 => bcd3_lpy(0),
      I5 => bcd2_lpy(3),
      O => \bin_lpy[13]_INST_0_i_18_n_0\
    );
\bin_lpy[13]_INST_0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666606066600000"
    )
        port map (
      I0 => bcd3_lpy(0),
      I1 => bcd2_lpy(1),
      I2 => bcd1_lpy(2),
      I3 => bcd1_lpy(1),
      I4 => bcd2_lpy(0),
      I5 => bcd1_lpy(3),
      O => \bin_lpy[13]_INST_0_i_19_n_0\
    );
\bin_lpy[13]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin_lpy[11]_INST_0_i_2_n_0\,
      I1 => \bin_lpy[11]_INST_0_i_4_n_0\,
      I2 => \bin_lpy[11]_INST_0_i_3_n_0\,
      O => \bin_lpy[13]_INST_0_i_2_n_0\
    );
\bin_lpy[13]_INST_0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => bcd3_lpy(2),
      I1 => bcd2_lpy(2),
      I2 => bcd2_lpy(1),
      I3 => bcd3_lpy(0),
      I4 => bcd2_lpy(3),
      I5 => bcd3_lpy(1),
      O => \bin_lpy[13]_INST_0_i_20_n_0\
    );
\bin_lpy[13]_INST_0_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => bcd3_lpy(2),
      I1 => bcd2_lpy(3),
      I2 => bcd3_lpy(0),
      I3 => bcd2_lpy(1),
      I4 => bcd2_lpy(2),
      I5 => bcd3_lpy(1),
      O => \bin_lpy[13]_INST_0_i_21_n_0\
    );
\bin_lpy[13]_INST_0_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F666666666666060"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I2 => shifter_lpy(17),
      I3 => shifter_lpy(15),
      I4 => shifter_lpy(16),
      I5 => \bin_lpy[7]_INST_0_i_7_n_0\,
      O => \bin_lpy[13]_INST_0_i_22_n_0\
    );
\bin_lpy[13]_INST_0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin_lpy[11]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_13_n_0\,
      I2 => \bin_lpy[11]_INST_0_i_1_n_0\,
      O => \bin_lpy[13]_INST_0_i_3_n_0\
    );
\bin_lpy[13]_INST_0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_14_n_0\,
      I1 => p_0_in0,
      I2 => \bin_lpy[13]_INST_0_i_15_n_0\,
      O => \bin_lpy[13]_INST_0_i_4_n_0\
    );
\bin_lpy[13]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAA80000"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I2 => \bin_lpy[13]_INST_0_i_16_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_4_n_0\,
      I4 => \bin_lpy[11]_INST_0_i_4_n_0\,
      O => \bin_lpy[13]_INST_0_i_5_n_0\
    );
\bin_lpy[13]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => p_0_in0,
      I1 => \bin_lpy[13]_INST_0_i_12_n_0\,
      I2 => \bin_lpy[13]_INST_0_i_11_n_0\,
      I3 => \bin_lpy[13]_INST_0_i_10_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_9_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_8_n_0\,
      O => \bin_lpy[13]_INST_0_i_6_n_0\
    );
\bin_lpy[13]_INST_0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"C4"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_17_n_0\,
      I1 => bcd3_lpy(3),
      I2 => \bin_lpy[13]_INST_0_i_18_n_0\,
      O => p_0_in0
    );
\bin_lpy[13]_INST_0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => bcd3_lpy(3),
      I1 => \bin_lpy[13]_INST_0_i_17_n_0\,
      I2 => \bin_lpy[13]_INST_0_i_18_n_0\,
      O => \bin_lpy[13]_INST_0_i_8_n_0\
    );
\bin_lpy[13]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_19_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I4 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I5 => \bin_lpy[7]_INST_0_i_8_n_0\,
      O => \bin_lpy[13]_INST_0_i_9_n_0\
    );
\bin_lpy[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^bcd0_lpy\(1),
      I1 => bcd1_lpy(0),
      O => \^bin_lpy\(1)
    );
\bin_lpy[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => bcd1_lpy(1),
      I1 => bcd2_lpy(0),
      I2 => \^bcd0_lpy\(2),
      I3 => bcd1_lpy(0),
      I4 => \^bcd0_lpy\(1),
      O => \^bin_lpy\(2)
    );
\bin_lpy[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8778788778878778"
    )
        port map (
      I0 => bcd1_lpy(1),
      I1 => bcd2_lpy(0),
      I2 => bcd1_lpy(2),
      I3 => bcd3_lpy(0),
      I4 => bcd2_lpy(1),
      I5 => shifter_lpy(15),
      O => \^bin_lpy\(3)
    );
\bin_lpy[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F6609F9F099F6060"
    )
        port map (
      I0 => bcd2_lpy(0),
      I1 => bcd1_lpy(1),
      I2 => \^bcd0_lpy\(2),
      I3 => \^bcd0_lpy\(1),
      I4 => bcd1_lpy(0),
      I5 => \^bcd0_lpy\(3),
      O => shifter_lpy(15)
    );
\bin_lpy[4]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[4]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[4]_INST_0_i_2_n_0\,
      O => \^bin_lpy\(4)
    );
\bin_lpy[4]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"78878778"
    )
        port map (
      I0 => bcd2_lpy(1),
      I1 => bcd3_lpy(0),
      I2 => bcd2_lpy(2),
      I3 => bcd3_lpy(1),
      I4 => \bin_lpy[5]_INST_0_i_5_n_0\,
      O => \bin_lpy[4]_INST_0_i_1_n_0\
    );
\bin_lpy[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A801055F7FEAAA00"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_7_n_0\,
      I1 => \^bcd0_lpy\(1),
      I2 => \^bcd0_lpy\(2),
      I3 => \^bcd0_lpy\(3),
      I4 => bcd1_lpy(0),
      I5 => \bin_lpy[4]_INST_0_i_3_n_0\,
      O => \bin_lpy[4]_INST_0_i_2_n_0\
    );
\bin_lpy[4]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd2_lpy(0),
      I1 => bcd1_lpy(1),
      O => \bin_lpy[4]_INST_0_i_3_n_0\
    );
\bin_lpy[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_2_n_0\,
      O => \^bin_lpy\(5)
    );
\bin_lpy[5]_INST_0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_5_n_0\,
      O => \bin_lpy[5]_INST_0_i_1_n_0\
    );
\bin_lpy[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F069690F9696F0F0"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I2 => shifter_lpy(17),
      I3 => shifter_lpy(15),
      I4 => shifter_lpy(16),
      I5 => \bin_lpy[7]_INST_0_i_7_n_0\,
      O => \bin_lpy[5]_INST_0_i_2_n_0\
    );
\bin_lpy[5]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9906900690669666"
    )
        port map (
      I0 => bcd3_lpy(0),
      I1 => bcd2_lpy(1),
      I2 => bcd1_lpy(3),
      I3 => bcd2_lpy(0),
      I4 => bcd1_lpy(1),
      I5 => bcd1_lpy(2),
      O => \bin_lpy[5]_INST_0_i_3_n_0\
    );
\bin_lpy[5]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9666"
    )
        port map (
      I0 => bcd3_lpy(1),
      I1 => bcd2_lpy(2),
      I2 => bcd3_lpy(0),
      I3 => bcd2_lpy(1),
      O => \bin_lpy[5]_INST_0_i_4_n_0\
    );
\bin_lpy[5]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F069690F9696F0F0"
    )
        port map (
      I0 => bcd3_lpy(0),
      I1 => bcd2_lpy(1),
      I2 => bcd1_lpy(3),
      I3 => bcd1_lpy(1),
      I4 => bcd1_lpy(2),
      I5 => bcd2_lpy(0),
      O => \bin_lpy[5]_INST_0_i_5_n_0\
    );
\bin_lpy[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_1_n_0\,
      O => \^bin_lpy\(6)
    );
\bin_lpy[7]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8778"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_2_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_3_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_4_n_0\,
      O => \^bin_lpy\(7)
    );
\bin_lpy[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_1_n_0\,
      I1 => shifter_lpy(16),
      I2 => shifter_lpy(15),
      I3 => shifter_lpy(17),
      I4 => \bin_lpy[7]_INST_0_i_7_n_0\,
      I5 => \bin_lpy[4]_INST_0_i_1_n_0\,
      O => \bin_lpy[7]_INST_0_i_1_n_0\
    );
\bin_lpy[7]_INST_0_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A81101777FAAEA00"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => bcd1_lpy(2),
      I2 => bcd1_lpy(1),
      I3 => bcd2_lpy(0),
      I4 => bcd1_lpy(3),
      I5 => shifter_lpy1_out0_out(22),
      O => \bin_lpy[7]_INST_0_i_10_n_0\
    );
\bin_lpy[7]_INST_0_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A888888888888080"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => shifter_lpy1_out0_out(22),
      I2 => bcd1_lpy(2),
      I3 => bcd1_lpy(1),
      I4 => bcd2_lpy(0),
      I5 => bcd1_lpy(3),
      O => \bin_lpy[7]_INST_0_i_11_n_0\
    );
\bin_lpy[7]_INST_0_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd3_lpy(0),
      I1 => bcd2_lpy(1),
      O => shifter_lpy1_out0_out(22)
    );
\bin_lpy[7]_INST_0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_5_n_0\,
      O => \bin_lpy[7]_INST_0_i_2_n_0\
    );
\bin_lpy[7]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545446422AAAAAAA"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_7_n_0\,
      I2 => shifter_lpy(16),
      I3 => shifter_lpy(15),
      I4 => shifter_lpy(17),
      I5 => \bin_lpy[4]_INST_0_i_1_n_0\,
      O => \bin_lpy[7]_INST_0_i_3_n_0\
    );
\bin_lpy[7]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_11_n_0\,
      I1 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_9_n_0\,
      I3 => \bin_lpy[7]_INST_0_i_10_n_0\,
      I4 => \bin_lpy[7]_INST_0_i_11_n_0\,
      I5 => \bin_lpy[8]_INST_0_i_3_n_0\,
      O => \bin_lpy[7]_INST_0_i_4_n_0\
    );
\bin_lpy[7]_INST_0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9096960690069666"
    )
        port map (
      I0 => bcd2_lpy(0),
      I1 => bcd1_lpy(1),
      I2 => bcd1_lpy(0),
      I3 => \^bcd0_lpy\(3),
      I4 => \^bcd0_lpy\(2),
      I5 => \^bcd0_lpy\(1),
      O => shifter_lpy(16)
    );
\bin_lpy[7]_INST_0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666666066000000"
    )
        port map (
      I0 => bcd2_lpy(0),
      I1 => bcd1_lpy(1),
      I2 => \^bcd0_lpy\(1),
      I3 => \^bcd0_lpy\(2),
      I4 => \^bcd0_lpy\(3),
      I5 => bcd1_lpy(0),
      O => shifter_lpy(17)
    );
\bin_lpy[7]_INST_0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"69969696"
    )
        port map (
      I0 => bcd2_lpy(1),
      I1 => bcd3_lpy(0),
      I2 => bcd1_lpy(2),
      I3 => bcd2_lpy(0),
      I4 => bcd1_lpy(1),
      O => \bin_lpy[7]_INST_0_i_7_n_0\
    );
\bin_lpy[7]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => bcd3_lpy(2),
      I1 => bcd3_lpy(0),
      I2 => bcd2_lpy(2),
      I3 => bcd2_lpy(1),
      I4 => bcd2_lpy(3),
      I5 => bcd3_lpy(1),
      O => \bin_lpy[7]_INST_0_i_8_n_0\
    );
\bin_lpy[7]_INST_0_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"545452422AAAAAAA"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => bcd1_lpy(3),
      I2 => bcd2_lpy(0),
      I3 => bcd1_lpy(1),
      I4 => bcd1_lpy(2),
      I5 => shifter_lpy1_out0_out(22),
      O => \bin_lpy[7]_INST_0_i_9_n_0\
    );
\bin_lpy[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[8]_INST_0_i_1_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_2_n_0\,
      O => \^bin_lpy\(8)
    );
\bin_lpy[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"65699A965999A666"
    )
        port map (
      I0 => \bin_lpy[13]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_3_n_0\,
      I2 => \bin_lpy[8]_INST_0_i_4_n_0\,
      I3 => \bin_lpy[8]_INST_0_i_5_n_0\,
      I4 => \bin_lpy[8]_INST_0_i_6_n_0\,
      I5 => \bin_lpy[13]_INST_0_i_11_n_0\,
      O => \bin_lpy[8]_INST_0_i_1_n_0\
    );
\bin_lpy[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A80111777FEAAA00"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[8]_INST_0_i_7_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_2_n_0\,
      I3 => \bin_lpy[8]_INST_0_i_8_n_0\,
      I4 => \bin_lpy[5]_INST_0_i_1_n_0\,
      I5 => \bin_lpy[7]_INST_0_i_2_n_0\,
      O => \bin_lpy[8]_INST_0_i_2_n_0\
    );
\bin_lpy[8]_INST_0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => bcd3_lpy(3),
      I1 => \bin_lpy[13]_INST_0_i_20_n_0\,
      O => \bin_lpy[8]_INST_0_i_3_n_0\
    );
\bin_lpy[8]_INST_0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"52424A6A"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_19_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I4 => \bin_lpy[5]_INST_0_i_3_n_0\,
      O => \bin_lpy[8]_INST_0_i_4_n_0\
    );
\bin_lpy[8]_INST_0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"C99366CC"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[13]_INST_0_i_19_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I4 => \bin_lpy[5]_INST_0_i_4_n_0\,
      O => \bin_lpy[8]_INST_0_i_5_n_0\
    );
\bin_lpy[8]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA88A800"
    )
        port map (
      I0 => \bin_lpy[7]_INST_0_i_8_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_3_n_0\,
      I2 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I3 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I4 => \bin_lpy[13]_INST_0_i_19_n_0\,
      O => \bin_lpy[8]_INST_0_i_6_n_0\
    );
\bin_lpy[8]_INST_0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9096900696069666"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I2 => \bin_lpy[7]_INST_0_i_7_n_0\,
      I3 => shifter_lpy(17),
      I4 => shifter_lpy(15),
      I5 => shifter_lpy(16),
      O => \bin_lpy[8]_INST_0_i_7_n_0\
    );
\bin_lpy[8]_INST_0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6666666060600000"
    )
        port map (
      I0 => \bin_lpy[5]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[5]_INST_0_i_5_n_0\,
      I2 => shifter_lpy(16),
      I3 => shifter_lpy(15),
      I4 => shifter_lpy(17),
      I5 => \bin_lpy[7]_INST_0_i_7_n_0\,
      O => \bin_lpy[8]_INST_0_i_8_n_0\
    );
\bin_lpy[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \bin_lpy[11]_INST_0_i_4_n_0\,
      I1 => \bin_lpy[11]_INST_0_i_2_n_0\,
      O => \^bin_lpy\(9)
    );
end STRUCTURE;
