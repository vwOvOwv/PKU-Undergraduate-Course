// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Sat Apr 12 11:30:59 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/22426/Desktop/ddca_lab_lpy/BCD_lpy/BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ip/BCD_IP_lpy_display_7seg_x4_lpy_0_0/BCD_IP_lpy_display_7seg_x4_lpy_0_0_stub.v
// Design      : BCD_IP_lpy_display_7seg_x4_lpy_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "display_7seg_x4_lpy,Vivado 2022.1.2" *)
module BCD_IP_lpy_display_7seg_x4_lpy_0_0(CLK_1KHz_lpy, in3_lpy, in2_lpy, in1_lpy, in0_lpy, 
  an_lpy, seg_lpy)
/* synthesis syn_black_box black_box_pad_pin="CLK_1KHz_lpy,in3_lpy[3:0],in2_lpy[3:0],in1_lpy[3:0],in0_lpy[3:0],an_lpy[0:3],seg_lpy[0:6]" */;
  input CLK_1KHz_lpy;
  input [3:0]in3_lpy;
  input [3:0]in2_lpy;
  input [3:0]in1_lpy;
  input [3:0]in0_lpy;
  output [0:3]an_lpy;
  output [0:6]seg_lpy;
endmodule
