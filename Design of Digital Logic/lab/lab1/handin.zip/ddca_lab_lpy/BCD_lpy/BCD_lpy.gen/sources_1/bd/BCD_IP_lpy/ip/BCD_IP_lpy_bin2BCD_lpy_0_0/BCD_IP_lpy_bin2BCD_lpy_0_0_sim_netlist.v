// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Sat Apr 12 11:31:00 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/22426/Desktop/ddca_lab_lpy/BCD_lpy/BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ip/BCD_IP_lpy_bin2BCD_lpy_0_0/BCD_IP_lpy_bin2BCD_lpy_0_0_sim_netlist.v
// Design      : BCD_IP_lpy_bin2BCD_lpy_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "BCD_IP_lpy_bin2BCD_lpy_0_0,bin2BCD_lpy,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "package_project" *) 
(* X_CORE_INFO = "bin2BCD_lpy,Vivado 2022.1.2" *) 
(* NotValidForBitStream *)
module BCD_IP_lpy_bin2BCD_lpy_0_0
   (bin_lpy,
    bcd3_lpy,
    bcd2_lpy,
    bcd1_lpy,
    bcd0_lpy);
  input [13:0]bin_lpy;
  output [3:0]bcd3_lpy;
  output [3:0]bcd2_lpy;
  output [3:0]bcd1_lpy;
  output [3:0]bcd0_lpy;

  wire [3:1]\^bcd0_lpy ;
  wire [3:0]bcd1_lpy;
  wire \bcd1_lpy[0]_INST_0_i_1_n_0 ;
  wire \bcd1_lpy[0]_INST_0_i_2_n_0 ;
  wire \bcd1_lpy[0]_INST_0_i_3_n_0 ;
  wire [3:0]bcd2_lpy;
  wire \bcd2_lpy[0]_INST_0_i_10_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_11_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_12_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_13_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_14_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_15_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_1_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_2_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_3_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_4_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_5_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_6_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_7_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_8_n_0 ;
  wire \bcd2_lpy[0]_INST_0_i_9_n_0 ;
  wire [3:0]bcd3_lpy;
  wire \bcd3_lpy[0]_INST_0_i_1_n_0 ;
  wire \bcd3_lpy[0]_INST_0_i_2_n_0 ;
  wire \bcd3_lpy[0]_INST_0_i_3_n_0 ;
  wire \bcd3_lpy[0]_INST_0_i_4_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_10_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_11_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_12_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_13_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_14_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_15_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_16_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_17_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_18_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_19_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_1_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_20_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_21_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_2_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_4_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_5_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_6_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_7_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_8_n_0 ;
  wire \bcd3_lpy[3]_INST_0_i_9_n_0 ;
  wire [13:0]bin_lpy;
  wire [21:21]shifter_lpy1_out;

  assign bcd0_lpy[3:1] = \^bcd0_lpy [3:1];
  assign bcd0_lpy[0] = bin_lpy[0];
  LUT6 #(
    .INIT(64'h900924094BF6DBB4)) 
    \bcd0_lpy[1]_INST_0 
       (.I0(bin_lpy[3]),
        .I1(\bcd1_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd1_lpy[0]_INST_0_i_2_n_0 ),
        .I3(\bcd1_lpy[0]_INST_0_i_3_n_0 ),
        .I4(bin_lpy[2]),
        .I5(bin_lpy[1]),
        .O(\^bcd0_lpy [1]));
  LUT6 #(
    .INIT(64'h00FFFF004B2409B4)) 
    \bcd0_lpy[2]_INST_0 
       (.I0(bin_lpy[3]),
        .I1(\bcd1_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd1_lpy[0]_INST_0_i_2_n_0 ),
        .I3(bin_lpy[2]),
        .I4(\bcd1_lpy[0]_INST_0_i_3_n_0 ),
        .I5(bin_lpy[1]),
        .O(\^bcd0_lpy [2]));
  LUT6 #(
    .INIT(64'h0942909066429066)) 
    \bcd0_lpy[3]_INST_0 
       (.I0(bin_lpy[3]),
        .I1(\bcd1_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd1_lpy[0]_INST_0_i_2_n_0 ),
        .I3(bin_lpy[2]),
        .I4(\bcd1_lpy[0]_INST_0_i_3_n_0 ),
        .I5(bin_lpy[1]),
        .O(\^bcd0_lpy [3]));
  LUT6 #(
    .INIT(64'h2D4BD2D24B4BD2B4)) 
    \bcd1_lpy[0]_INST_0 
       (.I0(bin_lpy[3]),
        .I1(\bcd1_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd1_lpy[0]_INST_0_i_2_n_0 ),
        .I3(bin_lpy[2]),
        .I4(\bcd1_lpy[0]_INST_0_i_3_n_0 ),
        .I5(bin_lpy[1]),
        .O(bcd1_lpy[0]));
  LUT6 #(
    .INIT(64'h5FA53AFC5B0530EC)) 
    \bcd1_lpy[0]_INST_0_i_1 
       (.I0(bin_lpy[4]),
        .I1(\bcd2_lpy[0]_INST_0_i_7_n_0 ),
        .I2(bin_lpy[5]),
        .I3(\bcd2_lpy[0]_INST_0_i_8_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_9_n_0 ),
        .I5(bin_lpy[3]),
        .O(\bcd1_lpy[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hC2836425195893CA)) 
    \bcd1_lpy[0]_INST_0_i_2 
       (.I0(\bcd2_lpy[0]_INST_0_i_12_n_0 ),
        .I1(\bcd2_lpy[0]_INST_0_i_11_n_0 ),
        .I2(bin_lpy[6]),
        .I3(\bcd2_lpy[0]_INST_0_i_10_n_0 ),
        .I4(bin_lpy[5]),
        .I5(bin_lpy[4]),
        .O(\bcd1_lpy[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h5FA53AFC5B0530EC)) 
    \bcd1_lpy[0]_INST_0_i_3 
       (.I0(bin_lpy[3]),
        .I1(\bcd2_lpy[0]_INST_0_i_13_n_0 ),
        .I2(bin_lpy[4]),
        .I3(\bcd2_lpy[0]_INST_0_i_14_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_15_n_0 ),
        .I5(bin_lpy[2]),
        .O(\bcd1_lpy[0]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hC2836425195893CA)) 
    \bcd1_lpy[1]_INST_0 
       (.I0(\bcd2_lpy[0]_INST_0_i_5_n_0 ),
        .I1(\bcd2_lpy[0]_INST_0_i_4_n_0 ),
        .I2(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_2_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_1_n_0 ),
        .I5(\bcd2_lpy[0]_INST_0_i_6_n_0 ),
        .O(bcd1_lpy[1]));
  LUT6 #(
    .INIT(64'h195495664251A58A)) 
    \bcd1_lpy[2]_INST_0 
       (.I0(\bcd2_lpy[0]_INST_0_i_1_n_0 ),
        .I1(\bcd2_lpy[0]_INST_0_i_2_n_0 ),
        .I2(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_4_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_5_n_0 ),
        .I5(\bcd2_lpy[0]_INST_0_i_6_n_0 ),
        .O(bcd1_lpy[2]));
  LUT6 #(
    .INIT(64'h4101204807A00AD0)) 
    \bcd1_lpy[3]_INST_0 
       (.I0(\bcd2_lpy[0]_INST_0_i_1_n_0 ),
        .I1(\bcd2_lpy[0]_INST_0_i_2_n_0 ),
        .I2(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_4_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_5_n_0 ),
        .I5(\bcd2_lpy[0]_INST_0_i_6_n_0 ),
        .O(bcd1_lpy[3]));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd2_lpy[0]_INST_0 
       (.I0(\bcd2_lpy[0]_INST_0_i_1_n_0 ),
        .I1(\bcd2_lpy[0]_INST_0_i_2_n_0 ),
        .I2(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_4_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_5_n_0 ),
        .I5(\bcd2_lpy[0]_INST_0_i_6_n_0 ),
        .O(bcd2_lpy[0]));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd2_lpy[0]_INST_0_i_1 
       (.I0(bin_lpy[4]),
        .I1(\bcd2_lpy[0]_INST_0_i_7_n_0 ),
        .I2(bin_lpy[5]),
        .I3(\bcd2_lpy[0]_INST_0_i_8_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_9_n_0 ),
        .I5(bin_lpy[3]),
        .O(\bcd2_lpy[0]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h3C623C46)) 
    \bcd2_lpy[0]_INST_0_i_10 
       (.I0(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I1(bin_lpy[8]),
        .I2(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I3(bin_lpy[7]),
        .I4(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .O(\bcd2_lpy[0]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h5FA53AFC5B0530EC)) 
    \bcd2_lpy[0]_INST_0_i_11 
       (.I0(bin_lpy[7]),
        .I1(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I2(bin_lpy[8]),
        .I3(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .I5(bin_lpy[6]),
        .O(\bcd2_lpy[0]_INST_0_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h481137EC)) 
    \bcd2_lpy[0]_INST_0_i_12 
       (.I0(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I2(bin_lpy[8]),
        .I3(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I4(bin_lpy[7]),
        .O(\bcd2_lpy[0]_INST_0_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h2299545A449A2592)) 
    \bcd2_lpy[0]_INST_0_i_13 
       (.I0(bin_lpy[6]),
        .I1(bin_lpy[7]),
        .I2(\bcd3_lpy[3]_INST_0_i_16_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_17_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_18_n_0 ),
        .I5(bin_lpy[5]),
        .O(\bcd2_lpy[0]_INST_0_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h5FA53AFC5B0530EC)) 
    \bcd2_lpy[0]_INST_0_i_14 
       (.I0(bin_lpy[5]),
        .I1(\bcd2_lpy[0]_INST_0_i_10_n_0 ),
        .I2(bin_lpy[6]),
        .I3(\bcd2_lpy[0]_INST_0_i_11_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_12_n_0 ),
        .I5(bin_lpy[4]),
        .O(\bcd2_lpy[0]_INST_0_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \bcd2_lpy[0]_INST_0_i_15 
       (.I0(\bcd2_lpy[0]_INST_0_i_8_n_0 ),
        .I1(bin_lpy[5]),
        .O(\bcd2_lpy[0]_INST_0_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB4)) 
    \bcd2_lpy[0]_INST_0_i_2 
       (.I0(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_9_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_10_n_0 ),
        .O(\bcd2_lpy[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd2_lpy[0]_INST_0_i_3 
       (.I0(bin_lpy[5]),
        .I1(\bcd2_lpy[0]_INST_0_i_10_n_0 ),
        .I2(bin_lpy[6]),
        .I3(\bcd2_lpy[0]_INST_0_i_11_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_12_n_0 ),
        .I5(bin_lpy[4]),
        .O(\bcd2_lpy[0]_INST_0_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hDF5E7A7A)) 
    \bcd2_lpy[0]_INST_0_i_4 
       (.I0(\bcd3_lpy[3]_INST_0_i_7_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_9_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_10_n_0 ),
        .O(\bcd2_lpy[0]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \bcd2_lpy[0]_INST_0_i_5 
       (.I0(\bcd3_lpy[3]_INST_0_i_9_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .O(\bcd2_lpy[0]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd2_lpy[0]_INST_0_i_6 
       (.I0(bin_lpy[3]),
        .I1(\bcd2_lpy[0]_INST_0_i_13_n_0 ),
        .I2(bin_lpy[4]),
        .I3(\bcd2_lpy[0]_INST_0_i_14_n_0 ),
        .I4(\bcd2_lpy[0]_INST_0_i_15_n_0 ),
        .I5(bin_lpy[2]),
        .O(\bcd2_lpy[0]_INST_0_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h195495664251A58A)) 
    \bcd2_lpy[0]_INST_0_i_7 
       (.I0(bin_lpy[7]),
        .I1(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I2(bin_lpy[8]),
        .I3(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .I5(bin_lpy[6]),
        .O(\bcd2_lpy[0]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h772379EC660371C8)) 
    \bcd2_lpy[0]_INST_0_i_8 
       (.I0(bin_lpy[6]),
        .I1(bin_lpy[7]),
        .I2(\bcd3_lpy[3]_INST_0_i_16_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_17_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_18_n_0 ),
        .I5(bin_lpy[5]),
        .O(\bcd2_lpy[0]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hC2836425195893CA)) 
    \bcd2_lpy[0]_INST_0_i_9 
       (.I0(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I2(bin_lpy[8]),
        .I3(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I4(bin_lpy[7]),
        .I5(bin_lpy[6]),
        .O(\bcd2_lpy[0]_INST_0_i_9_n_0 ));
  LUT5 #(
    .INIT(32'h23895472)) 
    \bcd2_lpy[1]_INST_0 
       (.I0(\bcd3_lpy[0]_INST_0_i_3_n_0 ),
        .I1(\bcd3_lpy[0]_INST_0_i_2_n_0 ),
        .I2(\bcd3_lpy[0]_INST_0_i_1_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I4(\bcd3_lpy[0]_INST_0_i_4_n_0 ),
        .O(bcd2_lpy[1]));
  LUT5 #(
    .INIT(32'h5466518A)) 
    \bcd2_lpy[2]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd3_lpy[0]_INST_0_i_2_n_0 ),
        .I3(\bcd3_lpy[0]_INST_0_i_3_n_0 ),
        .I4(\bcd3_lpy[0]_INST_0_i_4_n_0 ),
        .O(bcd2_lpy[2]));
  LUT5 #(
    .INIT(32'h0148A0D0)) 
    \bcd2_lpy[3]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd3_lpy[0]_INST_0_i_2_n_0 ),
        .I3(\bcd3_lpy[0]_INST_0_i_3_n_0 ),
        .I4(\bcd3_lpy[0]_INST_0_i_4_n_0 ),
        .O(bcd2_lpy[3]));
  LUT5 #(
    .INIT(32'hA17C01EC)) 
    \bcd3_lpy[0]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[0]_INST_0_i_1_n_0 ),
        .I2(\bcd3_lpy[0]_INST_0_i_2_n_0 ),
        .I3(\bcd3_lpy[0]_INST_0_i_3_n_0 ),
        .I4(\bcd3_lpy[0]_INST_0_i_4_n_0 ),
        .O(bcd3_lpy[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h41201804)) 
    \bcd3_lpy[0]_INST_0_i_1 
       (.I0(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I2(shifter_lpy1_out),
        .I3(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(\bcd3_lpy[0]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hC3611C86)) 
    \bcd3_lpy[0]_INST_0_i_2 
       (.I0(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I1(shifter_lpy1_out),
        .I2(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(\bcd3_lpy[0]_INST_0_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h249A45A2)) 
    \bcd3_lpy[0]_INST_0_i_3 
       (.I0(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I2(shifter_lpy1_out),
        .I3(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(\bcd3_lpy[0]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd3_lpy[0]_INST_0_i_4 
       (.I0(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_7_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_9_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_10_n_0 ),
        .I5(\bcd2_lpy[0]_INST_0_i_1_n_0 ),
        .O(\bcd3_lpy[0]_INST_0_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0E83F01C1002F33C)) 
    \bcd3_lpy[1]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I2(shifter_lpy1_out),
        .I3(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I5(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(bcd3_lpy[1]));
  LUT6 #(
    .INIT(64'hC330332CD330300C)) 
    \bcd3_lpy[2]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I2(shifter_lpy1_out),
        .I3(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I5(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(bcd3_lpy[2]));
  LUT6 #(
    .INIT(64'h300C0000200C04C0)) 
    \bcd3_lpy[3]_INST_0 
       (.I0(\bcd3_lpy[3]_INST_0_i_1_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_2_n_0 ),
        .I2(shifter_lpy1_out),
        .I3(\bcd3_lpy[3]_INST_0_i_4_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_5_n_0 ),
        .I5(\bcd3_lpy[3]_INST_0_i_6_n_0 ),
        .O(bcd3_lpy[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h95565A5A)) 
    \bcd3_lpy[3]_INST_0_i_1 
       (.I0(\bcd3_lpy[3]_INST_0_i_7_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_9_n_0 ),
        .I3(\bcd2_lpy[0]_INST_0_i_3_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_10_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h23895472)) 
    \bcd3_lpy[3]_INST_0_i_10 
       (.I0(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h300C0000200C04C0)) 
    \bcd3_lpy[3]_INST_0_i_11 
       (.I0(bin_lpy[8]),
        .I1(bin_lpy[12]),
        .I2(bin_lpy[13]),
        .I3(bin_lpy[11]),
        .I4(bin_lpy[10]),
        .I5(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0E83F01C1002F33C)) 
    \bcd3_lpy[3]_INST_0_i_12 
       (.I0(bin_lpy[8]),
        .I1(bin_lpy[12]),
        .I2(bin_lpy[13]),
        .I3(bin_lpy[11]),
        .I4(bin_lpy[10]),
        .I5(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h95565A5A)) 
    \bcd3_lpy[3]_INST_0_i_13 
       (.I0(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I1(bin_lpy[8]),
        .I2(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I3(bin_lpy[7]),
        .I4(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hC330332CD330300C)) 
    \bcd3_lpy[3]_INST_0_i_14 
       (.I0(bin_lpy[8]),
        .I1(bin_lpy[12]),
        .I2(bin_lpy[13]),
        .I3(bin_lpy[11]),
        .I4(bin_lpy[10]),
        .I5(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h4DA13A7C4B0130EC)) 
    \bcd3_lpy[3]_INST_0_i_15 
       (.I0(bin_lpy[7]),
        .I1(\bcd3_lpy[3]_INST_0_i_19_n_0 ),
        .I2(bin_lpy[8]),
        .I3(\bcd3_lpy[3]_INST_0_i_20_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_21_n_0 ),
        .I5(bin_lpy[6]),
        .O(\bcd3_lpy[3]_INST_0_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h2142081008104284)) 
    \bcd3_lpy[3]_INST_0_i_16 
       (.I0(bin_lpy[9]),
        .I1(bin_lpy[10]),
        .I2(bin_lpy[11]),
        .I3(bin_lpy[13]),
        .I4(bin_lpy[12]),
        .I5(bin_lpy[8]),
        .O(\bcd3_lpy[3]_INST_0_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hA2599A4545A2249A)) 
    \bcd3_lpy[3]_INST_0_i_17 
       (.I0(bin_lpy[12]),
        .I1(bin_lpy[13]),
        .I2(bin_lpy[11]),
        .I3(bin_lpy[10]),
        .I4(bin_lpy[9]),
        .I5(bin_lpy[8]),
        .O(\bcd3_lpy[3]_INST_0_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h9429A54AA54A2952)) 
    \bcd3_lpy[3]_INST_0_i_18 
       (.I0(bin_lpy[9]),
        .I1(bin_lpy[10]),
        .I2(bin_lpy[11]),
        .I3(bin_lpy[13]),
        .I4(bin_lpy[12]),
        .I5(bin_lpy[8]),
        .O(\bcd3_lpy[3]_INST_0_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h249A45A2)) 
    \bcd3_lpy[3]_INST_0_i_19 
       (.I0(bin_lpy[10]),
        .I1(bin_lpy[11]),
        .I2(bin_lpy[13]),
        .I3(bin_lpy[12]),
        .I4(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h3C303C303C3038F0)) 
    \bcd3_lpy[3]_INST_0_i_2 
       (.I0(bin_lpy[8]),
        .I1(bin_lpy[12]),
        .I2(bin_lpy[13]),
        .I3(bin_lpy[11]),
        .I4(bin_lpy[10]),
        .I5(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h3973CE9C31638C18)) 
    \bcd3_lpy[3]_INST_0_i_20 
       (.I0(bin_lpy[9]),
        .I1(bin_lpy[10]),
        .I2(bin_lpy[11]),
        .I3(bin_lpy[13]),
        .I4(bin_lpy[12]),
        .I5(bin_lpy[8]),
        .O(\bcd3_lpy[3]_INST_0_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hC3611C86)) 
    \bcd3_lpy[3]_INST_0_i_21 
       (.I0(bin_lpy[12]),
        .I1(bin_lpy[13]),
        .I2(bin_lpy[11]),
        .I3(bin_lpy[10]),
        .I4(bin_lpy[9]),
        .O(\bcd3_lpy[3]_INST_0_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hF000E000)) 
    \bcd3_lpy[3]_INST_0_i_3 
       (.I0(bin_lpy[9]),
        .I1(bin_lpy[10]),
        .I2(bin_lpy[12]),
        .I3(bin_lpy[13]),
        .I4(bin_lpy[11]),
        .O(shifter_lpy1_out));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h56AA)) 
    \bcd3_lpy[3]_INST_0_i_4 
       (.I0(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hA17C01EC)) 
    \bcd3_lpy[3]_INST_0_i_5 
       (.I0(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h772319EC660331C8)) 
    \bcd3_lpy[3]_INST_0_i_6 
       (.I0(\bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .I5(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h5466518A)) 
    \bcd3_lpy[3]_INST_0_i_7 
       (.I0(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h772319EC660331C8)) 
    \bcd3_lpy[3]_INST_0_i_8 
       (.I0(bin_lpy[6]),
        .I1(bin_lpy[7]),
        .I2(\bcd3_lpy[3]_INST_0_i_16_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_17_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_18_n_0 ),
        .I5(bin_lpy[5]),
        .O(\bcd3_lpy[3]_INST_0_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h772379EC660371C8)) 
    \bcd3_lpy[3]_INST_0_i_9 
       (.I0(\bcd3_lpy[3]_INST_0_i_15_n_0 ),
        .I1(\bcd3_lpy[3]_INST_0_i_13_n_0 ),
        .I2(\bcd3_lpy[3]_INST_0_i_11_n_0 ),
        .I3(\bcd3_lpy[3]_INST_0_i_12_n_0 ),
        .I4(\bcd3_lpy[3]_INST_0_i_14_n_0 ),
        .I5(\bcd3_lpy[3]_INST_0_i_8_n_0 ),
        .O(\bcd3_lpy[3]_INST_0_i_9_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
