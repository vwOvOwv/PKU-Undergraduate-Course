// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
// Date        : Sat Apr 12 11:30:59 2025
// Host        : A14 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/22426/Desktop/ddca_lab_lpy/BCD_lpy/BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ip/BCD_IP_lpy_clk_div_lpy_0_0/BCD_IP_lpy_clk_div_lpy_0_0_stub.v
// Design      : BCD_IP_lpy_clk_div_lpy_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "clk_div_lpy,Vivado 2022.1.2" *)
module BCD_IP_lpy_clk_div_lpy_0_0(clk_100MHz_lpy, clk_sys_lpy)
/* synthesis syn_black_box black_box_pad_pin="clk_100MHz_lpy,clk_sys_lpy" */;
  input clk_100MHz_lpy;
  output clk_sys_lpy;
endmodule
