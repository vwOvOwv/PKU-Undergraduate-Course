-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.1.2 (win64) Build 3605665 Fri Aug  5 22:53:37 MDT 2022
-- Date        : Sat Apr 12 11:30:59 2025
-- Host        : A14 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/22426/Desktop/ddca_lab_lpy/BCD_lpy/BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ip/BCD_IP_lpy_BCD2bin_lpy_0_0/BCD_IP_lpy_BCD2bin_lpy_0_0_stub.vhdl
-- Design      : BCD_IP_lpy_BCD2bin_lpy_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity BCD_IP_lpy_BCD2bin_lpy_0_0 is
  Port ( 
    bcd3_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd2_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd1_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bcd0_lpy : in STD_LOGIC_VECTOR ( 3 downto 0 );
    bin_lpy : out STD_LOGIC_VECTOR ( 13 downto 0 )
  );

end BCD_IP_lpy_BCD2bin_lpy_0_0;

architecture stub of BCD_IP_lpy_BCD2bin_lpy_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "bcd3_lpy[3:0],bcd2_lpy[3:0],bcd1_lpy[3:0],bcd0_lpy[3:0],bin_lpy[13:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "BCD2bin_lpy,Vivado 2022.1.2";
begin
end;
