vopt +acc=npr -l elaborate.log -L xil_defaultlib -L xlslice_v1_0_2 -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.BCD_IP_lpy xil_defaultlib.glbl -o BCD_IP_lpy_opt
