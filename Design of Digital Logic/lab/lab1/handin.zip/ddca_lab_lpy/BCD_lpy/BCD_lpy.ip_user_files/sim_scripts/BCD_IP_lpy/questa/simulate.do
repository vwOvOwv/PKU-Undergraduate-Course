onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib BCD_IP_lpy_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {BCD_IP_lpy.udo}

run -all

quit -force
