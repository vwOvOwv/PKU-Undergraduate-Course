onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+BCD_IP_lpy -L xil_defaultlib -L xlslice_v1_0_2 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.BCD_IP_lpy xil_defaultlib.glbl

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure

do {BCD_IP_lpy.udo}

run -all

endsim

quit -force
