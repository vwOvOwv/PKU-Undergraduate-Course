-makelib xcelium_lib/xil_defaultlib -sv \
  "../../../bd/BCD_IP_lpy/ipshared/86b3/clk_div_lpy.sv" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_clk_div_lpy_0_0/sim/BCD_IP_lpy_clk_div_lpy_0_0.sv" \
  "../../../bd/BCD_IP_lpy/ipshared/b045/bin2BCD_lpy.sv" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_bin2BCD_lpy_0_0/sim/BCD_IP_lpy_bin2BCD_lpy_0_0.sv" \
  "../../../bd/BCD_IP_lpy/ipshared/736c/BCD2bin_lpy.sv" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_BCD2bin_lpy_0_0/sim/BCD_IP_lpy_BCD2bin_lpy_0_0.sv" \
  "../../../bd/BCD_IP_lpy/ipshared/c482/display_7seg_x4_lpy.sv" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_display_7seg_x4_lpy_0_0/sim/BCD_IP_lpy_display_7seg_x4_lpy_0_0.sv" \
-endlib
-makelib xcelium_lib/xlslice_v1_0_2 \
  "../../../../BCD_lpy.gen/sources_1/bd/BCD_IP_lpy/ipshared/11d0/hdl/xlslice_v1_0_vl_rfs.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_xlslice_0_0/sim/BCD_IP_lpy_xlslice_0_0.v" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_xlslice_1_0/sim/BCD_IP_lpy_xlslice_1_0.v" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_xlslice_2_0/sim/BCD_IP_lpy_xlslice_2_0.v" \
  "../../../bd/BCD_IP_lpy/ip/BCD_IP_lpy_xlslice_3_0/sim/BCD_IP_lpy_xlslice_3_0.v" \
  "../../../bd/BCD_IP_lpy/sim/BCD_IP_lpy.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

