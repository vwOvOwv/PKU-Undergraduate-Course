`timescale 1ns / 1ps

module flowing_light(
    input logic clk,
    input logic rst,
    output logic [15:0] led
    );

    logic [23:0] cnt_reg;
    logic [15:0] light_reg;

    always_ff @(posedge clk)
      begin
          if(rst)
          cnt_reg<=0;
          else
          cnt_reg<=cnt_reg+1;
      end

    always_ff @(posedge clk)
      begin
          if(rst)
          light_reg<=16'h0001;
          else if(cnt_reg == 24'hffffff)
          begin
              if(light_reg == 16'h8000)
                light_reg<=16'h0001;
              else
                light_reg<=light_reg<<1;
          end
      end

assign led = light_reg;

endmodule
