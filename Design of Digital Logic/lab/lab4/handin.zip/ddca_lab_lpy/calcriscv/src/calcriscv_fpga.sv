module calcriscv_fpga(
    input  logic clk,
    input  logic btnC, btnU, btnL, btnD, btnR, 
    input  logic [15:0] sw,
    output logic [15:0] led,
    output logic [0:6] seg,
    output logic [0:3] an
        );

  // just for simulation, don't use in fpga emulation
  logic [31:0] DataAddr, WriteData, MemWrite; 
  
  // Clock Generation
  logic [23:0] cnt;
  logic clk_gen;
  logic clk_gen_bufg;
  logic mclk;
  
  // Input Ports  
  logic [3:0]  PortA;
  logic [13:0] PortB;
  logic [13:0] PortC;
  logic [15:0] PortD;
  
  assign PortA = {btnL, btnC, btnR, btnU}; // add, sub, multiply, =  
  
  BCD2bin_0 u_bcd2bin (
    .bcd3_lpy(sw[15:12]), 
    .bcd2_lpy(sw[11:8]), 
    .bcd1_lpy(sw[7:4]), 
    .bcd0_lpy(sw[3:0]), 
    .bin_lpy(PortB));
    
  // Calcriscv
  singleriscv_bd_wrapper u_signleriscv(
            .clk(mclk), 
            .reset(reset_global), 
            .MemWrite(MemWrite),
            .WriteData(WriteData),
            .DataAdr(DataAdr),
            .PortA(PortA),
            .PortB(PortB),
            .PortC(PortC),
            .PortD(PortD));

  // Output Ports
  logic [3:0]  bcd3, bcd2, bcd1, bcd0;
  
  bin2BCD_0 u_bin2bcd (
    .bin_lpy(PortC),
    .bcd3_lpy(bcd3), 
    .bcd2_lpy(bcd2), 
    .bcd1_lpy(bcd1), 
    .bcd0_lpy(bcd0));
  
  display_7seg_x4_0 u_display (mclk, bcd3, bcd2, bcd1, bcd0, an, seg);
  
  assign led = PortD;
  
  //generate 10KHz clock
  
  localparam PERIOD_CLK = 10000;   // 10KHz

  always_ff @(posedge clk)
    begin
       if (cnt == PERIOD_CLK/2)
         begin
           cnt <= 0;
           clk_gen <= ~clk_gen;
         end
       else
         cnt <= cnt + 1;
    end
    
  BUFG  CLK0_BUFG_INST (.I(clk_gen),
                        .O(clk_gen_bufg));

  //generate 10KHz clock
  assign mclk = clk_gen_bufg;
  
  logic rst_sync, btnD_reg;  
    // synchronize reset input btnD 
  always_ff @(posedge mclk)
    begin
	  btnD_reg <= btnD;
	  rst_sync <= btnD_reg;
    end
  assign reset_global = rst_sync | btnD;

endmodule
