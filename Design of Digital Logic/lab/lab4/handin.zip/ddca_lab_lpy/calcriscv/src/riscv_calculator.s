# riscv_calculator.s
# RISC-V Assembly code for a simple calculator running on Basys3 FPGA

# .equ  PORTA_ADDR, 0x7F00    # operator input
# .equ  PORTB_ADDR, 0x7F10    # operand input
# .equ  PORTC_ADDR, 0x7F20    # result output
# .equ  PORTD_ADDR, 0x7FFC    # reset signal
     
main:   add x5, x0, x0  # x5 = 0 (accumulator)                
        add x6, x0, x0  # x6 = 0 (operand buffer)
        # Get current value on PortB
        li  x28, 0x7F10
        lw  x29, 0(x28)
        li  x30, 0x1 # flag to indicate where the `wait_change_on_portb` is called
        beq x0, x0, wait_change_on_portb # always taken

wait_first_operator_set:
        # Load operand from PortB constantly until button is pressed
        # Waiting until input from PortB changes is buggy, since in this case
        # user can only change one switch at a time. After that, the calculator
        # will wait for operator input from PortA, rather than continuously
        # reading from PortB
        li  x28, 0x7F10
        lw  x7, 0(x28)
        li  x28, 0x3FFF
        and x7, x7, x28  # Mask to get the operand (assuming 14 bits for operand)
        # Display first operand on 7-segment display
        li  x28, 0x7F20
        sw  x7, 0(x28)
        # Wait for operator input from PortA
        li  x28, 0x7F00
        lw  x8, 0(x28)
        beq x8, x0, wait_first_operator_set
wait_first_operator_zero:
        # Wait until button is released
        li  x28, 0x7F00
        lw  x31, 0(x28)
        bne x31, x0, wait_first_operator_zero
        add x6, x8, x0
        li  x28, 0xF
        and x6, x6, x28 # Store first operator in x6
        add x5, x7, x0  # Store first operand in x5
        li  x28, 0x1
        beq x6, x28, equal # equal, display result at once
wait_next_operator_set:
        # Load next operand from PortB constantly until button is pressed
        li  x28, 0x7F10
        lw  x7, 0(x28)
        li  x28, 0x3FFF
        and x7, x7, x28
        # Display the operand on 7-segment display
        li  x28, 0x7F20
        sw  x7, 0(x28)
        # Wait for operator input from PortA
        li  x28, 0x7F00
        lw  x8, 0(x28)
        beq x8, x0, wait_next_operator_set
wait_next_operator_zero:
        # Wait until button is released
        li  x28, 0x7F00
        lw  x31, 0(x28)
        bne x31, x0, wait_next_operator_zero # Wait until button is released
        # When next operator is set, perform calculation defined by previous operator
        # Note: here x6 must not be 'equal'
        li  x28, 0x2
        beq x6, x28, multiply
        li  x28, 0x4
        beq x6, x28, subtract
        li  x28, 0x8
        beq x6, x28, addition
equal:  # Display result and reset
        li  x28, 0x7F20
        sw  x5, 0(x28)
        # Reset calculator
        beq x0, x0, main # always taken
multiply:
        li  x28, 0 # Counter for multiplication
        add x9, x5, x0
        li  x5, 0
multiply_loop:  
        # Perform multiplication through repeated addition
        add x5, x5, x9
        addi x28, x28, 1     # Increment counter
        bne x28, x7, multiply_loop # Loop until counter reaches second operand
        # Check if current operator x8 is 'equal'
        li  x28, 0xF
        and x8, x8, x28
        li  x28, 0x1
        beq x8, x28, equal
        # If not equal, update x6 and loop back to wait for next input
        add x6, x8, x0
        # Display current result on 7-segment display
        li  x28, 0x7F20
        sw  x5, 0(x28)
        # Get current value on PortB
        li  x28, 0x7F10
        lw  x29, 0(x28)
        li  x30, 0x0 # flag
        beq x0,x0, wait_change_on_portb # always taken
addition:
        add x5, x5, x7
        # Check if current operator x8 is 'equal'
        li  x28, 0xF
        and x8, x8, x28
        li  x28, 0x1
        beq x8, x28, equal
        # If not equal, update x6 and loop back to wait for next input
        add x6, x8, x0
        # Display current result on 7-segment display
        li  x28, 0x7F20
        sw  x5, 0(x28)
        # Get current value on PortB
        li  x28, 0x7F10
        lw  x29, 0(x28)
        li  x30, 0x0 # flag
        beq x0,x0, wait_change_on_portb # always taken
subtract:
        sub x5, x5, x7
        # Check if current operator x8 is 'equal'
        li  x28, 0xF
        and x8, x8, x28
        li  x28, 0x1
        beq x8, x28, equal
        # If not equal, update x6 and loop back to wait for next input
        add x6, x8, x0
        # Display current result on 7-segment display
        li  x28, 0x7F20
        sw  x5, 0(x28)
        # Get current value on PortB
        li  x28, 0x7F10
        lw  x29, 0(x28)
        li  x30, 0x0 # flag
        beq x0,x0, wait_change_on_portb # always taken
wait_change_on_portb:
	# Wait until PortB changes
	li  x28, 0x7F10
	lw  x7, 0(x28)
	beq x7, x29, wait_change_on_portb # If no change, keep waiting
	# If change detected, display updated operand on 7-segment display
	li  x28, 0x3FFF
	and x7, x7, x28
	li  x28, 0x7F20
	sw  x7, 0(x28)
	# Check where to branch back
	li  x28, 0x1
	beq x30, x28, wait_first_operator_set
	beq x0, x0, wait_next_operator_set
