# riscvtest.s
# Sarah.Harris@unlv.edu
# David_Harris@hmc.edu
# 27 Oct 2020
#
# Test the RISC-V processor.  
#  add, sub, and, or, slt, addi, lw, sw, beq, jal
# If successful, it should write the value 25 to address 100

#       RISC-V Assembly         Description               Address   Machine Code
main:   addi x2, x0, 5          # x2 = 5                  0         00500113   
        addi x3, x0, 12         # x3 = 12                 4         00C00193
        addi x7, x3, -9         # x7 = (12 - 9) = 3       8         FF718393
        or   x4, x7, x2         # x4 = (3 OR 5) = 7       C         0023E233
        and  x5, x3, x4         # x5 = (12 AND 7) = 4     10        0041F2B3
        add  x5, x5, x4         # x5 = (4 + 7) = 11       14        004282B3
        beq  x5, x7, end        # shouldn't be taken      18        02728863
        slt  x4, x3, x4         # x4 = (12 < 7) = 0       1C        0041A233
        beq  x4, x0, around     # should be taken         20        00020463
        addi x5, x0, 0          # shouldn't happen        24        00000293
around: slt  x4, x7, x2         # x4 = (3 < 5)  = 1       28        0023A233
        add  x7, x4, x5         # x7 = (1 + 11) = 12      2C        005203B3
        sub  x7, x7, x2         # x7 = (12 - 5) = 7       30        402383B3
        lui  x3, 1              # x3 = 0x1000             34        000011B7 
        sw   x7, 12(x3)         # [0x100c] = 7            38        0071A623
        addi x3, x3, 8          # x3 = 0x1008             3C        00818193
        lw   x2, 4(x3)          # x2 = [0x100c] = 7       40        0041A103 
        add  x9, x2, x5         # x9 = (7 + 11) = 18      44        005104B3
        jal  x3, end            # jump to end, x3 = 0x4C  48        008001EF
        addi x2, x0, 1          # shouldn't happen        4C        00100113
end:    addi x2, x2, -4         # x2 = (7 - 4)  = 3       50        FFC10113
        addi x3, x0, 8          # x3 = 8                  54        00800193
        srli  x3, x3, 3         # x3 = 8 >> 3 = 1         58        0031D193
        slli  x3, x3, 15        # x3 = 1 << 15 = 0x8000   5c        00F19193
        auipc x8, 0             # x8 = 0x60               60        00000417
        jalr  x1, x8, 8         # jump to 0x68 x1 = 0x68  64        008400E7
        addi  x9, x3, -0x100    # x9 - 0x7f00		  68        F0018493
        lw    x6, 0x10(x9)      # x6 = [0x7f10]           6C        0104A303
        addi  x6, x6, 3         # x6 = x6 + 3             70        00330313
        sw    x6, 0x20(x9)      # [0x7f20] = x6           74        0264A023
        sw    x2, -4(x3)        # [0x7ffc] = 3            78        FE21AE23
done:   bgeu  x8, x2, done      # infinite loop           7C        00247063
