module calcriscv_tb();

  logic        clk;
  logic        reset;
  logic [31:0] WriteData, DataAdr;
  logic        MemWrite;
  logic [3:0]  PortA;
  logic [13:0] PortB;
  logic [13:0] PortC;
  logic [15:0] PortD;

  // instantiate device to be tested
  singleriscv_bd_wrapper dut(
    .clk(clk),
    .reset(reset),
    .WriteData(WriteData),
    .DataAdr(DataAdr),
    .MemWrite(MemWrite),
    .PortA(PortA),
    .PortB(PortB),
    .PortC(PortC),
    .PortD(PortD)
    );
  
  // initialize test
  initial
    begin
      PortA = 0;
      PortB = 0;
      reset = 0;
      # 5; 
      reset = 1; 
      # 20; 
      reset = 0;
    end

  // generate clock to sequence tests
  always
    begin
      clk <= 1; # 5; clk <= 0; # 5;     // 100Mhz
    end

  // check results
  always @(negedge clk)
    begin
      if(MemWrite) begin
        if(DataAdr === 32'h00007ffc & WriteData === 3) begin
          $display("Simulation succeeded");
          $stop;
        end else begin
          $display("Simulation Continue...");
          // $stop;
        end
      end
    end
endmodule
