// dmem from address 0x1000 to address 0x1800 available
module dmem_io #(parameter DEPTH = 64)
  (
  input  logic clk, 
  input  logic reset,         // Reset IO ports
  input	 logic MemWrite,
  input  logic [31:0] DataAddr, 
  input  logic [31:0] WriteData,
  output logic [31:0] ReadData,
  input  logic [3:0]  PortA, 	// Buttons
  input  logic [13:0] PortB,	// BCD2bin after 16 Switches
  output logic [13:0] PortC,	// to bin2BCD then disply7seg
  output logic [15:0] PortD		// to 16 LEDs
  );

  localparam ADDR_BITS = $clog2(DEPTH);

  logic  [31:0] RAM[DEPTH-1:0]; 
  logic	 [31:0] ReadDataRAM;
  logic  [31:0] PortC_reg, PortD_reg;
    
  assign DataAddrRAM   = ( DataAddr >= 32'h00001000 ) && ( DataAddr < 32'h00001800 );
  assign DataAddrPortA = ( DataAddr == 32'h00007f00 );  
  assign DataAddrPortB = ( DataAddr == 32'h00007f10 );                    
  assign DataAddrPortC = ( DataAddr == 32'h00007f20 );
  assign DataAddrPortD = ( DataAddr == 32'h00007ffc );
  
  assign ReadDataRAM = RAM[DataAddr[(ADDR_BITS+2):2]];  // Word Alignment
  
  // dmemio read
  always_comb
    begin
      if ( DataAddrPortA )
        ReadData = {{28{1'b0}}, PortA };
      else if ( DataAddrPortB )
        ReadData = {{18{1'b0}}, PortB };
      else if ( DataAddrPortC )
        ReadData = PortC_reg;
      else if ( DataAddrPortD )
        ReadData = PortD_reg;
      else if ( DataAddrRAM )
        ReadData = ReadDataRAM; 		      // 4B word alignment
    end
  
  // dmem write
  always_ff @(posedge clk)
    if ( DataAddrRAM && MemWrite)
     RAM[DataAddr[(ADDR_BITS+2):2]] <= WriteData;      // 4B word alignment
		
  always_ff @(posedge clk)
    if (reset)
      PortC_reg <= 0;
    else if (DataAddrPortC && MemWrite)
	    PortC_reg <= WriteData;
  
  always_ff @(posedge clk)
    if (reset)
      PortD_reg <= 0;
    else if (DataAddrPortD && MemWrite)
	    PortD_reg <= WriteData;
  
  assign PortC = PortC_reg[13:0];
  assign PortD = PortD_reg[15:0];
  
endmodule
