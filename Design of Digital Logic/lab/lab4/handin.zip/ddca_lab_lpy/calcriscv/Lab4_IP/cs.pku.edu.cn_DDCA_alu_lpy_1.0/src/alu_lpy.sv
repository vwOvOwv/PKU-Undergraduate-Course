module alu_lpy(
  input  logic [31:0] a_lpy, b_lpy,
  input  logic [3:0]  alucontrol_lpy,
  output logic [31:0] result_lpy,
  output logic        zero_lpy, lessthan_lpy
  );

  logic        isSub, isSra, isSltu;
  
  logic [31:0] condinvb, sum;
  logic        ge;       // greater equal

  logic [31:0] shiftleft;
  logic [31:0] shiftright;
  
  assign isSub  = alucontrol_lpy[3];
  assign isSra  = b_lpy[30];                         
  assign isSltu = (alucontrol_lpy[2:0] == 3'b011);

  assign condinvb = isSub ? ~b_lpy : b_lpy;
  assign sum = a_lpy + condinvb + isSub;
  
  // Is greater equal
  always_comb begin
    if ((a_lpy[31] ^ b_lpy[31]) == 1'b0) begin
      ge = (sum[31] == 1'b0);
    end else begin
      ge = a_lpy[31] ^ ~isSltu; 
    end
  end
  
  assign zero_lpy = (sum == 32'b0);
  assign lessthan_lpy = ~ge;  
  
  // Shifters 
  assign shiftleft  = a_lpy << b_lpy[4:0];
  assign shiftright = {{32{isSra & a_lpy[31]}}, a_lpy} >> b_lpy[4:0];
  
  // result_lpy output mux
  always_comb
    case (alucontrol_lpy[2:0])                  // funct3
      3'b000:  result_lpy = sum;                // add or sub
      3'b001:  result_lpy = shiftleft;           // sll
      3'b010:  result_lpy = {{31{1'b0}}, ~ge};  // slt
      3'b011:  result_lpy = {{31{1'b0}}, ~ge};  // sltu
      3'b100:  result_lpy = a_lpy ^ b_lpy;              // xor
      3'b101:  result_lpy = shiftright;         // srl/sra
      3'b110:  result_lpy = a_lpy | b_lpy;              // or
      3'b111:  result_lpy = a_lpy & b_lpy;              // and
      default: result_lpy = {32{1'bx}};
    endcase
    
endmodule
