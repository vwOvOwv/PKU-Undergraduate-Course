module alu(
  input  logic [31:0] a, b,
  input  logic [3:0]  alucontrol,
  output logic [31:0] result,
  output logic        zero, lessthan
  );

  logic        isSub, isSra, isSltu;
  
  logic [31:0] condinvb, sum;
  logic        ge;       // greater equal

  logic [31:0] shiftleft;
  logic [31:0] shiftright;
  
  assign isSub  = alucontrol[3];
  assign isSra  = b[30];                         
  assign isSltu = (alucontrol[2:0] == 3'b011);

  assign condinvb = isSub ? ~b : b;
  assign sum = a + condinvb + isSub;
  
  // Is greater equal
  always_comb begin
    if ((a[31] ^ b[31]) == 1'b0) begin
      ge = (sum[31] == 1'b0);
    end else begin
      ge = a[31] ^ ~isSltu; 
    end
  end
  
  assign zero = (sum == 32'b0);
  assign lessthan = ~ge;  
  
  // Shifters 
  assign shiftleft  = a << b[4:0];
  assign shiftright = {{32{isSra & a[31]}}, a} >> b[4:0];
  
  // result output mux
  always_comb
    case (alucontrol[2:0])                  // funct3
      3'b000:  result = sum;                // add or sub
      3'b001:  result = shiftleft;           // sll
      3'b010:  result = {{31{1'b0}}, ~ge};  // slt
      3'b011:  result = {{31{1'b0}}, ~ge};  // sltu
      3'b100:  result = a ^ b;              // xor
      3'b101:  result = shiftright;         // srl/sra
      3'b110:  result = a | b;              // or
      3'b111:  result = a & b;              // and
      default: result = {32{1'bx}};
    endcase
    
endmodule
