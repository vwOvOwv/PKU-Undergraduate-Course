// Single-cycle implementation of RISC-V (RV32I)
// User-level Instruction Set Architecture V2.2 (May 7, 2017)
// Implements a subset of the base integer instructions:
//    lw, sw
//    add, sub, and, or, slt, 
//    addi, andi, ori, slti
//    beq
//    jal
// Exceptions, traps, and interrupts not implemented
// little-endian memory

// 31 32-bit registers x1-x31, x0 hardwired to 0
// R-Type instructions
//   add, sub, and, or, slt
//   INSTR rd, rs1, rs2
//   Instr[31:25] = funct7 (funct7b5 & opb5 = 1 for sub, 0 for others)
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// I-Type Instructions
//   lw, I-type ALU (addi, andi, ori, slti)
//   lw:         INSTR rd, imm(rs1)
//   I-type ALU: INSTR rd, rs1, imm (12-bit signed)
//   Instr[31:20] = imm[11:0]
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// S-Type Instruction
//   sw rs2, imm(rs1) (store rs2 into address specified by rs1 + immm)
//   Instr[31:25] = imm[11:5] (offset[11:5])
//   Instr[24:20] = rs2 (src)
//   Instr[19:15] = rs1 (base)
//   Instr[14:12] = funct3
//   Instr[11:7]  = imm[4:0]  (offset[4:0])
//   Instr[6:0]   = opcode
// B-Type Instruction
//   beq rs1, rs2, imm (PCTarget = PC + (signed imm x 2))
//   Instr[31:25] = imm[12], imm[10:5]
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = imm[4:1], imm[11]
//   Instr[6:0]   = opcode
// J-Type Instruction
//   jal rd, imm  (signed imm is multiplied by 2 and added to PC, rd = PC+4)
//   Instr[31:12] = imm[20], imm[10:1], imm[11], imm[19:12]
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// U-Type Instruction
//   lui rd, imm (rd[31:12] = imm, rd[11:0] = 0)
//   Instr[31:12] = imm[31:12]
//   Instr[11:7]  = rd 
//   Instr[6:0]   = opcode

//   Instruction  opcode    funct3    funct7
//   add          0110011   000       0000000
//   sub          0110011   000       0100000
//   and          0110011   111       0000000
//   or           0110011   110       0000000
//   slt          0110011   010       0000000
//   sll          0110011   001       0000000
//   srl          0110011   101       0000000
//   sra          0110011   101       0100000
//   addi         0010011   000       immediate
//   andi         0010011   111       immediate
//   ori          0010011   110       immediate
//   slti         0010011   010       immediate
//   beq          1100011   000       immediate
//   lw	          0000011   010       immediate
//   sw           0100011   010       immediate
//   jal          1101111   immediate immediate  

//   cs.pku.edu.cn 'digital logic design' course lab

//   lui          0110111   immediate immediate

//   bne          1100011   001       immediate
//   blt          1100011   100       immediate
//   bge          1100011   101       immediate
//   bltu         1100011   110       immediate
//   bgeu         1100011   111       immediate
//   sltui        0010011   011       immediate
//   slli         0010011   001       0000000_shamt
//   srli         0010011   101       0000000_shamt
//   srai         0010011   101       0100000_shamt

//   xor          0110011   100       0000000
//   xori         0010011   100       immediate

//   TODO: how to implement next two instruction 
//   aupic ???
//   jalr  ???

module controller(input  logic [6:0] op,
                  input  logic [2:0] funct3,
                  input  logic       funct7b5,
                  input  logic       zero, lessthan,
                  output logic [1:0] ResultSrc,
                  output logic       MemWrite,
                  output logic       PCSrc, ALUSrc,
                  output logic       RegWrite,  
                  output logic       Jump, JumpR, UType, AUIPC,
                  output logic [1:0] ImmSrc,
                  output logic [3:0] ALUControl);

  logic [1:0] ALUOp;
  logic       Branch;

  maindec md(op, ResultSrc, MemWrite, Branch,
             ALUSrc, RegWrite, Jump, JumpR, UType, AUIPC,ImmSrc, ALUOp);
  aludec  ad(funct3, funct7b5, ALUOp, ALUControl);

  pcsrcdec pd(funct3, Branch, Jump, JumpR, zero, lessthan, PCSrc);  

endmodule

module maindec(input  logic [6:0] op,
               output logic [1:0] ResultSrc,
               output logic       MemWrite,
               output logic       Branch, ALUSrc,
               output logic       RegWrite, 
               output logic       Jump, JumpR,
               output logic       UType, AUIPC,
               output logic [1:0] ImmSrc,
               output logic [1:0] ALUOp);

  logic [13:0] controls;

  assign {RegWrite, ImmSrc, ALUSrc, MemWrite,
          ResultSrc, Branch, ALUOp,Jump, UType, JumpR, AUIPC}
          = controls;

  always_comb
    case(op)
    // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_UType_JumpR_AUIPC
      7'b0000011: controls = 14'b1_00_1_0_01_0_00_0_0_0_0; // lw
      7'b0100011: controls = 14'b0_01_1_1_00_0_00_0_0_0_0; // sw
      7'b0110011: controls = 14'b1_xx_0_0_00_0_10_0_0_0_0; // R-type ALU
      7'b1100011: controls = 14'b0_10_0_0_00_1_01_0_0_0_0; // B-type
      7'b0010011: controls = 14'b1_00_1_0_00_0_11_0_0_0_0; // I-type ALU
      7'b1101111: controls = 14'b1_11_0_0_10_0_00_1_0_0_0; // jal
      7'b1100111: controls = 14'b1_00_1_0_10_0_00_0_0_1_0; // jalr I-type-Imm
      7'b0110111: controls = 14'b1_xx_0_0_10_0_00_0_1_0_0; // liu
      7'b0010111: controls = 14'b1_xx_0_0_10_0_00_0_1_0_1; // auipc
      default:    controls = 14'bx_xx_x_x_xx_x_xx_x_x_x_x; // non-implemented instruction
    endcase
endmodule

module aludec(input  logic [2:0] funct3,
              input  logic       funct7b5, 
              input  logic [1:0] ALUOp,
              output logic [3:0] ALUControl);

  always_comb
    case(ALUOp)
      2'b00:   ALUControl[2:0] =  3'b000           ; // addition
      2'b01:   ALUControl[2:0] = {2'b01, funct3[2]}; // branch slt/sltu 
      2'b10:   ALUControl[2:0] = funct3            ; // R-Type
      2'b11:   ALUControl[2:0] = funct3            ; // I-Type
      default: ALUControl[2:0] = 3'bxxx;
    endcase
  
  // isSub
  assign ALUControl[3] = (ALUOp == 2'b10 & funct7b5 ) |  // R-Type sub
                         (ALUControl[2:0] == 3'b010 ) |  // slt
                         (ALUControl[2:0] == 3'b011 );   // sltu

endmodule

module pcsrcdec(input  logic [2:0] funct3,
                input  logic       branch, jump, jumpr,
                input  logic       zero, lessthan,
                output logic       PCSrc);

  assign PCSrc = jump | jumpr |
                 ( branch & (((funct3 == 3'b000) &  zero    ) |   // beq
                             ((funct3 == 3'b001) & ~zero    ) |   // bne
                             ((funct3 == 3'b100) &  lessthan) |   // blt
                             ((funct3 == 3'b101) & ~lessthan) |   // bge
                             ((funct3 == 3'b110) &  lessthan) |   // bltu
                             ((funct3 == 3'b111) & ~lessthan))    // bgeu
                 );
endmodule
