module dmem #(parameter DEPTH = 64)
  (input  logic        clk, we,
   input  logic [31:0] a, wd,
   output logic [31:0] rd);

localparam ADDR_BITS = $clog2(DEPTH);

  logic [31:0] RAM[DEPTH-1:0];

  assign rd = RAM[a[(ADDR_BITS+2):2]];      // word aligned

  always_ff @(posedge clk)
    if (we) RAM[a[(ADDR_BITS+2):2]] <= wd;  // word aligned
endmodule