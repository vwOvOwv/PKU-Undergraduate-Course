module imem #(parameter DEPTH = 64)
  (input  logic [31:0] a,
   output logic [31:0] rd);
   
  localparam ADDR_BITS = $clog2(DEPTH);


  logic [31:0] RAM[DEPTH-1:0];

  initial
      $readmemh("riscvtest.txt",RAM);

  assign rd = RAM[a[(ADDR_BITS+2):2]]; // 32-bit aligned
  
endmodule