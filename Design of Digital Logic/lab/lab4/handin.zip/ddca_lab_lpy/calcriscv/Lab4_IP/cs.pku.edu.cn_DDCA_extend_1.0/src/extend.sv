module extend(input  logic [31:7] instr,
              input  logic [1:0]  immsrc,
              input  logic        utype,
              output logic [31:0] immext);
  
  logic [31:0] immutypen, immutype;
  
  always_comb
    case(immsrc) 
               // I-type 
      2'b00:   immutypen = {{20{instr[31]}}, instr[31:20]};  
               // S-type (stores)
      2'b01:   immutypen = {{20{instr[31]}}, instr[31:25], instr[11:7]}; 
               // B-type (branches)
      2'b10:   immutypen = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0}; 
               // J-type (jal)
      2'b11:   immutypen = {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0}; 
      default: immutypen = 32'bx; // undefined
    endcase
    
    assign immutype = {instr[31:12], {12{1'b0}}};
    assign immext = utype ? immutype : immutypen;        
endmodule
