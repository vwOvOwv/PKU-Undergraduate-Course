// Single-cycle implementation of RISC-V (RV32I)
// User-level Instruction Set Architecture V2.2 (May 7, 2017)
// Implements a subset of the base integer instructions:
//    lw, sw
//    add, sub, and, or, slt, 
//    addi, andi, ori, slti
//    beq
//    jal
// Exceptions, traps, and interrupts not implemented
// little-endian memory

// 31 32-bit registers x1-x31, x0 hardwired to 0
// R-Type instructions
//   add, sub, and, or, slt
//   INSTR rd, rs1, rs2
//   Instr[31:25] = funct7 (funct7b5 & opb5 = 1 for sub, 0 for others)
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// I-Type Instructions
//   lw, I-type ALU (addi, andi, ori, slti)
//   lw:         INSTR rd, imm(rs1)
//   I-type ALU: INSTR rd, rs1, imm (12-bit signed)
//   Instr[31:20] = imm[11:0]
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// S-Type Instruction
//   sw rs2, imm(rs1) (store rs2 into address specified by rs1 + immm)
//   Instr[31:25] = imm[11:5] (offset[11:5])
//   Instr[24:20] = rs2 (src)
//   Instr[19:15] = rs1 (base)
//   Instr[14:12] = funct3
//   Instr[11:7]  = imm[4:0]  (offset[4:0])
//   Instr[6:0]   = opcode
// B-Type Instruction
//   beq rs1, rs2, imm (PCTarget = PC + (signed imm x 2))
//   Instr[31:25] = imm[12], imm[10:5]
//   Instr[24:20] = rs2
//   Instr[19:15] = rs1
//   Instr[14:12] = funct3
//   Instr[11:7]  = imm[4:1], imm[11]
//   Instr[6:0]   = opcode
// J-Type Instruction
//   jal rd, imm  (signed imm is multiplied by 2 and added to PC, rd = PC+4)
//   Instr[31:12] = imm[20], imm[10:1], imm[11], imm[19:12]
//   Instr[11:7]  = rd
//   Instr[6:0]   = opcode
// U-Type Instruction
//   lui rd, imm (rd[31:12] = imm, rd[11:0] = 0)
//   Instr[31:12] = imm[31:12]
//   Instr[11:7]  = rd 
//   Instr[6:0]   = opcode

//   Instruction  opcode    funct3    funct7
//   add          0110011   000       0000000
//   sub          0110011   000       0100000
//   and          0110011   111       0000000
//   or           0110011   110       0000000
//   slt          0110011   010       0000000
//   sll          0110011   001       0000000
//   srl          0110011   101       0000000
//   sra          0110011   101       0100000
//   addi         0010011   000       immediate
//   andi         0010011   111       immediate
//   ori          0010011   110       immediate
//   slti         0010011   010       immediate
//   beq          1100011   000       immediate
//   lw	          0000011   010       immediate
//   sw           0100011   010       immediate
//   jal          1101111   immediate immediate  

//   cs.pku.edu.cn 'digital logic design' course lab

//   lui          0110111   immediate immediate

//   bne          1100011   001       immediate
//   blt          1100011   100       immediate
//   bge          1100011   101       immediate
//   bltu         1100011   110       immediate
//   bgeu         1100011   111       immediate
//   sltui        0010011   011       immediate
//   slli         0010011   001       0000000_shamt
//   srli         0010011   101       0000000_shamt
//   srai         0010011   101       0100000_shamt

//   xor          0110011   100       0000000
//   xori         0010011   100       immediate

//   auipc        0010111   immediate immediate
//   jalr         1100111   000       immediate

module controller_lpy(input  logic [6:0] op_lpy,
                  input  logic [2:0] funct3_lpy,
                  input  logic       funct7b5_lpy,
                  input  logic       zero_lpy, lessthan_lpy,
                  output logic [1:0] ResultSrc_lpy,
                  output logic       MemWrite_lpy,
                  output logic       PCSrc_lpy, ALUSrc_lpy,
                  output logic       RegWrite_lpy,  
                  output logic       Jump_lpy, JumpR_lpy, UType_lpy, AUIPC_lpy,
                  output logic [1:0] ImmSrc_lpy,
                  output logic [3:0] ALUControl_lpy);

  logic [1:0] ALUOp_lpy;
  logic       Branch_lpy;

  maindec_lpy md(op_lpy, ResultSrc_lpy, MemWrite_lpy, Branch_lpy,
             ALUSrc_lpy, RegWrite_lpy, Jump_lpy, JumpR_lpy, UType_lpy, AUIPC_lpy,ImmSrc_lpy, ALUOp_lpy);
  aludec_lpy  ad(funct3_lpy, funct7b5_lpy, ALUOp_lpy, ALUControl_lpy);

  pcsrcdec_lpy pd(funct3_lpy, Branch_lpy, Jump_lpy, JumpR_lpy, zero_lpy, lessthan_lpy, PCSrc_lpy);  

endmodule

module maindec_lpy(input  logic [6:0] op_lpy,
               output logic [1:0] ResultSrc_lpy,
               output logic       MemWrite_lpy,
               output logic       Branch_lpy, ALUSrc_lpy,
               output logic       RegWrite_lpy, 
               output logic       Jump_lpy, JumpR_lpy,
               output logic       UType_lpy, AUIPC_lpy,
               output logic [1:0] ImmSrc_lpy,
               output logic [1:0] ALUOp_lpy);

  logic [13:0] controls_lpy;

  assign {RegWrite_lpy, ImmSrc_lpy, ALUSrc_lpy, MemWrite_lpy,
          ResultSrc_lpy, Branch_lpy, ALUOp_lpy,Jump_lpy, UType_lpy, JumpR_lpy, AUIPC_lpy}
          = controls_lpy;

  always_comb
    case(op_lpy)
    // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_UType_JumpR_AUIPC
      7'b0000011: controls_lpy = 14'b1_00_1_0_01_0_00_0_0_0_0; // lw
      7'b0100011: controls_lpy = 14'b0_01_1_1_00_0_00_0_0_0_0; // sw
      7'b0110011: controls_lpy = 14'b1_xx_0_0_00_0_10_0_0_0_0; // R-type ALU
      7'b1100011: controls_lpy = 14'b0_10_0_0_00_1_01_0_0_0_0; // B-type
      7'b0010011: controls_lpy = 14'b1_00_1_0_00_0_11_0_0_0_0; // I-type ALU
      7'b1101111: controls_lpy = 14'b1_11_0_0_10_0_00_1_0_0_0; // jal
      7'b1100111: controls_lpy = 14'b1_00_1_0_10_0_00_0_0_1_0; // jalr I-type-Imm
      7'b0110111: controls_lpy = 14'b1_xx_0_0_10_0_00_0_1_0_0; // lui
      7'b0010111: controls_lpy = 14'b1_xx_0_0_10_0_00_0_1_0_1; // auipc
      default:    controls_lpy = 14'bx_xx_x_x_xx_x_xx_x_x_x_x; // non-implemented instruction
    endcase
endmodule

module aludec_lpy(input  logic [2:0] funct3_lpy,
              input  logic       funct7b5_lpy, 
              input  logic [1:0] ALUOp_lpy,
              output logic [3:0] ALUControl_lpy);

  always_comb
    case(ALUOp_lpy)
      2'b00:   ALUControl_lpy[2:0] =  3'b000           ; // addition
      2'b01:   ALUControl_lpy[2:0] = {2'b01, funct3_lpy[2]}; // branch slt/sltu 
      2'b10:   ALUControl_lpy[2:0] = funct3_lpy            ; // R-Type
      2'b11:   ALUControl_lpy[2:0] = funct3_lpy            ; // I-Type
      default: ALUControl_lpy[2:0] = 3'bxxx;
    endcase
  
  // isSub
  assign ALUControl_lpy[3] = (ALUOp_lpy == 2'b10 & funct7b5_lpy ) |  // R-Type sub
                         (ALUControl_lpy[2:0] == 3'b010 ) |  // slt
                         (ALUControl_lpy[2:0] == 3'b011 );  // sltu

endmodule

module pcsrcdec_lpy(input  logic [2:0] funct3_lpy,
                input  logic       branch_lpy, jump_lpy, jumpr_lpy,
                input  logic       zero_lpy, lessthan_lpy,
                output logic       PCSrc_lpy);

  assign PCSrc_lpy = jump_lpy | jumpr_lpy |
                 ( branch_lpy & (((funct3_lpy == 3'b000) &  zero_lpy    ) |   // beq
                             ((funct3_lpy == 3'b001) & ~zero_lpy    ) |   // bne
                             ((funct3_lpy == 3'b100) &  lessthan_lpy) |   // blt
                             ((funct3_lpy == 3'b101) & ~lessthan_lpy) |   // bge
                             ((funct3_lpy == 3'b110) &  lessthan_lpy) |   // bltu
                             ((funct3_lpy == 3'b111) & ~lessthan_lpy))    // bgeu
                 );
endmodule
