`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/12 11:17:25
// Design Name: 
// Module Name: BCD2bin_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module BCD2bin_lpy(
    input logic [3:0] bcd3_lpy,
    input logic [3:0] bcd2_lpy,
    input logic [3:0] bcd1_lpy,
    input logic [3:0] bcd0_lpy,
    output logic [13:0] bin_lpy
);

    logic [29:0] shifter_lpy;
    integer i_lpy;

    always_comb
    begin
        shifter_lpy[13:0] = 0;
        shifter_lpy[29:26] = bcd3_lpy;
        shifter_lpy[25:22] = bcd2_lpy;
        shifter_lpy[21:18] = bcd1_lpy;
        shifter_lpy[17:14] = bcd0_lpy;

        for (i_lpy = 0; i_lpy < 14; i_lpy = i_lpy + 1)
        begin
            shifter_lpy = shifter_lpy >> 1;

            if (shifter_lpy[17:14] >= 8)
                shifter_lpy[17:14] = shifter_lpy[17:14] - 3;

             if (shifter_lpy[21:18] >= 8)             
                shifter_lpy[21:18] = shifter_lpy[21:18] - 3;

            if (shifter_lpy[25:22] >= 8)             
                shifter_lpy[25:22] = shifter_lpy[25:22] - 3; 

            if (shifter_lpy[29:26] >= 8)              
                shifter_lpy[29:26] = shifter_lpy[29:26] - 3; 
        end
    end

    assign bin_lpy = shifter_lpy[13:0];

endmodule
