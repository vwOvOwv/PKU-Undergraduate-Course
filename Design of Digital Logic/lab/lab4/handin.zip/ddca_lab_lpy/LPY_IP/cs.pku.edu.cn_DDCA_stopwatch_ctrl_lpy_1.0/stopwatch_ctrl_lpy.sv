`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/29 11:59:21
// Design Name: 
// Module Name: stopwatch_ctrl_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module stopwatch_ctrl_lpy(
    input logic clk_10Hz,  	// 10Hz
    input logic btnC, 		// CLR Button
    input logic btnD, 		// PAUSE Button
    input logic [3:0] min1_cnt, sec10_cnt, sec1_cnt, ms100_cnt,
    output logic min1_clr, sec10_clr, sec1_clr, ms100_clr,
    output logic min1_load, sec10_load, sec1_load, ms100_load,
    output logic min1_en, sec10_en, sec1_en, ms100_en
    );
    
    assign {min1_load, sec10_load, sec1_load, ms100_load} = 4'b0000;
    logic clr;
    logic en;
    
    logic sync_clr0, sync_clr1;
    always_ff @(posedge clk_10Hz)
    begin
      sync_clr0 <= btnC;
      sync_clr1 <= sync_clr0;
    end
    assign clr = btnC | sync_clr1;
    
    logic sync_en0, sync_en1, sync_en2;
    always_ff @(posedge clk_10Hz)
    begin
      sync_en0 <= btnD;
      sync_en1 <= sync_en0;
      sync_en2 <= sync_en1;
    end
    
    always_ff @(posedge clk_10Hz)
    begin
      if (clr)
        en <= 0;
      else if (sync_en2 & ~sync_en1)
        en <= ~en;
    end
    
    // stopwatch control
    assign ms100_en = en;
    assign sec1_en  = (ms100_cnt==9) & ms100_en;
    assign sec10_en = (sec1_cnt==9) & sec1_en;
    assign min1_en = (sec10_cnt==5) & sec10_en;
    assign min10_en  = (min1_cnt==9) & min1_en;
    
    assign ms100_clr = clr | sec1_en;
    assign sec1_clr  = clr | sec10_en;
    assign sec10_clr = clr | min1_en;
    assign min1_clr = clr | min10_en;

endmodule

