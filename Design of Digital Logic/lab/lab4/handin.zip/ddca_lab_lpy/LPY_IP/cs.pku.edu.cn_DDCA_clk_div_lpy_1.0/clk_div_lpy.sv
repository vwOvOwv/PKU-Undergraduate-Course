`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/12 10:36:39
// Design Name: 
// Module Name: clk_div_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clk_div_lpy
    #(parameter DIVISION = 100000000)
    (
    input  logic clk_100MHz_lpy,        // 100MHz
    output logic clk_sys_lpy            // 1Hz; 100MHz / DIVISION
    );
    
    logic [26:0] div_counter_lpy;
    logic clk_div_lpy;
    
    always_ff @(posedge clk_100MHz_lpy)
    begin
        if (div_counter_lpy == DIVISION / 2)
        begin
            clk_div_lpy <= ~clk_div_lpy;
            div_counter_lpy <= 0;
        end
        else
        begin
            div_counter_lpy <= div_counter_lpy + 1;
        end
    end
    
    BUFG CLK0_BUFG_INST (.I(clk_div_lpy),
                         .O(clk_sys_lpy));
endmodule
