`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/21 13:24:50
// Design Name: 
// Module Name: stringreco_ctrl_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

module stringreco_ctrl_lpy(
    input logic clk_fsm,
    input logic btnC,		//CLR Button
    input logic btnD, 		//PAUSE btnC
    input logic fsm_en_clr,
    output logic clr_bnt, en_bnt,
    output logic fsm_en, count_en
    );
    
    logic sync_clr0, sync_clr1;
    always_ff @(posedge clk_fsm)
    begin
      sync_clr0 <= btnC;
      sync_clr1 <= sync_clr0;
    end
    assign clr_bnt = btnC | sync_clr1;
    
    logic sync_en0, sync_en1, sync_en2;
    always_ff @(posedge clk_fsm)
    begin
      sync_en0 <= btnD;
      sync_en1 <= sync_en0;
      sync_en2 <= sync_en1;
    end
    assign en_bnt = sync_en2 & ~sync_en1;

    // fsm_controller
    always_ff @(posedge clk_fsm)
    begin
      if (clr_bnt) fsm_en <= 0;
      else if (en_bnt) fsm_en <= 1;
      else if (fsm_en_clr) fsm_en <= 0;
      
      // pipelining
      count_en <= fsm_en;
    end
endmodule

