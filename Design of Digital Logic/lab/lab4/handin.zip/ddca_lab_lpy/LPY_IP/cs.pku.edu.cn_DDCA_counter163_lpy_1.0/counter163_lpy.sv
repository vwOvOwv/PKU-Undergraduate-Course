`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/29 11:36:03
// Design Name: 
// Module Name: counter163_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module counter163_lpy(
    input logic EN_lpy,
    input logic D_lpy=1'b0,
    input logic C_lpy=1'b0,
    input logic B_lpy=1'b0,
    input logic A_lpy=1'b0,
    input logic LOAD_lpy,
    input logic CLK_lpy,
    input logic CLR_lpy,
    output logic ECO_lpy,
    output logic QD_lpy,
    output logic QC_lpy,
    output logic QB_lpy,
    output logic QA_lpy
    );

    logic [3:0] out_lpy = 0;
    logic [3:0] in_lpy = {D_lpy, C_lpy, B_lpy, A_lpy};
    logic ECO_lpy = 0;

    always_ff @(posedge CLK_lpy)
    begin
        if (CLR_lpy == 1)
            out_lpy <= 0;
        else if (LOAD_lpy == 1)
            out_lpy <= in_lpy;
        else if (EN_lpy == 1)
            out_lpy <= out_lpy + 1;
        else
            out_lpy <= out_lpy;
    end

    always_comb begin
        if ((EN_lpy == 1) && (out_lpy == 15))
            ECO_lpy = 1;
        else
            ECO_lpy = 0;
    end

    assign {QD_lpy, QC_lpy, QB_lpy, QA_lpy} = out_lpy;
    
endmodule