`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/12 10:51:59
// Design Name: 
// Module Name: display_7seg_x4_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module display_7seg_x4_lpy(
    input logic CLK_1KHz_lpy,
    input logic [3:0] in3_lpy, in2_lpy, in1_lpy, in0_lpy,
    output logic [0:3] an_lpy,
    output logic [0:6] seg_lpy
    );
    
    logic [1:0] sel_lpy;
    logic [3:0] seg7_dec_in_lpy;
    
    always_ff @(posedge CLK_1KHz_lpy)
    begin
        sel_lpy <= sel_lpy + 1;
    end
    
    always_comb
    begin
        case (sel_lpy)
        0: begin an_lpy = 4'b0111; seg7_dec_in_lpy = in0_lpy; end
        1: begin an_lpy = 4'b1011; seg7_dec_in_lpy = in1_lpy; end
        2: begin an_lpy = 4'b1101; seg7_dec_in_lpy = in2_lpy; end
        3: begin an_lpy = 4'b1110; seg7_dec_in_lpy = in3_lpy; end
        default: begin an_lpy = 4'b1111; seg7_dec_in_lpy = 4'bxxxx; end
        endcase
    end
    
    always_comb
    begin
        case (seg7_dec_in_lpy)
        //          ABC_DEFG
        0: seg_lpy = 7'b000_0001;
        1: seg_lpy = 7'b100_1111;
        2: seg_lpy = 7'b001_0010;
        3: seg_lpy = 7'b000_0110;
        4: seg_lpy = 7'b100_1100;
        5: seg_lpy = 7'b010_0100;
        6: seg_lpy = 7'b010_0000;
        7: seg_lpy = 7'b000_1111;
        8: seg_lpy = 7'b000_0000;
        9: seg_lpy = 7'b000_0100;
        default: seg_lpy = 7'b011_0000;
        endcase
    end
endmodule

