`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/21 13:52:04
// Design Name: 
// Module Name: stringreco_dp_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module stringreco_dp_lpy (
    input  logic clk_fsm, 
    input  logic clr_bnt, en_bnt,
    input  logic fsm_en, count_en,
    input  logic [15:0] sw,
    output logic [15:0] count
    );
    
    logic [15:0] shifter;
    
    //16-bit left-shifter
    always_ff @(posedge clk_fsm)
    begin
      if (clr_bnt) shifter <= 0;
      else if (en_bnt) shifter <= sw;
      else if (fsm_en) shifter <= {shifter[14:0], 1'b0};
    end
    
    //string recognization
    stringreco_fsm u_stringreco_fsm(
	.Clk(clk_fsm), 
	.X(shifter[15]),
	.Reset(clr_bnt), 
	.Enable(fsm_en),
	.Z(reco)
    );
    
    // 16-bit count output
    always_ff @(posedge clk_fsm)
    begin
      if (clr_bnt) count <= 0;
      else if (reco && count_en) count <= count + 1;
    end
endmodule

// Synchronous Mealy FSM
module stringreco_fsm(
	input logic Clk, Reset, Enable,
	input logic X,
	output logic Z
	);
    
    // ?????????
    typedef enum logic [2:0] {S0, S1, S2, S3, S4, S5, S6} statetype;
    statetype state, nextstate;
    logic Z_mealy;

    always_ff @(posedge Clk) begin
        if (Reset) begin
            state = S0;
            Z = 0;
        end
        else if (Enable) begin
            state = nextstate;
            Z = Z_mealy;
        end
    end

    always_comb begin
        case (state)
	    S0: begin 	
	            if (X) begin nextstate <= S2; Z_mealy <= 0; end
	            else begin nextstate <= S1; Z_mealy <= 0; end
		end
        S1: begin
                if (X) begin nextstate <= S3; Z_mealy <= 0; end
                else begin nextstate <= S1; Z_mealy <= 0; end
        end
        S2: begin
                if (X) begin nextstate <= S4; Z_mealy <= 0; end
                else begin nextstate <= S1; Z_mealy <= 0; end
        end
        S3: begin
                if (X) begin nextstate <= S4; Z_mealy <= 0; end
                else begin nextstate <= S5; Z_mealy <= 0; end
        end
        S4: begin
                if (X) begin nextstate <= S6; Z_mealy <= 0; end
                else begin nextstate <= S1; Z_mealy <= 0; end
        end
        S5: begin
                if (X) begin nextstate <= S3; Z_mealy <= 1; end
                else begin nextstate <= S1; Z_mealy <= 0; end
        end
        S6: begin
                if (X) begin nextstate <= S6; Z_mealy <= 0; end
                else begin nextstate <= S1; Z_mealy <= 1; end
        end
        default:;
        endcase
    end
endmodule
