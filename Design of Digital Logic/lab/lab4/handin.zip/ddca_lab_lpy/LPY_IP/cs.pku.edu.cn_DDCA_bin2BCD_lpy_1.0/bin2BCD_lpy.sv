`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/12 10:46:20
// Design Name: 
// Module Name: bin2BCD_lpy
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bin2BCD_lpy(
  input logic [13:0] bin_lpy,
  output logic [3:0] bcd3_lpy,
  output logic [3:0] bcd2_lpy,
  output logic [3:0] bcd1_lpy,
  output logic [3:0] bcd0_lpy 
  ); 
  
  logic [29:0] shifter_lpy; 
  integer i_lpy;
 
  always_comb
  begin 
    shifter_lpy[13:0] = bin_lpy;
    shifter_lpy[29:14] = 0; 
    
    for (i_lpy = 0; i_lpy < 14; i_lpy = i_lpy + 1) 
    begin 
      if (shifter_lpy[17:14] >= 5) 
        shifter_lpy[17:14] = shifter_lpy[17:14] + 3; 

      if (shifter_lpy[21:18] >= 5)             
        shifter_lpy[21:18] = shifter_lpy[21:18] + 3;

      if (shifter_lpy[25:22] >= 5)             
        shifter_lpy[25:22] = shifter_lpy[25:22] + 3; 

      if (shifter_lpy[29:26] >= 5)              
        shifter_lpy[29:26] = shifter_lpy[29:26] + 3; 

      shifter_lpy = shifter_lpy  << 1;    
    end  
  end

  assign  {bcd3_lpy, bcd2_lpy, bcd1_lpy, bcd0_lpy} = shifter_lpy[29:14];

endmodule
